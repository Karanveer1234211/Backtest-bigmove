"""
tl_common.py - tradelab v1.1: shared pieces (versions, paths and guards, hashing, tables, ledger, bootstrap).

tradelab reads production data READ ONLY (the cache, pick_meta's research run, the panel, the 3-minute bars)
and writes only under its own output folder (TRADELAB_OUT, e.g. C:\\QuantData\\tradelab). The guards below
refuse an output folder inside the cache or inside the production code folder.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import platform
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

VERSION = "tradelab v1.3.1"
IST = "Asia/Kolkata"
SESSION_START_MIN = 9 * 60 + 15          # 09:15 IST
COST_RT_BP_DEFAULT = 35.0                # project convention: 35 bp round trip per trade
BOOT = {"B": 2000, "block": 10, "seed": 7}  # project convention: circular blocks of 10 signal days, 2,000, seed 7


class TLError(RuntimeError):
    """A precondition or user error. The command prints it and exits with code 2; nothing is written."""


class StopRun(RuntimeError):
    """A safety stop (e.g. the plan does not reproduce the recorded trades). Exit code 3, STOPPED.txt written."""


# ----------------------------------------------------------------------
# hashing
# ----------------------------------------------------------------------
def sha256_file(p) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha16(p) -> str:
    return sha256_file(p)[:16]


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def read_hash_file(p: Path) -> Dict[str, str]:
    """outputs.sha256 -> {file name: hex}. Accepts '<hex>  <name>' or '<name>  <hex>' lines (a leading '*' on the
    name is allowed) or a JSON object {name: hex}."""
    import re
    out: Dict[str, str] = {}
    if not Path(p).exists():
        return out
    txt = Path(p).read_text(encoding="utf-8")
    try:
        js = json.loads(txt)
        if isinstance(js, dict):
            return {str(k): str(v).lower() for k, v in js.items()}
    except json.JSONDecodeError:
        pass
    hexre = re.compile(r"^[0-9a-fA-F]{12,64}$")
    for line in txt.splitlines():
        parts = line.strip().split()
        if len(parts) < 2:
            continue
        hx = [x for x in parts if hexre.match(x)]
        nm = [x for x in parts if not hexre.match(x)]
        if hx and nm:
            out[nm[-1].lstrip("*")] = hx[0].lower()
    return out


def hash_matches(recorded: Optional[str], full_hex: str) -> bool:
    """A recorded hash matches the full SHA-256 or its leading characters (a 16-character fingerprint)."""
    if not recorded:
        return False
    recorded = recorded.lower()
    return recorded == full_hex or (len(recorded) >= 12 and full_hex.startswith(recorded))


# ----------------------------------------------------------------------
# paths and guards
# ----------------------------------------------------------------------
def require_root(root_arg: Optional[str]) -> Path:
    """The cache root must be given explicitly (--root %CACHE_DAILY_ROOT%). No silent default."""
    if not root_arg:
        raise TLError("--root is required (use --root %CACHE_DAILY_ROOT% after call env_tradelab.bat)")
    root = Path(root_arg)
    if not root.is_dir():
        raise TLError(f"--root {root} is not a folder")
    return root


def _inside(child: Path, parent: Path) -> bool:
    try:
        child = child.resolve()
        parent = parent.resolve()
    except OSError:
        return False
    return child == parent or parent in child.parents


def out_base(out_arg: Optional[str], root: Optional[Path] = None) -> Path:
    """tradelab's output folder: --out, else TRADELAB_OUT. Refused inside the cache or the production code."""
    v = out_arg or os.environ.get("TRADELAB_OUT")
    if not v:
        raise TLError("no output folder: pass --out or start with env_tradelab.bat (sets TRADELAB_OUT)")
    base = Path(v)
    guards = []
    if root is not None:
        guards.append(("the cache root (--root)", Path(root)))
    for name, env in (("the cache (CACHE_DAILY_ROOT)", "CACHE_DAILY_ROOT"), ("production code (BIGMOVE_DIR)", "BIGMOVE_DIR")):
        if os.environ.get(env):
            guards.append((name, Path(os.environ[env])))
    for name, g in guards:
        if _inside(base, g):
            raise TLError(f"output folder {base} is inside {name} ({g}); tradelab never writes there")
    base.mkdir(parents=True, exist_ok=True)
    return base


def new_run_dir(base: Path, sub: str, prefix: str) -> Path:
    """<base>/<sub>/<prefix>_YYYYMMDD_NNN (NNN counts up; an existing folder is never reused)."""
    d = Path(base) / sub
    d.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d")
    n = 1
    while (d / f"{prefix}_{stamp}_{n:03d}").exists():
        n += 1
    p = d / f"{prefix}_{stamp}_{n:03d}"
    p.mkdir()
    return p


def write_outputs_sha(run_dir: Path) -> None:
    lines = []
    for p in sorted(Path(run_dir).rglob("*")):
        if p.is_file() and p.name != "outputs.sha256":
            lines.append(f"{sha256_file(p)}  {p.relative_to(run_dir).as_posix()}")
    (Path(run_dir) / "outputs.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_table(df: pd.DataFrame, path_no_ext: Path, csv: bool = True, parquet: bool = True) -> List[str]:
    """Write <name>.csv and/or <name>.parquet. Dates are written as ISO dates/timestamps."""
    out = []
    path_no_ext = Path(path_no_ext)
    if parquet:
        df.to_parquet(path_no_ext.with_suffix(".parquet"), index=False)
        out.append(path_no_ext.with_suffix(".parquet").name)
    if csv:
        df.to_csv(path_no_ext.with_suffix(".csv"), index=False, float_format="%.10g")
        out.append(path_no_ext.with_suffix(".csv").name)
    return out


def provenance(extra: Optional[dict] = None) -> dict:
    here = Path(__file__).resolve().parent
    files = {}
    for p in sorted(here.glob("tl_*.py")):
        files[p.name] = sha16(p)
    d = {"version": VERSION, "python": sys.version.split()[0], "platform": platform.platform(),
         "pandas": pd.__version__, "numpy": np.__version__, "code_sha16": files,
         "created": dt.datetime.now().isoformat(timespec="seconds")}
    try:
        import pyarrow
        d["pyarrow"] = pyarrow.__version__
    except Exception:
        pass
    if extra:
        d.update(extra)
    return d


# ----------------------------------------------------------------------
# ledger (tradelab's own; production's research_ledger.jsonl is never touched)
# ----------------------------------------------------------------------
LEDGER_NAME = "tradelab_ledger.jsonl"


def ledger_append(base: Path, rec: dict) -> None:
    rec = dict(rec)
    rec.setdefault("time", dt.datetime.now().isoformat(timespec="seconds"))
    rec.setdefault("version", VERSION)
    with open(Path(base) / LEDGER_NAME, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, default=str) + "\n")


def ledger_read(base: Path) -> List[dict]:
    p = Path(base) / LEDGER_NAME
    if not p.exists():
        return []
    out = []
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                out.append({"unreadable": line[:200]})
    return out


# ----------------------------------------------------------------------
# block bootstrap over signal days
# ----------------------------------------------------------------------
def circular_block_index(n: int, B: int, block: int, seed: int) -> np.ndarray:
    """B x n matrix of day positions drawn as circular blocks of `block` consecutive days."""
    if n <= 0:
        return np.zeros((B, 0), dtype=np.int64)
    rng = np.random.default_rng(seed)
    k = int(np.ceil(n / block))
    starts = rng.integers(0, n, size=(B, k))
    idx = (starts[:, :, None] + np.arange(block)[None, None, :]) % n
    return idx.reshape(B, k * block)[:, :n]


def bootstrap_mean_by_day(day_codes: np.ndarray, values: np.ndarray, B: int = BOOT["B"], block: int = BOOT["block"],
                          seed: int = BOOT["seed"], min_days: int = 20) -> Tuple[float, float, float, int]:
    """Mean of per-trade values with a 95% circular block bootstrap over signal days.

    day_codes: signal day of each value (any sortable labels). Days are ordered; blocks of `block` consecutive
    signal days are resampled; the statistic is sum(values in drawn days) / count(values in drawn days).
    Returns (mean, lo, hi, n_days); lo/hi are NaN with fewer than `min_days` days."""
    v = np.asarray(values, dtype=float)
    ok = np.isfinite(v)
    v = v[ok]
    d = np.asarray(day_codes)[ok]
    if len(v) == 0:
        return float("nan"), float("nan"), float("nan"), 0
    days, inv = np.unique(d, return_inverse=True)
    S = np.bincount(inv, weights=v, minlength=len(days))
    N = np.bincount(inv, minlength=len(days)).astype(float)
    mean = float(S.sum() / N.sum())
    if len(days) < min_days:
        return mean, float("nan"), float("nan"), int(len(days))
    I = circular_block_index(len(days), B, block, seed)
    num = S[I].sum(axis=1)
    den = N[I].sum(axis=1)
    stat = num / np.where(den > 0, den, np.nan)
    lo, hi = np.nanpercentile(stat, [2.5, 97.5])
    return mean, float(lo), float(hi), int(len(days))


def bootstrap_daily(values: np.ndarray, B: int = BOOT["B"], block: int = BOOT["block"], seed: int = BOOT["seed"],
                    min_days: int = 20) -> Tuple[float, float, float]:
    """Mean of a daily series with a 95% circular block bootstrap (blocks of consecutive days)."""
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    if len(v) == 0:
        return float("nan"), float("nan"), float("nan")
    m = float(v.mean())
    if len(v) < min_days:
        return m, float("nan"), float("nan")
    I = circular_block_index(len(v), B, block, seed)
    stat = v[I].mean(axis=1)
    lo, hi = np.percentile(stat, [2.5, 97.5])
    return m, float(lo), float(hi)


def fmt_bp(m: float, lo: float = float("nan"), hi: float = float("nan"), nd: int = 1) -> str:
    """'+12.3 [-4.0, +28.1]' (signs kept, interval shown when available)."""
    def f(x):
        return "n/a" if not np.isfinite(x) else f"{x:+.{nd}f}"
    if np.isfinite(lo) and np.isfinite(hi):
        return f"{f(m)} [{f(lo)}, {f(hi)}]"
    return f(m)


def verdict_from_interval(lo: float, hi: float) -> str:
    if not (np.isfinite(lo) and np.isfinite(hi)):
        return "NO INTERVAL (fewer than 20 signal days)"
    if lo > 0:
        return "BETTER (interval above 0)"
    if hi < 0:
        return "WORSE (interval below 0)"
    return "NOT SHOWN (interval spans 0)"


# ----------------------------------------------------------------------
# dates
# ----------------------------------------------------------------------
def to_day(x) -> np.ndarray:
    """Any timestamps (tz-aware -> IST) -> numpy datetime64[D] (IST calendar day)."""
    s = pd.to_datetime(pd.Series(x))
    if getattr(s.dt, "tz", None) is not None:
        s = s.dt.tz_convert(IST).dt.tz_localize(None)
    return s.to_numpy(dtype="datetime64[ns]").astype("datetime64[D]")


def parse_day(s: Optional[str]) -> Optional[np.datetime64]:
    if s is None or s == "":
        return None
    try:
        d = dt.date.fromisoformat(str(s))
    except ValueError:
        raise TLError(f"date '{s}' is not YYYY-MM-DD")
    return np.datetime64(d, "D")


def parse_ranks(s) -> List[int]:
    """'1-3' / '1,2,5' / [1,2,3] -> sorted list."""
    if isinstance(s, (list, tuple)):
        return sorted({int(x) for x in s})
    out = set()
    for part in str(s).split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            out.update(range(int(a), int(b) + 1))
        else:
            out.add(int(part))
    if not out:
        raise TLError(f"ranks '{s}' is empty")
    return sorted(out)


def say(msg: str) -> None:
    print(msg, flush=True)
