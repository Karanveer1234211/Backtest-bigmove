"""3-minute bars: the plan's entry; in sessions 2-4 after 14:30, if the price is under the VWAP and the trade is
more than 3% under water, sell everything at the next bar's open. Uses a plugin value (vol_surge) only to show
how: it is recorded in the timeline but not traded on."""
STRATEGY = {
    "name": "weak_close_exit",
    "mode": "intraday",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 5,
    "plugins": ["example_plugin.py"],
    "events": {"weak": "close < vwap and hhmm >= 1430", "surge": "vol_surge > 3"},
    "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
    "exits": [
        {"name": "weak_exit", "type": "signal", "when": "weak and upnl < -0.03", "sessions": [2, 4]},
        {"name": "time", "type": "time", "at": "close", "session": 5},
    ],
}
