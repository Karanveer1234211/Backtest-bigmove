"""3-minute bars: half at the session-1 open; the other half on a buy stop at the 15-minute opening-range high
(session 1, 09:30-13:00). Everything sells at the 5th close."""
STRATEGY = {
    "name": "orb_add_on",
    "mode": "intraday",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3]},
    "max_sessions": 5,
    "entries": [
        {"name": "open50", "size": 0.5, "at": "open", "session": 1},
        {"name": "orb50", "size": 0.5, "fill": "stop", "level": "opening_range_high(5)", "sessions": [1, 1],
         "time": ["09:30", "13:00"]},
    ],
    "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
}
