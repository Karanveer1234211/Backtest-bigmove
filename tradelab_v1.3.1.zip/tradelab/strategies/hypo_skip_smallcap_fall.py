"""A HYPOTHESIS TO TEST - not a rule to trade (tradelab v1.1 example of the market layer in a strategy).

The plan (buy the session-1 open, sell the 5th close, 35 bp) on D ranks 1-3, skipping a pick when Smallcap 250 fell
1.5% or more on the signal day - warning sign W6 of tl_research's declaration. pre_small_ret is known at the
signal-day close, before entry. A pick whose Smallcap return is unknown is KEPT ('not (x <= -0.015)' is true when x
is blank; 'x > -0.015' would skip it).

How to judge it (declared before running, never tuned afterwards):
  1. the export's research report: W6 must be a CANDIDATE in its walk-forward (chronological, by year);
  2. this backtest with a split date you write down first, reading only the 'from' part:
         python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 ^
             --strategy strategies\\hypo_skip_smallcap_fall.py --split-date 2024-01-01 ^
             --declare "PASS if the paired lower bound > 0 in the from-2024 part"
  3. even then it is a hypothesis for a declared forward paper test - it changes nothing in production.
"""
STRATEGY = {
    "name": "hypo_skip_smallcap_fall",
    "description": "the plan, skipping picks made on a day Smallcap 250 fell 1.5% or more (W6) - a hypothesis",
    "mode": "daily",
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "filter": "not (pre_small_ret <= -0.015)"},
    "max_sessions": 5,
    "entries": [{"name": "open", "size": 1.0, "at": "open", "session": 1}],
    "exits": [{"name": "time", "type": "time", "at": "close", "session": 5}],
    "costs": {"model": "flat", "round_trip_bp": 35},
    "decision_rule": {"metric": "diff_mean_bp", "pass_if": "lower > 0"},
}
