"""
tl_run.py - tradelab v1.1: one run's data and simulation (shared by export, backtest and sim).

Workspace(root, pm_run) opens production read-only, loads the picks, and simulates strategies symbol by symbol:
a symbol's 3-minute sessions are read once for all its trades and dropped afterwards (memory stays flat even
for ranks 1-10 of both engines). Panel features are read in one pass for exactly the (symbol, day) pairs the
trades visit.
"""
from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import numpy as np
import pandas as pd

from tl_common import StopRun, TLError, parse_day, parse_ranks, say
import tl_data as D
import tl_engine as E
import tl_rules as R
import tl_context as C
import tl_state as S

NIFTY_3M = "NIFTY 50"
NIFTY_INTRADAY_NAMES = {"nifty", "nifty_day_ret", "rel_nifty_day"}


class Workspace:
    def __init__(self, root: Path, pm_run: str, stage_e_any: bool = False, panel: str = "panel_oc", quiet=False):
        self.root = Path(root)
        self.pm_run = pm_run
        self.prod = D.Production(stage_e_any=stage_e_any)
        self.market = D.Market(self.root, self.prod)
        self.panel_name = panel
        self.quiet = quiet
        self._picks_all: Optional[pd.DataFrame] = None
        self.picks_info: dict = {}
        self.intraday_info: dict = {}
        self.ctx: Optional[C.Context] = None

    def log(self, msg: str) -> None:
        if not self.quiet:
            say(msg)

    # ----- picks -----
    def picks(self, engines: Sequence[str], ranks, d_from=None, d_to=None) -> pd.DataFrame:
        T, info = D.load_picks(self.root, self.pm_run, list(engines), parse_ranks(ranks),
                               parse_day(d_from) if isinstance(d_from, str) else d_from,
                               parse_day(d_to) if isinstance(d_to, str) else d_to)
        self.picks_info = info
        return T

    def pick_attrs(self, T: pd.DataFrame) -> List[str]:
        """v1's pick attributes + v1.1's market context at the pick (pick_day_*, day_before_*, size, home index, betas)
        + v1.3's stock state at the pick (pre_state_*: numeric codes, flags and measurements)."""
        return D.rule_pick_columns(T.columns) + [c for c in C.CTX_PICK_ATTRS] + [c for c in S.STATE_PICK_ATTRS]

    # ----- market context (v1.1) -----
    def context(self, mode: str = "auto", base: Optional[Path] = None, rebuild: bool = False,
                amfi_dir: Optional[Path] = None) -> Optional[C.Context]:
        if mode == "none":
            return None
        self.ctx = C.build_context(self, mode, base, rebuild=rebuild, amfi_dir=amfi_dir, log=self.log)
        return self.ctx

    def add_pick_context(self, T: pd.DataFrame, states: bool = False) -> pd.DataFrame:
        """T + the context known at each pick (columns not already in T); states=True also adds the stock state at
        each pick (tl_state, about a minute for a thousand stocks)."""
        ctx = self.market.ctx if self.market.ctx is not None else C.light_context(self.market)
        X = ctx.pick_context(T)
        add = {c: X[c].values for c in X.columns if c not in T.columns}
        if states and "pre_state" not in T.columns and "pre_state" not in add:
            self.log(f"   stock states at {len(T):,} picks ({T['symbol'].nunique():,} stocks) ...")
            XS = S.pick_states(self.market, T, log=self.log)
            add.update({c: XS[c].values for c in XS.columns if c not in T.columns and c not in add})
        # v1.3.1: all new columns joined at once (one at a time fragmented the frame: pandas PerformanceWarnings)
        return pd.concat([T, pd.DataFrame(add, index=T.index)], axis=1) if add else T.copy()

    def strategy(self, path, T: pd.DataFrame) -> E.Strategy:
        st = E.load_strategy(path, self.pick_attrs(T))
        if st.features_needed():
            st.check_features(self.market.panel(self.panel_name).allowed)
        return st

    def strategy_picks(self, st: E.Strategy) -> pd.DataFrame:
        p = st.picks
        return self.picks(p["engines"], p["ranks"], p["from"], p["to"])

    # ----- simulation -----
    def simulate(self, strats: Sequence[E.Strategy], T: pd.DataFrame, timeline_ids: Iterable[str] = (),
                 extra_3m_sessions: Optional[Tuple[int, int]] = None) -> Tuple[Dict[str, List[E.TradeResult]], dict]:
        """Run every strategy on every pick of T. Returns ({strategy name: [TradeResult in T's order]}, extras).
        extra_3m_sessions=(a, b): also return each pick's 3-minute sessions a..b (for the export's detail)."""
        t0 = time.time()
        timeline_ids = set(timeline_ids)
        used = set()
        for s in strats:
            used |= StrategyPickNames(s)
        need = (used & (set(C.CTX_PICK_ATTRS) | set(S.STATE_PICK_ATTRS))) - set(T.columns)
        if need:
            self.log(f"   market context / stock state at each pick for {sorted(need)} ...")
            T = self.add_pick_context(T, states=bool(need & set(S.STATE_PICK_ATTRS)))
        syms = sorted(T["symbol"].unique())
        self.market.load(syms)
        need_3m = any(s.mode == "intraday" or s.intrabar == "intraday" for s in strats) or extra_3m_sessions
        feats_needed = sorted({f for s in strats for f in s.features_needed()})
        feats = self._features(T, strats, feats_needed) if feats_needed else {}
        nifty3 = None
        if any(s.mode == "intraday" and (set(TradeSimNames(s)) & NIFTY_INTRADAY_NAMES) for s in strats):
            nifty3 = self._nifty3(T, strats)
        sims = {s.name: E.TradeSim(s, self.market, feats, None, nifty3) for s in strats}
        out = {s.name: [None] * len(T) for s in strats}
        extra_bars: Dict[int, Dict] = {}
        idx_by_sym = {sym: g.index.to_numpy() for sym, g in T.groupby("symbol", sort=True)}
        recs = T.to_dict("records")
        store = self.market.intraday if need_3m else None
        done = 0
        checked = False
        for si, sym in enumerate(syms):
            rows = idx_by_sym[sym]
            cache = None
            if store is not None:
                ds = self.market.series(sym)
                days = set()
                if ds is not None:
                    for i in rows:
                        sig = ds.idx(np.datetime64(recs[i]["signal_day"], "D"))
                        if sig < 0:
                            continue
                        lo, hi = 0, 0
                        for s in strats:
                            if s.mode == "intraday":
                                lo, hi = min(lo, -s.warmup), max(hi, s.required_sessions[-1])
                            elif s.intrabar == "intraday":
                                hi = max(hi, s.max_sessions)
                        if extra_3m_sessions:
                            lo, hi = min(lo, extra_3m_sessions[0]), max(hi, extra_3m_sessions[1])
                        for k in range(lo, hi + 1):
                            if 0 <= sig + k < len(ds):
                                days.add(ds.dates[sig + k])
                    cache = {sym: store.sessions(sym, days, ds)} if days else {sym: {}}
                if not checked and store.with_bars >= 200:
                    store.layout_check()
                    checked = True
            for s in strats:
                sim = sims[s.name]
                sim.intraday_cache = cache
                for i in rows:
                    out[s.name][i] = sim.run(recs[i], timeline=recs[i]["trade_id"] in timeline_ids)
            if extra_3m_sessions and cache is not None:
                for i in rows:
                    extra_bars[i] = cache.get(sym, {})
            done += len(rows)
            if not self.quiet and (si + 1) % 100 == 0:
                self.log(f"   {si + 1:,} of {len(syms):,} stocks, {done:,} picks, {time.time() - t0:,.0f} s")
        if store is not None:
            self.intraday_info = store.layout_check()
        info = {"seconds": round(time.time() - t0, 1), "symbols": len(syms), "picks": len(T),
                "features": feats_needed, "intraday": self.intraday_info, "daily_diag": self.market.diag,
                "missing_daily": self.market.missing}
        return out, {"info": info, "bars3": extra_bars}

    def _windows(self, T: pd.DataFrame, lo: int, hi: int) -> pd.DataFrame:
        """(symbol, day) for sessions lo..hi around each pick's signal day (daily positions)."""
        out = []
        for sym, g in T.groupby("symbol"):
            ds = self.market.series(sym)
            if ds is None:
                continue
            for sd in g["signal_day"]:
                sig = ds.idx(np.datetime64(sd, "D"))
                if sig < 0:
                    continue
                for k in range(lo, hi + 1):
                    if 0 <= sig + k < len(ds):
                        out.append((sym, ds.dates[sig + k]))
        W = pd.DataFrame(out, columns=["symbol", "day"]).drop_duplicates()
        W["day"] = W["day"].astype("datetime64[ns]")
        return W

    def _features(self, T: pd.DataFrame, strats, cols: List[str]) -> Dict:
        lo = min([-(s.warmup + 1) for s in strats] + [-1])
        hi = max(s.max_sessions + 1 for s in strats)
        W = self._windows(T, lo, hi)
        self.log(f"   panel features {cols} for {len(W):,} stock-days ...")
        F = self.market.panel(self.panel_name).fetch(W, cols)
        d = {}
        for row in F.itertuples(index=False):
            d[(row.symbol, np.datetime64(row.day, "D"))] = {c: getattr(row, c) for c in cols}
        return d

    def _nifty3(self, T: pd.DataFrame, strats) -> Optional[Dict]:
        store = self.market.intraday
        N = self.market.daily["NIFTY50"]
        days = set()
        for s in strats:
            if s.mode != "intraday":
                continue
            for sd in T["signal_day"]:
                i = N.idx(np.datetime64(sd, "D"))
                if i < 0:
                    continue
                for k in range(-s.warmup, s.required_sessions[-1] + 1):
                    if 0 <= i + k < len(N):
                        days.add(N.dates[i + k])
        if not store.path(NIFTY_3M).exists():
            self.log(f"   note: no 3-minute file for {NIFTY_3M}; intraday NIFTY values are NaN (rules on them never fire)")
            return None
        return store.sessions(NIFTY_3M, days, None)


def TradeSimNames(s: E.Strategy) -> Set[str]:
    return {nm for r in s.rules + list(s.event_rules.values()) for nm in r.used}


def StrategyPickNames(s: E.Strategy) -> Set[str]:
    """Every name a strategy's rules, filter, sizing expression or --values could read as a pick attribute."""
    out = {nm for r in s.rules + list(s.event_rules.values()) + ([s.filter] if s.filter else []) for nm in r.used}
    expr = (s.sizing or {}).get("expression")
    if expr:
        out |= set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", str(expr)))
    out |= set(getattr(s, "observed", []) or [])
    return out


def results_frame(results: List[E.TradeResult], T: pd.DataFrame) -> pd.DataFrame:
    rows = [r.row() for r in results]
    R_ = pd.DataFrame(rows)
    return R_


def fills_frame(results: List[E.TradeResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        for f in r.fills:
            rows.append({"trade_id": r.pick.get("trade_id"), "strategy": r.strategy, "symbol": r.pick.get("symbol"),
                         "leg": f.leg, "side": f.side, "session": f.session, "time": f.when,
                         "ts": str(pd.Timestamp(f.ts)) if f.ts is not None else "", "price": f.price, "raw": f.raw,
                         "frac": f.frac, "notional": f.notional, "basis": f.basis, "cost": f.cost, "kind": f.kind,
                         "reason": f.reason})
    return pd.DataFrame(rows)


def path_frame(results: List[E.TradeResult]) -> pd.DataFrame:
    rows = []
    for r in results:
        for p in r.path:
            rows.append({"trade_id": r.pick.get("trade_id"), "strategy": r.strategy, "engine": r.pick.get("engine"),
                         "symbol": r.pick.get("symbol"), "rank": r.pick.get("rank"), **p,
                         "mtm_net_bp": p["mtm_net"] * 1e4, "day_net_bp": p["day_net"] * 1e4})
    return pd.DataFrame(rows)
