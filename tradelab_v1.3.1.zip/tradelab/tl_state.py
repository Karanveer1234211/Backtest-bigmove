"""
tl_state.py - tradelab v1.3 (tl_state v1.1 in v1.3.1: what ends a state is worded as the rules apply it - the swing
level with its 0.25 ATR tolerance, 2 sessions in a row; every reading unchanged): the STATE of a stock on a session,
point in time (the stock-state engine).

    python tl_state.py show  --root %CACHE_DAILY_ROOT% --symbol RELIANCE [--date 2026-10-23] [--sessions 30]
    python tl_state.py rules [--out STATE_RULES.md]          every state's rules, the precedence and the settings

A stock on a session gets (only bars up to that session's close are used - never a later bar):
  PRIMARY STATE  one structural state - the dominant state the watchlist shows:
                   S01 Strong bullish continuation   S02 Emerging bullish trend   S03 Bullish consolidation
                   S06 Bullish reversal attempt      S07 Neutral range            S08 Bearish continuation
                   S09 Emerging bearish trend        S12 Unstable / disorderly
                 or UNKNOWN (no state's required conditions hold: the evidence conflicts) or INSUFFICIENT_DATA
                 (fewer than 60 sessions of bars).
  EVENT          the latest of the last 10 sessions: S04 breakout (NEW, then CONFIRMED after holding 3 sessions, or
                 STALLED), S11 failed breakout / bull trap, S10 breakdown (NEW / CONFIRMED / STALLED), failed
                 breakdown (bear trap). An event sits beside the primary state; it never replaces it.
  RISK FLAGS     S05 overextended / extreme (a risk condition, not a sell signal), stretched down, large down candle,
                 gap risk, bearish divergence candidate, price up while volume flow is down (candidate).
  NOTES          bullish divergence candidate, price down while volume flow is up (candidate), volatility compressed.
  VOLATILITY     COMPRESSED / NORMAL / ELEVATED / EXTREME - its own dimension, never read as bearish by itself.
  CONFIDENCE     HIGH / MEDIUM / LOW / UNKNOWN from evidence agreement, conflicts, persistence and data completeness.
                 Not a probability: nothing here is calibrated against outcomes.
  TRANSITIONS    previous state, the session the change began and the session it was confirmed (2 sessions in a
                 row), sessions in the state, phase (EARLY / MATURE / DETERIORATING), a pending change, the
                 invalidation levels, the last transitions.
  MEASUREMENTS   the numbers behind it: swings, EMAs in ATR units, slopes, efficiency, momentum, volatility, volume.

Every threshold is a RESEARCH DEFAULT declared 25 Oct 2026 before any real run (STATE_CFG below, recorded in every
output's metadata) - transparent, not proven. Swing points count only from the session they became knowable (a
swing high needs 3 lower bars after it, so it is known 3 sessions later; it is never back-dated). Volume-based
signs are candidates read from OHLCV, never established accumulation or distribution.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import TLError, VERSION, parse_day, require_root, say, sha256_text, to_day

STATE_VERSION = "tl_state v1.1"   # v1.1 (tradelab v1.3.1): only the wording of what ends a state; every reading
#                                 is identical to v1 (same settings, same fingerprint)

# ----- research defaults, declared 25 Oct 2026 before any real run (never tuned on results) -----
STATE_CFG: Dict[str, object] = {
    "declared": "2026-10-25",
    "min_bars": 60,              # fewer bars -> INSUFFICIENT_DATA
    "atr_n": 14,                 # Wilder ATR (true range incl. gaps)
    "ema": [20, 50, 100, 200],   # EMA100 / EMA200 only once that much history exists (else not evaluated)
    "slope20_lag": 5, "slope20_min": 0.30,    # EMA20 rising / falling: moved >= 0.30 ATR over 5 sessions
    "slope50_lag": 10, "slope50_min": 0.50,   # EMA50 rising / falling: moved >= 0.50 ATR over 10 sessions
    "swing_k": 3,                # swing high: higher than the 3 bars before, not lower than the 3 after (known +3)
    "swing_tol_atr": 0.25,       # higher / lower swing and a break of structure need 0.25 ATR or more (else 'equal')
    "eff_n": 20, "eff_trend": 0.30, "eff_flat": 0.20,   # efficiency = net move / sum of absolute daily moves
    "persist_n": 20, "persist_hi": 0.70, "persist_lo": 0.30,   # share of closes above EMA50
    "established": 15,           # structure held this many sessions = established ...
    "ctx_n": 40, "ctx_lag": 5,   # ... or the 40 sessions before the last 5 mostly in that trend:
    "ctx_est": 0.60, "ctx_cons": 0.50, "ctx_prior": 0.40,      # established / before a consolidation / 'previously'
    "cons_n": 15, "cons_range_atr": 3.5, "cons_eff": 0.30, "cons_ema50_atr": 0.50,
    "rev_min": 2, "fresh_low_n": 5, "fresh_low_window": 25,    # reversal attempt: 2+ signs, no new low in 5 sessions
    "div_rsi_pts": 5.0, "div_recent": 20,                       # divergence: RSI 5+ points the other way at the swing
    "breakout_windows": [55, 20], "hold_n": 3, "fail_n": 5, "fail_atr": 0.25, "event_show": 10,
    "ext20_atr": 3.0, "ext50_atr": 6.0, "ext10_atr": 6.0,       # S05 overextended (any one)
    "extreme20_atr": 4.5, "extreme50_atr": 9.0,                 # S05 extreme
    "stretch_dn_atr": -3.0,
    "rv_short": 10, "rv_long": 60, "rank_n": 250, "rank_min": 60,
    "vol_elev_ratio": 1.5, "vol_elev_rank": 0.85, "vol_ext_ratio": 2.2, "vol_ext_rank": 0.97,
    "vol_comp_rank": 0.20, "vol_comp_ratio": 0.80,
    "big_move_atr": 1.5, "flip_n": 20, "gap_atr": 1.0, "gap_n": 10, "gap_risk": 2, "down_atr": 2.0, "down_n": 5,
    "disorder_ratio": 1.8, "disorder_rank": 0.95, "disorder_flips": 3, "disorder_gaps": 4, "disorder_eff": 0.25,
    "range20_atr": 8.0,
    "rvol_n": 50, "rvol_min": 20, "flow_n": 20, "flow_min": 0.10, "pv_ret": 0.05, "dry_ratio": 0.90,
    "decel_atr": -1.5, "accel_atr": 1.5, "below20_atr": -1.0, "above20_atr": 1.0,
    "confirm_n": 2,              # a new primary state is confirmed after 2 sessions in a row off the old one
    "early_n": 5,                # EARLY = the first 5 sessions of a state
    "weak_support": 0.50, "conflicts_low": 2,
    "high_support": 0.75, "high_age": 3, "complete_high": 0.90, "complete_low": 0.70,
    "history_keep": 6,
}

STATE_NAMES = {
    "S01": "Strong bullish continuation", "S02": "Emerging bullish trend", "S03": "Bullish consolidation",
    "S04": "Bullish breakout", "S05": "Bullish exhaustion / overextension", "S06": "Bullish reversal attempt",
    "S07": "Neutral range", "S08": "Bearish continuation", "S09": "Emerging bearish trend", "S10": "Bearish breakdown",
    "S11": "Failed breakout / bull trap", "S12": "Unstable / disorderly",
    "UNKNOWN": "Unknown - evidence conflicts", "INSUFFICIENT_DATA": "Insufficient data"}
SHORT = {"S01": "Strong bull", "S02": "Emerging bull", "S03": "Bull consolidation", "S06": "Reversal attempt",
         "S07": "Neutral range", "S08": "Bear continuation", "S09": "Emerging bear", "S12": "Unstable",
         "UNKNOWN": "Unknown", "INSUFFICIENT_DATA": "Too little data"}
PRIMARY = ("S01", "S02", "S03", "S06", "S07", "S08", "S09", "S12")
PRECEDENCE = ("S12", "S03", "S01", "S02", "S06", "S08", "S09", "S07")   # the first state whose required conditions hold
STATE_NUM = {"INSUFFICIENT_DATA": -1, "UNKNOWN": 0, "S01": 1, "S02": 2, "S03": 3, "S06": 6, "S07": 7, "S08": 8,
             "S09": 9, "S12": 12}
SIDE = {"S01": "bull", "S02": "bull", "S03": "bull", "S06": "turn", "S07": "flat", "S08": "bear", "S09": "bear",
        "S12": "wild", "UNKNOWN": "none", "INSUFFICIENT_DATA": "none"}
CONF_NUM = {"HIGH": 3, "MEDIUM": 2, "LOW": 1, "UNKNOWN": 0}
PHASE_NUM = {"EARLY": 1, "MATURE": 2, "DETERIORATING": 3}
EVENT_NAMES = {"BREAKOUT": ("S04", "breakout"), "FAILED_BREAKOUT": ("S11", "failed breakout (bull trap)"),
               "BREAKDOWN": ("S10", "breakdown"), "FAILED_BREAKDOWN": ("", "failed breakdown (bear trap)")}
EVENT_NUM = {"": 0, "BREAKOUT:NEW": 1, "BREAKOUT:CONFIRMED": 2, "BREAKOUT:STALLED": 3, "FAILED_BREAKOUT:FAILED": 4,
             "BREAKDOWN:NEW": 5, "BREAKDOWN:CONFIRMED": 6, "BREAKDOWN:STALLED": 7, "FAILED_BREAKDOWN:FAILED": 8}
RISK_TEXT = {"S05_EXTREME": "S05 extremely overextended", "S05_OVEREXTENDED": "S05 overextended",
             "STRETCHED_DOWN": "stretched far below EMA20", "BIG_DOWN_CANDLE": "large down candle in the last 5 sessions",
             "GAP_RISK": "repeated large gaps", "BEAR_DIVERGENCE": "bearish divergence candidate (RSI)",
             "PRICE_UP_FLOW_DOWN": "price up, volume flow down (candidate)"}
NOTE_TEXT = {"BULL_DIVERGENCE": "bullish divergence candidate (RSI)",
             "PRICE_DOWN_FLOW_UP": "price down, volume flow up (candidate)", "VOL_COMPRESSED": "volatility compressed"}


def cfg_with(over: Optional[dict] = None) -> dict:
    c = dict(STATE_CFG)
    for k, v in (over or {}).items():
        if k not in STATE_CFG:
            raise TLError(f"unknown state setting '{k}' (settings: {', '.join(sorted(STATE_CFG))})")
        c[k] = v
    return c


def cfg_hash(cfg: dict) -> str:
    return sha256_text(json.dumps(cfg, sort_keys=True, default=str))[:16]


# ======================================================================
# the conditions (one sentence each; also the documentation)
# ======================================================================
def cond_text(cfg: dict) -> Dict[str, str]:
    c = cfg
    return {
        "bull_struct": f"higher highs and higher lows (the last two confirmed swing highs and lows both rising by "
                       f"{c['swing_tol_atr']}+ ATR)",
        "bear_struct": f"lower highs and lower lows (the last two confirmed swing highs and lows both falling by "
                       f"{c['swing_tol_atr']}+ ATR)",
        "no_bear_struct": "not a lower-high / lower-low structure",
        "hh": f"last confirmed swing high {c['swing_tol_atr']}+ ATR above the one before",
        "hl": f"last confirmed swing low {c['swing_tol_atr']}+ ATR above the one before",
        "lh": f"last confirmed swing high {c['swing_tol_atr']}+ ATR below the one before",
        "ll": f"last confirmed swing low {c['swing_tol_atr']}+ ATR below the one before",
        "above_last_low": f"close not more than {c['swing_tol_atr']} ATR below the last confirmed swing low (bullish "
                          f"structure intact)",
        "below_last_high": f"close not more than {c['swing_tol_atr']} ATR above the last confirmed swing high "
                           f"(bearish structure intact)",
        "bos_up": f"close {c['swing_tol_atr']}+ ATR above the last confirmed swing high (structure broken upward)",
        "bos_dn": f"close {c['swing_tol_atr']}+ ATR below the last confirmed swing low (structure broken downward)",
        "bull_early": "bullish structure forming: higher highs and lows intact, or a higher low then a close above "
                      "the last swing high",
        "bear_early": "bearish structure forming: lower highs and lows intact, or a close below the last swing low "
                      "with a lower high or below EMA50",
        "bull_est": f"bullish structure established: held {c['established']}+ sessions, or above a rising EMA50 on "
                    f"{c['ctx_est']:.0%}+ of the {c['ctx_n']} sessions before the last {c['ctx_lag']} (judged on the "
                    f"{c['established']} sessions alone while that context is not yet available)",
        "bull_not_est": "bullish structure not yet established (see S01)",
        "bear_est": f"bearish structure established: held {c['established']}+ sessions, or below a falling EMA50 on "
                    f"{c['ctx_est']:.0%}+ of the {c['ctx_n']} sessions before the last {c['ctx_lag']} (judged on the "
                    f"{c['established']} sessions alone while that context is not yet available)",
        "bear_not_est": "bearish structure not yet established (see S08)",
        "prior_bull": f"previously bullish: above a rising EMA50 on {c['ctx_cons']:.0%}+ of the {c['ctx_n']} sessions "
                      f"before the last {c['ctx_lag']}",
        "prior_bear": f"previously bearish: below a falling EMA50 on {c['ctx_prior']:.0%}+ of the {c['ctx_n']} "
                      f"sessions before the last {c['ctx_lag']}",
        "above20": "close above EMA20", "below20": "close below EMA20",
        "above50": "close above EMA50", "below50": "close below EMA50",
        "near50": f"close no more than {c['cons_ema50_atr']} ATR below EMA50",
        "above200": "close above EMA200 (needs 200 sessions)", "below200": "close below EMA200 (needs 200 sessions)",
        "rise20": f"EMA20 rising ({c['slope20_min']}+ ATR over {c['slope20_lag']} sessions)",
        "fall20": f"EMA20 falling ({c['slope20_min']}+ ATR over {c['slope20_lag']} sessions)",
        "flat20": f"EMA20 flat (less than {c['slope20_min']} ATR over {c['slope20_lag']} sessions)",
        "rise50": f"EMA50 rising ({c['slope50_min']}+ ATR over {c['slope50_lag']} sessions)",
        "fall50": f"EMA50 falling ({c['slope50_min']}+ ATR over {c['slope50_lag']} sessions)",
        "flat50": f"EMA50 flat (less than {c['slope50_min']} ATR over {c['slope50_lag']} sessions)",
        "ema50_up": f"EMA50 higher than {c['slope50_lag']} sessions ago", "ema50_dn": f"EMA50 lower than {c['slope50_lag']} sessions ago",
        "align_bull": "averages stacked upward (close > EMA20 > EMA50, and > EMA100 > EMA200 where known)",
        "align_bear": "averages stacked downward (close < EMA20 < EMA50, and < EMA100 < EMA200 where known)",
        "eff_up": f"efficient rise ({c['eff_n']}-session efficiency +{c['eff_trend']} or more)",
        "eff_dn": f"efficient fall ({c['eff_n']}-session efficiency -{c['eff_trend']} or less)",
        "eff_flat": f"no direction ({c['eff_n']}-session efficiency between -{c['eff_flat']} and +{c['eff_flat']})",
        "persist_up": f"above EMA50 on {c['persist_hi']:.0%}+ of the last {c['persist_n']} sessions",
        "persist_dn": f"above EMA50 on {c['persist_lo']:.0%} or less of the last {c['persist_n']} sessions",
        "persist_mid": f"above EMA50 on {c['persist_lo']:.0%}-{c['persist_hi']:.0%} of the last {c['persist_n']} sessions",
        "mom_up": "20-session return above 0 and RSI 14 at 50 or more", "mom_dn": "20-session return below 0 and RSI 14 below 50",
        "macd_up": "MACD histogram above 0", "macd_dn": "MACD histogram below 0",
        "r60_up": "60-session return above 0", "r60_dn": "60-session return below 0",
        "rsi_up50": "RSI 14 at 50 or more", "rsi_mid": "RSI 14 between 40 and 60", "rsi_cons": "RSI 14 between 45 and 65",
        "decel": f"momentum decelerating (10-session move {abs(c['decel_atr'])}+ ATR smaller than the 10 before)",
        "accel": f"momentum accelerating (10-session move {c['accel_atr']}+ ATR larger than the 10 before)",
        "deep_below20": f"close {abs(c['below20_atr'])}+ ATR below EMA20",
        "well_above20": f"close {c['above20_atr']}+ ATR above EMA20",
        "above20_turning": "close above EMA20 and EMA20 turning up",
        "bear_div": f"bearish divergence candidate: a higher swing high with RSI {c['div_rsi_pts']:.0f}+ points lower "
                    f"(swing known in the last {c['div_recent']} sessions)",
        "bull_div": f"bullish divergence candidate: a lower swing low with RSI {c['div_rsi_pts']:.0f}+ points higher "
                    f"(swing known in the last {c['div_recent']} sessions)",
        "fresh_low": f"made the lowest low of {c['fresh_low_window']} sessions within the last {c['fresh_low_n']}",
        "no_fresh_low": f"no new {c['fresh_low_window']}-session low in the last {c['fresh_low_n']} sessions",
        "rev2": f"at least {c['rev_min']} reversal signs: higher low, close above the last swing high, bullish "
                f"divergence, close above a turning EMA20, RSI 50+, volume flow up",
        "contained": f"contained range: the last {c['cons_n']} sessions span {c['cons_range_atr']} ATR or less with "
                       f"efficiency under {c['cons_eff']}",
        "range20_ok": f"20-session range {c['range20_atr']} ATR or less",
        "vol_comp": "volatility compressed (ATR% in the lowest fifth of its year and short vol below long)",
        "vol_elev": "volatility elevated or extreme", "vol_not_elev": "volatility not elevated",
        "vol_extreme": "volatility extreme", "big_down": f"a {c['down_atr']}+ ATR down candle in the last {c['down_n']} sessions",
        "gap_risk": f"{c['gap_risk']}+ gaps of {c['gap_atr']}+ ATR in the last {c['gap_n']} sessions",
        "disorder": f"disorderly: 10-session vol {c['disorder_ratio']}x+ the 60-session or ATR% at its "
                    f"{c['disorder_rank']:.0%} rank, AND {c['disorder_flips']}+ reversals of large moves in "
                    f"{c['flip_n']} sessions or {c['disorder_gaps']}+ large gaps in {c['gap_n']}, AND efficiency under "
                    f"{c['disorder_eff']}",
        "no_struct": "neither higher-high/higher-low nor lower-high/lower-low structure",
        "flow_up": f"volume flow up (signed volume share +{c['flow_min']} or more over {c['flow_n']} sessions)",
        "flow_dn": f"volume flow down (signed volume share -{c['flow_min']} or less over {c['flow_n']} sessions)",
        "vol_drying": f"volume drying up (10-session median below {c['dry_ratio']}x the 50-session)",
        "pv_up_flow_dn": f"price up {c['pv_ret']:.0%}+ over 20 sessions while volume flow is down (candidate)",
        "pv_dn_flow_up": f"price down {c['pv_ret']:.0%}+ over 20 sessions while volume flow is up (candidate)",
    }


# each primary state: kind, required (all must hold), supporting, conflicting, typical transitions (what ends
# each one: inval_text / StateSeries.invalidation)
STATES: Dict[str, dict] = {
    "S12": {"kind": "persistent state (usually short-lived)", "required": ["disorder"],
            "supporting": ["vol_extreme", "gap_risk", "big_down", "eff_flat"],
            "conflicting": ["bull_struct", "bear_struct"],
            "from": "any state", "to": "S07, UNKNOWN or a new trend once volatility calms"},
    "S03": {"kind": "persistent state", "required": ["prior_bull", "contained", "above_last_low", "near50", "no_bear_struct"],
            "supporting": ["hl", "above50", "ema50_up", "vol_comp", "vol_drying", "rsi_cons", "persist_up"],
            "conflicting": ["big_down", "flow_dn", "bear_div", "fall20"],
            "from": "S01, S02", "to": "S01 with an S04 breakout, or S09 / S10 if the floor breaks"},
    "S01": {"kind": "persistent state", "required": ["bull_struct", "above_last_low", "above50", "ema50_up", "bull_est"],
            "supporting": ["rise20", "rise50", "align_bull", "eff_up", "mom_up", "macd_up", "persist_up", "r60_up",
                           "above200", "flow_up"],
            "conflicting": ["bear_div", "pv_up_flow_dn", "decel", "deep_below20", "big_down"],
            "from": "S02, S03 (after a breakout)", "to": "S03, S05 risk, S09"},
    "S02": {"kind": "persistent state (early phase of a trend)", "required": ["bull_early", "above50", "bull_not_est"],
            "supporting": ["rise20", "above20", "eff_up", "mom_up", "macd_up", "hl", "bos_up", "flow_up", "ema50_up"],
            "conflicting": ["bear_div", "big_down", "fall50"],
            "from": "S06, S07, S08, S09", "to": "S01 (matures), S03, or back to S07 / S09"},
    "S06": {"kind": "persistent state (an attempt, not yet a trend)", "required": ["prior_bear", "rev2", "no_fresh_low"],
            "supporting": ["hl", "bos_up", "bull_div", "above20_turning", "rsi_up50", "flow_up", "pv_dn_flow_up"],
            "conflicting": ["fall20", "big_down", "flow_dn"],
            "from": "S08, S09", "to": "S02 (confirmed bullish), or back to S08"},
    "S08": {"kind": "persistent state", "required": ["bear_struct", "below_last_high", "below50", "ema50_dn", "bear_est"],
            "supporting": ["fall20", "fall50", "align_bear", "eff_dn", "mom_dn", "macd_dn", "persist_dn", "r60_dn",
                           "below200", "flow_dn"],
            "conflicting": ["bull_div", "pv_dn_flow_up", "accel", "well_above20"],
            "from": "S09", "to": "S06, S07"},
    "S09": {"kind": "persistent state (early phase of a decline)", "required": ["bear_early", "bear_not_est", "weak_trend"],
            "supporting": ["fall20", "below20", "eff_dn", "mom_dn", "macd_dn", "lh", "bos_dn", "flow_dn", "big_down",
                           "ema50_dn"],
            "conflicting": ["bull_div", "accel", "rise50"],
            "from": "S01, S02, S03, S07", "to": "S08 (matures), S06, or back to S07 / S02"},
    "S07": {"kind": "persistent state", "required": ["eff_flat", "flat50"],
            "supporting": ["flat20", "no_struct", "rsi_mid", "range20_ok", "persist_mid", "vol_not_elev"],
            "conflicting": ["bull_struct", "bear_struct", "vol_elev", "gap_risk"],
            "from": "any trend losing direction", "to": "S02 / S09 on a break of the range, S03"},
}
EXTRA_TEXT = {"weak_trend": "close below EMA50 or EMA20 falling"}


def inval_text(cfg: dict) -> Dict[str, str]:
    """What ends each primary state, in words, from the settings (v1.3.1: the swing levels carry the tolerance the
    rules use, and the 2-session confirmation is stated; the levels with prices are in StateSeries.invalidation)."""
    c = cfg
    n2, t = f"{c['confirm_n']} sessions in a row", c["swing_tol_atr"]
    return {
        "S01": f"{n2} closing below the last higher low less {t} ATR, or at / below EMA50 (also the higher-high / "
               f"higher-low structure or the rising EMA50 failing)",
        "S02": f"{n2} closing below the last swing low less {t} ATR, or at / below EMA50; it becomes S01 once the "
               f"structure is established",
        "S03": f"{n2} closing below the last swing low less {t} ATR, or below EMA50 less {c['cons_ema50_atr']} ATR "
               f"(downward); the {c['cons_n']}-session range widening past {c['cons_range_atr']} ATR or a directional "
               f"run (efficiency {c['cons_eff']}+) ends it either way - upward with an S04 breakout",
        "S06": f"a new {c['fresh_low_window']}-session low (any low below the lowest low of the last "
               f"{c['fresh_low_window']} sessions), or fewer than {c['rev_min']} reversal signs",
        "S07": f"a direction emerging: {c['eff_n']}-session efficiency beyond -{c['eff_flat']} / +{c['eff_flat']}, "
               f"or EMA50 moving {c['slope50_min']}+ ATR in {c['slope50_lag']} sessions (a move out of the 20-session "
               f"range usually starts it)",
        "S08": f"{n2} closing above the last lower high plus {t} ATR, or at / above EMA50 (also the lower-high / "
               f"lower-low structure or the falling EMA50 failing)",
        "S09": f"{n2} closing above the last swing high plus {t} ATR, or at / above EMA50 once EMA20 stops falling; "
               f"it becomes S08 once the structure is established",
        "S12": f"volatility calming (10-session vol under {c['disorder_ratio']}x the 60-session and ATR% under its "
               f"{c['disorder_rank']:.0%} rank), the large reversals and gaps stopping (under {c['disorder_flips']} in "
               f"{c['flip_n']} sessions and under {c['disorder_gaps']} gaps in {c['gap_n']}), or a direction emerging "
               f"(efficiency {c['disorder_eff']}+)",
    }
EVENT_RULES = {
    "S04": "BREAKOUT - the close crosses above the highest high of the previous 55 sessions (else 20). NEW on that "
           "session; CONFIRMED when every close of the next 3 sessions stays at or above that level; STALLED when "
           "neither confirmed nor failed within 5 sessions. Temporary event (shown for 10 sessions).",
    "S11": "FAILED BREAKOUT / BULL TRAP - within 5 sessions of a breakout (even a confirmed one) a close falls more "
           "than 0.25 ATR below the breakout level. Temporary event (shown for 10 sessions).",
    "S10": "BREAKDOWN - the close crosses below the lowest low of the previous 55 sessions (else 20); NEW / CONFIRMED "
           "(3 sessions held below) / STALLED as for S04. Temporary event.",
    "bear trap": "FAILED BREAKDOWN - within 5 sessions of a breakdown a close rises more than 0.25 ATR above the level.",
    "S05": "OVEREXTENDED (risk flag, not a sell signal) - close 3.0+ ATR above EMA20, or 6.0+ ATR above EMA50, or a "
           "6.0+ ATR rise in 10 sessions; EXTREME at 4.5 / 9.0 ATR. Shown beside any primary state.",
}


# ======================================================================
# arithmetic (all trailing: a value at t uses bars up to t only)
# ======================================================================
def _ewm_seeded(x: np.ndarray, n: int, alpha: float) -> np.ndarray:
    """Recursive average y_t = y_{t-1} + alpha (x_t - y_{t-1}) seeded with the simple mean of the first n values
    (from the first finite one). EMA: alpha = 2 / (n + 1); Wilder: alpha = 1 / n."""
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    ok = np.isfinite(x)
    if not ok.any():
        return out
    f = int(np.argmax(ok))
    if len(x) - f < n:
        return out
    y = x[f:].copy()
    seed = float(np.mean(y[:n]))
    y[:n - 1] = np.nan
    y[n - 1] = seed
    s = np.array(pd.Series(y).ewm(alpha=alpha, adjust=False).mean().to_numpy(float), dtype=float)   # writable copy
    s[:n - 1] = np.nan
    out[f:] = s
    return out


def rolling_rank(x: np.ndarray, window: int, minp: int) -> np.ndarray:
    """Share of the last `window` values (today included) at or below today's value (= tl_context.rolling_pct_rank)."""
    x = np.asarray(x, float)
    n = len(x)
    out = np.full(n, np.nan)
    if n == 0:
        return out
    pad = np.concatenate([np.full(window - 1, np.nan), x])
    W = np.lib.stride_tricks.sliding_window_view(pad, window)
    fin_ = np.isfinite(W)
    cnt = fin_.sum(axis=1)
    with np.errstate(invalid="ignore"):
        le = (np.where(fin_, W, np.inf) <= x[:, None]).sum(axis=1)
    ok = np.isfinite(x) & (cnt >= minp)
    out[ok] = le[ok] / cnt[ok]
    return out


def _f(b, valid) -> np.ndarray:
    """A condition as 1.0 / 0.0, NaN where it cannot be evaluated."""
    return np.where(np.asarray(valid, bool), np.asarray(b, bool).astype(float), np.nan)


def _and(*xs) -> np.ndarray:
    """1 when every input is 1; 0 when any is 0; NaN otherwise (something missing, nothing failed)."""
    X = np.vstack([np.asarray(x, float) for x in xs])
    out = np.where(np.all(X == 1, axis=0), 1.0, np.nan)
    out[np.any(X == 0, axis=0)] = 0.0
    return out


def _or(*xs) -> np.ndarray:
    X = np.vstack([np.asarray(x, float) for x in xs])
    out = np.where(np.all(X == 0, axis=0), 0.0, np.nan)
    out[np.any(X == 1, axis=0)] = 1.0
    return out


def _not(x) -> np.ndarray:
    x = np.asarray(x, float)
    return np.where(np.isfinite(x), 1.0 - x, np.nan)


def _run_length(b: np.ndarray) -> np.ndarray:
    """Sessions in a row the condition has held up to and including t (0 when it does not hold)."""
    b = np.asarray(b == 1)
    out = np.zeros(len(b), np.int64)
    run = 0
    for i, v in enumerate(b):
        run = run + 1 if v else 0
        out[i] = run
    return out


def _ffill_at(n: int, at: np.ndarray, values: np.ndarray) -> np.ndarray:
    a = np.full(n, np.nan)
    a[at] = values
    return pd.Series(a).ffill().to_numpy(float)


# ======================================================================
# one stock's state series
# ======================================================================
class StateSeries:
    """Every session of one stock: measurements, conditions, raw and confirmed state, events, flags, confidence."""

    def __init__(self, sym: str, dates, o, h, l, c, v=None, cfg: Optional[dict] = None):
        self.sym = sym
        self.cfg = cfg_with(cfg)
        self.dates = np.asarray(dates).astype("datetime64[D]")
        self.o, self.h, self.l, self.c = (np.asarray(x, float) for x in (o, h, l, c))
        self.v = np.asarray(v, float) if v is not None and len(np.asarray(v)) == len(self.c) else np.full(len(self.c), np.nan)
        self.n = len(self.c)
        self.A: Dict[str, np.ndarray] = {}
        self.C: Dict[str, np.ndarray] = {}
        self._pos = {d: i for i, d in enumerate(self.dates.tolist())}
        self._measure()
        self._conditions()
        self._classify()
        self._machine()
        self._events()
        self._flags()

    # ------------------------------------------------------------------
    def idx(self, day) -> int:
        return self._pos.get(np.datetime64(day, "D").item(), -1) if day is not None else -1

    def idx_on_or_before(self, day) -> int:
        return int(np.searchsorted(self.dates, np.datetime64(day, "D"), side="right")) - 1

    # ------------------------------------------------------------------
    def _measure(self) -> None:
        g, n = self.cfg, self.n
        o, h, l, c, v = self.o, self.h, self.l, self.c, self.v
        A = self.A
        cp = np.r_[np.nan, c[:-1]]
        tr = np.maximum.reduce([h - l, np.abs(h - cp), np.abs(l - cp)])
        tr[0] = np.nan
        atr = _ewm_seeded(tr, g["atr_n"], 1.0 / g["atr_n"])
        atr = np.where(atr > 0, atr, np.nan)
        A["atr"], A["atr_pct"] = atr, atr / c
        atr_prev = np.r_[np.nan, atr[:-1]]
        for k in g["ema"]:
            A[f"ema{k}"] = _ewm_seeded(c, k, 2.0 / (k + 1))
        with np.errstate(divide="ignore", invalid="ignore"):
            for k in g["ema"]:
                A[f"d{k}"] = (c - A[f"ema{k}"]) / atr
            e20, e50 = A["ema20"], A["ema50"]
            A["s20"] = (e20 - pd.Series(e20).shift(g["slope20_lag"]).to_numpy(float)) / atr
            A["s50"] = (e50 - pd.Series(e50).shift(g["slope50_lag"]).to_numpy(float)) / atr
            cs = pd.Series(c)
            dc = np.abs(cs.diff())
            for m, nm in ((g["eff_n"], "eff20"), (g["cons_n"], "eff_cons")):
                den = dc.rolling(m, min_periods=m).sum().to_numpy(float)
                A[nm] = np.where(den > 0, (c - cs.shift(m).to_numpy(float)) / den, np.nan)
            ab = pd.Series(np.where(np.isfinite(e50), (c > e50).astype(float), np.nan))
            A["share50"] = ab.rolling(g["persist_n"], min_periods=g["persist_n"]).mean().to_numpy(float)
            for m in (5, 10, 20, 60):
                A[f"r{m}"] = c / cs.shift(m).to_numpy(float) - 1
            m10 = (c - cs.shift(10).to_numpy(float)) / atr
            A["m10"] = m10
            A["acc"] = m10 - pd.Series(m10).shift(10).to_numpy(float)
            # RSI 14 (Wilder)
            d = np.r_[np.nan, np.diff(c)]
            ag = _ewm_seeded(np.where(np.isfinite(d), np.maximum(d, 0), np.nan), 14, 1 / 14)
            al = _ewm_seeded(np.where(np.isfinite(d), np.maximum(-d, 0), np.nan), 14, 1 / 14)
            rsi = np.where(al > 0, 100 - 100 / (1 + ag / np.where(al > 0, al, 1)), np.where(ag > 0, 100.0, 50.0))
            A["rsi14"] = np.where(np.isfinite(ag) & np.isfinite(al), rsi, np.nan)
            macd = _ewm_seeded(c, 12, 2 / 13) - _ewm_seeded(c, 26, 2 / 27)
            sig = _ewm_seeded(macd, 9, 0.2)
            A["macd_h"] = (macd - sig) / atr
            lr = pd.Series(np.log(c / cp))
            rvs = lr.rolling(g["rv_short"], min_periods=g["rv_short"]).std().to_numpy(float) * np.sqrt(252)
            rvl = lr.rolling(g["rv_long"], min_periods=int(g["rv_long"] * 2 // 3)).std().to_numpy(float) * np.sqrt(252)
            A["rv10"], A["rv60"] = rvs, rvl
            A["vol_ratio"] = np.where(rvl > 0, rvs / rvl, np.nan)
            A["atr_rank"] = rolling_rank(A["atr_pct"], g["rank_n"], g["rank_min"])
            # ranges: the previous N sessions (today excluded) for breakouts; the last N (today included) for width
            hs, ls = pd.Series(h), pd.Series(l)
            for w in sorted(set(g["breakout_windows"]) | {20}):
                A[f"hi{w}"] = hs.rolling(w, min_periods=w).max().shift(1).to_numpy(float)
                A[f"lo{w}"] = ls.rolling(w, min_periods=w).min().shift(1).to_numpy(float)
            A["pos20"] = np.where(A["hi20"] > A["lo20"], (c - A["lo20"]) / (A["hi20"] - A["lo20"]), np.nan)
            cn = g["cons_n"]
            A["cons_top"] = hs.rolling(cn, min_periods=cn).max().to_numpy(float)
            A["cons_floor"] = ls.rolling(cn, min_periods=cn).min().to_numpy(float)
            A["rng_cons"] = (A["cons_top"] - A["cons_floor"]) / atr
            A["rng20"] = (hs.rolling(20, min_periods=20).max().to_numpy(float)
                          - ls.rolling(20, min_periods=20).min().to_numpy(float)) / atr
            # gaps, large moves, reversals of large moves, large down candles (in ATR of the session before)
            gap = (o - cp) / atr_prev
            mv = (c - cp) / atr_prev
            A["gap_atr"], A["move_atr"] = gap, mv
            big_gap = np.abs(gap) >= g["gap_atr"]
            A["gaps10"] = pd.Series(np.where(np.isfinite(gap), big_gap, np.nan)).rolling(g["gap_n"], min_periods=g["gap_n"]).sum().to_numpy(float)
            big = np.isfinite(mv) & (np.abs(mv) >= g["big_move_atr"])
            sg = np.where(big, np.sign(mv), np.nan)
            last = pd.Series(sg).ffill().shift(1).to_numpy(float)
            flip = big & np.isfinite(last) & (np.sign(mv) != last)
            A["flips20"] = pd.Series(np.where(np.isfinite(mv), flip, np.nan)).rolling(g["flip_n"], min_periods=g["flip_n"]).sum().to_numpy(float)
            down = ((mv <= -g["down_atr"]) | ((o - c) / atr_prev >= g["down_atr"])) & np.isfinite(mv)
            A["downs5"] = pd.Series(np.where(np.isfinite(mv), down, np.nan)).rolling(g["down_n"], min_periods=1).sum().to_numpy(float)
            # volume (NaN when missing; zero-volume medians give NaN)
            vs = pd.Series(np.where(v > 0, v, np.nan) if np.isfinite(v).any() else v)
            med_prev = vs.shift(1).rolling(g["rvol_n"], min_periods=g["rvol_min"]).median().to_numpy(float)
            A["rvol"] = np.where(med_prev > 0, v / med_prev, np.nan)
            m10v = vs.rolling(10, min_periods=10).median().to_numpy(float)
            m50v = vs.rolling(50, min_periods=30).median().to_numpy(float)
            A["vtrend"] = np.where(m50v > 0, m10v / m50v, np.nan)
            inc = pd.Series(np.sign(c - cp) * v)
            den = pd.Series(v).rolling(g["flow_n"], min_periods=g["flow_n"]).sum().to_numpy(float)
            A["flow20"] = np.where(den > 0, inc.rolling(g["flow_n"], min_periods=g["flow_n"]).sum().to_numpy(float) / den, np.nan)
        self._swings()

    def _swings(self) -> None:
        """Confirmed swing highs / lows. A swing at bar p needs k bars on each side, so it is KNOWN at p + k: before
        that session nothing about it is used (never back-dated)."""
        k, n, h, l = int(self.cfg["swing_k"]), self.n, self.h, self.l
        A = self.A
        hs, ls = pd.Series(h), pd.Series(l)
        left_h, right_h = hs.rolling(k, min_periods=k).max().shift(1).to_numpy(float), hs.rolling(k, min_periods=k).max().shift(-k).to_numpy(float)
        left_l, right_l = ls.rolling(k, min_periods=k).min().shift(1).to_numpy(float), ls.rolling(k, min_periods=k).min().shift(-k).to_numpy(float)
        with np.errstate(invalid="ignore"):
            ph = np.flatnonzero(np.isfinite(left_h) & np.isfinite(right_h) & (h > left_h) & (h >= right_h))
            pl = np.flatnonzero(np.isfinite(left_l) & np.isfinite(right_l) & (l < left_l) & (l <= right_l))
        self.piv_hi, self.piv_lo = ph, pl
        rsi = A["rsi14"]
        for nm, P, price in (("hi", ph, h), ("lo", pl, l)):
            kn = P + k
            A[f"last_{nm}"] = _ffill_at(n, kn, price[P])
            A[f"last_{nm}_i"] = _ffill_at(n, kn, P.astype(float))
            A[f"last_{nm}_known"] = _ffill_at(n, kn, kn.astype(float))
            A[f"last_{nm}_rsi"] = _ffill_at(n, kn, rsi[P])
            if len(P) > 1:
                A[f"prev_{nm}"] = _ffill_at(n, kn[1:], price[P[:-1]])
                A[f"prev_{nm}_i"] = _ffill_at(n, kn[1:], P[:-1].astype(float))
                A[f"prev_{nm}_rsi"] = _ffill_at(n, kn[1:], rsi[P[:-1]])
            else:
                for s in ("", "_i", "_rsi"):
                    A[f"prev_{nm}{s}"] = np.full(n, np.nan)

    # ------------------------------------------------------------------
    def _conditions(self) -> None:
        g, A, c, n = self.cfg, self.A, self.c, self.n
        C = self.C
        fin = np.isfinite
        e20, e50, e100, e200 = A["ema20"], A["ema50"], A["ema100"], A["ema200"]
        lh_, ph_, ll_, pl_ = A["last_hi"], A["prev_hi"], A["last_lo"], A["prev_lo"]
        tol = g["swing_tol_atr"] * A["atr"]
        two = fin(lh_) & fin(ph_) & fin(ll_) & fin(pl_) & fin(tol)
        vh, vl = fin(lh_) & fin(ph_) & fin(tol), fin(ll_) & fin(pl_) & fin(tol)
        with np.errstate(invalid="ignore"):
            hh, lh = lh_ > ph_ + tol, lh_ < ph_ - tol
            hl, ll = ll_ > pl_ + tol, ll_ < pl_ - tol
            C["hh"], C["lh"], C["hl"], C["ll"] = _f(hh, vh), _f(lh, vh), _f(hl, vl), _f(ll, vl)
            C["bull_struct"] = _f(hh & hl, two)
            C["bear_struct"] = _f(lh & ll, two)
            C["no_bear_struct"] = _not(C["bear_struct"])
            C["no_struct"] = _f(~(hh & hl) & ~(lh & ll), two)
            C["bos_up"], C["below_last_high"] = _f(c > lh_ + tol, fin(lh_) & fin(tol)), _f(c <= lh_ + tol, fin(lh_) & fin(tol))
            C["bos_dn"], C["above_last_low"] = _f(c < ll_ - tol, fin(ll_) & fin(tol)), _f(c >= ll_ - tol, fin(ll_) & fin(tol))
            v50 = fin(e50)
            C["above20"], C["below20"] = _f(c > e20, fin(e20)), _f(c < e20, fin(e20))
            C["above50"], C["below50"] = _f(c > e50, v50), _f(c < e50, v50)
            C["near50"] = _f(c >= e50 - g["cons_ema50_atr"] * A["atr"], v50 & fin(A["atr"]))
            C["above200"], C["below200"] = _f(c > e200, fin(e200)), _f(c < e200, fin(e200))
            s20, s50 = A["s20"], A["s50"]
            C["rise20"], C["fall20"] = _f(s20 >= g["slope20_min"], fin(s20)), _f(s20 <= -g["slope20_min"], fin(s20))
            C["flat20"] = _f(np.abs(s20) < g["slope20_min"], fin(s20))
            C["rise50"], C["fall50"] = _f(s50 >= g["slope50_min"], fin(s50)), _f(s50 <= -g["slope50_min"], fin(s50))
            C["flat50"] = _f(np.abs(s50) < g["slope50_min"], fin(s50))
            C["ema50_up"], C["ema50_dn"] = _f(s50 > 0, fin(s50)), _f(s50 < 0, fin(s50))
            # alignment: close / EMA20 / EMA50 required; EMA100 / EMA200 joined where known
            ab = (c > e20) & (e20 > e50)
            ad = (c < e20) & (e20 < e50)
            ab = ab & np.where(fin(e100), e50 > e100, True) & np.where(fin(e200), np.where(fin(e100), e100 > e200, e50 > e200), True)
            ad = ad & np.where(fin(e100), e50 < e100, True) & np.where(fin(e200), np.where(fin(e100), e100 < e200, e50 < e200), True)
            C["align_bull"], C["align_bear"] = _f(ab, fin(e20) & v50), _f(ad, fin(e20) & v50)
            ef = A["eff20"]
            C["eff_up"], C["eff_dn"] = _f(ef >= g["eff_trend"], fin(ef)), _f(ef <= -g["eff_trend"], fin(ef))
            C["eff_flat"] = _f(np.abs(ef) < g["eff_flat"], fin(ef))
            sh = A["share50"]
            C["persist_up"], C["persist_dn"] = _f(sh >= g["persist_hi"], fin(sh)), _f(sh <= g["persist_lo"], fin(sh))
            C["persist_mid"] = _f((sh > g["persist_lo"]) & (sh < g["persist_hi"]), fin(sh))
            r20, rsi = A["r20"], A["rsi14"]
            C["mom_up"] = _f((r20 > 0) & (rsi >= 50), fin(r20) & fin(rsi))
            C["mom_dn"] = _f((r20 < 0) & (rsi < 50), fin(r20) & fin(rsi))
            C["macd_up"], C["macd_dn"] = _f(A["macd_h"] > 0, fin(A["macd_h"])), _f(A["macd_h"] < 0, fin(A["macd_h"]))
            C["r60_up"], C["r60_dn"] = _f(A["r60"] > 0, fin(A["r60"])), _f(A["r60"] < 0, fin(A["r60"]))
            C["rsi_up50"] = _f(rsi >= 50, fin(rsi))
            C["rsi_mid"] = _f((rsi >= 40) & (rsi <= 60), fin(rsi))
            C["rsi_cons"] = _f((rsi >= 45) & (rsi <= 65), fin(rsi))
            acc = A["acc"]
            C["decel"], C["accel"] = _f(acc <= g["decel_atr"], fin(acc)), _f(acc >= g["accel_atr"], fin(acc))
            d20 = A["d20"]
            C["deep_below20"] = _f(d20 <= g["below20_atr"], fin(d20))
            C["well_above20"] = _f(d20 >= g["above20_atr"], fin(d20))
            C["above20_turning"] = _f((c > e20) & (s20 > 0), fin(e20) & fin(s20))
            # divergence candidates on confirmed swings known in the last div_recent sessions
            idx = np.arange(n, dtype=float)
            rec_h = fin(A["last_hi_known"]) & (idx - A["last_hi_known"] <= g["div_recent"])
            rec_l = fin(A["last_lo_known"]) & (idx - A["last_lo_known"] <= g["div_recent"])
            vh = fin(A["last_hi_rsi"]) & fin(A["prev_hi_rsi"]) & fin(lh_) & fin(ph_)
            vl = fin(A["last_lo_rsi"]) & fin(A["prev_lo_rsi"]) & fin(ll_) & fin(pl_)
            C["bear_div"] = _f(rec_h & (lh_ > ph_) & (A["last_hi_rsi"] <= A["prev_hi_rsi"] - g["div_rsi_pts"]), vh)
            C["bull_div"] = _f(rec_l & (ll_ < pl_) & (A["last_lo_rsi"] >= A["prev_lo_rsi"] + g["div_rsi_pts"]), vl)
            # a fresh low: the lowest low of the last fresh_low_window sessions was made in the last fresh_low_n
            lw = pd.Series(self.l).rolling(g["fresh_low_window"], min_periods=g["fresh_low_window"]).min().to_numpy(float)
            l5 = pd.Series(self.l).rolling(g["fresh_low_n"], min_periods=g["fresh_low_n"]).min().to_numpy(float)
            C["fresh_low"] = _f(l5 <= lw, fin(lw) & fin(l5))
            C["no_fresh_low"] = _not(C["fresh_low"])
            # volatility
            vr, rk = A["vol_ratio"], A["atr_rank"]
            elev = (vr >= g["vol_elev_ratio"]) | (rk >= g["vol_elev_rank"])
            ext = (vr >= g["vol_ext_ratio"]) | (rk >= g["vol_ext_rank"])
            C["vol_elev"] = _f(elev, fin(vr) | fin(rk))
            C["vol_not_elev"] = _not(C["vol_elev"])
            C["vol_extreme"] = _f(ext, fin(vr) | fin(rk))
            C["vol_comp"] = _f((rk <= g["vol_comp_rank"]) & (vr <= g["vol_comp_ratio"]), fin(vr) & fin(rk))
            C["big_down"] = _f(A["downs5"] >= 1, fin(A["downs5"]))
            C["gap_risk"] = _f(A["gaps10"] >= g["gap_risk"], fin(A["gaps10"]))
            wild = (vr >= g["disorder_ratio"]) | (rk >= g["disorder_rank"])
            chop = (A["flips20"] >= g["disorder_flips"]) | (A["gaps10"] >= g["disorder_gaps"])
            C["disorder"] = _f(wild & chop & (np.abs(A["eff20"]) < g["disorder_eff"]),
                               (fin(vr) | fin(rk)) & fin(A["flips20"]) & fin(A["gaps10"]) & fin(A["eff20"]))
            C["contained"] = _f((A["rng_cons"] <= g["cons_range_atr"]) & (np.abs(A["eff_cons"]) < g["cons_eff"]),
                                  fin(A["rng_cons"]) & fin(A["eff_cons"]))
            C["range20_ok"] = _f(A["rng20"] <= g["range20_atr"], fin(A["rng20"]))
            fl = A["flow20"]
            C["flow_up"], C["flow_dn"] = _f(fl >= g["flow_min"], fin(fl)), _f(fl <= -g["flow_min"], fin(fl))
            C["vol_drying"] = _f(A["vtrend"] < g["dry_ratio"], fin(A["vtrend"]))
            C["pv_up_flow_dn"] = _f((r20 >= g["pv_ret"]) & (fl <= -g["flow_min"]), fin(r20) & fin(fl))
            C["pv_dn_flow_up"] = _f((r20 <= -g["pv_ret"]) & (fl >= g["flow_min"]), fin(r20) & fin(fl))
        # structure age and the trend context of the sessions before the last ctx_lag
        C["bull_core"] = _and(C["bull_struct"], C["above_last_low"])
        C["bear_core"] = _and(C["bear_struct"], C["below_last_high"])
        A["bull_age"] = _run_length(C["bull_core"]).astype(float)
        A["bear_age"] = _run_length(C["bear_core"]).astype(float)
        up_ev = _and(C["above50"], C["rise50"])
        dn_ev = _and(C["below50"], C["fall50"])
        for nm, ev in (("bull_share", up_ev), ("bear_share", dn_ev)):
            s = pd.Series(np.where(np.isfinite(ev), ev, np.nan))
            A[nm] = s.shift(g["ctx_lag"]).rolling(g["ctx_n"], min_periods=g["ctx_n"] // 2).mean().to_numpy(float)
        with np.errstate(invalid="ignore"):
            bs, br = A["bull_share"], A["bear_share"]
            # established: held long enough, or the context before says so; while the context is not yet available
            # (a young stock) it is judged on how long the structure has held alone
            C["bull_est"] = np.where(A["bull_age"] >= g["established"], 1.0,
                                     np.where(fin(bs), (bs >= g["ctx_est"]).astype(float), 0.0))
            C["bear_est"] = np.where(A["bear_age"] >= g["established"], 1.0,
                                     np.where(fin(br), (br >= g["ctx_est"]).astype(float), 0.0))
            C["bull_not_est"], C["bear_not_est"] = _not(C["bull_est"]), _not(C["bear_est"])
            C["prior_bull"] = _f(bs >= g["ctx_cons"], fin(bs))
            C["prior_bear"] = _f(br >= g["ctx_prior"], fin(br))
        C["bull_early"] = _or(C["bull_core"], _and(C["bos_up"], C["hl"]))
        C["bear_early"] = _or(C["bear_core"], _and(C["bos_dn"], _or(C["lh"], C["below50"])))
        C["weak_trend"] = _or(C["below50"], C["fall20"])
        rev = np.vstack([C[k] for k in ("hl", "bos_up", "bull_div", "above20_turning", "rsi_up50", "flow_up")])
        cnt = np.nansum(rev == 1, axis=0)
        evaluable = np.isfinite(rev).sum(axis=0)
        A["rev_signs"] = cnt.astype(float)
        C["rev2"] = np.where(cnt >= g["rev_min"], 1.0, np.where(evaluable >= 1, 0.0, np.nan))

    # ------------------------------------------------------------------
    def _classify(self) -> None:
        """Raw state of each session: the first state in PRECEDENCE whose required conditions all hold."""
        g, n, C = self.cfg, self.n, self.C
        raw = np.full(n, "UNKNOWN", dtype=object)
        done = np.zeros(n, bool)
        insuff = (np.arange(n) < g["min_bars"] - 1) | ~np.isfinite(self.A["ema50"]) | ~np.isfinite(self.A["atr"]) | \
            ~np.isfinite(self.c)
        raw[insuff] = "INSUFFICIENT_DATA"
        done |= insuff
        self.req_ok: Dict[str, np.ndarray] = {}
        for s in PRECEDENCE:
            ok = np.all(np.vstack([self.cond(k) == 1 for k in STATES[s]["required"]]), axis=0)
            self.req_ok[s] = ok
            pick = ok & ~done
            raw[pick] = s
            done |= pick
        self.raw = raw
        # evidence agreement for every state on every session (used for the confirmed state)
        self.support, self.conflicts, self.complete = {}, {}, {}
        for s, r in STATES.items():
            S = np.vstack([self.cond(k) for k in r["supporting"]])
            K = np.vstack([self.cond(k) for k in r["conflicting"]])
            Rq = np.vstack([self.cond(k) for k in r["required"]])
            ev = np.isfinite(S).sum(axis=0)
            self.support[s] = np.where(ev > 0, np.nansum(S == 1, axis=0) / np.maximum(ev, 1), np.nan)
            self.conflicts[s] = np.nansum(K == 1, axis=0).astype(int)
            tot = S.shape[0] + K.shape[0] + Rq.shape[0]
            self.complete[s] = (np.isfinite(S).sum(axis=0) + np.isfinite(K).sum(axis=0) + np.isfinite(Rq).sum(axis=0)) / tot

    def cond(self, k: str) -> np.ndarray:
        return self.C[k]

    # ------------------------------------------------------------------
    def _machine(self) -> None:
        """Confirmed state with hysteresis: a change is confirmed once the raw state has been off the current state for
        confirm_n sessions in a row (the new state = the raw state of that session). INSUFFICIENT_DATA ends at once."""
        g, n, raw = self.cfg, self.n, self.raw
        st = np.full(n, "INSUFFICIENT_DATA", dtype=object)
        prev = np.full(n, "", dtype=object)
        age = np.zeros(n, np.int64)
        began = np.full(n, -1, np.int64)
        conf_i = np.full(n, -1, np.int64)
        pend = np.full(n, "", dtype=object)
        pend_n = np.zeros(n, np.int64)
        trans: List[Tuple[int, int, str, str]] = []      # (confirmed at, began at, from, to)
        need = int(g["confirm_n"])
        cur, cur_prev, cur_began, cur_conf, off = (raw[0] if n else "INSUFFICIENT_DATA"), "", 0, 0, 0
        for t in range(n):
            r = raw[t]
            if t > 0 and r != cur:
                if r == "INSUFFICIENT_DATA" or cur == "INSUFFICIENT_DATA":
                    trans.append((t, t, cur, r))
                    cur_prev, cur, cur_began, cur_conf, off = cur, r, t, t, 0
                else:
                    off += 1
                    if off >= need:
                        b = t - off + 1
                        trans.append((t, b, cur, r))
                        cur_prev, cur, cur_began, cur_conf, off = cur, r, b, t, 0
            else:
                off = 0
            st[t], prev[t], began[t], conf_i[t] = cur, cur_prev, cur_began, cur_conf
            age[t] = t - cur_began + 1
            if off > 0:
                pend[t], pend_n[t] = r, off
        self.state, self.prev, self.age, self.began, self.conf_i = st, prev, age, began, conf_i
        self.pending, self.pending_n = pend, pend_n
        self.transitions = trans
        # evidence for the confirmed state, confidence and phase
        sup = np.full(n, np.nan)
        con = np.zeros(n, np.int64)
        cmp_ = np.full(n, np.nan)
        for s in STATES:
            m = st == s
            sup[m], con[m], cmp_[m] = self.support[s][m], self.conflicts[s][m], self.complete[s][m]
        self.st_support, self.st_conflicts, self.st_complete = sup, con, cmp_
        known = np.isin(st, PRIMARY)
        is_pend = pend != ""
        with np.errstate(invalid="ignore"):
            low = is_pend | (sup < g["weak_support"]) | (con >= g["conflicts_low"]) | (cmp_ < g["complete_low"]) | ~np.isfinite(sup)
            high = ~is_pend & (sup >= g["high_support"]) & (con == 0) & (cmp_ >= g["complete_high"]) & (age >= g["high_age"])
        conf = np.where(~known, "UNKNOWN", np.where(low, "LOW", np.where(high, "HIGH", "MEDIUM"))).astype(object)
        with np.errstate(invalid="ignore"):
            det = is_pend | (sup < g["weak_support"]) | (con >= g["conflicts_low"])
        phase = np.where(~known, "", np.where(det, "DETERIORATING", np.where(age <= g["early_n"], "EARLY", "MATURE")))
        self.confidence, self.phase = conf, phase.astype(object)

    # ------------------------------------------------------------------
    def _events(self) -> None:
        """Breakouts / breakdowns and what became of them, session by session (only closes up to t are used)."""
        g, n, A = self.cfg, self.n, self.A
        c, atr = self.c, A["atr"]
        wins = list(g["breakout_windows"])
        ev_kind = np.full(n, "", dtype=object)
        ev_status = np.full(n, "", dtype=object)
        ev_start = np.full(n, -1, np.int64)
        ev_change = np.full(n, -1, np.int64)
        ev_level = np.full(n, np.nan)
        ev_win = np.zeros(n, np.int64)
        ev_rvol = np.full(n, np.nan)
        log: List[dict] = []
        act = {"up": None, "dn": None}            # the live breakout / breakdown
        for t in range(1, n):
            # 1. what became of the live events
            for side in ("up", "dn"):
                e = act[side]
                if e is None or e["status"] not in ("NEW", "CONFIRMED"):
                    continue
                k = t - e["start"]
                a = atr[t]
                if k <= g["fail_n"] and np.isfinite(a) and (
                        (side == "up" and c[t] < e["level"] - g["fail_atr"] * a) or
                        (side == "dn" and c[t] > e["level"] + g["fail_atr"] * a)):
                    e["status"], e["change"] = "FAILED", t
                    e["kind"] = "FAILED_BREAKOUT" if side == "up" else "FAILED_BREAKDOWN"
                    log.append(dict(e))
                elif e["status"] == "NEW":
                    seg = c[e["start"]:t + 1]
                    held = (seg >= e["level"]).all() if side == "up" else (seg <= e["level"]).all()
                    if k >= g["hold_n"] and held:
                        e["status"], e["change"] = "CONFIRMED", t
                        log.append(dict(e))
                    elif k > g["fail_n"]:
                        e["status"], e["change"] = "STALLED", t
                        log.append(dict(e))
            # 2. a new crossing today (the longest window first)
            for side, key, kind in (("up", "hi", "BREAKOUT"), ("dn", "lo", "BREAKDOWN")):
                for w in wins:
                    lv, lv0 = A[f"{key}{w}"][t], A[f"{key}{w}"][t - 1]
                    if not (np.isfinite(lv) and np.isfinite(lv0)):
                        continue
                    cross = (c[t] > lv and c[t - 1] <= lv0) if side == "up" else (c[t] < lv and c[t - 1] >= lv0)
                    if cross:
                        e = {"kind": kind, "status": "NEW", "start": t, "change": t, "level": float(lv), "window": int(w),
                             "rvol": float(A["rvol"][t]) if np.isfinite(A["rvol"][t]) else np.nan}
                        act[side] = e
                        log.append(dict(e))
                        break
            # 3. the event shown: the most recent change among the two sides, within event_show sessions
            best = None
            for side in ("up", "dn"):
                e = act[side]
                if e is not None and t - e["change"] <= g["event_show"]:
                    if best is None or e["change"] > best["change"] or (e["change"] == best["change"] and e["start"] > best["start"]):
                        best = e
            if best is not None:
                ev_kind[t], ev_status[t], ev_start[t], ev_change[t] = best["kind"], best["status"], best["start"], best["change"]
                ev_level[t], ev_win[t], ev_rvol[t] = best["level"], best["window"], best["rvol"]
        self.ev_kind, self.ev_status, self.ev_start, self.ev_change = ev_kind, ev_status, ev_start, ev_change
        self.ev_level, self.ev_win, self.ev_rvol = ev_level, ev_win, ev_rvol
        self.event_log = log

    # ------------------------------------------------------------------
    def _flags(self) -> None:
        g, n, A, C = self.cfg, self.n, self.A, self.C
        d20, d50, m10 = A["d20"], A["d50"], A["m10"]
        risks = [[] for _ in range(n)]
        notes = [[] for _ in range(n)]
        with np.errstate(invalid="ignore"):
            extreme = (d20 >= g["extreme20_atr"]) | (d50 >= g["extreme50_atr"])
            over = (d20 >= g["ext20_atr"]) | (d50 >= g["ext50_atr"]) | (m10 >= g["ext10_atr"])
            stretch = d20 <= g["stretch_dn_atr"]
        for i in np.flatnonzero(extreme):
            risks[i].append("S05_EXTREME")
        for i in np.flatnonzero(over & ~extreme):
            risks[i].append("S05_OVEREXTENDED")
        for i in np.flatnonzero(stretch):
            risks[i].append("STRETCHED_DOWN")
        for key, flag in (("big_down", "BIG_DOWN_CANDLE"), ("gap_risk", "GAP_RISK"), ("bear_div", "BEAR_DIVERGENCE"),
                          ("pv_up_flow_dn", "PRICE_UP_FLOW_DOWN")):
            for i in np.flatnonzero(C[key] == 1):
                risks[i].append(flag)
        for key, flag in (("bull_div", "BULL_DIVERGENCE"), ("pv_dn_flow_up", "PRICE_DOWN_FLOW_UP"), ("vol_comp", "VOL_COMPRESSED")):
            for i in np.flatnonzero(C[key] == 1):
                notes[i].append(flag)
        self.risks = np.array([",".join(r) for r in risks], dtype=object)
        self.notes = np.array([",".join(r) for r in notes], dtype=object)
        self.overext = np.where(extreme, 2, np.where(over, 1, 0)).astype(np.int64)
        vr, rk = A["vol_ratio"], A["atr_rank"]
        with np.errstate(invalid="ignore"):
            vext = (vr >= g["vol_ext_ratio"]) | (rk >= g["vol_ext_rank"])
            velev = (vr >= g["vol_elev_ratio"]) | (rk >= g["vol_elev_rank"])
        vreg = np.where(~(np.isfinite(vr) | np.isfinite(rk)), "", np.where(vext, "EXTREME", np.where(
            velev, "ELEVATED", np.where(C["vol_comp"] == 1, "COMPRESSED", "NORMAL"))))
        self.vol_regime = vreg.astype(object)

    # ==================================================================
    # reading one session
    # ==================================================================
    def day(self, i: int):
        return pd.Timestamp(self.dates[i]) if 0 <= i < self.n else None

    def event_text(self, i: int, ascii_only: bool = True) -> str:
        k = self.ev_kind[i]
        if not k:
            return ""
        code, nm = EVENT_NAMES[k]
        st, s0, ch = self.ev_status[i], int(self.ev_start[i]), int(self.ev_change[i])
        lvl, w = self.ev_level[i], int(self.ev_win[i])
        ago = i - s0
        when = "today" if ago == 0 else f"{ago} session{'s' if ago != 1 else ''} ago"
        rv = self.ev_rvol[i]
        vol = f", volume {rv:.1f}x normal" if np.isfinite(rv) else ""
        head = f"{code} {nm}" if code else nm
        if k in ("BREAKOUT", "BREAKDOWN"):
            dirn = "above" if k == "BREAKOUT" else "below"
            what = {"NEW": "NEW (not yet confirmed)", "CONFIRMED": f"CONFIRMED on {self.day(ch):%d %b}",
                    "STALLED": "STALLED (neither confirmed nor failed in 5 sessions)"}.get(st, st)
            return f"{head}: closed {dirn} the {w}-session {'high' if k == 'BREAKOUT' else 'low'} {lvl:,.2f} {when}{vol} - {what}"
        side = "back below" if k == "FAILED_BREAKOUT" else "back above"
        return (f"{head}: broke out {when} at {lvl:,.2f} ({w}-session level), closed {side} it on {self.day(ch):%d %b}"
                if k == "FAILED_BREAKOUT" else
                f"{head}: broke down {when} at {lvl:,.2f} ({w}-session level), closed {side} it on {self.day(ch):%d %b}")

    def invalidation(self, i: int) -> str:
        """What would end the state, with this session's prices. The price conditions among its REQUIRED ones: swing
        levels carry the tolerance the rules use; the confirmed state changes after confirm_n sessions in a row off it
        (v1.3.1 - v1.3 printed the bare swing level, so a close just under it while the state held looked wrong).
        Any other required condition failing ends it too: the evidence lists them all."""
        s = self.state[i]
        A, g = self.A, self.cfg
        f2 = (lambda x: f"{x:,.2f}" if np.isfinite(x) else "n/a")
        atr, t = A["atr"][i], g["swing_tol_atr"]
        tol = t * atr
        lo, hi, e50 = A["last_lo"][i], A["last_hi"][i], A["ema50"][i]
        n2 = f"{g['confirm_n']} sessions in a row"
        if s == "S01":
            return (f"{n2} closing below {f2(lo - tol)} (the last higher low {f2(lo)} less {t} ATR) or at / below EMA50 "
                    f"{f2(e50)}; also the higher-high / higher-low structure or the rising EMA50 failing")
        if s == "S02":
            return (f"{n2} closing below {f2(lo - tol)} (the last swing low {f2(lo)} less {t} ATR) or at / below EMA50 "
                    f"{f2(e50)}; it becomes S01 once the structure is established")
        if s == "S03":
            c50 = g["cons_ema50_atr"]
            return (f"{n2} closing below {f2(lo - tol)} (the last swing low {f2(lo)} less {t} ATR) or below "
                    f"{f2(e50 - c50 * atr)} (EMA50 {f2(e50)} less {c50} ATR) ends it downward; the "
                    f"{g['cons_n']}-session range ({f2(A['cons_floor'][i])} - {f2(A['cons_top'][i])}) widening past "
                    f"{g['cons_range_atr']} ATR ends it either way - upward with an S04 breakout")
        if s == "S06":
            w = int(g["fresh_low_window"])
            low_w = float(np.min(self.l[max(0, i - w + 1):i + 1])) if i >= 0 else np.nan
            return (f"a low below {f2(low_w)} (the lowest low of the last {w} sessions), or fewer than "
                    f"{g['rev_min']} reversal signs")
        if s == "S07":
            return (f"a direction emerging ({g['eff_n']}-session efficiency beyond -{g['eff_flat']} / +{g['eff_flat']}, "
                    f"or EMA50 moving {g['slope50_min']}+ ATR in {g['slope50_lag']} sessions) - a move out of "
                    f"{f2(A['lo20'][i])} - {f2(A['hi20'][i])} (the previous 20 sessions' range) usually starts it")
        if s == "S08":
            return (f"{n2} closing above {f2(hi + tol)} (the last lower high {f2(hi)} plus {t} ATR) or at / above EMA50 "
                    f"{f2(e50)}; also the lower-high / lower-low structure or the falling EMA50 failing")
        if s == "S09":
            return (f"{n2} closing above {f2(hi + tol)} (the last swing high {f2(hi)} plus {t} ATR), or at / above "
                    f"EMA50 {f2(e50)} once EMA20 stops falling; it becomes S08 once the structure is established")
        if s == "S12":
            return inval_text(g)["S12"]
        return ""

    def evidence(self, i: int, state: Optional[str] = None) -> Dict[str, List[Tuple[str, float]]]:
        s = state or self.state[i]
        if s not in STATES:
            return {}
        r = STATES[s]
        return {part: [(k, float(self.C[k][i])) for k in r[part]] for part in ("required", "supporting", "conflicting")}

    def unknown_why(self, i: int) -> str:
        """For UNKNOWN: the two states that came closest and what they lack."""
        txt = {**cond_text(self.cfg), **EXTRA_TEXT}
        rows = []
        for s in PRECEDENCE:
            req = STATES[s]["required"]
            v = np.array([self.C[k][i] for k in req])
            rows.append((float(np.mean(v == 1)), s, [k for k, x in zip(req, v) if x != 1]))
        rows.sort(key=lambda x: -x[0])
        parts = []
        for share, s, miss in rows[:2]:
            parts.append(f"{s} {SHORT[s].lower()} lacks: " + "; ".join(txt.get(k, k) for k in miss[:3]))
        return " | ".join(parts)

    def history(self, i: int, keep: Optional[int] = None) -> List[Tuple[pd.Timestamp, pd.Timestamp, str, str]]:
        keep = keep or int(self.cfg["history_keep"])
        out = [(self.day(b), self.day(t), f, to) for t, b, f, to in self.transitions if t <= i]
        return out[-keep:]

    def events_recent(self, i: int, sessions: int = 20) -> List[dict]:
        return [e for e in self.event_log if i - sessions < e["change"] <= i]

    def row(self, i: int) -> dict:
        """Everything about session i (display: includes price levels; export uses pick_columns)."""
        A, s = self.A, self.state[i]
        g = self.cfg
        out = {"symbol": self.sym, "date": self.day(i), "state": s, "state_name": STATE_NAMES.get(s, s),
               "state_short": SHORT.get(s, s), "side": SIDE.get(s, "none"), "raw_state": self.raw[i],
               "confidence": self.confidence[i], "phase": self.phase[i], "age": int(self.age[i]),
               "prev_state": self.prev[i], "began": self.day(int(self.began[i])), "confirmed": self.day(int(self.conf_i[i])),
               "pending": self.pending[i], "pending_n": int(self.pending_n[i]),
               "support": float(self.st_support[i]), "conflicts": int(self.st_conflicts[i]),
               "completeness": float(self.st_complete[i]), "event": self.ev_kind[i], "event_status": self.ev_status[i],
               "event_age": int(i - self.ev_start[i]) if self.ev_kind[i] else -1, "event_level": float(self.ev_level[i]),
               "event_window": int(self.ev_win[i]), "event_text": self.event_text(i), "risks": self.risks[i],
               "notes": self.notes[i], "vol_regime": self.vol_regime[i], "invalidation": self.invalidation(i),
               "bars": int(i + 1)}
        for k in ("atr", "atr_pct", "ema20", "ema50", "ema100", "ema200", "d20", "d50", "d100", "d200", "s20", "s50",
                  "eff20", "eff_cons", "share50", "r5", "r20", "r60", "rsi14", "macd_h", "acc", "m10", "rv10", "rv60",
                  "vol_ratio", "atr_rank", "rng_cons", "rng20", "gaps10", "flips20", "downs5", "rvol", "vtrend", "flow20",
                  "hi20", "lo20", "hi55", "lo55", "pos20", "cons_top", "cons_floor", "last_hi", "prev_hi", "last_lo", "prev_lo",
                  "bull_age", "bear_age", "bull_share", "bear_share", "rev_signs"):
            out[k] = float(A[k][i]) if k in A else np.nan
        for nm in ("last_hi", "prev_hi", "last_lo", "prev_lo"):
            p = A[f"{nm}_i"][i]
            out[f"{nm}_day"] = self.day(int(p)) if np.isfinite(p) else None
        for nm in ("last_hi", "last_lo"):
            kn = A[f"{nm}_known"][i]
            out[f"{nm}_known_day"] = self.day(int(kn)) if np.isfinite(kn) else None
        out["unknown_why"] = self.unknown_why(i) if s == "UNKNOWN" else ""
        out["headline"] = headline(out)
        return out

    def pick_columns(self, i: int) -> dict:
        """The state known at session i's close, for a pick (no raw price levels: ATR units, ratios, codes only)."""
        A, s = self.A, self.state[i]
        ek = f"{self.ev_kind[i]}:{self.ev_status[i]}" if self.ev_kind[i] else ""
        evn = EVENT_NUM.get(ek, 0)
        rk = self.risks[i]
        out = {"pre_state": s, "pre_state_name": STATE_NAMES.get(s, s), "pre_state_num": float(STATE_NUM.get(s, 0)),
               "pre_state_bullish": float(s in ("S01", "S02", "S03")), "pre_state_bearish": float(s in ("S08", "S09")),
               "pre_state_confidence": self.confidence[i], "pre_state_conf_num": float(CONF_NUM.get(self.confidence[i], 0)),
               "pre_state_phase": self.phase[i], "pre_state_phase_num": float(PHASE_NUM.get(self.phase[i], np.nan)) if self.phase[i] else np.nan,
               "pre_state_age": float(self.age[i]), "pre_state_prev": self.prev[i], "pre_state_raw": self.raw[i],
               "pre_state_pending": self.pending[i], "pre_state_support": float(self.st_support[i]),
               "pre_state_conflicts": float(self.st_conflicts[i]),
               "pre_state_event": ek, "pre_state_event_num": float(evn),
               "pre_state_event_age": float(i - self.ev_start[i]) if self.ev_kind[i] else np.nan,
               "pre_state_breakout_recent": float(ek in ("BREAKOUT:NEW", "BREAKOUT:CONFIRMED", "BREAKOUT:STALLED")),
               "pre_state_failed_breakout": float(ek == "FAILED_BREAKOUT:FAILED"),
               "pre_state_breakdown_recent": float(ek in ("BREAKDOWN:NEW", "BREAKDOWN:CONFIRMED", "BREAKDOWN:STALLED")),
               "pre_state_overextended": float(self.overext[i]),
               "pre_state_risks": rk, "pre_state_notes": self.notes[i], "pre_state_vol_regime": self.vol_regime[i],
               "pre_state_vol_elevated": float(self.vol_regime[i] in ("ELEVATED", "EXTREME")) if self.vol_regime[i] else np.nan,
               "pre_state_big_down": float("BIG_DOWN_CANDLE" in rk), "pre_state_bear_div": float("BEAR_DIVERGENCE" in rk)}
        for k, nm in (("d20", "ext20_atr"), ("d50", "ext50_atr"), ("s20", "ema20_slope_atr"), ("s50", "ema50_slope_atr"),
                      ("eff20", "eff20"), ("rsi14", "rsi14"), ("macd_h", "macd_hist_atr"), ("r20", "r20"), ("r60", "r60"),
                      ("vol_ratio", "vol_ratio"), ("atr_rank", "atr_rank"), ("rvol", "rvol"), ("flow20", "flow20"),
                      ("rng_cons", "cons_range_atr"), ("pos20", "pos20")):
            out[f"pre_state_{nm}"] = float(A[k][i])
        return out


def headline(r: dict) -> str:
    """One line: primary state (confidence, age, phase) | event | risks | volatility."""
    s = r["state"]
    if s == "INSUFFICIENT_DATA":
        b = int(r.get("bars") or 0)
        return f"INSUFFICIENT DATA ({b} sessions of bars)" if b else "INSUFFICIENT DATA (too few sessions of bars)"
    if s == "UNKNOWN":
        p = f"UNKNOWN - evidence conflicts ({r['age']} sessions)"
    else:
        p = f"{s} {STATE_NAMES[s]} ({r['confidence']}, {r['age']} session{'s' if r['age'] != 1 else ''}, {r['phase'].lower()})"
    if r.get("pending"):
        p += f" -> {r['pending']} pending"
    parts = [p]
    if r.get("event"):
        code, nm = EVENT_NAMES[r["event"]]
        st = r["event_status"]
        parts.append(f"{code + ' ' if code else ''}{nm}" + ("" if st == "FAILED" else f" {st}") +
                     (" today" if r["event_age"] == 0 else f" ({r['event_age']}d)"))
    rk = [RISK_TEXT.get(x, x) for x in str(r.get("risks") or "").split(",") if x]
    if rk:
        parts.append("risk: " + "; ".join(rk))
    if r.get("vol_regime") in ("ELEVATED", "EXTREME", "COMPRESSED"):
        parts.append(f"volatility {r['vol_regime'].lower()}")
    return " | ".join(parts)


def pick_headline(t: dict) -> str:
    """The headline from a pick's pre_state_* columns (trade cards)."""
    s = str(t.get("pre_state") or "")
    if not s:
        return "no state"
    fin_ = (lambda x: x is not None and isinstance(x, (int, float, np.floating, np.integer)) and np.isfinite(x))
    r = {"state": s, "confidence": t.get("pre_state_confidence") or "", "age": int(t["pre_state_age"]) if fin_(t.get("pre_state_age")) else 0,
         "phase": str(t.get("pre_state_phase") or ""), "pending": t.get("pre_state_pending") or "", "risks": t.get("pre_state_risks") or "",
         "vol_regime": t.get("pre_state_vol_regime") or "", "bars": 0, "event": "", "event_status": "", "event_age": -1}
    ek = str(t.get("pre_state_event") or "")
    if ek and ":" in ek:
        r["event"], r["event_status"] = ek.split(":", 1)
        r["event_age"] = int(t["pre_state_event_age"]) if fin_(t.get("pre_state_event_age")) else -1
    return headline(r)


# ======================================================================
# many stocks: series from tradelab's market (read-only daily bars)
# ======================================================================
class StateBook:
    """State series for a market's symbols, computed on first use from the cached daily bars (full history)."""

    def __init__(self, market, cfg: Optional[dict] = None, keep: bool = True):
        self.m = market
        self.cfg = cfg_with(cfg)
        self.keep = keep
        self._s: Dict[str, Optional[StateSeries]] = {}

    def series(self, sym: str) -> Optional[StateSeries]:
        if sym in self._s:
            return self._s[sym]
        ds = self.m.series(sym)
        ss = None if ds is None or len(ds) == 0 else StateSeries(sym, ds.dates, ds.o, ds.h, ds.l, ds.c, ds.v, self.cfg)
        if self.keep:
            self._s[sym] = ss
        return ss

    def drop(self, sym: str) -> None:
        self._s.pop(sym, None)


def pick_states(market, T: pd.DataFrame, cfg: Optional[dict] = None, log=None) -> pd.DataFrame:
    """One row per pick (T's order): the state known at the signal day's close (pre_state_*). A stock without a bar on
    the signal day is left blank (never the nearest day)."""
    book = StateBook(market, cfg, keep=False)
    n = len(T)
    rows: List[Optional[dict]] = [None] * n
    if n == 0:
        return pd.DataFrame(columns=STATE_PICK_COLUMNS)
    sdays = to_day(T["signal_day"])
    syms = T["symbol"].astype(str).to_numpy()
    order = pd.Series(np.arange(n)).groupby(syms).apply(list)
    for k, (sym, idxs) in enumerate(order.items()):
        ss = book.series(sym)
        for j in idxs:
            i = ss.idx(sdays[j]) if ss is not None else -1
            rows[j] = ss.pick_columns(i) if i >= 0 else None
        if log and k and k % 250 == 0:
            log(f"   stock states: {k:,} of {len(order):,} symbols")
    out = pd.DataFrame([r if r is not None else {} for r in rows], columns=STATE_PICK_COLUMNS)
    blank = np.array([r is None for r in rows])
    if blank.any():
        out.loc[blank, "pre_state"] = ""
        out.loc[blank, "pre_state_name"] = "no bar on the signal day"
    return out


def _cols() -> List[str]:
    z = np.zeros(80)
    d = pd.date_range("2020-01-01", periods=80, freq="B").to_numpy()
    p = 100 + np.cumsum(np.ones(80) * 0.1)
    return list(StateSeries("X", d, p, p + 1, p - 1, p, z + 1000).pick_columns(79).keys())


STATE_PICK_COLUMNS = _cols()
# numeric pick attributes a rule or filter may read (all known at the signal day's close)
STATE_PICK_ATTRS = tuple(c for c in STATE_PICK_COLUMNS if c not in (
    "pre_state", "pre_state_name", "pre_state_confidence", "pre_state_phase", "pre_state_prev", "pre_state_raw",
    "pre_state_pending", "pre_state_event", "pre_state_risks", "pre_state_notes", "pre_state_vol_regime"))
STATE_TEXT_COLS = tuple(c for c in STATE_PICK_COLUMNS if c not in STATE_PICK_ATTRS)

# breakdown dimensions for the export's context tables (tl_context.breakdown format)
STATE_DIMS = (
    ("stock state at the pick", "pre_state", ("S01", "S02", "S03", "S06", "S07", "S08", "S09", "S12", "UNKNOWN",
                                             "INSUFFICIENT_DATA"), "before"),
    ("state phase at the pick", "pre_state_phase", ("EARLY", "MATURE", "DETERIORATING"), "before"),
    ("state confidence at the pick", "pre_state_confidence", ("HIGH", "MEDIUM", "LOW", "UNKNOWN"), "before"),
    ("event in the last 10 sessions", "pre_state_event", ("BREAKOUT:NEW", "BREAKOUT:CONFIRMED", "BREAKOUT:STALLED",
                                                           "FAILED_BREAKOUT:FAILED", "BREAKDOWN:NEW",
                                                           "BREAKDOWN:CONFIRMED", "BREAKDOWN:STALLED",
                                                           "FAILED_BREAKDOWN:FAILED"), "before"),
    ("S05 overextension at the pick", "pre_state_overextended", ((-np.inf, 0.5, 1.5, np.inf), ("no", "overextended", "extreme")), "before"),
    ("stock volatility at the pick", "pre_state_vol_regime", ("COMPRESSED", "NORMAL", "ELEVATED", "EXTREME"), "before"),
)


# ======================================================================
# documentation (STATE_RULES.md) and the command line
# ======================================================================
def rules_md(cfg: Optional[dict] = None) -> str:
    cfg = cfg_with(cfg)
    txt = {**cond_text(cfg), **EXTRA_TEXT}
    itx = inval_text(cfg)
    L = [f"# Stock states - the rules ({STATE_VERSION}, {VERSION})", "",
         f"Research defaults declared {cfg['declared']} before any real run; settings fingerprint {cfg_hash(cfg)}. "
         "Every threshold is transparent and configurable; none is proven. Written by `python tl_state.py rules`.", "",
         "## How a session is read", "",
         "1. **Measurements** from the stock's own daily bars up to that session's close (nothing later): swings, "
         "EMA20/50/100/200, slopes and distances in ATR units, efficiency, returns, RSI 14, MACD, realised volatility, "
         "ATR% rank, gaps, large moves, volume flow.",
         f"2. **Swing points** - a swing high is a bar higher than the {cfg['swing_k']} bars before it and not lower "
         f"than the {cfg['swing_k']} after it (swing lows the mirror). It becomes KNOWN {cfg['swing_k']} sessions "
         "after the pivot and is used only from then on; nothing is back-dated to the pivot day.",
         "3. **Raw state** - the first state below (in this order of precedence) whose REQUIRED conditions all "
         f"hold: {' > '.join(PRECEDENCE)}. None -> UNKNOWN. Fewer than {cfg['min_bars']} sessions, or no ATR / EMA50 "
         "yet -> INSUFFICIENT_DATA.",
         f"4. **Confirmed (primary) state** - changes only after the raw state has been off the current state for "
         f"{cfg['confirm_n']} sessions in a row; the new state is that session's raw state. The change BEGAN on the "
         "first of those sessions and was CONFIRMED on the last (both shown; the confirmation date is when it was "
         "known). INSUFFICIENT_DATA ends at once.",
         "5. **Events** (S04, S10, S11, bear trap) and **risk flags** (S05 and others) sit BESIDE the primary state; "
         "they never replace it. Volatility is its own dimension.",
         "", "## Precedence and conflicts", "",
         "- S12 first: when movement is disorderly the structural reading is unreliable, so nothing else is claimed.",
         "- S03 before S01: a bullish stock moving sideways in a tight range is consolidating, even though its "
         "higher-high / higher-low structure still stands.",
         "- S01 before S02: an established structure is a continuation; S02 requires 'not yet established'.",
         "- S02 before S06: once structure and EMA50 have turned, the attempt has become an emerging trend.",
         "- S06 before S08 / S09: a downtrend showing 2+ reversal signs and no fresh low is an attempt; with a fresh "
         "low it stays bearish.",
         "- S07 last: no direction and a flat EMA50.",
         "- Nothing fits: UNKNOWN (the card names the two closest states and what each lacks). The engine prefers "
         "UNKNOWN to a forced label.",
         "- Missing inputs (EMA200 before 200 sessions, no volume): a condition that cannot be evaluated is neither "
         "met nor failed. A REQUIRED condition that cannot be evaluated is not met. Missing supporting / conflicting "
         "inputs lower COMPLETENESS, and so confidence.",
         "- Two events at once: the one that changed most recently is shown (a failed breakout replaces its "
         "breakout; a later breakdown replaces both); the card lists every event of the last 20 sessions.",
         "", "## Confidence (not a probability)", "",
         f"- support = share of the state's SUPPORTING conditions that hold (of those that can be evaluated); "
         f"conflicts = how many CONFLICTING conditions hold; completeness = share of all its conditions that can be "
         "evaluated.",
         f"- HIGH: support >= {cfg['high_support']:.0%}, no conflict, completeness >= {cfg['complete_high']:.0%}, in "
         f"the state {cfg['high_age']}+ sessions, no change pending.",
         f"- LOW: a change pending, or support < {cfg['weak_support']:.0%}, or {cfg['conflicts_low']}+ conflicts, or "
         f"completeness < {cfg['complete_low']:.0%}.  MEDIUM: otherwise.  UNKNOWN: state UNKNOWN or INSUFFICIENT_DATA.",
         "", "## Phase (for the D / ENS research)", "",
         f"- DETERIORATING: a change pending, or support < {cfg['weak_support']:.0%}, or {cfg['conflicts_low']}+ "
         f"conflicts.  EARLY: the first {cfg['early_n']} sessions of the state.  MATURE: otherwise.", "",
         "## The primary states", ""]
    for s in ("S01", "S02", "S03", "S06", "S07", "S08", "S09", "S12"):
        r = STATES[s]
        L += [f"### {s} {STATE_NAMES[s]}", "", f"- Kind: {r['kind']}.",
              "- Required (all): " + "; ".join(txt.get(k, k) for k in r["required"]) + ".",
              "- Supporting: " + "; ".join(txt.get(k, k) for k in r["supporting"]) + ".",
              "- Conflicting (lower confidence): " + "; ".join(txt.get(k, k) for k in r["conflicting"]) + ".",
              f"- Confirmation: {cfg['confirm_n']} sessions in a row (as every primary state).",
              f"- Invalidation: {itx[s]}.",
              f"- Typical transitions: from {r['from']}; to {r['to']} (possible paths, not mandatory).",
              f"- Minimum history: {cfg['min_bars']} sessions to be read at all; the 'previously bullish / bearish' "
              f"context (needed by S03 and S06) from about {50 + cfg['slope50_lag'] + cfg['ctx_lag'] + cfg['ctx_n'] // 2} "
              f"sessions; EMA100 / EMA200 conditions from 100 / 200 sessions.", ""]
    L += ["## Events and risk flags", ""] + [f"- **{k}**: {v}" for k, v in EVENT_RULES.items()] + [
        "- Other risk flags: " + "; ".join(f"{k} = {v}" for k, v in RISK_TEXT.items() if not k.startswith("S05")) + ".",
        "- Notes: " + "; ".join(f"{k} = {v}" for k, v in NOTE_TEXT.items()) + ".",
        f"- Volatility: EXTREME if 10-session vol >= {cfg['vol_ext_ratio']}x the 60-session or ATR% at its "
        f"{cfg['vol_ext_rank']:.0%} rank of {cfg['rank_n']} sessions; ELEVATED at {cfg['vol_elev_ratio']}x / "
        f"{cfg['vol_elev_rank']:.0%}; COMPRESSED at rank <= {cfg['vol_comp_rank']:.0%} with ratio <= "
        f"{cfg['vol_comp_ratio']}; else NORMAL.",
        "- Volume-based signs (flow, divergence with price) are CANDIDATES read from OHLCV; they never establish "
        "accumulation or distribution.", "",
        "## Every condition", ""] + [f"- `{k}`: {v}" for k, v in sorted(txt.items())] + [
        "", "## Settings (STATE_CFG)", "", "```", json.dumps(cfg, indent=1, default=str), "```", ""]
    return "\n".join(L)


def show_text(ss: StateSeries, i: int, sessions: int = 30) -> str:
    r = ss.row(i)
    txt = {**cond_text(ss.cfg), **EXTRA_TEXT}
    f2 = (lambda x, f="{:+.2f}": f.format(x) if np.isfinite(x) else "n/a")
    L = [f"{ss.sym} on {r['date']:%a %d %b %Y} ({r['bars']} sessions of bars)", "  " + r["headline"]]
    if r["state"] in STATES:
        L.append(f"  began {r['began']:%d %b %Y}, confirmed {r['confirmed']:%d %b %Y}; before it: {r['prev_state'] or '-'}"
                 f"; support {r['support']:.0%}, conflicts {r['conflicts']}, completeness {r['completeness']:.0%}")
        L.append(f"  invalidation: {r['invalidation']}")
        ev = ss.evidence(i)
        for part in ("required", "supporting", "conflicting"):
            L.append(f"  {part}:")
            for k, v in ev[part]:
                mark = "yes" if v == 1 else ("no " if v == 0 else "n/a")
                L.append(f"    [{mark}] {txt.get(k, k)}")
    elif r["state"] == "UNKNOWN":
        L.append("  why: " + r["unknown_why"])
    if r["event_text"]:
        L.append("  event: " + r["event_text"])
    L.append(f"  measurements: EMA20 {f2(r['d20'])} ATR, EMA50 {f2(r['d50'])}, EMA200 {f2(r['d200'])}; slopes EMA20 "
             f"{f2(r['s20'])}, EMA50 {f2(r['s50'])} ATR; efficiency {f2(r['eff20'])}; RSI {f2(r['rsi14'], '{:.0f}')}; "
             f"20d {f2(r['r20'] * 100, '{:+.1f}')}%; ATR {f2(r['atr_pct'] * 100, '{:.2f}')}% (rank "
             f"{f2(r['atr_rank'], '{:.0%}')}); vol ratio {f2(r['vol_ratio'], '{:.2f}')}; rel. volume "
             f"{f2(r['rvol'], '{:.2f}')}; volume flow {f2(r['flow20'])}")
    L.append("  recent transitions: " + (", ".join(f"{a:%d %b}->{b:%d %b} {f}->{t}" for a, b, f, t in ss.history(i)) or "none"))
    L.append(f"  last {sessions} sessions (date, close, raw -> confirmed, event):")
    for j in range(max(0, i - sessions + 1), i + 1):
        e = f"{ss.ev_kind[j]}:{ss.ev_status[j]}" if ss.ev_kind[j] else ""
        L.append(f"    {ss.day(j):%Y-%m-%d} {ss.c[j]:>10,.2f}  {ss.raw[j]:<18} {ss.state[j]:<18} {e}")
    return "\n".join(L)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="tradelab stock states")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s1 = sub.add_parser("show", help="one stock's state on a day, with the evidence and the last sessions")
    s1.add_argument("--root")
    s1.add_argument("--symbol", required=True)
    s1.add_argument("--date", default=None)
    s1.add_argument("--sessions", type=int, default=30)
    s1.add_argument("--stage-e-any", action="store_true")
    s2 = sub.add_parser("rules", help="write the rules (STATE_RULES.md)")
    s2.add_argument("--out", default=None)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "rules":
            md = rules_md()
            if a.out:
                Path(a.out).write_text(md, encoding="utf-8")
                say(f"wrote {a.out}")
            else:
                print(md)
            return 0
        import tl_data as D
        root = require_root(a.root)
        m = D.Market(root, D.Production(stage_e_any=a.stage_e_any))
        ds = m.series(a.symbol.strip().upper())
        if ds is None:
            raise TLError(f"no daily bars for {a.symbol} in {root}")
        ss = StateSeries(ds.sym, ds.dates, ds.o, ds.h, ds.l, ds.c, ds.v)
        i = ss.n - 1 if a.date is None else ss.idx_on_or_before(parse_day(a.date))
        if i < 0:
            raise TLError(f"{a.symbol} has no bar on or before {a.date}")
        print(show_text(ss, i, a.sessions))
        return 0
    except TLError as e:
        print(f"ERROR: {e}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
