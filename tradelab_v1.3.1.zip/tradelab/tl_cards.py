"""
tl_cards.py - tradelab v1.1: readable trade cards and the market diary, from an export folder (recomputes nothing).

    python tl_cards.py --export C:\\QuantData\\tradelab\\export\\TLX_20261024_001 --worst 20
    python tl_cards.py --export ...TLX_... --trade D-20240425-2 --trade ENS-20250102-1
    python tl_cards.py --export ...TLX_... --day 2024-06-04            (every pick of that signal day)
    python tl_cards.py --export ...TLX_... --symbol RELIANCE --ranks 1-3
    python tl_cards.py --export ...TLX_... --where "pick_day_small_ret < -0.015 and engine == 'D'" --best 10
    python tl_cards.py --export ...TLX_... --diary 2024-06-01 2024-06-30

Each card tells one trade as a chain:
  1. the market before the pick (the day before and the pick day: NIFTY, Midcap, Smallcap, VIX, breadth, regime)
  2. the pick (engine, rank, score, size class, the index it moves with)
  3. day by day: the stock next to NIFTY / Midcap / Smallcap / VIX, and the held part of each day split into the
     market part (beta x its home index) and the stock part
  4. the verdict: gross and net, the market over the hold, market part vs stock part
Writes <export>\\cards\\cards_<what>.md and .html (the HTML has a chart: the stock against the three indices from the
pick-day close). Selections: --engine, --ranks (default 1-3), --from / --to, --where (a pandas query on trades),
then --best N / --worst N (by net), or all matching (up to --max, default 200).
"""
from __future__ import annotations

import argparse
import html
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import TLError, VERSION, parse_day, parse_ranks, say, write_outputs_sha
import tl_context as C
from tl_context import DRIVER_TEXT, day_label, fin, pct, pts

TOOL = "tl_cards v1.3"
LINE_COLORS = {"stock": "#24292f", "nifty": "#1f6feb", "mid": "#9a6700", "small": "#d1242f"}


def _g(r: dict, k: str, default=None):
    v = r.get(k, default)
    if v is None:
        return default
    if isinstance(v, float) and np.isnan(v):
        return default
    return v


def _num(x, fmt: str = "{:.2f}") -> str:
    return fmt.format(float(x)) if fin(x) else "n/a"


def _bp(x) -> str:
    return f"{float(x):+.0f}" if fin(x) else "n/a"


# ----------------------------------------------------------------------
# one card
# ----------------------------------------------------------------------
def card_md(t: dict, days: pd.DataFrame, mkt: pd.DataFrame) -> str:
    """Markdown card for one trade row (trades), its trade_days rows and the market_days table."""
    tid, sym = t.get("trade_id"), t.get("symbol")
    st = t.get("status")
    head = f"## {tid} - {sym} - "
    head += (f"net {_bp(t.get('net_bp'))} bp (gross {pct(t.get('post_gross_ret'), 2)})" if st == "ok" else f"status {st}")
    if _g(t, "outcome"):
        head += f" - {str(t['outcome']).replace('_', ' ').upper()}"
    L = [head, ""]
    prof = [f"{t.get('engine')} rank {int(t['rank']) if fin(t.get('rank')) else '?'}"]
    if fin(t.get("score")):
        prof[-1] += f" (score {float(t['score']):.3f})"
    if fin(t.get("other_rank")):
        prof.append(f"the other engine ranked it {int(t['other_rank'])}")
    sc = _g(t, "pre_size_class", "")
    if sc in ("large", "mid", "small"):
        prof.append(f"size: {sc.upper()} cap ({_g(t, 'pre_amfi_list', 'AMFI')}, AMFI rank "
                    f"{int(t['pre_amfi_rank']) if fin(t.get('pre_amfi_rank')) else '?'})")
    elif sc:
        prof.append(f"size: {sc} (no AMFI class)")
    if _g(t, "pre_home_index_name"):
        prof.append(f"moves most with {t['pre_home_index_name']} (beta {_num(t.get('pre_beta_home'))}, correlation "
                    f"{_num(t.get('pre_corr_home'))}; NIFTY beta {_num(t.get('pre_beta_nifty'))}, Smallcap beta "
                    f"{_num(t.get('pre_beta_small'))})")
    L += ["- " + " | ".join(prof), ""]
    # 1. the market before the pick (known before entry)
    L += ["**1. The market before entry** (known at the pick day's close)", ""]
    md = mkt.set_index("date")
    for lbl, dcol in (("Day before", "pre_prev_date"), ("Pick day", "signal_day")):
        d = t.get(dcol)
        if d is None or pd.isna(d):
            continue
        d = pd.Timestamp(d).normalize()
        if d in md.index:
            L.append(f"- {lbl}: {C.day_sentence({**md.loc[d].to_dict(), 'date': d})}")
    sline = f"- The stock: day before {pct(t.get('pre_prev_stock_ret'))}, pick day {pct(t.get('pre_stock_ret'))}"
    if fin(t.get("pre_stock_minus_home")):
        sline += f" ({pts(t.get('pre_stock_minus_home'))} vs {t.get('pre_home_index_name') or 'its index'})"
    L.append(sline)
    if _g(t, "pre_state"):
        import tl_state as ST
        L.append(f"- Its state (tl_state, known at the pick day's close): {ST.pick_headline(t)}")
    if _g(t, "warnings_fired"):
        L.append(f"- Warning signs that fired before entry: {t['warnings_fired']}")
    if fin(t.get("pre_context_complete")) and float(t["pre_context_complete"]) < 1:
        L.append(f"- Incomplete market data before entry: {_g(t, 'pre_missing', '') or 'see market_days'} (left blank, "
                 f"never filled)")
    L.append("")
    # 2. forecasts (if any)
    fc = {k: v for k, v in t.items() if (k.startswith("pred_") or k.startswith("prob_")) and fin(v)}
    if fc:
        L += ["**2. What the model expected** (pick_meta's forecasts, made at the pick)", "",
              "- " + ", ".join(f"{k} {float(v):.3f}" for k, v in sorted(fc.items())), ""]
    else:
        L += ["**2. What the model expected** - no forecasts recorded for this pick", ""]
    # 3. day by day (observed during the trade)
    L += ["**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after "
          "entry)", "",
          "| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home "
          "| held: market / stock bp | pos | day P&L bp | total bp | trades |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in days.to_dict("records"):
        s_ = int(r["session"])
        oc = r["close"] / r["open"] - 1 if fin(r.get("open")) and r["open"] else np.nan
        split = (f"{_bp(r.get('mkt_part_day_bp'))} / {_bp(r.get('stock_part_day_bp'))}" if fin(r.get("held_ret")) else "")
        tr = " ".join(x for x in (r.get("buys") and f"buy {r['buys'].split('@')[0]}",
                                  r.get("sells") and f"sell {r['sells'].split('@')[0]}") if x)
        env = C.ENV_TEXT.get(r.get("environment") or "", "n/a")
        L.append(f"| {s_} | {pd.Timestamp(r['date']).strftime('%a %d %b')} | {pct(r.get('day_ret'))} | {pct(oc)} | "
                 f"{pct(r.get('nifty_day_ret'))} | {pct(r.get('mid_day_ret'))} | {pct(r.get('small_day_ret'))} | "
                 f"{_num(r.get('ad_ratio'))} | {_num(r.get('vix_close'), '{:.1f}')} | {env} | {pts(r.get('rel_home_day'))} | "
                 f"{split} | {float(r.get('pos', 0)):.0%} | {_bp(r.get('day_pnl_bp'))} | {_bp(r.get('cum_pnl_bp'))} | {tr} |")
    L.append("")
    # 4. verdict (observed after entry)
    L += ["**4. Verdict** (observed after entry)", ""]
    if st == "ok":
        L.append(f"- Bought {day_label(t.get('entry_day'))} at the open {_num(t.get('entry'))}; sold "
                 f"{day_label(t.get('exit_day'))} at the {'close' if t.get('exit_kind') == 'close' else 'open'} "
                 f"{_num(t.get('exit_price'))}{' (lower-circuit lock: sold at the first free open)' if t.get('locked_exit') else ''}. "
                 f"Gross {pct(t.get('post_gross_ret'), 2)}, costs {_bp(t.get('post_cost_bp'))} bp, net {_bp(t.get('net_bp'))} bp.")
        hold = (f"- Over the same hold: NIFTY {pct(t.get('post_hold_nifty_ret'))}, Midcap {pct(t.get('post_hold_mid_ret'))}, "
                f"Smallcap {pct(t.get('post_hold_small_ret'))}; VIX {pct(t.get('post_hold_vix_chg_pct'))}")
        if fin(t.get("post_hold_ad_ratio_avg")):
            hold += f"; breadth averaged {float(t['post_hold_ad_ratio_avg']):.2f}"
        if fin(t.get("post_hold_stress_days")):
            hold += f"; {int(t['post_hold_stress_days'])} high-stress session(s)"
        L.append(hold + ".")
        L.append(f"- Against each index (gross minus the index): NIFTY {_bp(t.get('post_excess_vs_nifty_bp'))} bp, "
                 f"Midcap {_bp(t.get('post_excess_vs_mid_bp'))} bp, Smallcap {_bp(t.get('post_excess_vs_small_bp'))} bp.")
        if fin(t.get("post_mkt_part_bp")):
            L.append(f"- Split: market part {pct(float(t['post_mkt_part_bp']) / 1e4, 2)} = beta {_num(t.get('pre_beta_home'))} x "
                     f"{t.get('pre_home_index_name')} {pct(t.get('post_hold_home_ret'), 2)}; stock part "
                     f"{pct(float(t['post_stock_part_bp']) / 1e4, 2)} -> "
                     f"**{DRIVER_TEXT.get(t.get('post_driver'), t.get('post_driver'))}**.")
        held = days[np.isfinite(days["stock_part_day_bp"].to_numpy(float))] if "stock_part_day_bp" in days \
            else days.iloc[0:0]
        if len(held):
            bb = held.loc[held["stock_part_day_bp"].astype(float).idxmax()]
            ww = held.loc[held["stock_part_day_bp"].astype(float).idxmin()]
            L.append(f"- The stock's own strongest day: session {int(bb['session'])} ({_bp(bb['stock_part_day_bp'])} bp "
                     f"beyond its market); weakest: session {int(ww['session'])} ({_bp(ww['stock_part_day_bp'])} bp).")
    else:
        L.append(f"- Not a finished trade ({st}).")
    L += ["", f"_{_g(t, 'story', '')}_", ""]
    return "\n".join(L)


def card_svg(t: dict, days: pd.DataFrame, mkt: pd.DataFrame) -> str:
    """The stock and the three indices, % from the pick-day close, one point per session."""
    md = mkt.set_index("date")
    d0 = pd.Timestamp(t["signal_day"]).normalize()
    if d0 not in md.index or not fin(t.get("signal_close")):
        return ""
    ser = {"stock": [], "nifty": [], "mid": [], "small": []}
    labels = []
    for r in days.to_dict("records"):
        d = pd.Timestamp(r["date"]).normalize()
        labels.append((int(r["session"]), d))
        ser["stock"].append(r["close"] / t["signal_close"] - 1)
        for k in ("nifty", "mid", "small"):
            a, b = (md.loc[d, f"{k}_close"] if d in md.index else np.nan), md.loc[d0, f"{k}_close"]
            ser[k].append(a / b - 1 if fin(a) and fin(b) else np.nan)
    allv = np.array([v for s in ser.values() for v in s if fin(v)] + [0.0])
    lo, hi = float(allv.min()), float(allv.max())
    pad = (hi - lo) * 0.08 or 0.01
    lo, hi = lo - pad, hi + pad
    Wd, Ht, ML, MR, MT, MB = 720, 240, 56, 110, 14, 30
    n = len(labels)
    x = lambda i: ML + (Wd - ML - MR) * (i / max(1, n - 1))
    y = lambda v: MT + (Ht - MT - MB) * (1 - (v - lo) / (hi - lo))
    P = [f'<svg viewBox="0 0 {Wd} {Ht}" xmlns="http://www.w3.org/2000/svg" font-family="Segoe UI, Arial" font-size="11">',
         f'<rect x="{ML}" y="{MT}" width="{Wd - ML - MR}" height="{Ht - MT - MB}" fill="#fafbfc" stroke="#d0d7de"/>',
         f'<line x1="{ML}" x2="{Wd - MR}" y1="{y(0):.1f}" y2="{y(0):.1f}" stroke="#8c959f" stroke-dasharray="3,3"/>']
    for k in range(5):
        v = lo + (hi - lo) * k / 4
        P.append(f'<text x="{ML - 6}" y="{y(v) + 4:.1f}" text-anchor="end" fill="#57606a">{v * 100:+.1f}%</text>')
    for i, (s_, d) in enumerate(labels):
        P.append(f'<text x="{x(i):.1f}" y="{Ht - 12}" text-anchor="middle" fill="#57606a">s{s_}</text>')
        if s_ == 1:
            P.append(f'<line x1="{x(i):.1f}" x2="{x(i):.1f}" y1="{MT}" y2="{Ht - MB}" stroke="#1a7f37" stroke-dasharray="2,3"/>')
    xs = t.get("sessions_held")
    if fin(xs):
        i = [k for k, (s_, _) in enumerate(labels) if s_ == int(xs)]
        if i:
            P.append(f'<line x1="{x(i[0]):.1f}" x2="{x(i[0]):.1f}" y1="{MT}" y2="{Ht - MB}" stroke="#cf222e" stroke-dasharray="2,3"/>')
    names = {"stock": str(t.get("symbol")), "nifty": "NIFTY 50", "mid": "Midcap 150", "small": "Smallcap 250"}
    for j, (k, vals) in enumerate(ser.items()):
        pts_ = " ".join(f"{x(i):.1f},{y(v):.1f}" for i, v in enumerate(vals) if fin(v))
        if pts_:
            P.append(f'<polyline points="{pts_}" fill="none" stroke="{LINE_COLORS[k]}" stroke-width="{2.2 if k == "stock" else 1.4}"/>')
        last = next((v for v in reversed(vals) if fin(v)), None)
        P.append(f'<text x="{Wd - MR + 8}" y="{MT + 14 + 16 * j}" fill="{LINE_COLORS[k]}">{html.escape(names[k])}'
                 f'{"" if last is None else f" {last * 100:+.1f}%"}</text>')
    P.append("</svg>")
    return "".join(P)


def _md_to_html(md: str) -> str:
    """Just enough markdown for the cards: headings, bold, italics, bullets, tables."""
    out, in_tab, in_ul = [], False, False
    for line in md.splitlines():
        esc = html.escape(line)
        esc = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", esc)
        esc = re.sub(r"(?<![\w*])_(.+?)_(?![\w*])", r"<i>\1</i>", esc)
        if line.startswith("|"):
            if set(line.replace("|", "").strip()) <= set("-: "):
                continue
            cells = [c.strip() for c in esc.strip("|").split("|")]
            tag = "th" if not in_tab else "td"
            if not in_tab:
                out.append("<table>")
                in_tab = True
            out.append("<tr>" + "".join(f"<{tag}>{c}</{tag}>" for c in cells) + "</tr>")
            continue
        if in_tab:
            out.append("</table>")
            in_tab = False
        if line.startswith("- "):
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{esc[2:]}</li>")
            continue
        if in_ul:
            out.append("</ul>")
            in_ul = False
        if line.startswith("## "):
            out.append(f"<h2>{esc[3:]}</h2>")
        elif line.startswith("# "):
            out.append(f"<h1>{esc[2:]}</h1>")
        elif line.strip():
            out.append(f"<p>{esc}</p>")
    if in_tab:
        out.append("</table>")
    if in_ul:
        out.append("</ul>")
    return "\n".join(out)


CSS = ("body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#24292f;max-width:1180px}"
       "h1{font-size:20px}h2{font-size:16px;border-top:1px solid #d0d7de;padding-top:14px;margin-top:28px}"
       "table{border-collapse:collapse;font-size:12px;margin:6px 0}td,th{border:1px solid #d0d7de;padding:3px 6px;"
       "text-align:right}th{background:#f6f8fa}td:nth-child(2){text-align:left}p,li{font-size:13px;line-height:1.45}"
       ".toc a{margin-right:10px;font-size:12px}")


def write_cards(out_dir: Path, name: str, sel: pd.DataFrame, days: pd.DataFrame, mkt: pd.DataFrame,
                title: str) -> List[str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    mkt = mkt.copy()
    mkt["date"] = pd.to_datetime(mkt["date"]).dt.normalize()
    days = days.copy()
    by = {k: g.sort_values("session") for k, g in days.groupby("trade_id", sort=False)}
    mds, hts = [f"# {title}", "", _legend_md(), ""], []
    for t in sel.to_dict("records"):
        dd = by.get(t["trade_id"], days.iloc[0:0])
        c = card_md(t, dd, mkt)
        mds.append(c)
        svg = card_svg(t, dd, mkt)
        hts.append((t["trade_id"], _md_to_html(c), svg))
    md_path = out_dir / f"{name}.md"
    md_path.write_text("\n".join(mds) + "\n", encoding="utf-8")
    toc = " ".join(f'<a href="#{html.escape(tid)}">{html.escape(tid)}</a>' for tid, _, _ in hts)
    body = "".join(f'<div id="{html.escape(tid)}">{h}{svg}</div>' for tid, h, svg in hts)
    page = (f"<!doctype html><html><head><meta charset='utf-8'><title>{html.escape(title)}</title><style>{CSS}</style>"
            f"</head><body><h1>{html.escape(title)}</h1>{_md_to_html(_legend_md())}<div class='toc'>{toc}</div>{body}"
            f"</body></html>")
    (out_dir / f"{name}.html").write_text(page, encoding="utf-8")
    return [md_path.name, f"{name}.html"]


def _legend_md() -> str:
    return ("How to read a card: s = session (0 = the pick day, the model ranks at its close; 1 = entry day, bought at "
            "the open; 5 = sold at the close unless the lower circuit locked it). Sections 1-2 were known BEFORE "
            "entry; sections 3-4 were observed after. Breadth = advancers / (advancers + decliners) over the cached "
            "stocks. 'stock - home' = the stock's day return minus its home index's. 'held: market / stock bp' = the "
            "part of the day the position was held, split into beta x the home index (market) and the rest (stock). "
            "Size = AMFI's list in force on the pick day (blank when none was given - never filled). Environment "
            "labels and the high-stress flag are defined in tl_context.py (declared 24 Oct 2026).")


# ----------------------------------------------------------------------
# command line
# ----------------------------------------------------------------------
def select(T: pd.DataFrame, a) -> pd.DataFrame:
    X = T.copy()
    X["signal_day"] = pd.to_datetime(X["signal_day"])
    if a.engine:
        X = X[X["engine"].isin(a.engine)]
    if a.ranks:
        X = X[X["rank"].isin(parse_ranks(a.ranks))]
    if a.d_from:
        X = X[X["signal_day"] >= pd.Timestamp(str(parse_day(a.d_from)))]
    if a.d_to:
        X = X[X["signal_day"] <= pd.Timestamp(str(parse_day(a.d_to)))]
    if a.symbol:
        X = X[X["symbol"].isin([s.upper() for s in a.symbol])]
    if a.day:
        X = X[X["signal_day"].isin([pd.Timestamp(str(parse_day(d))) for d in a.day])]
    if a.where:
        try:
            X = X.query(a.where, engine="python")
        except Exception as e:  # noqa: BLE001
            raise TLError(f"--where '{a.where}' failed ({type(e).__name__}: {e}); use trades.csv column names")
    if a.trade:
        X = T[T["trade_id"].isin(a.trade)].copy()
        miss = sorted(set(a.trade) - set(X["trade_id"]))
        if miss:
            raise TLError(f"unknown trade ids {miss[:5]}")
    if a.best:
        X = X[X["status"] == "ok"].sort_values("net_bp", ascending=False).head(a.best)
    elif a.worst:
        X = X[X["status"] == "ok"].sort_values("net_bp", ascending=True).head(a.worst)
    if len(X) > a.max:
        say(f"note: {len(X):,} trades match; writing the first {a.max} (raise --max for more)")
        X = X.head(a.max)
    return X


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="tradelab cards: trades told as a chain, and the market diary")
    ap.add_argument("--export", required=False, help="an export folder (TLX_YYYYMMDD_NNN)")
    ap.add_argument("--trade", action="append", default=[])
    ap.add_argument("--symbol", action="append", default=[])
    ap.add_argument("--day", action="append", default=[])
    ap.add_argument("--engine", nargs="+", default=None)
    ap.add_argument("--ranks", default="1-3")
    ap.add_argument("--from", dest="d_from", default=None)
    ap.add_argument("--to", dest="d_to", default=None)
    ap.add_argument("--where", default="")
    ap.add_argument("--best", type=int, default=0)
    ap.add_argument("--worst", type=int, default=0)
    ap.add_argument("--max", type=int, default=200)
    ap.add_argument("--diary", nargs=2, metavar=("FROM", "TO"), default=None)
    ap.add_argument("--name", default="")
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if not a.export:
            raise TLError("--export is required (an export folder, e.g. C:\\QuantData\\tradelab\\export\\TLX_20261024_001)")
        ex = Path(a.export)
        need = [ex / "trades.parquet", ex / "trade_days.parquet", ex / "market_days.parquet"]
        miss = [p.name for p in need if not p.exists()]
        if miss:
            raise TLError(f"{ex} lacks {miss} - run tl_export.py v1.1 (with market context) first")
        T = pd.read_parquet(need[0])
        Dd = pd.read_parquet(need[1])
        M = pd.read_parquet(need[2])
        out = ex / "cards"
        if a.diary:
            lo, hi = parse_day(a.diary[0]), parse_day(a.diary[1])
            X = M[(pd.to_datetime(M["date"]) >= pd.Timestamp(str(lo))) & (pd.to_datetime(M["date"]) <= pd.Timestamp(str(hi)))]
            nm = a.name or f"diary_{str(lo).replace('-', '')}_{str(hi).replace('-', '')}"
            out.mkdir(parents=True, exist_ok=True)
            (out / f"{nm}.md").write_text(C.diary_md(X, f"Market diary {lo} .. {hi}"), encoding="utf-8")
            for s in X["summary"]:
                say(s)
            write_outputs_sha(ex)                  # the export's fingerprints include the new file
            say(f"DONE {out / (nm + '.md')} ({len(X):,} sessions)")
            return 0
        S = select(T, a)
        if S.empty:
            raise TLError("no trades match the selection")
        nm = a.name or ("cards_" + re.sub(r"[^A-Za-z0-9_-]+", "_", "_".join(
            [*(a.trade or []), *(a.symbol or []), *(a.day or []), f"best{a.best}" if a.best else "",
             f"worst{a.worst}" if a.worst else ""]).strip("_"))[:80]).rstrip("_")
        if nm == "cards":
            nm = "cards_selection"
        files = write_cards(out, nm, S, Dd[Dd["trade_id"].isin(S["trade_id"])], M,
                            f"tradelab trade cards - {len(S)} trades ({ex.name})")
        for t in S.to_dict("records")[:5]:
            say(f"{t['trade_id']}: {t.get('story', '')}")
        write_outputs_sha(ex)                      # the export's fingerprints include the new files
        say(f"DONE {out}: {', '.join(files)} ({len(S):,} cards)")
        return 0
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
