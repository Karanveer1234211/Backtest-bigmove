# tradelab export - PM_20261017_001

tl_export v1.2 (tradelab v1.2), 2026-10-24T18:18:07. Picks: 33,100 (engines ['D', 'ENS'], ranks [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).

## Headline (the plan: buy the session-1 open, sell the session-5 close, honest exits, 35 bp)

- D ranks 1-3: 4,964 finished trades, mean net +108.0 [+57.8, +160.0] bp over 1,655 signal days; excess over buy-everything +123.6 [+91.7, +157.7] bp
- ENS ranks 1-3: 4,964 finished trades, mean net +112.4 [+59.8, +164.5] bp over 1,655 signal days; excess over buy-everything +128.0 [+93.2, +163.2] bp

Intervals: 95% circular block bootstrap over signal days (blocks of 10, 2,000 resamples, seed 7). Same history the engines were built and studied on - a description, not new evidence.

## Reconciliation (safety stop)

- OK - D 16,544 of 16,550 (99.96%), mean net +76.06 bp vs recorded +76.06 (diff +0.0005); MFE/MAE agree on 99.96%; ENS 16,543 of 16,550 (99.96%), mean net +82.11 bp vs recorded +82.11 (diff +0.0000); MFE/MAE agree on 99.96%

## Status of every pick

- ok: 33,098
- stuck: 2

## Mean net by rank (finished trades, bp)

| engine | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| D | +113.4 | +121.9 | +88.7 | +101.5 | +55.4 | +74.7 | +62.3 | +30.5 | +56.9 | +55.4 |
| ENS | +129.8 | +127.8 | +79.6 | +76.3 | +99.2 | +81.4 | +60.6 | +76.7 | +59.9 | +29.9 |

## Files

- trade_day_features.parquet
- trades.parquet
- trades.csv
- trade_days.parquet
- trade_days.csv
- daily_book.parquet
- daily_book.csv
- market_days.parquet
- market_days.csv
- market_diary.md
- context_breakdown.csv
- cards/cards_sample.md
- cards/cards_sample.html
- research/outcome_groups.csv
- research/outcome_profiles.csv
- research/warning_signs.csv
- research/walk_forward.csv
- research/walk_forward_verdicts.csv
- research/book_by_environment.csv
- research/research_report.md
- research/severe_losers.md
- research/severe_losers.html
- research/research_summary.json
- DATA_DICTIONARY.md
- data_dictionary.csv

## Column notes

- Returns (ret_*, mfe, mae, close_ret_sK, open_ret_sK) are fractions of the entry price (session-1 open). P&L columns ending _bp are basis points of the trade's size, after costs.
- mfe / mae: best high / worst low of sessions 1-5 vs entry (pick_meta's definition; mfe_session / mae_session = the session it happened). mfe_held / mae_held: the same while actually held (a locked exit holds longer). touch_* = first session (1-5) whose high / low reached the level; blank = never.
- open6_net_bp: sold at the 6th session's open instead; hold10_net_bp: held to the 10th close (both with honest exits). These are alternatives on the same history, not tested rules.
- trade_days: day_pnl_bp is the change in the trade's marked-to-close P&L that session (half of the 35 bp is charged at the buy, half at the sale); cum_pnl_bp ends at net_bp. Rows after the exit (after_exit) show what the stock did next with no position.
- daily_book: positions are the traded ranks 1-3; 1/15 of capital a slot, additive - a proxy, not the execution simulator.
- Features are panel values at each session's close (the firewall removed labels, forward-looking names and raw price / volume levels). Never use label_* or outcome columns as model inputs.

## Market context (v1.1)

- Indices found: NIFTY 50, Midcap 150, Smallcap 250, India VIX. Missing: none.
- Breadth: counted now; advancers / (advancers + decliners) over 2495 cached stocks, median 1502.0 a session. Not NSE's official count: the cache's coverage, and stocks delisted before the cache was built are missing.
- Size class: BLANK - no AMFI lists given (it is never filled from today's list or a proxy). Put AMFI's half-yearly PDFs in %CACHE_DAILY_ROOT%\sectors\amfi\ and re-run.

### Environment labels (declared 24 Oct 2026, before any real run)

- index_up: close >= its 50-session average
- breadth: 10-session average of advancers / (advancers + decliners), all cached stocks
- breadth_strong: >= 0.5
- broad_bullish: NIFTY, Midcap, Smallcap up and breadth strong
- narrow_bullish: NIFTY up, and Midcap or Smallcap down or breadth weak
- broad_bearish: NIFTY, Midcap, Smallcap down and breadth weak
- mixed: anything else
- high_stress: VIX at or above the 90th percentile of its last 250 sessions, or VIX +25% in 5 sessions, or NIFTY / Smallcap day move >= 2.5 sd (of the previous 60 days)
- size: AMFI half-yearly lists only, each used from the 1st of the second month after its half-year ends (1 Feb / 1 Aug: an ASSUMED, conservative availability - AMFI's publication dates are not recorded; actual dates in amfi_published.csv are used instead, from the next day) until the next half-year's list is due (a missing list leaves the size blank; never carried forward)
- sensitivity: beta and correlation of daily returns, 120 sessions to the pick day (>= 60 returns)

### Where the P&L came from (ranks 1-3, the plan)

Market part = beta to the home index x that index over exactly the same hold; stock part = the rest. Intervals: 95% block bootstrap over signal days.

- **D** (4,964 trades; complete pre-entry context on 100.0%): gross +143.0 [+92.8, +195.0] bp = market part +9.4 [-33.3, +48.0] + stock part **+133.6 [+99.6, +169.5]** bp. vs NIFTY +129.2 [+88.1, +171.0], vs Smallcap +124.8 [+90.7, +160.3], vs home +127.1 [+92.9, +163.7] bp. High stress at the pick: 14.4% of trades.
  - environment at the pick: broad_bullish 31%, narrow_bullish 27%, high_stress 14%, broad_bearish 14%, mixed 13%
  - driver: stock 51%, opposite 16%, market 15%, both 15%, flat 3%
  - size (AMFI): no list 100%
  - home index: Smallcap 250 71%, Midcap 150 20%, NIFTY 50 9%
- **ENS** (4,964 trades; complete pre-entry context on 100.0%): gross +147.4 [+94.8, +199.5] bp = market part +111.3 [-22.7, +339.6] + stock part **+36.1 [-189.5, +165.3]** bp. vs NIFTY +133.8 [+90.3, +175.7], vs Smallcap +129.4 [+92.9, +166.6], vs home +131.8 [+95.0, +169.1] bp. High stress at the pick: 14.4% of trades.
  - environment at the pick: broad_bullish 31%, narrow_bullish 27%, high_stress 14%, broad_bearish 14%, mixed 13%
  - driver: stock 51%, opposite 17%, both 15%, market 15%, flat 2%, (blank) 0%
  - size (AMFI): no list 100%
  - home index: Smallcap 250 72%, Midcap 150 20%, NIFTY 50 8%, (blank) 0%

### The chain: the market before entry -> the trade -> the market during it

Each table groups the traded picks (means in bp, 95% intervals; win = share with net > 0; severe = share with net <= -500 bp). 'Known BEFORE entry' tables could in principle choose trades - but these are the same 2020-2026 years the engines were built on and many tables are shown, so a difference is a hypothesis (research\research_report.md tests the declared warning signs out of sample). 'Observed AFTER entry' tables explain outcomes and can never select. Nothing here filters trades.

#### engine D

**environment at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,539 | 31% | +91.1 [+27.4, +150.9] | +101.0 [+53.5, +146.3] | +21.4 [-15.1, +56.5] | +104.8 [+56.8, +151.1] | 49% | 14.1% |
| narrow_bullish | 1,350 | 27% | +118.1 [+53.6, +181.3] | +117.0 [+68.8, +164.9] | +30.8 [-10.9, +70.7] | +122.3 [+75.3, +169.1] | 51% | 16.7% |
| mixed | 657 | 13% | +69.6 [-38.8, +173.9] | +136.7 [+64.2, +209.9] | -52.9 [-133.5, +15.9] | +157.4 [+81.8, +229.8] | 48% | 21.6% |
| broad_bearish | 704 | 14% | +82.7 [-69.9, +231.9] | +121.1 [+27.8, +218.8] | +8.5 [-96.3, +112.3] | +109.2 [+10.9, +209.3] | 51% | 25.0% |
| high_stress | 714 | 14% | +185.6 [-33.5, +403.0] | +175.4 [+73.9, +290.6] | +1.5 [-228.2, +180.9] | +219.1 [+105.6, +354.6] | 57% | 20.9% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,250 | 86% | +95.0 [+52.4, +142.5] | +114.9 [+83.8, +150.7] | +10.8 [-18.4, +41.4] | +119.2 [+87.9, +154.2] | 49% | 17.9% |
| yes | 714 | 14% | +185.6 [-33.5, +403.0] | +175.4 [+73.9, +290.6] | +1.5 [-228.2, +180.9] | +219.1 [+105.6, +354.6] | 57% | 20.9% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,629 | 33% | +82.0 [+21.0, +143.5] | +98.8 [+53.9, +145.7] | +13.9 [-21.2, +48.1] | +103.1 [+57.2, +150.9] | 48% | 14.9% |
| narrow_bullish | 1,524 | 31% | +133.0 [+73.4, +197.3] | +119.6 [+76.9, +164.8] | +46.2 [+0.6, +93.0] | +121.8 [+81.0, +165.4] | 52% | 16.5% |
| mixed | 786 | 16% | +139.6 [+36.5, +243.4] | +161.8 [+85.2, +246.7] | -3.1 [-77.2, +63.5] | +177.7 [+94.4, +266.1] | 50% | 20.5% |
| broad_bearish | 1,025 | 21% | +87.9 [-70.5, +243.6] | +139.8 [+61.2, +221.4] | -42.8 [-208.2, +87.7] | +165.7 [+72.1, +268.4] | 53% | 25.0% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < 0.40 | 525 | 11% | +154.4 [-147.3, +388.2] | +216.1 [+85.0, +337.2] | -90.3 [-392.5, +131.8] | +279.7 [+160.9, +413.2] | 58% | 25.7% |
| 0.40 - 0.50 | 2,372 | 48% | +99.0 [+38.8, +160.8] | +112.6 [+72.2, +154.1] | +18.6 [-30.0, +66.1] | +115.3 [+73.5, +157.2] | 50% | 19.3% |
| 0.50 - 0.60 | 1,878 | 38% | +93.9 [+39.2, +148.1] | +104.8 [+65.0, +144.9] | +19.2 [-16.5, +55.7] | +109.7 [+68.7, +150.0] | 49% | 15.0% |
| >= 0.60 | 189 | 4% | +232.1 [+84.8, +394.6] | +192.2 [+70.6, +321.2] | +73.5 [+1.0, +151.1] | +193.5 [+64.9, +334.2] | 56% | 18.5% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -10% | 651 | 13% | +193.3 [+54.0, +347.5] | +162.6 [+54.1, +279.4] | +62.7 [+1.7, +123.0] | +165.6 [+52.3, +287.9] | 52% | 15.8% |
| -10% .. 0% | 1,977 | 40% | +88.0 [+32.2, +140.8] | +114.0 [+73.1, +154.5] | +4.3 [-35.5, +41.6] | +118.7 [+75.9, +162.3] | 49% | 16.9% |
| 0% .. +10% | 1,566 | 32% | +119.2 [+51.3, +193.1] | +124.5 [+71.7, +183.7] | +26.6 [-15.8, +64.6] | +127.6 [+73.1, +187.7] | 51% | 19.0% |
| +10% .. +25% | 626 | 13% | +115.9 [-0.5, +232.7] | +119.4 [+52.2, +188.9] | +28.2 [-68.5, +114.2] | +122.7 [+55.3, +190.0] | 52% | 20.3% |
| >= +25% | 144 | 3% | -159.6 [-798.0, +386.9] | +89.1 [-142.8, +278.0] | -429.6 [-1163.4, +201.8] | +304.9 [+115.0, +565.7] | 49% | 33.3% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,446 | 29% | +54.4 [-8.3, +118.2] | +79.4 [+36.2, +125.7] | +11.0 [-29.5, +50.6] | +78.5 [+32.1, +126.0] | 46% | 17.8% |
| -3 .. 0 pts | 1,640 | 33% | +126.1 [+61.0, +188.9] | +138.6 [+93.0, +185.7] | +22.4 [-23.2, +65.7] | +138.7 [+93.1, +184.6] | 52% | 15.8% |
| 0 .. +3 pts | 1,122 | 23% | +78.0 [-53.3, +199.3] | +120.8 [+56.3, +189.2] | -45.6 [-185.0, +61.4] | +158.5 [+91.2, +231.9] | 50% | 21.3% |
| >= +3 pts (NIFTY ahead: narrow) | 756 | 15% | +215.6 [+56.6, +391.2] | +180.0 [+78.5, +294.5] | +59.8 [-26.9, +146.4] | +190.8 [+84.8, +314.6] | 56% | 20.5% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no list | 4,964 | 100% | +108.0 [+57.8, +160.0] | +123.6 [+91.7, +157.7] | +9.4 [-33.3, +48.0] | +133.6 [+99.6, +169.5] | 50% | 18.3% |

**home index** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| NIFTY 50 | 446 | 9% | +128.6 [-8.8, +265.2] | +133.8 [+3.9, +271.1] | +17.0 [-11.4, +44.6] | +146.6 [+12.0, +280.2] | 45% | 9.4% |
| Midcap 150 | 993 | 20% | +47.3 [-22.6, +116.5] | +40.0 [-20.5, +99.7] | +32.2 [-10.7, +73.2] | +50.1 [-18.8, +117.8] | 49% | 18.0% |
| Smallcap 250 | 3,525 | 71% | +122.5 [+67.0, +178.5] | +145.9 [+111.1, +180.0] | +2.0 [-44.9, +48.8] | +155.5 [+117.8, +193.4] | 52% | 19.5% |

**environment on the entry day** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,536 | 31% | +114.6 [+53.3, +172.7] | +94.5 [+45.0, +143.4] | +48.9 [+16.2, +80.2] | +100.7 [+52.0, +149.9] | 50% | 13.3% |
| narrow_bullish | 1,350 | 27% | +117.8 [+59.1, +174.9] | +120.9 [+71.3, +167.4] | +32.7 [-7.7, +71.0] | +120.1 [+73.4, +164.5] | 50% | 17.2% |
| mixed | 657 | 13% | +108.0 [+4.7, +208.1] | +147.0 [+75.1, +222.4] | -14.5 [-77.0, +43.6] | +157.4 [+86.5, +227.4] | 48% | 18.3% |
| broad_bearish | 707 | 14% | +59.5 [-104.3, +209.3] | +125.7 [+26.6, +228.4] | -29.5 [-133.9, +63.7] | +124.0 [+25.2, +228.2] | 50% | 27.2% |
| high_stress | 714 | 14% | +123.3 [-98.9, +347.2] | +167.9 [+61.3, +286.9] | -59.1 [-296.6, +121.1] | +217.4 [+103.7, +354.1] | 53% | 22.7% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3% | 664 | 13% | -574.3 [-706.3, -463.3] | -25.8 [-102.7, +46.9] | -627.2 [-812.0, -493.2] | +87.8 [+0.6, +189.7] | 21% | 53.3% |
| -3% .. -1% | 779 | 16% | -101.4 [-167.6, -36.1] | +124.1 [+60.4, +187.0] | -192.2 [-210.6, -173.8] | +125.8 [+66.1, +191.2] | 34% | 23.9% |
| -1% .. +1% | 1,494 | 30% | +115.9 [+68.0, +163.7] | +143.4 [+96.1, +191.8] | +3.8 [-4.8, +11.5] | +147.1 [+99.7, +196.3] | 51% | 13.3% |
| +1% .. +3% | 1,341 | 27% | +276.1 [+216.8, +337.4] | +116.3 [+59.9, +175.0] | +189.0 [+173.9, +205.2] | +122.1 [+69.0, +176.2] | 60% | 9.3% |
| >= +3% | 686 | 14% | +660.5 [+528.4, +803.3] | +239.1 [+127.2, +351.1] | +515.8 [+456.8, +576.4] | +179.7 [+52.3, +308.5] | 77% | 6.7% |

**what drove the trade** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| market | 744 | 15% | -108.7 [-231.1, +4.8] | -25.9 [-64.4, +9.3] | -90.0 [-228.8, +31.3] | +16.4 [-4.7, +42.3] | 49% | 22.4% |
| stock | 2,535 | 51% | +243.1 [+182.3, +308.2] | +240.5 [+183.1, +298.7] | +30.3 [+16.8, +43.8] | +247.8 [+189.4, +307.8] | 57% | 21.3% |
| both | 720 | 15% | +71.0 [-42.5, +178.0] | +64.9 [-0.8, +125.5] | +41.7 [-14.5, +92.5] | +64.3 [+5.0, +119.2] | 57% | 26.0% |
| opposite | 800 | 16% | -56.4 [-78.0, -37.7] | -30.3 [-77.4, +16.8] | +8.1 [-84.1, +90.9] | -29.5 [-107.5, +54.3] | 33% | 2.0% |
| flat | 165 | 3% | -32.3 [-36.1, -28.8] | +4.3 [-27.2, +41.6] | +2.3 [-0.2, +5.6] | +0.4 [-4.1, +4.0] | 3% | 0.0% |

#### engine ENS

**environment at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,539 | 31% | +87.2 [+24.6, +145.6] | +97.1 [+50.2, +143.4] | +15.7 [-18.8, +47.5] | +106.6 [+61.6, +150.4] | 50% | 14.2% |
| narrow_bullish | 1,350 | 27% | +132.4 [+68.6, +193.7] | +131.3 [+83.6, +177.6] | +407.3 [+4.5, +1179.9] | -239.9 [-1027.6, +165.3] | 53% | 15.0% |
| mixed | 657 | 13% | +28.1 [-85.2, +135.7] | +95.3 [+22.1, +163.5] | -45.1 [-126.2, +26.4] | +108.2 [+37.4, +175.5] | 46% | 21.5% |
| broad_bearish | 704 | 14% | +97.4 [-80.2, +270.5] | +135.8 [+11.3, +257.4] | -0.0 [-114.0, +110.9] | +132.4 [-0.0, +254.8] | 51% | 25.3% |
| high_stress | 714 | 14% | +221.0 [+21.3, +437.6] | +210.7 [+98.2, +340.5] | +11.1 [-215.7, +193.2] | +245.3 [+95.6, +413.4] | 58% | 20.0% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,250 | 86% | +94.1 [+47.2, +140.7] | +114.1 [+80.0, +149.3] | +128.1 [-12.7, +381.7] | +1.0 [-247.6, +144.4] | 50% | 17.4% |
| yes | 714 | 14% | +221.0 [+21.3, +437.6] | +210.7 [+98.2, +340.5] | +11.1 [-215.7, +193.2] | +245.3 [+95.6, +413.4] | 58% | 20.0% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,629 | 33% | +84.3 [+25.1, +142.8] | +101.1 [+55.3, +146.5] | +8.7 [-24.3, +40.8] | +110.7 [+69.2, +154.9] | 49% | 14.6% |
| narrow_bullish | 1,524 | 31% | +145.8 [+81.1, +210.4] | +132.4 [+85.5, +177.7] | +379.3 [+17.7, +1076.3] | -198.6 [-900.0, +160.9] | 53% | 14.8% |
| mixed | 786 | 16% | +110.7 [-9.8, +241.2] | +132.8 [+46.4, +236.0] | +7.3 [-72.6, +76.3] | +138.4 [+49.7, +247.8] | 49% | 20.4% |
| broad_bearish | 1,025 | 21% | +108.6 [-59.1, +262.2] | +160.6 [+51.9, +261.7] | -44.7 [-205.9, +89.4] | +188.3 [+54.9, +321.8] | 54% | 25.4% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < 0.40 | 525 | 11% | +165.3 [-70.5, +370.6] | +227.1 [+111.0, +346.6] | -98.3 [-394.5, +124.6] | +298.6 [+138.7, +469.3] | 59% | 24.2% |
| 0.40 - 0.50 | 2,372 | 48% | +111.5 [+46.6, +173.5] | +125.2 [+82.2, +167.1] | +234.6 [-11.8, +689.5] | -88.1 [-551.4, +157.5] | 51% | 18.3% |
| 0.50 - 0.60 | 1,878 | 38% | +79.9 [+24.5, +137.3] | +90.7 [+46.6, +136.2] | +18.1 [-17.3, +53.1] | +96.8 [+52.0, +140.5] | 49% | 15.8% |
| >= 0.60 | 189 | 4% | +298.6 [+139.1, +495.6] | +258.7 [+122.1, +427.3] | +69.8 [+7.5, +132.0] | +263.8 [+131.3, +426.7] | 58% | 13.2% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -10% | 651 | 13% | +157.7 [+30.8, +320.8] | +127.0 [+27.4, +245.8] | +71.7 [+7.8, +136.1] | +121.3 [+23.5, +241.2] | 51% | 17.7% |
| -10% .. 0% | 1,977 | 40% | +87.1 [+33.5, +139.3] | +113.0 [+76.1, +151.1] | +9.1 [-28.6, +45.1] | +113.0 [+72.9, +152.9] | 50% | 16.4% |
| 0% .. +10% | 1,566 | 32% | +134.9 [+63.4, +205.9] | +140.3 [+86.5, +196.5] | +345.2 [-6.0, +997.3] | -175.2 [-840.5, +188.4] | 52% | 18.1% |
| +10% .. +25% | 626 | 13% | +144.2 [+46.3, +235.9] | +147.7 [+81.9, +209.8] | +8.5 [-103.5, +104.0] | +170.7 [+93.6, +251.4] | 55% | 18.5% |
| >= +25% | 144 | 3% | -130.0 [-612.1, +291.4] | +118.7 [-68.7, +293.3] | -404.3 [-1127.9, +217.1] | +309.2 [+12.3, +730.1] | 49% | 31.2% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,446 | 29% | +51.8 [-13.3, +115.9] | +76.7 [+27.4, +130.0] | +353.0 [-23.2, +1068.6] | -266.2 [-986.8, +116.4] | 47% | 16.9% |
| -3 .. 0 pts | 1,640 | 33% | +89.5 [+17.4, +152.3] | +102.0 [+59.8, +142.2] | +29.9 [-16.7, +74.8] | +94.5 [+49.3, +134.9] | 52% | 17.3% |
| 0 .. +3 pts | 1,122 | 23% | +118.8 [-12.3, +244.9] | +161.6 [+77.1, +242.6] | -39.1 [-175.1, +67.2] | +193.0 [+96.1, +288.0] | 53% | 19.6% |
| >= +3 pts (NIFTY ahead: narrow) | 756 | 15% | +268.3 [+103.3, +447.7] | +232.7 [+127.3, +352.6] | +48.2 [-53.1, +147.6] | +255.1 [+139.2, +378.8] | 56% | 18.0% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no list | 4,964 | 100% | +112.4 [+59.8, +164.5] | +128.0 [+93.2, +163.2] | +111.3 [-22.7, +339.6] | +36.1 [-189.5, +165.3] | 51% | 17.8% |

**home index** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| NIFTY 50 | 394 | 8% | +54.2 [-123.3, +202.1] | +61.1 [-112.2, +207.0] | +9.1 [-18.0, +34.3] | +80.1 [-97.2, +221.0] | 47% | 10.9% |
| Midcap 150 | 1,013 | 20% | +81.3 [+1.8, +155.4] | +96.5 [+28.7, +161.4] | +500.7 [-42.8, +1556.1] | -384.4 [-1442.4, +166.6] | 51% | 15.2% |
| Smallcap 250 | 3,556 | 72% | +127.7 [+72.9, +182.8] | +144.4 [+107.1, +182.1] | +11.6 [-32.8, +52.9] | +151.0 [+112.0, +191.5] | 52% | 19.3% |
| (blank) | 1 | 0% | -35.0 | +267.0 | n/a | n/a | 0% | 0.0% |

**environment on the entry day** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,536 | 31% | +118.6 [+55.5, +175.1] | +98.5 [+50.2, +144.5] | +42.9 [+11.9, +70.8] | +110.8 [+64.7, +156.5] | 51% | 13.1% |
| narrow_bullish | 1,350 | 27% | +128.5 [+67.4, +185.9] | +131.6 [+83.1, +180.8] | +409.6 [+9.0, +1176.3] | -246.2 [-1021.2, +160.5] | 52% | 15.1% |
| mixed | 657 | 13% | +79.4 [-20.8, +179.5] | +118.4 [+46.9, +188.5] | -7.3 [-76.1, +53.3] | +121.7 [+47.5, +193.6] | 50% | 19.2% |
| broad_bearish | 707 | 14% | +68.2 [-114.4, +237.7] | +134.4 [+2.8, +258.4] | -40.8 [-161.3, +63.2] | +144.0 [+4.8, +273.3] | 50% | 27.6% |
| high_stress | 714 | 14% | +142.5 [-53.1, +364.3] | +187.1 [+75.0, +320.4] | -46.2 [-278.0, +137.6] | +223.7 [+71.4, +399.1] | 53% | 22.1% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3% | 667 | 13% | -572.3 [-680.0, -465.7] | -24.4 [-113.5, +68.1] | -637.3 [-822.6, -505.2] | +100.0 [-18.9, +243.6] | 22% | 51.1% |
| -3% .. -1% | 781 | 16% | -151.0 [-215.1, -92.0] | +73.5 [+8.8, +134.9] | -197.2 [-216.6, -180.0] | +81.0 [+13.4, +149.0] | 33% | 28.3% |
| -1% .. +1% | 1,487 | 30% | +98.5 [+48.0, +149.8] | +125.2 [+74.8, +173.9] | +5.7 [-1.3, +13.2] | +127.8 [+78.6, +177.1] | 49% | 12.3% |
| +1% .. +3% | 1,344 | 27% | +343.8 [+284.7, +409.1] | +184.1 [+124.7, +250.0] | +573.0 [+192.3, +1320.1] | -194.3 [-966.6, +226.7] | 65% | 7.3% |
| >= +3% | 685 | 14% | +655.4 [+510.1, +795.2] | +234.5 [+117.8, +341.5] | +514.5 [+452.6, +582.0] | +175.9 [+49.7, +288.1] | 79% | 6.0% |

**what drove the trade** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| market | 738 | 15% | -77.1 [-171.7, +10.2] | -14.6 [-46.3, +13.1] | -53.9 [-156.7, +39.4] | +11.9 [-4.9, +31.0] | 51% | 21.7% |
| stock | 2,533 | 51% | +226.7 [+159.3, +301.5] | +234.1 [+172.4, +301.0] | +25.7 [+11.0, +40.6] | +236.1 [+172.5, +305.1] | 57% | 21.0% |
| both | 751 | 15% | +122.3 [+30.2, +211.7] | +93.2 [+41.4, +145.0] | +64.6 [+19.0, +108.1] | +92.7 [+44.8, +137.9] | 59% | 22.8% |
| opposite | 832 | 17% | -57.3 [-83.5, -31.6] | -15.8 [-76.8, +46.7] | +574.6 [-115.2, +1860.0] | -596.9 [-1873.3, +84.8] | 35% | 2.6% |
| flat | 109 | 2% | -35.9 [-39.8, -32.2] | -37.2 [-64.5, -8.3] | +3.4 [+0.7, +6.1] | -4.3 [-7.7, -0.8] | 6% | 0.0% |
| (blank) | 1 | 0% | -35.0 | +267.0 | n/a | n/a | 0% | 0.0% |

### Research (research\research_report.md)

- D W1: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W2: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W3: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W4: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W5: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W6: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W7: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W8: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D ANY: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W1: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W2: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W3: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W4: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W5: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W6: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W7: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W8: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS ANY: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)

### Files

- trades: pre_* (known at the pick day's close: the market the day before and that day, environment, high stress, breadth, VIX, divergence, AMFI size, beta / correlation to the three indices) and post_* (observed after the entry: entry-day moves, the hold, market part / stock part, driver); outcome; story.
- trade_days: Midcap / Smallcap / VIX / breadth / environment that session; held_ret split into mkt_part_day_bp and stock_part_day_bp.
- market_days + market_diary.md: every session; context_breakdown.csv: the tables above; cards\cards_sample.html: readable trades (python tl_cards.py --export <this folder> --worst 20 ...); research\: winners vs losers, warning signs, walk-forward, the book by environment.
- DATA_DICTIONARY.md: every column, its unit and when it is known.
