# tradelab export - PM_20261017_001

tl_export v1.2 (tradelab v1.2.1), 2026-10-24T22:09:21. Picks: 33,100 (engines ['D', 'ENS'], ranks [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).

## Headline (the plan: buy the session-1 open, sell the session-5 close, honest exits, 35 bp)

- D ranks 1-3: 4,964 finished trades, mean net +108.0 [+57.8, +160.0] bp over 1,655 signal days; excess over buy-everything +123.6 [+91.7, +157.7] bp
- ENS ranks 1-3: 4,964 finished trades, mean net +112.4 [+59.8, +164.5] bp over 1,655 signal days; excess over buy-everything +128.0 [+93.2, +163.2] bp

Intervals: 95% circular block bootstrap over signal days (blocks of 10, 2,000 resamples, seed 7). Same history the engines were built and studied on - a description, not new evidence.

## Reconciliation (safety stop)

- OK - D 16,544 of 16,550 (99.96%), mean net +76.06 bp vs recorded +76.06 (diff +0.0005); MFE/MAE agree on 99.96%; ENS 16,543 of 16,550 (99.96%), mean net +82.11 bp vs recorded +82.11 (diff +0.0000); MFE/MAE agree on 99.96%

## Status of every pick

- ok: 33,098
- stuck: 2

## Mean net by rank (finished trades, bp)

| engine | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| D | +113.4 | +121.9 | +88.7 | +101.5 | +55.4 | +74.7 | +62.3 | +30.5 | +56.9 | +55.4 |
| ENS | +129.8 | +127.8 | +79.6 | +76.3 | +99.2 | +81.4 | +60.6 | +76.7 | +59.9 | +29.9 |

## Files

- trade_day_features.parquet
- trades.parquet
- trades.csv
- trade_days.parquet
- trade_days.csv
- daily_book.parquet
- daily_book.csv
- market_days.parquet
- market_days.csv
- market_diary.md
- context_breakdown.csv
- cards/cards_sample.md
- cards/cards_sample.html
- research/outcome_groups.csv
- research/outcome_profiles.csv
- research/warning_signs.csv
- research/walk_forward.csv
- research/walk_forward_verdicts.csv
- research/book_by_environment.csv
- research/research_report.md
- research/severe_losers.md
- research/severe_losers.html
- research/research_summary.json
- DATA_DICTIONARY.md
- data_dictionary.csv

## Column notes

- Returns (ret_*, mfe, mae, close_ret_sK, open_ret_sK) are fractions of the entry price (session-1 open). P&L columns ending _bp are basis points of the trade's size, after costs.
- mfe / mae: best high / worst low of sessions 1-5 vs entry (pick_meta's definition; mfe_session / mae_session = the session it happened). mfe_held / mae_held: the same while actually held (a locked exit holds longer). touch_* = first session (1-5) whose high / low reached the level; blank = never.
- open6_net_bp: sold at the 6th session's open instead; hold10_net_bp: held to the 10th close (both with honest exits). These are alternatives on the same history, not tested rules.
- trade_days: day_pnl_bp is the change in the trade's marked-to-close P&L that session (half of the 35 bp is charged at the buy, half at the sale); cum_pnl_bp ends at net_bp. Rows after the exit (after_exit) show what the stock did next with no position.
- daily_book: positions are the traded ranks 1-3; 1/15 of capital a slot, additive - a proxy, not the execution simulator.
- Features are panel values at each session's close (the firewall removed labels, forward-looking names and raw price / volume levels). Never use label_* or outcome columns as model inputs.

## Market context (v1.1)

- Indices found: NIFTY 50, Midcap 150, Smallcap 250, India VIX. Missing: none.
- Breadth: counted now; advancers / (advancers + decliners) over 2495 cached stocks, median 1502.0 a session. Not NSE's official count: the cache's coverage, and stocks delisted before the cache was built are missing.
- Size class: BLANK - no AMFI lists given (it is never filled from today's list or a proxy). Put AMFI's half-yearly PDFs in %CACHE_DAILY_ROOT%\sectors\amfi\ and re-run.

### Environment labels (declared 24 Oct 2026, before any real run)

- index_up: close >= its 50-session average
- breadth: 10-session average of advancers / (advancers + decliners), all cached stocks
- breadth_strong: >= 0.5
- broad_bullish: NIFTY, Midcap, Smallcap up and breadth strong
- narrow_bullish: NIFTY up, and Midcap or Smallcap down or breadth weak
- broad_bearish: NIFTY, Midcap, Smallcap down and breadth weak
- mixed: anything else
- high_stress: VIX at or above the 90th percentile of its last 250 sessions, or VIX +25% in 5 sessions, or NIFTY / Smallcap day move >= 2.5 sd (of the previous 60 days)
- size: AMFI half-yearly lists only, each used from the 1st of the second month after its half-year ends (1 Feb / 1 Aug: an ASSUMED, conservative availability - AMFI's publication dates are not recorded; actual dates in amfi_published.csv are used instead, from the next day) until the next half-year's list is due (a missing list leaves the size blank; never carried forward)
- sensitivity: beta and correlation of daily returns, 120 sessions to the pick day (>= 60 returns)

### Where the P&L came from (ranks 1-3, the plan)

Market part = beta to the home index x that index over exactly the same hold; stock part = the rest. Intervals: 95% block bootstrap over signal days.

- **D** (4,964 trades; complete pre-entry context on 100.0%): gross +143.0 [+92.8, +195.0] bp = market part +7.8 [-34.9, +45.8] + stock part **+135.2 [+102.2, +171.3]** bp. vs NIFTY +129.2 [+88.1, +171.0], vs Smallcap +124.8 [+90.7, +160.3], vs home +127.1 [+93.0, +163.7] bp. High stress at the pick: 14.4% of trades.
  - environment at the pick: broad_bullish 31%, narrow_bullish 27%, high_stress 14%, broad_bearish 14%, mixed 13%
  - driver: stock 51%, opposite 16%, market 15%, both 15%, flat 3%
  - size (AMFI): no list 100%
  - home index: Smallcap 250 71%, Midcap 150 20%, NIFTY 50 9%
- **ENS** (4,964 trades; complete pre-entry context on 100.0%): gross +147.4 [+94.8, +199.5] bp = market part +11.2 [-31.2, +49.2] + stock part **+136.1 [+98.7, +174.2]** bp. vs NIFTY +133.8 [+90.3, +175.7], vs Smallcap +129.4 [+92.9, +166.6], vs home +131.9 [+95.0, +169.3] bp. High stress at the pick: 14.4% of trades.
  - environment at the pick: broad_bullish 31%, narrow_bullish 27%, high_stress 14%, broad_bearish 14%, mixed 13%
  - driver: stock 51%, opposite 17%, both 15%, market 15%, flat 2%, (blank) 0%
  - size (AMFI): no list 100%
  - home index: Smallcap 250 72%, Midcap 150 20%, NIFTY 50 8%, (blank) 0%

### The chain: the market before entry -> the trade -> the market during it

Each table groups the traded picks (means in bp, 95% intervals; win = share with net > 0; severe = share with net <= -500 bp). 'Known BEFORE entry' tables could in principle choose trades - but these are the same 2020-2026 years the engines were built on and many tables are shown, so a difference is a hypothesis (research\research_report.md tests the declared warning signs out of sample). 'Observed AFTER entry' tables explain outcomes and can never select. Nothing here filters trades.

#### engine D

**environment at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,539 | 31% | +91.1 [+27.4, +150.9] | +101.0 [+53.5, +146.3] | +22.6 [-13.4, +56.9] | +103.6 [+55.5, +150.0] | 49% | 14.1% |
| narrow_bullish | 1,350 | 27% | +118.1 [+53.6, +181.3] | +117.0 [+68.8, +164.9] | +30.3 [-11.4, +69.8] | +122.8 [+75.9, +170.0] | 51% | 16.7% |
| mixed | 657 | 13% | +69.6 [-38.8, +173.9] | +136.7 [+64.2, +209.9] | -52.9 [-133.6, +15.9] | +157.5 [+81.8, +229.8] | 48% | 21.6% |
| broad_bearish | 704 | 14% | +82.7 [-69.9, +231.9] | +121.1 [+27.8, +218.8] | -9.3 [-107.4, +83.0] | +127.1 [+29.0, +223.5] | 51% | 25.0% |
| high_stress | 714 | 14% | +185.6 [-33.5, +403.0] | +175.4 [+73.9, +290.6] | +6.1 [-223.2, +185.5] | +214.5 [+99.8, +351.2] | 57% | 20.9% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,250 | 86% | +95.0 [+52.4, +142.5] | +114.9 [+83.8, +150.7] | +8.1 [-21.1, +37.9] | +121.9 [+90.5, +156.0] | 49% | 17.9% |
| yes | 714 | 14% | +185.6 [-33.5, +403.0] | +175.4 [+73.9, +290.6] | +6.1 [-223.2, +185.5] | +214.5 [+99.8, +351.2] | 57% | 20.9% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,629 | 33% | +82.0 [+21.0, +143.5] | +98.8 [+53.9, +145.7] | +15.0 [-20.1, +48.7] | +102.0 [+56.5, +149.5] | 48% | 14.9% |
| narrow_bullish | 1,524 | 31% | +133.0 [+73.4, +197.3] | +119.6 [+76.9, +164.8] | +45.7 [+1.2, +90.5] | +122.2 [+83.2, +165.3] | 52% | 16.5% |
| mixed | 786 | 16% | +139.6 [+36.5, +243.4] | +161.8 [+85.2, +246.7] | -3.1 [-77.2, +63.6] | +177.7 [+94.4, +266.1] | 50% | 20.5% |
| broad_bearish | 1,025 | 21% | +87.9 [-70.5, +243.6] | +139.8 [+61.2, +221.4] | -51.9 [-214.2, +75.4] | +174.7 [+85.2, +271.7] | 53% | 25.0% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < 0.40 | 525 | 11% | +154.4 [-147.3, +388.2] | +216.1 [+85.0, +337.2] | -90.3 [-392.3, +131.8] | +279.6 [+160.8, +413.2] | 58% | 25.7% |
| 0.40 - 0.50 | 2,372 | 48% | +99.0 [+38.8, +160.8] | +112.6 [+72.2, +154.1] | +14.4 [-28.4, +57.4] | +119.6 [+79.8, +160.1] | 50% | 19.3% |
| 0.50 - 0.60 | 1,878 | 38% | +93.9 [+39.2, +148.1] | +104.8 [+65.0, +144.9] | +20.2 [-15.5, +56.1] | +108.7 [+68.2, +148.3] | 49% | 15.0% |
| >= 0.60 | 189 | 4% | +232.1 [+84.8, +394.6] | +192.2 [+70.6, +321.2] | +73.5 [+1.0, +151.1] | +193.5 [+64.9, +334.2] | 56% | 18.5% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -10% | 651 | 13% | +193.3 [+54.0, +347.5] | +162.6 [+54.1, +279.4] | +56.6 [-0.5, +113.4] | +171.7 [+56.5, +296.6] | 52% | 15.8% |
| -10% .. 0% | 1,977 | 40% | +88.0 [+32.2, +140.8] | +114.0 [+73.1, +154.5] | +3.2 [-32.6, +38.0] | +119.8 [+77.1, +163.4] | 49% | 16.9% |
| 0% .. +10% | 1,566 | 32% | +119.2 [+51.3, +193.1] | +124.5 [+71.7, +183.7] | +28.7 [-12.3, +66.2] | +125.5 [+71.3, +186.7] | 51% | 19.0% |
| +10% .. +25% | 626 | 13% | +115.9 [-0.5, +232.7] | +119.4 [+52.2, +188.9] | +19.7 [-75.2, +103.8] | +131.3 [+68.0, +195.9] | 52% | 20.3% |
| >= +25% | 144 | 3% | -159.6 [-798.0, +386.9] | +89.1 [-142.8, +278.0] | -429.6 [-1163.4, +201.8] | +304.9 [+115.0, +565.7] | 49% | 33.3% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,446 | 29% | +54.4 [-8.3, +118.2] | +79.4 [+36.2, +125.7] | +8.4 [-32.1, +47.9] | +81.1 [+37.5, +126.8] | 46% | 17.8% |
| -3 .. 0 pts | 1,640 | 33% | +126.1 [+61.0, +188.9] | +138.6 [+93.0, +185.7] | +14.4 [-29.7, +57.0] | +146.8 [+102.9, +193.5] | 52% | 15.8% |
| 0 .. +3 pts | 1,122 | 23% | +78.0 [-53.3, +199.3] | +120.8 [+56.3, +189.2] | -40.6 [-177.4, +66.1] | +153.5 [+88.8, +225.8] | 50% | 21.3% |
| >= +3 pts (NIFTY ahead: narrow) | 756 | 15% | +215.6 [+56.6, +391.2] | +180.0 [+78.5, +294.5] | +64.2 [-21.7, +150.4] | +186.5 [+78.3, +310.2] | 56% | 20.5% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no list | 4,964 | 100% | +108.0 [+57.8, +160.0] | +123.6 [+91.7, +157.7] | +7.8 [-34.9, +45.8] | +135.2 [+102.2, +171.3] | 50% | 18.3% |

**home index** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| NIFTY 50 | 446 | 9% | +128.6 [-8.8, +265.2] | +133.8 [+3.9, +271.1] | +17.0 [-11.4, +44.6] | +146.6 [+12.0, +280.2] | 45% | 9.4% |
| Midcap 150 | 983 | 20% | +48.6 [-22.2, +121.2] | +41.9 [-21.3, +100.6] | +24.0 [-18.4, +63.4] | +59.6 [-7.4, +123.4] | 49% | 18.0% |
| Smallcap 250 | 3,535 | 71% | +121.9 [+66.0, +178.7] | +145.1 [+110.4, +179.6] | +2.1 [-44.7, +48.7] | +154.8 [+117.4, +192.7] | 52% | 19.5% |

**environment on the entry day** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,536 | 31% | +114.6 [+53.3, +172.7] | +94.5 [+45.0, +143.4] | +50.2 [+18.3, +80.5] | +99.4 [+51.1, +148.4] | 50% | 13.3% |
| narrow_bullish | 1,350 | 27% | +117.8 [+59.1, +174.9] | +120.9 [+71.3, +167.4] | +29.7 [-8.9, +67.5] | +123.1 [+76.1, +168.3] | 50% | 17.2% |
| mixed | 657 | 13% | +108.0 [+4.7, +208.1] | +147.0 [+75.1, +222.4] | -20.4 [-82.8, +38.7] | +163.3 [+92.2, +232.6] | 48% | 18.3% |
| broad_bearish | 707 | 14% | +59.5 [-104.3, +209.3] | +125.7 [+26.6, +228.4] | -33.1 [-128.3, +52.1] | +127.6 [+29.2, +228.5] | 50% | 27.2% |
| high_stress | 714 | 14% | +123.3 [-98.9, +347.2] | +167.9 [+61.3, +286.9] | -58.6 [-296.1, +121.6] | +216.9 [+103.2, +353.1] | 53% | 22.7% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3% | 664 | 13% | -574.3 [-706.3, -463.3] | -25.8 [-102.7, +46.9] | -617.4 [-800.8, -482.8] | +78.1 [-7.0, +178.8] | 21% | 53.3% |
| -3% .. -1% | 779 | 16% | -101.4 [-167.6, -36.1] | +124.1 [+60.4, +187.0] | -192.3 [-210.7, -173.8] | +125.9 [+66.1, +191.3] | 34% | 23.9% |
| -1% .. +1% | 1,494 | 30% | +115.9 [+68.0, +163.7] | +143.4 [+96.1, +191.8] | +5.3 [-1.9, +12.5] | +145.6 [+98.3, +194.3] | 51% | 13.3% |
| +1% .. +3% | 1,341 | 27% | +276.1 [+216.8, +337.4] | +116.3 [+59.9, +175.0] | +189.1 [+174.0, +205.3] | +122.0 [+68.9, +176.2] | 60% | 9.3% |
| >= +3% | 686 | 14% | +660.5 [+528.4, +803.3] | +239.1 [+127.2, +351.1] | +491.1 [+440.8, +546.9] | +204.3 [+84.7, +326.6] | 77% | 6.7% |

**what drove the trade** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| market | 744 | 15% | -108.2 [-230.6, +4.7] | -26.1 [-64.1, +9.0] | -89.3 [-227.4, +31.0] | +16.1 [-4.8, +42.2] | 49% | 22.4% |
| stock | 2,539 | 51% | +242.5 [+180.9, +305.9] | +240.0 [+182.8, +295.8] | +30.2 [+16.6, +43.7] | +247.3 [+189.7, +305.6] | 57% | 21.3% |
| both | 722 | 15% | +70.2 [-42.5, +179.2] | +64.3 [+0.1, +128.6] | +41.4 [-14.5, +94.5] | +63.9 [+5.7, +121.2] | 57% | 26.0% |
| opposite | 794 | 16% | -56.1 [-77.4, -38.2] | -29.4 [-78.4, +19.7] | -2.4 [-94.8, +72.3] | -18.7 [-89.3, +58.9] | 33% | 1.8% |
| flat | 165 | 3% | -32.3 [-36.1, -28.8] | +4.3 [-27.2, +41.6] | +2.3 [-0.2, +5.6] | +0.4 [-4.1, +4.0] | 3% | 0.0% |

#### engine ENS

**environment at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,539 | 31% | +87.2 [+24.6, +145.6] | +97.1 [+50.2, +143.4] | +15.7 [-18.8, +47.5] | +106.6 [+61.6, +150.4] | 50% | 14.2% |
| narrow_bullish | 1,350 | 27% | +132.4 [+68.6, +193.7] | +131.3 [+83.6, +177.6] | +36.4 [-5.4, +75.6] | +131.0 [+85.5, +175.9] | 53% | 15.0% |
| mixed | 657 | 13% | +28.1 [-85.2, +135.7] | +95.3 [+22.1, +163.5] | -45.2 [-126.3, +26.4] | +108.3 [+37.5, +175.6] | 46% | 21.5% |
| broad_bearish | 704 | 14% | +97.4 [-80.2, +270.5] | +135.8 [+11.3, +257.4] | -3.4 [-101.1, +90.8] | +135.8 [+8.5, +257.1] | 51% | 25.3% |
| high_stress | 714 | 14% | +221.0 [+21.3, +437.6] | +210.7 [+98.2, +340.5] | +20.6 [-206.0, +197.0] | +235.7 [+90.4, +400.8] | 58% | 20.0% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,250 | 86% | +94.1 [+47.2, +140.7] | +114.1 [+80.0, +149.3] | +9.7 [-19.3, +39.1] | +119.4 [+85.7, +154.0] | 50% | 17.4% |
| yes | 714 | 14% | +221.0 [+21.3, +437.6] | +210.7 [+98.2, +340.5] | +20.6 [-206.0, +197.0] | +235.7 [+90.4, +400.8] | 58% | 20.0% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,629 | 33% | +84.3 [+25.1, +142.8] | +101.1 [+55.3, +146.5] | +8.7 [-24.3, +40.8] | +110.7 [+69.2, +154.9] | 49% | 14.6% |
| narrow_bullish | 1,524 | 31% | +145.8 [+81.1, +210.4] | +132.4 [+85.5, +177.7] | +50.8 [+7.7, +96.5] | +130.0 [+87.4, +170.5] | 53% | 14.8% |
| mixed | 786 | 16% | +110.7 [-9.8, +241.2] | +132.8 [+46.4, +236.0] | +7.2 [-72.8, +76.2] | +138.5 [+49.8, +247.8] | 49% | 20.4% |
| broad_bearish | 1,025 | 21% | +108.6 [-59.1, +262.2] | +160.6 [+51.9, +261.7] | -40.4 [-199.6, +83.7] | +184.0 [+56.9, +307.7] | 54% | 25.4% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < 0.40 | 525 | 11% | +165.3 [-70.5, +370.6] | +227.1 [+111.0, +346.6] | -85.9 [-387.1, +133.9] | +286.3 [+130.7, +455.7] | 59% | 24.2% |
| 0.40 - 0.50 | 2,372 | 48% | +111.5 [+46.6, +173.5] | +125.2 [+82.2, +167.1] | +22.6 [-20.0, +67.2] | +123.9 [+80.4, +165.0] | 51% | 18.3% |
| 0.50 - 0.60 | 1,878 | 38% | +79.9 [+24.5, +137.3] | +90.7 [+46.6, +136.2] | +18.1 [-17.3, +53.1] | +96.8 [+52.0, +140.5] | 49% | 15.8% |
| >= 0.60 | 189 | 4% | +298.6 [+139.1, +495.6] | +258.7 [+122.1, +427.3] | +69.8 [+7.5, +132.0] | +263.8 [+131.3, +426.7] | 58% | 13.2% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -10% | 651 | 13% | +157.7 [+30.8, +320.8] | +127.0 [+27.4, +245.8] | +65.5 [+4.1, +128.0] | +127.5 [+28.7, +252.5] | 51% | 17.7% |
| -10% .. 0% | 1,977 | 40% | +87.1 [+33.5, +139.3] | +113.0 [+76.1, +151.1] | +6.7 [-28.6, +41.2] | +115.5 [+77.4, +154.9] | 50% | 16.4% |
| 0% .. +10% | 1,566 | 32% | +134.9 [+63.4, +205.9] | +140.3 [+86.5, +196.5] | +27.6 [-12.0, +62.4] | +142.3 [+87.4, +198.0] | 52% | 18.1% |
| +10% .. +25% | 626 | 13% | +144.2 [+46.3, +235.9] | +147.7 [+81.9, +209.8] | +23.9 [-74.0, +110.1] | +155.3 [+82.0, +231.7] | 55% | 18.5% |
| >= +25% | 144 | 3% | -130.0 [-612.1, +291.4] | +118.7 [-68.7, +293.3] | -404.3 [-1127.9, +217.1] | +309.2 [+12.3, +730.1] | 49% | 31.2% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,446 | 29% | +51.8 [-13.3, +115.9] | +76.7 [+27.4, +130.0] | +4.6 [-36.2, +43.4] | +82.2 [+35.1, +131.1] | 47% | 16.9% |
| -3 .. 0 pts | 1,640 | 33% | +89.5 [+17.4, +152.3] | +102.0 [+59.8, +142.2] | +22.8 [-23.5, +67.3] | +101.6 [+57.3, +142.3] | 52% | 17.3% |
| 0 .. +3 pts | 1,122 | 23% | +118.8 [-12.3, +244.9] | +161.6 [+77.1, +242.6] | -35.8 [-171.5, +69.9] | +189.8 [+94.1, +284.1] | 53% | 19.6% |
| >= +3 pts (NIFTY ahead: narrow) | 756 | 15% | +268.3 [+103.3, +447.7] | +232.7 [+127.3, +352.6] | +68.6 [-18.7, +159.3] | +234.8 [+127.3, +360.4] | 56% | 18.0% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no list | 4,964 | 100% | +112.4 [+59.8, +164.5] | +128.0 [+93.2, +163.2] | +11.2 [-31.2, +49.2] | +136.1 [+98.7, +174.2] | 51% | 17.8% |

**home index** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| NIFTY 50 | 396 | 8% | +56.5 [-120.5, +202.3] | +62.4 [-104.0, +208.1] | +9.0 [-17.6, +33.6] | +82.5 [-90.1, +225.8] | 48% | 10.9% |
| Midcap 150 | 997 | 20% | +84.0 [+9.7, +157.0] | +98.8 [+33.4, +161.6] | +11.5 [-40.3, +53.3] | +107.5 [+32.1, +178.6] | 52% | 14.9% |
| Smallcap 250 | 3,570 | 72% | +126.5 [+71.4, +181.7] | +143.4 [+105.8, +181.4] | +11.4 [-32.9, +53.1] | +150.1 [+110.4, +191.2] | 52% | 19.4% |
| (blank) | 1 | 0% | -35.0 | +267.0 | n/a | n/a | 0% | 0.0% |

**environment on the entry day** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,536 | 31% | +118.6 [+55.5, +175.1] | +98.5 [+50.2, +144.5] | +42.9 [+11.9, +70.8] | +110.8 [+64.7, +156.5] | 51% | 13.1% |
| narrow_bullish | 1,350 | 27% | +128.5 [+67.4, +185.9] | +131.6 [+83.1, +180.8] | +36.2 [-2.9, +74.3] | +127.3 [+80.8, +173.7] | 52% | 15.1% |
| mixed | 657 | 13% | +79.4 [-20.8, +179.5] | +118.4 [+46.9, +188.5] | -13.0 [-80.5, +49.4] | +127.4 [+58.3, +195.4] | 50% | 19.2% |
| broad_bearish | 707 | 14% | +68.2 [-114.4, +237.7] | +134.4 [+2.8, +258.4] | -30.0 [-125.6, +53.4] | +133.2 [-1.4, +255.5] | 50% | 27.6% |
| high_stress | 714 | 14% | +142.5 [-53.1, +364.3] | +187.1 [+75.0, +320.4] | -40.9 [-275.4, +140.5] | +218.4 [+67.5, +390.4] | 53% | 22.1% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3% | 667 | 13% | -572.3 [-680.0, -465.7] | -24.4 [-113.5, +68.1] | -614.5 [-791.7, -482.1] | +77.2 [-40.0, +221.6] | 22% | 51.1% |
| -3% .. -1% | 781 | 16% | -151.0 [-215.1, -92.0] | +73.5 [+8.8, +134.9] | -190.7 [-205.8, -175.9] | +74.5 [+9.8, +135.2] | 33% | 28.3% |
| -1% .. +1% | 1,487 | 30% | +98.5 [+48.0, +149.8] | +125.2 [+74.8, +173.9] | +5.9 [-1.1, +13.3] | +127.6 [+78.5, +177.0] | 49% | 12.3% |
| +1% .. +3% | 1,344 | 27% | +343.8 [+284.7, +409.1] | +184.1 [+124.7, +250.0] | +198.1 [+184.1, +212.8] | +180.6 [+124.0, +243.1] | 65% | 7.3% |
| >= +3% | 685 | 14% | +655.4 [+510.1, +795.2] | +234.5 [+117.8, +341.5] | +495.4 [+437.0, +559.8] | +195.1 [+74.8, +303.0] | 79% | 6.0% |

**what drove the trade** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| market | 738 | 15% | -76.6 [-172.1, +11.5] | -14.7 [-46.5, +13.2] | -53.2 [-155.8, +40.1] | +11.6 [-5.2, +30.9] | 51% | 21.7% |
| stock | 2,544 | 51% | +225.4 [+158.6, +299.2] | +233.5 [+173.8, +297.5] | +25.0 [+10.2, +39.4] | +235.4 [+174.3, +302.0] | 57% | 21.1% |
| both | 752 | 15% | +122.6 [+29.9, +212.3] | +93.1 [+41.2, +145.4] | +64.7 [+20.5, +109.5] | +92.8 [+45.4, +140.0] | 59% | 22.7% |
| opposite | 820 | 17% | -57.7 [-82.6, -34.8] | -17.0 [-78.4, +46.1] | -21.4 [-147.6, +77.0] | -1.3 [-91.0, +105.1] | 35% | 2.1% |
| flat | 109 | 2% | -35.9 [-39.8, -32.2] | -37.2 [-64.5, -8.3] | +3.4 [+0.7, +6.1] | -4.3 [-7.7, -0.8] | 6% | 0.0% |
| (blank) | 1 | 0% | -35.0 | +267.0 | n/a | n/a | 0% | 0.0% |

### Research (research\research_report.md)

- D W1: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W2: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W3: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W4: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W5: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W6: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W7: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W8: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D ANY: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W1: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W2: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W3: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W4: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W5: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W6: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W7: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W8: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS ANY: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)

### Files

- trades: pre_* (known at the pick day's close: the market the day before and that day, environment, high stress, breadth, VIX, divergence, AMFI size, beta / correlation to the three indices) and post_* (observed after the entry: entry-day moves, the hold, market part / stock part, driver); outcome; story.
- trade_days: Midcap / Smallcap / VIX / breadth / environment that session; held_ret split into mkt_part_day_bp and stock_part_day_bp.
- market_days + market_diary.md: every session; context_breakdown.csv: the tables above; cards\cards_sample.html: readable trades (python tl_cards.py --export <this folder> --worst 20 ...); research\: winners vs losers, warning signs, walk-forward, the book by environment.
- DATA_DICTIONARY.md: every column, its unit and when it is known.
