# tradelab sample trade cards (TLX_20261024_002): best and worst 5 per engine, and the latest signal day

How to read a card: s = session (0 = the pick day, the model ranks at its close; 1 = entry day, bought at the open; 5 = sold at the close unless the lower circuit locked it). Sections 1-2 were known BEFORE entry; sections 3-4 were observed after. Breadth = advancers / (advancers + decliners) over the cached stocks. 'stock - home' = the stock's day return minus its home index's. 'held: market / stock bp' = the part of the day the position was held, split into beta x the home index (market) and the rest (stock). Size = AMFI's list in force on the pick day (blank when none was given - never filled). Environment labels and the high-stress flag are defined in tl_context.py (declared 24 Oct 2026).

## D-20240119-3 - IFCI - net +7937 bp (gross +79.72%) - WINNER

- D rank 3 (score 0.017) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 2.15, correlation 0.46; NIFTY beta 1.38, Smallcap beta 2.15)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 18 Jan 2024: NIFTY -0.5%, Midcap 0.0%, Smallcap 0.0%; NIFTY minus Smallcap -0.5 pts (20-day -5.7 pts); breadth 0.44 (854 up / 1,068 down of 1,953; 10-day 0.45); VIX 14.1 (day -6.7%, 5-day +10.2%, 86th percentile); environment: Narrow bullish.
- Pick day: Fri 19 Jan 2024: NIFTY +0.7%, Midcap +1.5% (2.1 sd rise), Smallcap +1.1%; NIFTY minus Smallcap -0.3 pts (20-day -4.8 pts); breadth 0.69 (1,328 up / 586 down of 1,951; 10-day 0.47); VIX 13.9 (day -1.4%, 5-day +6.0%, 84th percentile); environment: Narrow bullish.
- The stock: day before -0.3%, pick day +2.1% (+1.0 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.003, pred_mae_q20 -0.093, pred_mae_q50 -0.047, pred_mae_q80 -0.013, pred_mfe_q20 0.015, pred_mfe_q50 0.046, pred_mfe_q80 0.093, prob_big 0.453, prob_deep 0.273, prob_trap 0.002, prob_win 0.468

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 19 Jan | +2.1% | +1.1% | +0.7% | +1.5% | +1.1% | 0.69 | 13.9 | Narrow bullish | +1.0 pts |  | 0% | +0 | +0 |  |
| 1 | Sat 20 Jan | +19.9% | +19.2% | -0.2% | +0.3% | +0.5% | 0.49 | 13.8 | Narrow bullish | +19.5 pts | -12 / +1931 | 100% | +1902 | +1902 | buy open |
| 2 | Tue 23 Jan | +3.9% | -3.4% | -1.5% | -2.9% | -2.7% | 0.13 | 14.8 | HIGH STRESS | +6.6 pts | -584 / +974 | 100% | +464 | +2366 |  |
| 3 | Wed 24 Jan | +20.0% | +17.6% | +1.0% | +1.7% | +1.8% | 0.74 | 14.4 | Narrow bullish | +18.2 pts | +378 / +1622 | 100% | +2477 | +4843 |  |
| 4 | Thu 25 Jan | +10.0% | +5.6% | -0.5% | -0.5% | +0.5% | 0.55 | 13.9 | Narrow bullish | +9.5 pts | +114 / +886 | 100% | +1486 | +6329 |  |
| 5 | Mon 29 Jan | +9.9% | +5.5% | +1.8% | +1.5% | +1.3% | 0.61 | 15.7 | HIGH STRESS | +8.7 pts | +276 / +718 | 0% | +1608 | +7937 | sell time |

**4. Verdict** (observed after entry)

- Bought Sat 20 Jan 2024 at the open 32.30; sold Mon 29 Jan 2024 at the close 58.05. Gross +79.72%, costs -35 bp, net +7937 bp.
- Over the same hold: NIFTY +0.1%, Midcap -0.7%, Smallcap +0.7%; VIX +13.0%; breadth averaged 0.50; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY +7958 bp, Midcap +8045 bp, Smallcap +7898 bp.
- Split: market part +1.59% = beta 2.15 x Smallcap 250 +0.74%; stock part +78.13% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+1931 bp beyond its market); weakest: session 5 (+718 bp).

_Pick day Fri 19 Jan 2024 [Narrow bullish]: NIFTY +0.7%, Smallcap +1.1%, breadth 0.69, VIX 13.9 (+6% in 5 days) -> D rank 3 IFCI (moves with Smallcap 250, beta 2.15) -> bought Sat 20 Jan 2024 open, sold Mon 29 Jan 2024 close: gross +79.72%, net +7937 bp -> during the hold NIFTY +0.1%, Smallcap +0.7%, 2 high-stress day(s) -> market part +1.59%, stock part +78.13%: mostly the stock itself._

## D-20230227-1 - ADANIENT - net +7282 bp (gross +73.17%) - WINNER

- D rank 1 (score 0.030) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 2.24, correlation 0.33; NIFTY beta 2.24, Smallcap beta 1.78)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 24 Feb 2023: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.2%; NIFTY minus Smallcap -0.1 pts (20-day -0.3 pts); breadth 0.39 (693 up / 1,080 down of 1,819; 10-day 0.38); VIX 14.2 (day -5.9%, 5-day +8.4%, 15th percentile); environment: Broad bearish.
- Pick day: Mon 27 Feb 2023: NIFTY -0.4%, Midcap -0.6%, Smallcap -1.2%; NIFTY minus Smallcap +0.8 pts (20-day 0.0 pts); breadth 0.19 (336 up / 1,468 down of 1,831; 10-day 0.38); VIX 13.9 (day -2.2%, 5-day +3.7%, 12th percentile); environment: Broad bearish.
- The stock: day before -4.8%, pick day -9.3% (-8.9 pts vs NIFTY 50)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.018, pred_mae_q20 -0.104, pred_mae_q50 -0.044, pred_mae_q80 -0.015, pred_mfe_q20 0.042, pred_mfe_q50 0.093, pred_mfe_q80 0.160, prob_big 0.658, prob_deep 0.296, prob_trap 0.003, prob_win 0.683

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 27 Feb | -9.3% | -8.2% | -0.4% | -0.6% | -1.2% | 0.19 | 13.9 | Broad bearish | -8.9 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 28 Feb | +14.3% | +19.1% | -0.5% | +0.6% | +0.3% | 0.50 | 14.0 | Broad bearish | +14.8 pts | -102 / +2013 | 100% | +1893 | +1893 | buy open |
| 2 | Wed 01 Mar | +14.7% | +9.9% | +0.8% | +1.4% | +1.2% | 0.78 | 13.0 | Broad bearish | +13.9 pts | +191 / +1280 | 100% | +1751 | +3644 |  |
| 3 | Thu 02 Mar | +2.7% | +7.2% | -0.7% | -0.2% | -0.1% | 0.40 | 13.0 | Broad bearish | +3.5 pts | -166 / +440 | 100% | +375 | +4019 |  |
| 4 | Fri 03 Mar | +16.9% | +11.3% | +1.6% | +0.5% | +0.7% | 0.69 | 12.2 | Broad bearish | +15.4 pts | +353 / +1341 | 100% | +2377 | +6396 |  |
| 5 | Mon 06 Mar | +5.5% | +0.8% | +0.7% | +0.7% | +1.0% | 0.62 | 12.3 | Mixed / ranging | +4.8 pts | +149 / +401 | 0% | +886 | +7282 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 28 Feb 2023 at the open 1110.10; sold Mon 06 Mar 2023 at the close 1922.40. Gross +73.17%, costs -35 bp, net +7282 bp.
- Over the same hold: NIFTY +1.9%, Midcap +2.8%, Smallcap +2.9%; VIX -11.6%; breadth averaged 0.60; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY +7129 bp, Midcap +7034 bp, Smallcap +7025 bp.
- Split: market part +4.24% = beta 2.24 x NIFTY 50 +1.89%; stock part +68.94% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+2013 bp beyond its market); weakest: session 5 (+401 bp).

_Pick day Mon 27 Feb 2023 [Broad bearish]: NIFTY -0.4%, Smallcap -1.2%, breadth 0.19, VIX 13.9 (+4% in 5 days) -> D rank 1 ADANIENT (moves with NIFTY 50, beta 2.24) -> bought Tue 28 Feb 2023 open, sold Mon 06 Mar 2023 close: gross +73.17%, net +7282 bp -> during the hold NIFTY +1.9%, Smallcap +2.9% -> market part +4.24%, stock part +68.94%: mostly the stock itself._

## D-20200324-1 - V2RETAIL - net +6215 bp (gross +62.50%) - WINNER

- D rank 1 (score 0.075) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.35, correlation 0.62; NIFTY beta 1.21, Smallcap beta 1.35)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 23 Mar 2020: NIFTY -13.0% (5.9 sd fall), Midcap -13.0% (6.6 sd fall), Smallcap -12.4% (6.0 sd fall); NIFTY minus Smallcap -0.6 pts (20-day +5.4 pts); breadth 0.04 (51 up / 1,331 down of 1,406; 10-day 0.25); VIX 72.0 (day +7.3%, 5-day +22.3%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; NIFTY -5.9 sd day; Smallcap -6.0 sd day.
- Pick day: Tue 24 Mar 2020: NIFTY +2.5%, Midcap +1.0%, Smallcap -1.0%; NIFTY minus Smallcap +3.5 pts (20-day +7.9 pts); breadth 0.43 (579 up / 775 down of 1,412; 10-day 0.29); VIX 83.6 (day +16.1%, 5-day +32.9%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +33% in 5 sessions.
- The stock: day before -7.7%, pick day -5.6% (-4.6 pts vs Smallcap 250)

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 24 Mar | -5.6% | -8.1% | +2.5% | +1.0% | -1.0% | 0.43 | 83.6 | HIGH STRESS | -4.6 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 25 Mar | +8.8% | +15.6% | +6.6% | +3.3% | +2.5% | 0.65 | 77.6 | HIGH STRESS | +6.3 pts | +563 / +1000 | 100% | +1545 | +1545 | buy open |
| 2 | Thu 26 Mar | +10.8% | 0.0% | +3.9% | +3.7% | +3.5% | 0.74 | 71.5 | HIGH STRESS | +7.3 pts | +470 / +611 | 100% | +1250 | +2795 |  |
| 3 | Fri 27 Mar | +9.8% | 0.0% | +0.2% | -0.4% | +0.9% | 0.54 | 70.4 | HIGH STRESS | +8.9 pts | +119 / +857 | 100% | +1250 | +4045 |  |
| 4 | Mon 30 Mar | +8.9% | 0.0% | -4.4% | -2.4% | -2.3% | 0.35 | 71.9 | HIGH STRESS | +11.2 pts | -315 / +1203 | 100% | +1250 | +5295 |  |
| 5 | Tue 31 Mar | +6.1% | 0.0% | +3.8% | +2.5% | +3.2% | 0.76 | 64.4 | HIGH STRESS | +2.9 pts | +439 / +173 | 0% | +920 | +6215 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 25 Mar 2020 at the open 3.20; sold Tue 31 Mar 2020 at the close 5.20. Gross +62.50%, costs -35 bp, net +6215 bp.
- Over the same hold: NIFTY +11.2%, Midcap +8.6%, Smallcap +9.6%; VIX -23.0%; breadth averaged 0.61; 5 high-stress session(s).
- Against each index (gross minus the index): NIFTY +5135 bp, Midcap +5388 bp, Smallcap +5286 bp.
- Split: market part +13.05% = beta 1.35 x Smallcap 250 +9.64%; stock part +49.45% -> **mostly the stock itself**.
- The stock's own strongest day: session 4 (+1203 bp beyond its market); weakest: session 5 (+173 bp).

_Pick day Tue 24 Mar 2020 [HIGH STRESS]: NIFTY +2.5%, Smallcap -1.0%, breadth 0.43, VIX 83.6 (+33% in 5 days) -> D rank 1 V2RETAIL (moves with Smallcap 250, beta 1.35) -> bought Wed 25 Mar 2020 open, sold Tue 31 Mar 2020 close: gross +62.50%, net +6215 bp -> during the hold NIFTY +11.2%, Smallcap +9.6%, 5 high-stress day(s) -> market part +13.05%, stock part +49.45%: mostly the stock itself._

## D-20200407-2 - NCC - net +5742 bp (gross +57.77%) - WINNER

- D rank 2 (score 0.039) | the other engine ranked it 6 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 1.51, correlation 0.69; NIFTY beta 1.19, Smallcap beta 1.52)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 03 Apr 2020: NIFTY -2.1%, Midcap -1.3%, Smallcap -1.1%; NIFTY minus Smallcap -1.0 pts (20-day +5.9 pts); breadth 0.49 (653 up / 692 down of 1,408; 10-day 0.52); VIX 55.3 (day -7.9%, 5-day -22.7%, 95th percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 95th percentile of 250 sessions.
- Pick day: Tue 07 Apr 2020: NIFTY +8.8% (2.8 sd rise), Midcap +4.8%, Smallcap +3.5%; NIFTY minus Smallcap +5.3 pts (20-day +10.1 pts); breadth 0.87 (1,200 up / 184 down of 1,429; 10-day 0.54); VIX 51.8 (day -6.3%, 5-day -26.4%, 94th percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 94th percentile of 250 sessions; NIFTY +2.8 sd day.
- The stock: day before -9.4%, pick day +1.5% (-3.3 pts vs Midcap 150)

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 07 Apr | +1.5% | -2.0% | +8.8% | +4.8% | +3.5% | 0.87 | 51.8 | HIGH STRESS | -3.3 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 08 Apr | +5.2% | +6.2% | -0.5% | +1.6% | +1.7% | 0.65 | 52.2 | HIGH STRESS | +3.6 pts | +263 / +353 | 100% | +598 | +598 | buy open |
| 2 | Thu 09 Apr | +11.3% | +7.8% | +4.2% | +3.2% | +3.4% | 0.85 | 49.8 | HIGH STRESS | +8.1 pts | +484 / +648 | 100% | +1202 | +1801 |  |
| 3 | Mon 13 Apr | +18.9% | +18.0% | -1.3% | -1.1% | -0.4% | 0.45 | 51.5 | HIGH STRESS | +20.0 pts | -167 / +2053 | 100% | +2229 | +4029 |  |
| 4 | Wed 15 Apr | +6.1% | +2.0% | -0.8% | +1.3% | +1.1% | 0.62 | 49.7 | HIGH STRESS | +4.7 pts | +199 / +406 | 100% | +850 | +4880 |  |
| 5 | Thu 16 Apr | +5.9% | +5.5% | +0.8% | +1.5% | +2.0% | 0.71 | 46.1 | HIGH STRESS | +4.4 pts | +233 / +357 | 0% | +862 | +5742 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 08 Apr 2020 at the open 17.05; sold Thu 16 Apr 2020 at the close 26.90. Gross +57.77%, costs -35 bp, net +5742 bp.
- Over the same hold: NIFTY +3.5%, Midcap +6.9%, Smallcap +7.2%; VIX -11.0%; breadth averaged 0.66; 5 high-stress session(s).
- Against each index (gross minus the index): NIFTY +5427 bp, Midcap +5092 bp, Smallcap +5056 bp.
- Split: market part +10.32% = beta 1.51 x Midcap 150 +6.85%; stock part +47.45% -> **mostly the stock itself**.
- The stock's own strongest day: session 3 (+2053 bp beyond its market); weakest: session 1 (+353 bp).

_Pick day Tue 07 Apr 2020 [HIGH STRESS]: NIFTY +8.8%, Smallcap +3.5%, breadth 0.87, VIX 51.8 (-26% in 5 days) -> D rank 2 NCC (moves with Midcap 150, beta 1.51) -> bought Wed 08 Apr 2020 open, sold Thu 16 Apr 2020 close: gross +57.77%, net +5742 bp -> during the hold NIFTY +3.5%, Smallcap +7.2%, 5 high-stress day(s) -> market part +10.32%, stock part +47.45%: mostly the stock itself._

## D-20200413-1 - J&KBANK - net +5649 bp (gross +56.84%) - WINNER

- D rank 1 (score 0.030) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 0.88, correlation 0.52; NIFTY beta 0.76, Smallcap beta 0.84)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 09 Apr 2020: NIFTY +4.2%, Midcap +3.2%, Smallcap +3.4%; NIFTY minus Smallcap +0.7 pts (20-day +10.5 pts); breadth 0.85 (1,176 up / 202 down of 1,421; 10-day 0.64); VIX 49.8 (day -4.8%, 5-day -22.8%, 93rd percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 93rd percentile of 250 sessions.
- Pick day: Mon 13 Apr 2020: NIFTY -1.3%, Midcap -1.1%, Smallcap -0.4%; NIFTY minus Smallcap -0.9 pts (20-day +9.4 pts); breadth 0.45 (614 up / 748 down of 1,426; 10-day 0.62); VIX 51.5 (day +3.4%, 5-day -14.3%, 93rd percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 93rd percentile of 250 sessions.
- The stock: day before +0.4%, pick day -3.4% (-2.2 pts vs Midcap 150)

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 13 Apr | -3.4% | -3.4% | -1.3% | -1.1% | -0.4% | 0.45 | 51.5 | HIGH STRESS | -2.2 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 15 Apr | +5.2% | +3.4% | -0.8% | +1.3% | +1.1% | 0.62 | 49.7 | HIGH STRESS | +3.9 pts | -1 / +343 | 100% | +324 | +324 | buy open |
| 2 | Thu 16 Apr | -1.2% | -0.4% | +0.8% | +1.5% | +2.0% | 0.71 | 46.1 | HIGH STRESS | -2.8 pts | +137 / -261 | 100% | -128 | +196 |  |
| 3 | Fri 17 Apr | +19.7% | +16.3% | +3.0% | +2.2% | +3.0% | 0.76 | 42.6 | HIGH STRESS | +17.4 pts | +196 / +1770 | 100% | +2009 | +2205 |  |
| 4 | Mon 20 Apr | +19.9% | +3.0% | -0.1% | +0.5% | +0.7% | 0.58 | 43.5 | HIGH STRESS | +19.5 pts | +42 / +1951 | 100% | +2436 | +4641 |  |
| 5 | Tue 21 Apr | +7.0% | -1.9% | -3.0% | -2.9% | -3.5% | 0.21 | 45.2 | HIGH STRESS | +9.9 pts | -256 / +956 | 0% | +1008 | +5649 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 15 Apr 2020 at the open 11.70; sold Tue 21 Apr 2020 at the close 18.35. Gross +56.84%, costs -35 bp, net +5649 bp.
- Over the same hold: NIFTY -2.3%, Midcap +1.3%, Smallcap +1.6%; VIX -12.2%; breadth averaged 0.58; 5 high-stress session(s).
- Against each index (gross minus the index): NIFTY +5917 bp, Midcap +5558 bp, Smallcap +5529 bp.
- Split: market part +1.11% = beta 0.88 x Midcap 150 +1.26%; stock part +55.72% -> **mostly the stock itself**.
- The stock's own strongest day: session 4 (+1951 bp beyond its market); weakest: session 2 (-261 bp).

_Pick day Mon 13 Apr 2020 [HIGH STRESS]: NIFTY -1.3%, Smallcap -0.4%, breadth 0.45, VIX 51.5 (-14% in 5 days) -> D rank 1 J&KBANK (moves with Midcap 150, beta 0.88) -> bought Wed 15 Apr 2020 open, sold Tue 21 Apr 2020 close: gross +56.84%, net +5649 bp -> during the hold NIFTY -2.3%, Smallcap +1.6%, 5 high-stress day(s) -> market part +1.11%, stock part +55.72%: mostly the stock itself._

## D-20260302-3 - AQYLON - net -4638 bp (gross -46.03%) - SEVERE LOSER

- D rank 3 (score 0.026) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 0.81, correlation 0.15; NIFTY beta 0.81, Smallcap beta 0.02)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 27 Feb 2026: NIFTY -1.2%, Midcap -1.1%, Smallcap -1.0%; NIFTY minus Smallcap -0.2 pts (20-day -1.6 pts); breadth 0.30 (703 up / 1,648 down of 2,382; 10-day 0.44); VIX 13.7 (day +4.9%, 5-day -4.6%, 73rd percentile); environment: Broad bearish.
- Pick day: Mon 02 Mar 2026: NIFTY -1.2%, Midcap -1.7%, Smallcap -1.9%; NIFTY minus Smallcap +0.7 pts (20-day -1.4 pts); breadth 0.13 (310 up / 2,068 down of 2,385; 10-day 0.41); VIX 17.1 (day +25.0%, 5-day +20.9%, 90th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 90th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-3.8 pts vs NIFTY 50)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.015, pred_mae_q20 -0.107, pred_mae_q50 -0.053, pred_mae_q80 -0.020, pred_mfe_q20 0.037, pred_mfe_q50 0.092, pred_mfe_q80 0.134, prob_big 0.742, prob_deep 0.366, prob_trap 0.209, prob_win 0.629

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 02 Mar | -5.0% | 0.0% | -1.2% | -1.7% | -1.9% | 0.13 | 17.1 | HIGH STRESS | -3.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 04 Mar | -5.0% | -1.0% | -1.5% | -2.2% | -2.1% | 0.14 | 21.1 | HIGH STRESS | -3.4 pts | +31 / -131 | 100% | -118 | -118 | buy open |
| 2 | Thu 05 Mar | +5.0% | +4.4% | +1.2% | +1.5% | +1.4% | 0.70 | 17.9 | HIGH STRESS | +3.8 pts | +95 / +403 | 100% | +493 | +375 |  |
| 3 | Fri 06 Mar | -4.5% | -6.5% | -1.3% | -0.7% | -0.3% | 0.35 | 19.9 | HIGH STRESS | -3.2 pts | -104 / -344 | 100% | -466 | -91 |  |
| 4 | Mon 09 Mar | -5.0% | 0.0% | -1.7% | -2.0% | -2.3% | 0.14 | 23.4 | HIGH STRESS | -3.2 pts | -141 / -356 | 100% | -493 | -584 |  |
| 5 | Tue 10 Mar | -4.9% | 0.0% | +1.0% | +1.6% | +2.1% | 0.84 | 18.9 | HIGH STRESS | -5.9 pts | +79 / -573 | 100% | -466 | -1049 |  |
| 6 | Wed 11 Mar | -5.0% | 0.0% | -1.6% | -1.1% | -0.4% | 0.38 | 21.1 | HIGH STRESS | -3.4 pts | -132 / -367 | 100% | -447 | -1497 |  |
| 7 | Thu 12 Mar | -4.9% | 0.0% | -1.0% | -0.2% | -0.4% | 0.34 | 21.5 | HIGH STRESS | -4.0 pts | -78 / -415 | 100% | -420 | -1917 |  |
| 8 | Fri 13 Mar | -5.0% | 0.0% | -2.1% | -2.7% | -2.7% | 0.10 | 22.6 | HIGH STRESS | -2.9 pts | -168 / -328 | 100% | -402 | -2319 |  |
| 9 | Mon 16 Mar | -5.0% | 0.0% | +1.1% | -0.4% | -0.4% | 0.34 | 21.6 | HIGH STRESS | -6.1 pts | +91 / -589 | 100% | -384 | -2702 |  |
| 10 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts | +60 / -559 | 100% | -365 | -3068 |  |
| 11 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +68 / -567 | 100% | -347 | -3415 |  |
| 12 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -266 / -232 | 100% | -329 | -3744 |  |
| 13 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +40 / -535 | 100% | -311 | -4054 |  |
| 14 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -212 / -278 | 100% | -292 | -4346 |  |
| 15 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +132 / -615 | 0% | -291 | -4638 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 04 Mar 2026 at the open 109.50; sold Tue 24 Mar 2026 at the open 59.10 (lower-circuit lock: sold at the first free open). Gross -46.03%, costs -35 bp, net -4638 bp.
- Over the same hold: NIFTY -6.2%, Midcap -6.1%, Smallcap -5.2%; VIX +56.0%; breadth averaged 0.42; 15 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3983 bp, Midcap -3991 bp, Smallcap -4082 bp.
- Split: market part -5.04% = beta 0.81 x NIFTY 50 -6.19%; stock part -40.99% -> **mostly the stock itself**.
- The stock's own strongest day: session 2 (+403 bp beyond its market); weakest: session 15 (-615 bp).

_Pick day Mon 02 Mar 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -1.9%, breadth 0.13, VIX 17.1 (+21% in 5 days) -> D rank 3 AQYLON (moves with NIFTY 50, beta 0.81) -> bought Wed 04 Mar 2026 open, sold Tue 24 Mar 2026 open: gross -46.03%, net -4638 bp -> during the hold NIFTY -6.2%, Smallcap -5.2%, 15 high-stress day(s) -> market part -5.04%, stock part -40.99%: mostly the stock itself._

## D-20260317-1 - AQYLON - net -3847 bp (gross -38.12%) - SEVERE LOSER

- D rank 1 (score 0.045) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.19, correlation 0.24; NIFTY beta 1.19, Smallcap beta 0.30)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 16 Mar 2026: NIFTY +1.1%, Midcap -0.4%, Smallcap -0.4%; NIFTY minus Smallcap +1.5 pts (20-day -0.7 pts); breadth 0.34 (805 up / 1,580 down of 2,402; 10-day 0.35); VIX 21.6 (day -4.6%, 5-day -7.5%, 98th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 98th percentile of 250 sessions.
- Pick day: Tue 17 Mar 2026: NIFTY +0.7%, Midcap +1.0%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day -1.4 pts); breadth 0.63 (1,487 up / 889 down of 2,399; 10-day 0.40); VIX 19.8 (day -8.4%, 5-day +4.7%, 95th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 95th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-5.7 pts vs NIFTY 50)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.014, pred_mae_q20 -0.107, pred_mae_q50 -0.044, pred_mae_q80 -0.016, pred_mfe_q20 0.035, pred_mfe_q50 0.095, pred_mfe_q80 0.192, prob_big 0.670, prob_deep 0.311, prob_trap 0.294, prob_win 0.533

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +73 / -73 | 100% | -18 | -18 | buy open |
| 2 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -387 / -110 | 100% | -498 | -515 |  |
| 3 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +58 / -553 | 100% | -470 | -986 |  |
| 4 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -309 / -181 | 100% | -443 | -1428 |  |
| 5 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +211 / -710 | 100% | -429 | -1857 |  |
| 6 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +204 / -696 | 100% | -401 | -2258 |  |
| 7 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -248 / -251 | 100% | -387 | -2645 |  |
| 8 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -254 / -234 | 100% | -360 | -3005 |  |
| 9 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +185 / -684 | 100% | -350 | -3355 |  |
| 10 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +18 / -516 | 100% | -332 | -3687 |  |
| 11 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +133 / -632 | 100% | -315 | -4002 |  |
| 12 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +80 / -579 | 100% | -300 | -4302 |  |
| 13 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +449 / -30 | 100% | +239 | -4063 |  |
| 14 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -44 / +436 | 0% | +216 | -3847 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 18 Mar 2026 at the open 72.30; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -38.12%, costs -35 bp, net -3847 bp.
- Over the same hold: NIFTY +1.2%, Midcap +2.5%, Smallcap +3.7%; VIX -0.5%; breadth averaged 0.56; 14 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3929 bp, Midcap -4061 bp, Smallcap -4180 bp.
- Split: market part +1.39% = beta 1.19 x NIFTY 50 +1.17%; stock part -39.51% -> **mostly the stock itself**.
- The stock's own strongest day: session 14 (+436 bp beyond its market); weakest: session 5 (-710 bp).

_Pick day Tue 17 Mar 2026 [HIGH STRESS]: NIFTY +0.7%, Smallcap +0.6%, breadth 0.63, VIX 19.8 (+5% in 5 days) -> D rank 1 AQYLON (moves with NIFTY 50, beta 1.19) -> bought Wed 18 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -38.12%, net -3847 bp -> during the hold NIFTY +1.2%, Smallcap +3.7%, 14 high-stress day(s) -> market part +1.39%, stock part -39.51%: mostly the stock itself._

## D-20200313-3 - ORISSAMINE - net -3612 bp (gross -35.77%) - SEVERE LOSER

- D rank 3 (score 0.064) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.04, correlation 0.27; NIFTY beta 0.92, Smallcap beta 1.04)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 12 Mar 2020: NIFTY -8.3% (7.0 sd fall), Midcap -7.8% (7.1 sd fall), Smallcap -8.9% (7.4 sd fall); NIFTY minus Smallcap +0.6 pts (20-day +1.9 pts); breadth 0.04 (52 up / 1,358 down of 1,442; 10-day 0.28); VIX 41.2 (day +30.4%, 5-day +69.9%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +70% in 5 sessions; NIFTY -7.0 sd day; Smallcap -7.4 sd day.
- Pick day: Fri 13 Mar 2020: NIFTY +3.8% (2.4 sd rise), Midcap +2.3%, Smallcap +0.7%; NIFTY minus Smallcap +3.1 pts (20-day +3.6 pts); breadth 0.56 (773 up / 610 down of 1,432; 10-day 0.30); VIX 51.5 (day +25.0%, 5-day +121.4%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +121% in 5 sessions.
- The stock: day before -5.0%, pick day -4.1% (-4.8 pts vs Smallcap 250)

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 13 Mar | -4.1% | +1.0% | +3.8% | +2.3% | +0.7% | 0.56 | 51.5 | HIGH STRESS | -4.8 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 16 Mar | -5.0% | -3.2% | -7.6% | -5.9% | -5.4% | 0.12 | 58.9 | HIGH STRESS | +0.4 pts | -194 / -125 | 100% | -337 | -337 | buy open |
| 2 | Tue 17 Mar | -5.0% | -1.3% | -2.5% | -2.4% | -2.3% | 0.29 | 62.9 | HIGH STRESS | -2.7 pts | -241 / -258 | 100% | -484 | -821 |  |
| 3 | Wed 18 Mar | -5.0% | 0.0% | -5.6% | -5.4% | -6.1% | 0.11 | 64.0 | HIGH STRESS | +1.1 pts | -631 / +131 | 100% | -460 | -1280 |  |
| 4 | Thu 19 Mar | -5.0% | 0.0% | -2.4% | -4.0% | -5.2% | 0.19 | 72.2 | HIGH STRESS | +0.2 pts | -544 / +44 | 100% | -437 | -1717 |  |
| 5 | Fri 20 Mar | -5.0% | 0.0% | +5.8% | +4.4% | +2.2% | 0.67 | 67.1 | HIGH STRESS | -7.2 pts | +233 / -733 | 100% | -415 | -2132 |  |
| 6 | Mon 23 Mar | -5.0% | 0.0% | -13.0% | -13.0% | -12.4% | 0.04 | 72.0 | HIGH STRESS | +7.4 pts | -1286 / +786 | 100% | -394 | -2526 |  |
| 7 | Tue 24 Mar | -5.0% | 0.0% | +2.5% | +1.0% | -1.0% | 0.43 | 83.6 | HIGH STRESS | -4.0 pts | -100 / -400 | 100% | -374 | -2901 |  |
| 8 | Wed 25 Mar | -5.0% | 0.0% | +6.6% | +3.3% | +2.5% | 0.65 | 77.6 | HIGH STRESS | -7.5 pts | +259 / -759 | 100% | -356 | -3256 |  |
| 9 | Thu 26 Mar | -5.0% | 0.0% | +3.9% | +3.7% | +3.5% | 0.74 | 71.5 | HIGH STRESS | -8.5 pts | +360 / -860 | 100% | -338 | -3594 |  |
| 10 | Fri 27 Mar | -5.0% | -5.0% | +0.2% | -0.4% | +0.9% | 0.54 | 70.4 | HIGH STRESS | -5.9 pts | +330 / -330 | 0% | -18 | -3612 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 16 Mar 2020 at the open 1488.00; sold Fri 27 Mar 2020 at the open 955.75 (lower-circuit lock: sold at the first free open). Gross -35.77%, costs -35 bp, net -3612 bp.
- Over the same hold: NIFTY -6.7%, Midcap -12.4%, Smallcap -17.2%; VIX +39.0%; breadth averaged 0.38; 10 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2911 bp, Midcap -2335 bp, Smallcap -1854 bp.
- Split: market part -17.85% = beta 1.04 x Smallcap 250 -17.23%; stock part -17.92% -> **market and stock together**.
- The stock's own strongest day: session 6 (+786 bp beyond its market); weakest: session 9 (-860 bp).

_Pick day Fri 13 Mar 2020 [HIGH STRESS]: NIFTY +3.8%, Smallcap +0.7%, breadth 0.56, VIX 51.5 (+121% in 5 days) -> D rank 3 ORISSAMINE (moves with Smallcap 250, beta 1.04) -> bought Mon 16 Mar 2020 open, sold Fri 27 Mar 2020 open: gross -35.77%, net -3612 bp -> during the hold NIFTY -6.7%, Smallcap -17.2%, 10 high-stress day(s) -> market part -17.85%, stock part -17.92%: market and stock together._

## D-20260318-1 - AQYLON - net -3523 bp (gross -34.88%) - SEVERE LOSER

- D rank 1 (score 0.022) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.11, correlation 0.23; NIFTY beta 1.11, Smallcap beta 0.22)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 17 Mar 2026: NIFTY +0.7%, Midcap +1.0%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day -1.4 pts); breadth 0.63 (1,487 up / 889 down of 2,399; 10-day 0.40); VIX 19.8 (day -8.4%, 5-day +4.7%, 95th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 95th percentile of 250 sessions.
- Pick day: Wed 18 Mar 2026: NIFTY +0.8%, Midcap +1.9%, Smallcap +1.8%; NIFTY minus Smallcap -0.9 pts (20-day -1.7 pts); breadth 0.85 (2,024 up / 361 down of 2,403; 10-day 0.47); VIX 18.7 (day -5.4%, 5-day -11.1%, 93rd percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 93rd percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-5.8 pts vs NIFTY 50)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.006, pred_mae_q20 -0.127, pred_mae_q50 -0.047, pred_mae_q80 -0.014, pred_mfe_q20 0.012, pred_mfe_q50 0.086, pred_mfe_q80 0.176, prob_big 0.656, prob_deep 0.408, prob_trap 0.328, prob_win 0.482

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -93 / +93 | 100% | -18 | -18 | buy open |
| 2 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +54 / -549 | 100% | -495 | -512 |  |
| 3 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -288 / -202 | 100% | -466 | -978 |  |
| 4 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +197 / -696 | 100% | -451 | -1429 |  |
| 5 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +191 / -682 | 100% | -422 | -1852 |  |
| 6 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -231 / -268 | 100% | -408 | -2259 |  |
| 7 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -237 / -251 | 100% | -378 | -2638 |  |
| 8 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +173 / -672 | 100% | -368 | -3006 |  |
| 9 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +16 / -515 | 100% | -349 | -3355 |  |
| 10 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +124 / -623 | 100% | -332 | -3687 |  |
| 11 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +75 / -574 | 100% | -316 | -4003 |  |
| 12 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +419 / +0 | 100% | +252 | -3751 |  |
| 13 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -41 / +433 | 0% | +228 | -3523 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 19 Mar 2026 at the open 68.70; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -34.88%, costs -35 bp, net -3523 bp.
- Over the same hold: NIFTY +3.1%, Midcap +2.4%, Smallcap +3.8%; VIX +5.2%; breadth averaged 0.53; 13 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3794 bp, Midcap -3731 bp, Smallcap -3867 bp.
- Split: market part +3.40% = beta 1.11 x NIFTY 50 +3.07%; stock part -38.27% -> **mostly the stock itself**.
- The stock's own strongest day: session 13 (+433 bp beyond its market); weakest: session 4 (-696 bp).

_Pick day Wed 18 Mar 2026 [HIGH STRESS]: NIFTY +0.8%, Smallcap +1.8%, breadth 0.85, VIX 18.7 (-11% in 5 days) -> D rank 1 AQYLON (moves with NIFTY 50, beta 1.11) -> bought Thu 19 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -34.88%, net -3523 bp -> during the hold NIFTY +3.1%, Smallcap +3.8%, 13 high-stress day(s) -> market part +3.40%, stock part -38.27%: mostly the stock itself._

## D-20220117-2 - TTML - net -3411 bp (gross -33.76%) - SEVERE LOSER

- D rank 2 (score 0.027) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.63, correlation 0.18; NIFTY beta 0.29, Smallcap beta 0.63)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 14 Jan 2022: NIFTY 0.0%, Midcap 0.0%, Smallcap +0.7%; NIFTY minus Smallcap -0.7 pts (20-day -2.1 pts); breadth 0.60 (989 up / 650 down of 1,666; 10-day 0.57); VIX 16.6 (day -0.9%, 5-day -5.9%, 42nd percentile); environment: Broad bullish.
- Pick day: Mon 17 Jan 2022: NIFTY +0.3%, Midcap +0.3%, Smallcap +0.5%; NIFTY minus Smallcap -0.2 pts (20-day -3.8 pts); breadth 0.62 (1,018 up / 629 down of 1,682; 10-day 0.55); VIX 16.8 (day +1.3%, 5-day -5.1%, 46th percentile); environment: Broad bullish.
- The stock: day before -5.0%, pick day -5.0% (-5.4 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.013, pred_mae_q20 -0.134, pred_mae_q50 -0.073, pred_mae_q80 -0.025, pred_mfe_q20 0.013, pred_mfe_q50 0.047, pred_mfe_q80 0.108, prob_big 0.463, prob_deep 0.521, prob_trap 0.412, prob_win 0.359

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 17 Jan | -5.0% | 0.0% | +0.3% | +0.3% | +0.5% | 0.62 | 16.8 | Broad bullish | -5.4 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 18 Jan | -5.0% | 0.0% | -1.1% | -1.9% | -2.0% | 0.19 | 17.8 | Broad bullish | -2.9 pts | -153 / +153 | 100% | -18 | -18 | buy open |
| 2 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts | +14 / -513 | 100% | -499 | -516 |  |
| 3 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -7 / -492 | 100% | -474 | -990 |  |
| 4 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -118 / -380 | 100% | -450 | -1440 |  |
| 5 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -290 / -208 | 100% | -427 | -1867 |  |
| 6 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +67 / -566 | 100% | -407 | -2274 |  |
| 7 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -29 / -468 | 100% | -385 | -2659 |  |
| 8 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +33 / -532 | 100% | -367 | -3027 |  |
| 9 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +60 / -560 | 100% | -349 | -3376 |  |
| 10 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +47 / -546 | 100% | -332 | -3708 |  |
| 11 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +51 / +446 | 0% | +296 | -3411 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 18 Jan 2022 at the open 224.65; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -33.76%, costs -35 bp, net -3411 bp.
- Over the same hold: NIFTY -3.4%, Midcap -4.4%, Smallcap -5.2%; VIX +19.1%; breadth averaged 0.45; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3032 bp, Midcap -2934 bp, Smallcap -2857 bp.
- Split: market part -3.26% = beta 0.63 x Smallcap 250 -5.20%; stock part -30.50% -> **mostly the stock itself**.
- The stock's own strongest day: session 11 (+446 bp beyond its market); weakest: session 6 (-566 bp).

_Pick day Mon 17 Jan 2022 [Broad bullish]: NIFTY +0.3%, Smallcap +0.5%, breadth 0.62, VIX 16.8 (-5% in 5 days) -> D rank 2 TTML (moves with Smallcap 250, beta 0.63) -> bought Tue 18 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -33.76%, net -3411 bp -> during the hold NIFTY -3.4%, Smallcap -5.2%, 1 high-stress day(s) -> market part -3.26%, stock part -30.50%: mostly the stock itself._

## ENS-20230227-1 - ADANIENT - net +7282 bp (gross +73.17%) - WINNER

- ENS rank 1 (score 1.000) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 2.24, correlation 0.33; NIFTY beta 2.24, Smallcap beta 1.78)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 24 Feb 2023: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.2%; NIFTY minus Smallcap -0.1 pts (20-day -0.3 pts); breadth 0.39 (693 up / 1,080 down of 1,819; 10-day 0.38); VIX 14.2 (day -5.9%, 5-day +8.4%, 15th percentile); environment: Broad bearish.
- Pick day: Mon 27 Feb 2023: NIFTY -0.4%, Midcap -0.6%, Smallcap -1.2%; NIFTY minus Smallcap +0.8 pts (20-day 0.0 pts); breadth 0.19 (336 up / 1,468 down of 1,831; 10-day 0.38); VIX 13.9 (day -2.2%, 5-day +3.7%, 12th percentile); environment: Broad bearish.
- The stock: day before -4.8%, pick day -9.3% (-8.9 pts vs NIFTY 50)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.024, pred_mae_q20 -0.096, pred_mae_q50 -0.055, pred_mae_q80 -0.013, pred_mfe_q20 0.046, pred_mfe_q50 0.097, pred_mfe_q80 0.197, prob_big 0.822, prob_deep 0.257, prob_trap 0.005, prob_win 0.708

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 27 Feb | -9.3% | -8.2% | -0.4% | -0.6% | -1.2% | 0.19 | 13.9 | Broad bearish | -8.9 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 28 Feb | +14.3% | +19.1% | -0.5% | +0.6% | +0.3% | 0.50 | 14.0 | Broad bearish | +14.8 pts | -102 / +2013 | 100% | +1893 | +1893 | buy open |
| 2 | Wed 01 Mar | +14.7% | +9.9% | +0.8% | +1.4% | +1.2% | 0.78 | 13.0 | Broad bearish | +13.9 pts | +191 / +1280 | 100% | +1751 | +3644 |  |
| 3 | Thu 02 Mar | +2.7% | +7.2% | -0.7% | -0.2% | -0.1% | 0.40 | 13.0 | Broad bearish | +3.5 pts | -166 / +440 | 100% | +375 | +4019 |  |
| 4 | Fri 03 Mar | +16.9% | +11.3% | +1.6% | +0.5% | +0.7% | 0.69 | 12.2 | Broad bearish | +15.4 pts | +353 / +1341 | 100% | +2377 | +6396 |  |
| 5 | Mon 06 Mar | +5.5% | +0.8% | +0.7% | +0.7% | +1.0% | 0.62 | 12.3 | Mixed / ranging | +4.8 pts | +149 / +401 | 0% | +886 | +7282 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 28 Feb 2023 at the open 1110.10; sold Mon 06 Mar 2023 at the close 1922.40. Gross +73.17%, costs -35 bp, net +7282 bp.
- Over the same hold: NIFTY +1.9%, Midcap +2.8%, Smallcap +2.9%; VIX -11.6%; breadth averaged 0.60; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY +7129 bp, Midcap +7034 bp, Smallcap +7025 bp.
- Split: market part +4.24% = beta 2.24 x NIFTY 50 +1.89%; stock part +68.94% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+2013 bp beyond its market); weakest: session 5 (+401 bp).

_Pick day Mon 27 Feb 2023 [Broad bearish]: NIFTY -0.4%, Smallcap -1.2%, breadth 0.19, VIX 13.9 (+4% in 5 days) -> ENS rank 1 ADANIENT (moves with NIFTY 50, beta 2.24) -> bought Tue 28 Feb 2023 open, sold Mon 06 Mar 2023 close: gross +73.17%, net +7282 bp -> during the hold NIFTY +1.9%, Smallcap +2.9% -> market part +4.24%, stock part +68.94%: mostly the stock itself._

## ENS-20240117-1 - SALASAR - net +6164 bp (gross +61.99%) - WINNER

- ENS rank 1 (score 0.994) | the other engine ranked it 9 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.27, correlation 0.40; NIFTY beta 1.18, Smallcap beta 1.27)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 16 Jan 2024: NIFTY -0.3%, Midcap -0.3%, Smallcap -0.3%; NIFTY minus Smallcap 0.0 pts (20-day -2.0 pts); breadth 0.28 (548 up / 1,381 down of 1,948; 10-day 0.50); VIX 13.6 (day -1.6%, 5-day +2.3%, 79th percentile); environment: Broad bullish.
- Pick day: Wed 17 Jan 2024: NIFTY -2.1% (3.1 sd fall), Midcap -1.1%, Smallcap -1.0%; NIFTY minus Smallcap -1.0 pts (20-day -3.1 pts); breadth 0.24 (458 up / 1,468 down of 1,948; 10-day 0.47); VIX 15.1 (day +11.1%, 5-day +16.3%, 94th percentile); environment: HIGH STRESS (direction: Narrow bullish) - VIX at its 94th percentile of 250 sessions; NIFTY -3.1 sd day.
- The stock: day before -5.2%, pick day -2.9% (-1.9 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.000, pred_mae_q20 -0.084, pred_mae_q50 -0.037, pred_mae_q80 -0.014, pred_mfe_q20 0.019, pred_mfe_q50 0.048, pred_mfe_q80 0.097, prob_big 0.514, prob_deep 0.279, prob_trap 0.006, prob_win 0.522

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 17 Jan | -2.9% | -2.9% | -2.1% | -1.1% | -1.0% | 0.24 | 15.1 | HIGH STRESS | -1.9 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 18 Jan | +5.2% | +4.1% | -0.5% | 0.0% | 0.0% | 0.44 | 14.1 | Narrow bullish | +5.2 pts | +8 / +398 | 100% | +388 | +388 | buy open |
| 2 | Fri 19 Jan | +12.4% | +7.1% | +0.7% | +1.5% | +1.1% | 0.69 | 13.9 | Narrow bullish | +11.3 pts | +136 / +1105 | 100% | +1292 | +1680 |  |
| 3 | Sat 20 Jan | +19.6% | +14.5% | -0.2% | +0.3% | +0.5% | 0.49 | 13.8 | Narrow bullish | +19.1 pts | +57 / +1898 | 100% | +2288 | +3968 |  |
| 4 | Tue 23 Jan | +13.7% | +0.7% | -1.5% | -2.9% | -2.7% | 0.13 | 14.8 | HIGH STRESS | +16.4 pts | -345 / +1717 | 100% | +1919 | +5887 |  |
| 5 | Wed 24 Jan | +1.9% | -4.6% | +1.0% | +1.7% | +1.8% | 0.74 | 14.4 | Narrow bullish | +0.1 pts | +224 / -38 | 0% | +278 | +6164 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 18 Jan 2024 at the open 13.55; sold Wed 24 Jan 2024 at the close 21.95. Gross +61.99%, costs -35 bp, net +6164 bp.
- Over the same hold: NIFTY +0.2%, Midcap +0.6%, Smallcap +0.6%; VIX -4.6%; breadth averaged 0.50; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY +6181 bp, Midcap +6137 bp, Smallcap +6143 bp.
- Split: market part +0.72% = beta 1.27 x Smallcap 250 +0.56%; stock part +61.28% -> **mostly the stock itself**.
- The stock's own strongest day: session 3 (+1898 bp beyond its market); weakest: session 5 (-38 bp).

_Pick day Wed 17 Jan 2024 [HIGH STRESS]: NIFTY -2.1%, Smallcap -1.0%, breadth 0.24, VIX 15.1 (+16% in 5 days) -> ENS rank 1 SALASAR (moves with Smallcap 250, beta 1.27) -> bought Thu 18 Jan 2024 open, sold Wed 24 Jan 2024 close: gross +61.99%, net +6164 bp -> during the hold NIFTY +0.2%, Smallcap +0.6%, 1 high-stress day(s) -> market part +0.72%, stock part +61.28%: mostly the stock itself._

## ENS-20200407-3 - ASHOKA - net +5949 bp (gross +59.84%) - WINNER

- ENS rank 3 (score 0.986) | the other engine ranked it 9 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.34, correlation 0.71; NIFTY beta 0.97, Smallcap beta 1.34)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 03 Apr 2020: NIFTY -2.1%, Midcap -1.3%, Smallcap -1.1%; NIFTY minus Smallcap -1.0 pts (20-day +5.9 pts); breadth 0.49 (653 up / 692 down of 1,408; 10-day 0.52); VIX 55.3 (day -7.9%, 5-day -22.7%, 95th percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 95th percentile of 250 sessions.
- Pick day: Tue 07 Apr 2020: NIFTY +8.8% (2.8 sd rise), Midcap +4.8%, Smallcap +3.5%; NIFTY minus Smallcap +5.3 pts (20-day +10.1 pts); breadth 0.87 (1,200 up / 184 down of 1,429; 10-day 0.54); VIX 51.8 (day -6.3%, 5-day -26.4%, 94th percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 94th percentile of 250 sessions; NIFTY +2.8 sd day.
- The stock: day before -4.8%, pick day +3.6% (+0.1 pts vs Smallcap 250)

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 07 Apr | +3.6% | -0.4% | +8.8% | +4.8% | +3.5% | 0.87 | 51.8 | HIGH STRESS | +0.1 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 08 Apr | +9.9% | +11.3% | -0.5% | +1.6% | +1.7% | 0.65 | 52.2 | HIGH STRESS | +8.2 pts | +127 / +1007 | 100% | +1117 | +1117 | buy open |
| 2 | Thu 09 Apr | +18.1% | +9.9% | +4.2% | +3.2% | +3.4% | 0.85 | 49.8 | HIGH STRESS | +14.7 pts | +459 / +1356 | 100% | +2021 | +3138 |  |
| 3 | Mon 13 Apr | -1.9% | -2.0% | -1.3% | -1.1% | -0.4% | 0.45 | 51.5 | HIGH STRESS | -1.5 pts | -56 / -132 | 100% | -248 | +2890 |  |
| 4 | Wed 15 Apr | +4.5% | +4.5% | -0.8% | +1.3% | +1.1% | 0.62 | 49.7 | HIGH STRESS | +3.5 pts | +143 / +312 | 100% | +587 | +3477 |  |
| 5 | Thu 16 Apr | +18.5% | +15.7% | +0.8% | +1.5% | +2.0% | 0.71 | 46.1 | HIGH STRESS | +16.4 pts | +271 / +1574 | 0% | +2473 | +5949 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 08 Apr 2020 at the open 38.35; sold Thu 16 Apr 2020 at the close 61.30. Gross +59.84%, costs -35 bp, net +5949 bp.
- Over the same hold: NIFTY +3.5%, Midcap +6.9%, Smallcap +7.2%; VIX -11.0%; breadth averaged 0.66; 5 high-stress session(s).
- Against each index (gross minus the index): NIFTY +5635 bp, Midcap +5299 bp, Smallcap +5263 bp.
- Split: market part +9.66% = beta 1.34 x Smallcap 250 +7.21%; stock part +50.19% -> **mostly the stock itself**.
- The stock's own strongest day: session 5 (+1574 bp beyond its market); weakest: session 3 (-132 bp).

_Pick day Tue 07 Apr 2020 [HIGH STRESS]: NIFTY +8.8%, Smallcap +3.5%, breadth 0.87, VIX 51.8 (-26% in 5 days) -> ENS rank 3 ASHOKA (moves with Smallcap 250, beta 1.34) -> bought Wed 08 Apr 2020 open, sold Thu 16 Apr 2020 close: gross +59.84%, net +5949 bp -> during the hold NIFTY +3.5%, Smallcap +7.2%, 5 high-stress day(s) -> market part +9.66%, stock part +50.19%: mostly the stock itself._

## ENS-20230907-3 - NIITLTD - net +5903 bp (gross +59.38%) - WINNER

- ENS rank 3 (score 0.969) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.77, correlation 0.23; NIFTY beta 1.36, Smallcap beta 1.77)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 06 Sep 2023: NIFTY +0.2%, Midcap 0.0%, Smallcap +0.1%; NIFTY minus Smallcap +0.1 pts (20-day -7.3 pts); breadth 0.48 (899 up / 955 down of 1,899; 10-day 0.54); VIX 10.7 (day -1.3%, 5-day -9.5%, 4th percentile); environment: Broad bullish.
- Pick day: Thu 07 Sep 2023: NIFTY +0.6%, Midcap +0.6%, Smallcap +0.6%; NIFTY minus Smallcap 0.0 pts (20-day -7.0 pts); breadth 0.61 (1,119 up / 730 down of 1,895; 10-day 0.55); VIX 10.9 (day +1.8%, 5-day -9.9%, 6th percentile); environment: Broad bullish.
- The stock: day before -0.6%, pick day +0.3% (-0.3 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.002, pred_mae_q20 -0.049, pred_mae_q50 -0.025, pred_mae_q80 -0.008, pred_mfe_q20 0.010, pred_mfe_q50 0.034, pred_mfe_q80 0.083, prob_big 0.402, prob_deep 0.054, prob_trap 0.005, prob_win 0.486

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 07 Sep | +0.3% | 0.0% | +0.6% | +0.6% | +0.6% | 0.61 | 10.9 | Broad bullish | -0.3 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 08 Sep | -0.8% | -0.4% | +0.5% | +0.9% | +0.6% | 0.52 | 10.8 | Broad bullish | -1.5 pts | +5 / -41 | 100% | -54 | -54 | buy open |
| 2 | Mon 11 Sep | +20.0% | +16.7% | +0.9% | +1.1% | +1.0% | 0.56 | 11.3 | Broad bullish | +19.0 pts | +172 / +1826 | 100% | +1992 | +1938 |  |
| 3 | Tue 12 Sep | +18.8% | +12.5% | 0.0% | -3.0% | -3.9% | 0.09 | 11.7 | HIGH STRESS | +22.7 pts | -686 / +2564 | 100% | +2246 | +4183 |  |
| 4 | Wed 13 Sep | +20.0% | +16.3% | +0.4% | +0.1% | +1.0% | 0.65 | 11.8 | Broad bullish | +19.0 pts | +174 / +1825 | 100% | +2839 | +7022 |  |
| 5 | Thu 14 Sep | -6.5% | -12.2% | +0.2% | +0.9% | +1.2% | 0.74 | 11.3 | Broad bullish | -7.7 pts | +216 / -863 | 0% | -1119 | +5903 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 08 Sep 2023 at the open 82.60; sold Thu 14 Sep 2023 at the close 131.65. Gross +59.38%, costs -35 bp, net +5903 bp.
- Over the same hold: NIFTY +1.7%, Midcap -0.3%, Smallcap -0.8%; VIX +4.1%; breadth averaged 0.51; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY +5772 bp, Midcap +5968 bp, Smallcap +6014 bp.
- Split: market part -1.35% = beta 1.77 x Smallcap 250 -0.76%; stock part +60.73% -> **mostly the stock itself**.
- The stock's own strongest day: session 3 (+2564 bp beyond its market); weakest: session 5 (-863 bp).

_Pick day Thu 07 Sep 2023 [Broad bullish]: NIFTY +0.6%, Smallcap +0.6%, breadth 0.61, VIX 10.9 (-10% in 5 days) -> ENS rank 3 NIITLTD (moves with Smallcap 250, beta 1.77) -> bought Fri 08 Sep 2023 open, sold Thu 14 Sep 2023 close: gross +59.38%, net +5903 bp -> during the hold NIFTY +1.7%, Smallcap -0.8%, 1 high-stress day(s) -> market part -1.35%, stock part +60.73%: mostly the stock itself._

## ENS-20200413-1 - J&KBANK - net +5649 bp (gross +56.84%) - WINNER

- ENS rank 1 (score 0.995) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 0.88, correlation 0.52; NIFTY beta 0.76, Smallcap beta 0.84)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 09 Apr 2020: NIFTY +4.2%, Midcap +3.2%, Smallcap +3.4%; NIFTY minus Smallcap +0.7 pts (20-day +10.5 pts); breadth 0.85 (1,176 up / 202 down of 1,421; 10-day 0.64); VIX 49.8 (day -4.8%, 5-day -22.8%, 93rd percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 93rd percentile of 250 sessions.
- Pick day: Mon 13 Apr 2020: NIFTY -1.3%, Midcap -1.1%, Smallcap -0.4%; NIFTY minus Smallcap -0.9 pts (20-day +9.4 pts); breadth 0.45 (614 up / 748 down of 1,426; 10-day 0.62); VIX 51.5 (day +3.4%, 5-day -14.3%, 93rd percentile); environment: HIGH STRESS (direction: Mixed / ranging) - VIX at its 93rd percentile of 250 sessions.
- The stock: day before +0.4%, pick day -3.4% (-2.2 pts vs Midcap 150)

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 13 Apr | -3.4% | -3.4% | -1.3% | -1.1% | -0.4% | 0.45 | 51.5 | HIGH STRESS | -2.2 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 15 Apr | +5.2% | +3.4% | -0.8% | +1.3% | +1.1% | 0.62 | 49.7 | HIGH STRESS | +3.9 pts | -1 / +343 | 100% | +324 | +324 | buy open |
| 2 | Thu 16 Apr | -1.2% | -0.4% | +0.8% | +1.5% | +2.0% | 0.71 | 46.1 | HIGH STRESS | -2.8 pts | +137 / -261 | 100% | -128 | +196 |  |
| 3 | Fri 17 Apr | +19.7% | +16.3% | +3.0% | +2.2% | +3.0% | 0.76 | 42.6 | HIGH STRESS | +17.4 pts | +196 / +1770 | 100% | +2009 | +2205 |  |
| 4 | Mon 20 Apr | +19.9% | +3.0% | -0.1% | +0.5% | +0.7% | 0.58 | 43.5 | HIGH STRESS | +19.5 pts | +42 / +1951 | 100% | +2436 | +4641 |  |
| 5 | Tue 21 Apr | +7.0% | -1.9% | -3.0% | -2.9% | -3.5% | 0.21 | 45.2 | HIGH STRESS | +9.9 pts | -256 / +956 | 0% | +1008 | +5649 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 15 Apr 2020 at the open 11.70; sold Tue 21 Apr 2020 at the close 18.35. Gross +56.84%, costs -35 bp, net +5649 bp.
- Over the same hold: NIFTY -2.3%, Midcap +1.3%, Smallcap +1.6%; VIX -12.2%; breadth averaged 0.58; 5 high-stress session(s).
- Against each index (gross minus the index): NIFTY +5917 bp, Midcap +5558 bp, Smallcap +5529 bp.
- Split: market part +1.11% = beta 0.88 x Midcap 150 +1.26%; stock part +55.72% -> **mostly the stock itself**.
- The stock's own strongest day: session 4 (+1951 bp beyond its market); weakest: session 2 (-261 bp).

_Pick day Mon 13 Apr 2020 [HIGH STRESS]: NIFTY -1.3%, Smallcap -0.4%, breadth 0.45, VIX 51.5 (-14% in 5 days) -> ENS rank 1 J&KBANK (moves with Midcap 150, beta 0.88) -> bought Wed 15 Apr 2020 open, sold Tue 21 Apr 2020 close: gross +56.84%, net +5649 bp -> during the hold NIFTY -2.3%, Smallcap +1.6%, 5 high-stress day(s) -> market part +1.11%, stock part +55.72%: mostly the stock itself._

## ENS-20230120-2 - PCJEWELLER - net -6262 bp (gross -62.27%) - SEVERE LOSER

- ENS rank 2 (score 0.995) | the other engine ranked it 10 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 1.08, correlation 0.33; NIFTY beta 0.87, Smallcap beta 0.94)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 19 Jan 2023: NIFTY -0.3%, Midcap -0.1%, Smallcap -0.3%; NIFTY minus Smallcap 0.0 pts (20-day -0.4 pts); breadth 0.39 (679 up / 1,072 down of 1,804; 10-day 0.45); VIX 14.0 (day -2.9%, 5-day -8.6%, 7th percentile); environment: Broad bearish.
- Pick day: Fri 20 Jan 2023: NIFTY -0.4%, Midcap -0.7%, Smallcap -0.6%; NIFTY minus Smallcap +0.1 pts (20-day -3.0 pts); breadth 0.35 (616 up / 1,143 down of 1,808; 10-day 0.45); VIX 13.8 (day -1.2%, 5-day -4.6%, 6th percentile); environment: Broad bearish.
- The stock: day before -5.0%, pick day -5.0% (-4.3 pts vs Midcap 150)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.007, pred_mae_q20 -0.098, pred_mae_q50 -0.056, pred_mae_q80 -0.016, pred_mfe_q20 0.022, pred_mfe_q50 0.063, pred_mfe_q80 0.112, prob_big 0.582, prob_deep 0.348, prob_trap 0.098, prob_win 0.551

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 20 Jan | -5.0% | -1.4% | -0.4% | -0.7% | -0.6% | 0.35 | 13.8 | Broad bearish | -4.3 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 23 Jan | -5.0% | 0.0% | +0.5% | +0.2% | -0.1% | 0.44 | 13.6 | Broad bearish | -5.1 pts | +3 / -3 | 100% | -18 | -18 | buy open |
| 2 | Tue 24 Jan | -5.1% | 0.0% | 0.0% | -0.3% | -0.4% | 0.38 | 13.7 | Broad bearish | -4.7 pts | -38 / -468 | 100% | -506 | -524 |  |
| 3 | Wed 25 Jan | -5.0% | 0.0% | -1.2% | -1.3% | -0.9% | 0.20 | 14.7 | Broad bearish | -3.8 pts | -135 / -366 | 100% | -475 | -999 |  |
| 4 | Fri 27 Jan | -4.9% | 0.0% | -1.6% | -1.2% | -1.8% | 0.15 | 17.3 | Broad bearish | -3.7 pts | -134 / -359 | 100% | -445 | -1444 |  |
| 5 | Mon 30 Jan | -5.0% | 0.0% | +0.3% | -0.2% | -0.2% | 0.41 | 17.7 | HIGH STRESS | -4.9 pts | -16 / -485 | 100% | -429 | -1873 |  |
| 6 | Tue 31 Jan | -5.1% | 0.0% | +0.1% | +1.5% | +2.6% | 0.78 | 16.9 | HIGH STRESS | -6.6 pts | +165 / -673 | 100% | -414 | -2287 |  |
| 7 | Wed 01 Feb | -4.8% | 0.0% | -0.3% | -0.9% | -1.1% | 0.27 | 16.8 | Broad bearish | -3.9 pts | -92 / -384 | 100% | -368 | -2656 |  |
| 8 | Thu 02 Feb | -5.0% | 0.0% | 0.0% | +0.2% | +0.4% | 0.47 | 15.7 | Broad bearish | -5.2 pts | +19 / -519 | 100% | -368 | -3024 |  |
| 9 | Fri 03 Feb | -5.0% | 0.0% | +1.4% | -0.1% | -0.4% | 0.36 | 14.4 | Broad bearish | -4.9 pts | -13 / -492 | 100% | -353 | -3376 |  |
| 10 | Mon 06 Feb | -4.8% | 0.0% | -0.5% | +0.9% | +0.3% | 0.54 | 14.7 | Broad bearish | -5.7 pts | +92 / -577 | 100% | -322 | -3698 |  |
| 11 | Tue 07 Feb | -5.1% | 0.0% | -0.2% | 0.0% | -0.4% | 0.41 | 14.1 | Broad bearish | -5.1 pts | -1 / -508 | 100% | -322 | -4021 |  |
| 12 | Wed 08 Feb | -4.9% | 0.0% | +0.8% | +0.8% | +0.8% | 0.65 | 13.6 | Broad bearish | -5.7 pts | +91 / -577 | 100% | -291 | -4312 |  |
| 13 | Thu 09 Feb | -5.1% | 0.0% | +0.1% | +0.1% | -0.3% | 0.48 | 13.0 | Broad bearish | -5.2 pts | +9 / -520 | 100% | -291 | -4603 |  |
| 14 | Fri 10 Feb | -4.8% | 0.0% | -0.2% | +0.2% | +0.5% | 0.51 | 12.8 | Broad bearish | -5.1 pts | +27 / -508 | 100% | -261 | -4864 |  |
| 15 | Mon 13 Feb | -5.1% | 0.0% | -0.5% | -1.3% | -1.2% | 0.26 | 13.7 | Broad bearish | -3.8 pts | -141 / -365 | 100% | -261 | -5125 |  |
| 16 | Tue 14 Feb | -5.0% | 0.0% | +0.9% | -0.4% | -0.5% | 0.33 | 13.4 | Broad bearish | -4.6 pts | -47 / -455 | 100% | -245 | -5370 |  |
| 17 | Wed 15 Feb | -5.0% | 0.0% | +0.5% | +0.5% | +0.4% | 0.56 | 12.9 | Broad bearish | -5.4 pts | +52 / -547 | 100% | -230 | -5600 |  |
| 18 | Thu 16 Feb | -4.9% | 0.0% | +0.1% | +0.8% | +0.8% | 0.59 | 12.9 | Broad bearish | -5.6 pts | +83 / -569 | 100% | -215 | -5815 |  |
| 19 | Fri 17 Feb | -5.1% | 0.0% | -0.5% | -0.6% | -0.3% | 0.35 | 13.1 | Broad bearish | -4.5 pts | -68 / -443 | 100% | -215 | -6030 |  |
| 20 | Mon 20 Feb | -4.6% | 0.0% | -0.6% | 0.0% | -0.3% | 0.34 | 13.4 | Broad bearish | -4.6 pts | +0 / -462 | 100% | -184 | -6214 |  |
| 21 | Tue 21 Feb | -4.8% | 0.0% | -0.1% | -0.3% | -0.3% | 0.38 | 14.0 | Broad bearish | -4.6 pts | -29 / -455 | 100% | -184 | -6398 |  |
| 22 | Wed 22 Feb | -5.1% | 0.0% | -1.5% | -1.0% | -1.1% | 0.19 | 15.6 | Broad bearish | -4.1 pts | -108 / -400 | 100% | -184 | -6582 |  |
| 23 | Thu 23 Feb | +4.9% | +10.3% | -0.2% | -0.2% | +0.2% | 0.44 | 15.1 | Broad bearish | +5.2 pts | -26 / +517 | 100% | +169 | -6413 |  |
| 24 | Fri 24 Feb | +4.7% | 0.0% | -0.3% | -0.2% | -0.2% | 0.39 | 14.2 | Broad bearish | +4.9 pts | +31 / +437 | 0% | +151 | -6262 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 23 Jan 2023 at the open 6.52; sold Fri 24 Feb 2023 at the open 2.46 (lower-circuit lock: sold at the first free open). Gross -62.27%, costs -35 bp, net -6262 bp.
- Over the same hold: NIFTY -2.9%, Midcap -2.6%, Smallcap -3.5%; VIX +9.4%; breadth averaged 0.41; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -5936 bp, Midcap -5969 bp, Smallcap -5873 bp.
- Split: market part -2.78% = beta 1.08 x Midcap 150 -2.58%; stock part -59.49% -> **mostly the stock itself**.
- The stock's own strongest day: session 23 (+517 bp beyond its market); weakest: session 6 (-673 bp).

_Pick day Fri 20 Jan 2023 [Broad bearish]: NIFTY -0.4%, Smallcap -0.6%, breadth 0.35, VIX 13.8 (-5% in 5 days) -> ENS rank 2 PCJEWELLER (moves with Midcap 150, beta 1.08) -> bought Mon 23 Jan 2023 open, sold Fri 24 Feb 2023 open: gross -62.27%, net -6262 bp -> during the hold NIFTY -2.9%, Smallcap -3.5%, 2 high-stress day(s) -> market part -2.78%, stock part -59.49%: mostly the stock itself._

## ENS-20260302-2 - AQYLON - net -4638 bp (gross -46.03%) - SEVERE LOSER

- ENS rank 2 (score 0.999) | the other engine ranked it 3 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 0.81, correlation 0.15; NIFTY beta 0.81, Smallcap beta 0.02)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 27 Feb 2026: NIFTY -1.2%, Midcap -1.1%, Smallcap -1.0%; NIFTY minus Smallcap -0.2 pts (20-day -1.6 pts); breadth 0.30 (703 up / 1,648 down of 2,382; 10-day 0.44); VIX 13.7 (day +4.9%, 5-day -4.6%, 73rd percentile); environment: Broad bearish.
- Pick day: Mon 02 Mar 2026: NIFTY -1.2%, Midcap -1.7%, Smallcap -1.9%; NIFTY minus Smallcap +0.7 pts (20-day -1.4 pts); breadth 0.13 (310 up / 2,068 down of 2,385; 10-day 0.41); VIX 17.1 (day +25.0%, 5-day +20.9%, 90th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 90th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-3.8 pts vs NIFTY 50)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.035, pred_mae_q20 -0.115, pred_mae_q50 -0.050, pred_mae_q80 -0.017, pred_mfe_q20 0.040, pred_mfe_q50 0.094, pred_mfe_q80 0.164, prob_big 0.760, prob_deep 0.420, prob_trap 0.164, prob_win 0.660

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 02 Mar | -5.0% | 0.0% | -1.2% | -1.7% | -1.9% | 0.13 | 17.1 | HIGH STRESS | -3.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 04 Mar | -5.0% | -1.0% | -1.5% | -2.2% | -2.1% | 0.14 | 21.1 | HIGH STRESS | -3.4 pts | +31 / -131 | 100% | -118 | -118 | buy open |
| 2 | Thu 05 Mar | +5.0% | +4.4% | +1.2% | +1.5% | +1.4% | 0.70 | 17.9 | HIGH STRESS | +3.8 pts | +95 / +403 | 100% | +493 | +375 |  |
| 3 | Fri 06 Mar | -4.5% | -6.5% | -1.3% | -0.7% | -0.3% | 0.35 | 19.9 | HIGH STRESS | -3.2 pts | -104 / -344 | 100% | -466 | -91 |  |
| 4 | Mon 09 Mar | -5.0% | 0.0% | -1.7% | -2.0% | -2.3% | 0.14 | 23.4 | HIGH STRESS | -3.2 pts | -141 / -356 | 100% | -493 | -584 |  |
| 5 | Tue 10 Mar | -4.9% | 0.0% | +1.0% | +1.6% | +2.1% | 0.84 | 18.9 | HIGH STRESS | -5.9 pts | +79 / -573 | 100% | -466 | -1049 |  |
| 6 | Wed 11 Mar | -5.0% | 0.0% | -1.6% | -1.1% | -0.4% | 0.38 | 21.1 | HIGH STRESS | -3.4 pts | -132 / -367 | 100% | -447 | -1497 |  |
| 7 | Thu 12 Mar | -4.9% | 0.0% | -1.0% | -0.2% | -0.4% | 0.34 | 21.5 | HIGH STRESS | -4.0 pts | -78 / -415 | 100% | -420 | -1917 |  |
| 8 | Fri 13 Mar | -5.0% | 0.0% | -2.1% | -2.7% | -2.7% | 0.10 | 22.6 | HIGH STRESS | -2.9 pts | -168 / -328 | 100% | -402 | -2319 |  |
| 9 | Mon 16 Mar | -5.0% | 0.0% | +1.1% | -0.4% | -0.4% | 0.34 | 21.6 | HIGH STRESS | -6.1 pts | +91 / -589 | 100% | -384 | -2702 |  |
| 10 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts | +60 / -559 | 100% | -365 | -3068 |  |
| 11 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +68 / -567 | 100% | -347 | -3415 |  |
| 12 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -266 / -232 | 100% | -329 | -3744 |  |
| 13 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +40 / -535 | 100% | -311 | -4054 |  |
| 14 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -212 / -278 | 100% | -292 | -4346 |  |
| 15 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +132 / -615 | 0% | -291 | -4638 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 04 Mar 2026 at the open 109.50; sold Tue 24 Mar 2026 at the open 59.10 (lower-circuit lock: sold at the first free open). Gross -46.03%, costs -35 bp, net -4638 bp.
- Over the same hold: NIFTY -6.2%, Midcap -6.1%, Smallcap -5.2%; VIX +56.0%; breadth averaged 0.42; 15 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3983 bp, Midcap -3991 bp, Smallcap -4082 bp.
- Split: market part -5.04% = beta 0.81 x NIFTY 50 -6.19%; stock part -40.99% -> **mostly the stock itself**.
- The stock's own strongest day: session 2 (+403 bp beyond its market); weakest: session 15 (-615 bp).

_Pick day Mon 02 Mar 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -1.9%, breadth 0.13, VIX 17.1 (+21% in 5 days) -> ENS rank 2 AQYLON (moves with NIFTY 50, beta 0.81) -> bought Wed 04 Mar 2026 open, sold Tue 24 Mar 2026 open: gross -46.03%, net -4638 bp -> during the hold NIFTY -6.2%, Smallcap -5.2%, 15 high-stress day(s) -> market part -5.04%, stock part -40.99%: mostly the stock itself._

## ENS-20230202-3 - PCJEWELLER - net -4354 bp (gross -43.19%) - SEVERE LOSER

- ENS rank 3 (score 0.996) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 0.99, correlation 0.29; NIFTY beta 0.83, Smallcap beta 0.82)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 01 Feb 2023: NIFTY -0.3%, Midcap -0.9%, Smallcap -1.1%; NIFTY minus Smallcap +0.9 pts (20-day +0.9 pts); breadth 0.27 (491 up / 1,306 down of 1,818; 10-day 0.39); VIX 16.8 (day -0.6%, 5-day +22.8%, 27th percentile); environment: Broad bearish.
- Pick day: Thu 02 Feb 2023: NIFTY 0.0%, Midcap +0.2%, Smallcap +0.4%; NIFTY minus Smallcap -0.5 pts (20-day +0.6 pts); breadth 0.47 (832 up / 957 down of 1,820; 10-day 0.38); VIX 15.7 (day -6.3%, 5-day +7.3%, 22nd percentile); environment: Broad bearish.
- The stock: day before -4.8%, pick day -5.0% (-5.2 pts vs Midcap 150)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.005, pred_mae_q20 -0.143, pred_mae_q50 -0.062, pred_mae_q80 -0.013, pred_mfe_q20 0.021, pred_mfe_q50 0.088, pred_mfe_q80 0.162, prob_big 0.670, prob_deep 0.484, prob_trap 0.393, prob_win 0.447

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 02 Feb | -5.0% | 0.0% | 0.0% | +0.2% | +0.4% | 0.47 | 15.7 | Broad bearish | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 03 Feb | -5.0% | 0.0% | +1.4% | -0.1% | -0.4% | 0.36 | 14.4 | Broad bearish | -4.9 pts | -37 / +37 | 100% | -18 | -18 | buy open |
| 2 | Mon 06 Feb | -4.8% | 0.0% | -0.5% | +0.9% | +0.3% | 0.54 | 14.7 | Broad bearish | -5.7 pts | +84 / -569 | 100% | -485 | -502 |  |
| 3 | Tue 07 Feb | -5.1% | 0.0% | -0.2% | 0.0% | -0.4% | 0.41 | 14.1 | Broad bearish | -5.1 pts | -1 / -509 | 100% | -485 | -987 |  |
| 4 | Wed 08 Feb | -4.9% | 0.0% | +0.8% | +0.8% | +0.8% | 0.65 | 13.6 | Broad bearish | -5.7 pts | +83 / -569 | 100% | -439 | -1426 |  |
| 5 | Thu 09 Feb | -5.1% | 0.0% | +0.1% | +0.1% | -0.3% | 0.48 | 13.0 | Broad bearish | -5.2 pts | +9 / -519 | 100% | -439 | -1865 |  |
| 6 | Fri 10 Feb | -4.8% | 0.0% | -0.2% | +0.2% | +0.5% | 0.51 | 12.8 | Broad bearish | -5.1 pts | +24 / -506 | 100% | -393 | -2258 |  |
| 7 | Mon 13 Feb | -5.1% | 0.0% | -0.5% | -1.3% | -1.2% | 0.26 | 13.7 | Broad bearish | -3.8 pts | -129 / -377 | 100% | -393 | -2650 |  |
| 8 | Tue 14 Feb | -5.0% | 0.0% | +0.9% | -0.4% | -0.5% | 0.33 | 13.4 | Broad bearish | -4.6 pts | -42 / -459 | 100% | -370 | -3020 |  |
| 9 | Wed 15 Feb | -5.0% | 0.0% | +0.5% | +0.5% | +0.4% | 0.56 | 12.9 | Broad bearish | -5.4 pts | +47 / -542 | 100% | -346 | -3366 |  |
| 10 | Thu 16 Feb | -4.9% | 0.0% | +0.1% | +0.8% | +0.8% | 0.59 | 12.9 | Broad bearish | -5.6 pts | +76 / -562 | 100% | -323 | -3690 |  |
| 11 | Fri 17 Feb | -5.1% | 0.0% | -0.5% | -0.6% | -0.3% | 0.35 | 13.1 | Broad bearish | -4.5 pts | -62 / -449 | 100% | -323 | -4013 |  |
| 12 | Mon 20 Feb | -4.6% | 0.0% | -0.6% | 0.0% | -0.3% | 0.34 | 13.4 | Broad bearish | -4.6 pts | +0 / -462 | 100% | -277 | -4290 |  |
| 13 | Tue 21 Feb | -4.8% | 0.0% | -0.1% | -0.3% | -0.3% | 0.38 | 14.0 | Broad bearish | -4.6 pts | -26 / -458 | 100% | -277 | -4567 |  |
| 14 | Wed 22 Feb | -5.1% | 0.0% | -1.5% | -1.0% | -1.1% | 0.19 | 15.6 | Broad bearish | -4.1 pts | -99 / -410 | 100% | -277 | -4844 |  |
| 15 | Thu 23 Feb | +4.9% | +10.3% | -0.2% | -0.2% | +0.2% | 0.44 | 15.1 | Broad bearish | +5.2 pts | -24 / +515 | 100% | +254 | -4590 |  |
| 16 | Fri 24 Feb | +4.7% | 0.0% | -0.3% | -0.2% | -0.2% | 0.39 | 14.2 | Broad bearish | +4.9 pts | +28 / +440 | 0% | +237 | -4354 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 03 Feb 2023 at the open 4.33; sold Fri 24 Feb 2023 at the open 2.46 (lower-circuit lock: sold at the first free open). Gross -43.19%, costs -35 bp, net -4354 bp.
- Over the same hold: NIFTY -0.7%, Midcap -0.7%, Smallcap -1.9%; VIX -4.1%; breadth averaged 0.42; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -4245 bp, Midcap -4246 bp, Smallcap -4125 bp.
- Split: market part -0.72% = beta 0.99 x Midcap 150 -0.73%; stock part -42.47% -> **mostly the stock itself**.
- The stock's own strongest day: session 15 (+515 bp beyond its market); weakest: session 2 (-569 bp).

_Pick day Thu 02 Feb 2023 [Broad bearish]: NIFTY 0.0%, Smallcap +0.4%, breadth 0.47, VIX 15.7 (+7% in 5 days) -> ENS rank 3 PCJEWELLER (moves with Midcap 150, beta 0.99) -> bought Fri 03 Feb 2023 open, sold Fri 24 Feb 2023 open: gross -43.19%, net -4354 bp -> during the hold NIFTY -0.7%, Smallcap -1.9% -> market part -0.72%, stock part -42.47%: mostly the stock itself._

## ENS-20220112-1 - TTML - net -4353 bp (gross -43.18%) - SEVERE LOSER

- ENS rank 1 (score 0.996) | the other engine ranked it 6 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.63, correlation 0.18; NIFTY beta 0.20, Smallcap beta 0.63)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 11 Jan 2022: NIFTY +0.3%, Midcap +0.2%, Smallcap +0.1%; NIFTY minus Smallcap +0.2 pts (20-day +0.6 pts); breadth 0.46 (748 up / 895 down of 1,669; 10-day 0.57); VIX 17.8 (day +0.5%, 5-day +10.2%, 56th percentile); environment: Broad bullish.
- Pick day: Wed 12 Jan 2022: NIFTY +0.9%, Midcap +1.2%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day +1.1 pts); breadth 0.54 (893 up / 748 down of 1,668; 10-day 0.57); VIX 17.2 (day -3.3%, 5-day -0.3%, 48th percentile); environment: Broad bullish.
- The stock: day before +5.0%, pick day -5.0% (-5.6 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.009, pred_mae_q20 -0.124, pred_mae_q50 -0.066, pred_mae_q80 -0.023, pred_mfe_q20 0.017, pred_mfe_q50 0.064, pred_mfe_q80 0.134, prob_big 0.558, prob_deep 0.524, prob_trap 0.141, prob_win 0.378

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 12 Jan | -5.0% | 0.0% | +0.9% | +1.2% | +0.6% | 0.54 | 17.2 | Broad bullish | -5.6 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 13 Jan | -5.0% | 0.0% | +0.2% | +0.5% | +0.6% | 0.53 | 16.7 | Broad bullish | -5.6 pts | +16 / -16 | 100% | -18 | -18 | buy open |
| 2 | Fri 14 Jan | -5.0% | 0.0% | 0.0% | 0.0% | +0.7% | 0.60 | 16.6 | Broad bullish | -5.7 pts | +43 / -542 | 100% | -498 | -516 |  |
| 3 | Mon 17 Jan | -5.0% | 0.0% | +0.3% | +0.3% | +0.5% | 0.62 | 16.8 | Broad bullish | -5.4 pts | +29 / -527 | 100% | -473 | -989 |  |
| 4 | Tue 18 Jan | -5.0% | 0.0% | -1.1% | -1.9% | -2.0% | 0.19 | 17.8 | Broad bullish | -2.9 pts | -129 / -370 | 100% | -451 | -1440 |  |
| 5 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts | +14 / -513 | 100% | -428 | -1867 |  |
| 6 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -7 / -492 | 100% | -407 | -2274 |  |
| 7 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -118 / -380 | 100% | -386 | -2660 |  |
| 8 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -291 / -207 | 100% | -367 | -3026 |  |
| 9 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +67 / -567 | 100% | -349 | -3376 |  |
| 10 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -29 / -468 | 100% | -330 | -3706 |  |
| 11 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +33 / -532 | 100% | -315 | -4021 |  |
| 12 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +61 / -560 | 100% | -300 | -4321 |  |
| 13 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +47 / -547 | 100% | -284 | -4605 |  |
| 14 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +51 / +446 | 0% | +252 | -4353 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 13 Jan 2022 at the open 261.90; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -43.18%, costs -35 bp, net -4353 bp.
- Over the same hold: NIFTY -3.0%, Midcap -3.5%, Smallcap -3.5%; VIX +16.3%; breadth averaged 0.48; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -4017 bp, Midcap -3965 bp, Smallcap -3970 bp.
- Split: market part -2.20% = beta 0.63 x Smallcap 250 -3.48%; stock part -40.99% -> **mostly the stock itself**.
- The stock's own strongest day: session 14 (+446 bp beyond its market); weakest: session 9 (-567 bp).

_Pick day Wed 12 Jan 2022 [Broad bullish]: NIFTY +0.9%, Smallcap +0.6%, breadth 0.54, VIX 17.2 (0% in 5 days) -> ENS rank 1 TTML (moves with Smallcap 250, beta 0.63) -> bought Thu 13 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -43.18%, net -4353 bp -> during the hold NIFTY -3.0%, Smallcap -3.5%, 1 high-stress day(s) -> market part -2.20%, stock part -40.99%: mostly the stock itself._

## ENS-20260306-1 - AQYLON - net -4314 bp (gross -42.79%) - SEVERE LOSER

- ENS rank 1 (score 0.999) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.14, correlation 0.22; NIFTY beta 1.14, Smallcap beta 0.22)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 05 Mar 2026: NIFTY +1.2%, Midcap +1.5%, Smallcap +1.4%; NIFTY minus Smallcap -0.2 pts (20-day -0.1 pts); breadth 0.70 (1,653 up / 721 down of 2,393; 10-day 0.37); VIX 17.9 (day -15.5%, 5-day +32.4%, 93rd percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 93rd percentile of 250 sessions; VIX +32% in 5 sessions.
- Pick day: Fri 06 Mar 2026: NIFTY -1.3%, Midcap -0.7%, Smallcap -0.3%; NIFTY minus Smallcap -1.0 pts (20-day -1.5 pts); breadth 0.35 (837 up / 1,536 down of 2,392; 10-day 0.39); VIX 19.9 (day +11.3%, 5-day +52.2%, 97th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 97th percentile of 250 sessions; VIX +52% in 5 sessions.
- The stock: day before +5.0%, pick day -4.5% (-3.2 pts vs NIFTY 50)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.021, pred_mae_q20 -0.177, pred_mae_q50 -0.071, pred_mae_q80 -0.026, pred_mfe_q20 0.031, pred_mfe_q50 0.074, pred_mfe_q80 0.155, prob_big 0.673, prob_deep 0.555, prob_trap 0.171, prob_win 0.583

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 06 Mar | -4.5% | -6.5% | -1.3% | -0.7% | -0.3% | 0.35 | 19.9 | HIGH STRESS | -3.2 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 09 Mar | -5.0% | 0.0% | -1.7% | -2.0% | -2.3% | 0.14 | 23.4 | HIGH STRESS | -3.2 pts | +76 / -76 | 100% | -18 | -18 | buy open |
| 2 | Tue 10 Mar | -4.9% | 0.0% | +1.0% | +1.6% | +2.1% | 0.84 | 18.9 | HIGH STRESS | -5.9 pts | +111 / -604 | 100% | -494 | -511 |  |
| 3 | Wed 11 Mar | -5.0% | 0.0% | -1.6% | -1.1% | -0.4% | 0.38 | 21.1 | HIGH STRESS | -3.4 pts | -185 / -314 | 100% | -474 | -986 |  |
| 4 | Thu 12 Mar | -4.9% | 0.0% | -1.0% | -0.2% | -0.4% | 0.34 | 21.5 | HIGH STRESS | -4.0 pts | -109 / -384 | 100% | -445 | -1431 |  |
| 5 | Fri 13 Mar | -5.0% | 0.0% | -2.1% | -2.7% | -2.7% | 0.10 | 22.6 | HIGH STRESS | -2.9 pts | -235 / -261 | 100% | -426 | -1857 |  |
| 6 | Mon 16 Mar | -5.0% | 0.0% | +1.1% | -0.4% | -0.4% | 0.34 | 21.6 | HIGH STRESS | -6.1 pts | +127 / -625 | 100% | -407 | -2263 |  |
| 7 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts | +84 / -583 | 100% | -387 | -2651 |  |
| 8 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +95 / -594 | 100% | -368 | -3018 |  |
| 9 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -371 / -127 | 100% | -348 | -3367 |  |
| 10 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +56 / -551 | 100% | -329 | -3696 |  |
| 11 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -296 / -194 | 100% | -310 | -4006 |  |
| 12 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +185 / -668 | 0% | -308 | -4314 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 09 Mar 2026 at the open 103.30; sold Tue 24 Mar 2026 at the open 59.10 (lower-circuit lock: sold at the first free open). Gross -42.79%, costs -35 bp, net -4314 bp.
- Over the same hold: NIFTY -4.1%, Midcap -4.4%, Smallcap -3.9%; VIX +34.5%; breadth averaged 0.43; 12 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3864 bp, Midcap -3836 bp, Smallcap -3889 bp.
- Split: market part -4.72% = beta 1.14 x NIFTY 50 -4.15%; stock part -38.07% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (-76 bp beyond its market); weakest: session 12 (-668 bp).

_Pick day Fri 06 Mar 2026 [HIGH STRESS]: NIFTY -1.3%, Smallcap -0.3%, breadth 0.35, VIX 19.9 (+52% in 5 days) -> ENS rank 1 AQYLON (moves with NIFTY 50, beta 1.14) -> bought Mon 09 Mar 2026 open, sold Tue 24 Mar 2026 open: gross -42.79%, net -4314 bp -> during the hold NIFTY -4.1%, Smallcap -3.9%, 12 high-stress day(s) -> market part -4.72%, stock part -38.07%: mostly the stock itself._

## D-20260915-1 - SSWL - net +669 bp (gross +7.04%) - WINNER

- D rank 1 (score 0.029) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.22, correlation 0.47; NIFTY beta 1.33, Smallcap beta 1.22)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 11 Sep 2026: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.5%; NIFTY minus Smallcap +0.2 pts (20-day -4.3 pts); breadth 0.36 (872 up / 1,575 down of 2,484; 10-day 0.41); VIX 12.3 (day +4.2%, 5-day +15.1%, 51st percentile); environment: Mixed / ranging.
- Pick day: Tue 15 Sep 2026: NIFTY -1.2%, Midcap -2.1% (3.7 sd fall), Smallcap -2.4% (3.5 sd fall); NIFTY minus Smallcap +1.2 pts (20-day -2.5 pts); breadth 0.14 (351 up / 2,126 down of 2,488; 10-day 0.39); VIX 13.4 (day +9.3%, 5-day +20.3%, 64th percentile); environment: HIGH STRESS (direction: Broad bearish) - Smallcap -3.5 sd day.
- The stock: day before -0.8%, pick day -8.5% (-6.1 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.001, pred_mae_q20 -0.089, pred_mae_q50 -0.042, pred_mae_q80 -0.016, pred_mfe_q20 0.029, pred_mfe_q50 0.075, pred_mfe_q80 0.115, prob_big 0.665, prob_deep 0.193, prob_trap 0.002, prob_win 0.553

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 15 Sep | -8.5% | -8.4% | -1.2% | -2.1% | -2.4% | 0.14 | 13.4 | HIGH STRESS | -6.1 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 16 Sep | +3.3% | +2.7% | +0.4% | 0.0% | -0.2% | 0.46 | 13.2 | Broad bearish | +3.4 pts | -11 / +282 | 100% | +254 | +254 | buy open |
| 2 | Thu 17 Sep | -0.5% | -0.8% | +0.2% | +0.9% | +0.8% | 0.67 | 12.3 | Broad bearish | -1.3 pts | +100 / -151 | 100% | -53 | +201 |  |
| 3 | Fri 18 Sep | +6.9% | +5.9% | +0.3% | +1.5% | +1.5% | 0.68 | 11.4 | Mixed / ranging | +5.4 pts | +189 / +505 | 100% | +709 | +910 |  |
| 4 | Mon 21 Sep | -2.9% | -3.5% | +0.3% | -0.4% | 0.0% | 0.48 | 11.2 | Mixed / ranging | -2.8 pts | -6 / -280 | 100% | -312 | +597 |  |
| 5 | Tue 22 Sep | +0.8% | +0.8% | -0.4% | -0.1% | -0.1% | 0.43 | 11.0 | Mixed / ranging | +0.9 pts | -12 / +97 | 0% | +72 | +669 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 16 Sep 2026 at the open 340.80; sold Tue 22 Sep 2026 at the close 364.80. Gross +7.04%, costs -35 bp, net +669 bp.
- Over the same hold: NIFTY +0.5%, Midcap +1.7%, Smallcap +2.1%; VIX -18.1%; breadth averaged 0.54; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY +649 bp, Midcap +530 bp, Smallcap +491 bp.
- Split: market part +2.61% = beta 1.22 x Smallcap 250 +2.14%; stock part +4.43% -> **market and stock together**.
- The stock's own strongest day: session 3 (+505 bp beyond its market); weakest: session 4 (-280 bp).

_Pick day Tue 15 Sep 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -2.4%, breadth 0.14, VIX 13.4 (+20% in 5 days) -> D rank 1 SSWL (moves with Smallcap 250, beta 1.22) -> bought Wed 16 Sep 2026 open, sold Tue 22 Sep 2026 close: gross +7.04%, net +669 bp -> during the hold NIFTY +0.5%, Smallcap +2.1% -> market part +2.61%, stock part +4.43%: market and stock together._

## D-20260915-2 - MOREPENLAB - net +1148 bp (gross +11.83%) - WINNER

- D rank 2 (score 0.027) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.70, correlation 0.46; NIFTY beta 1.39, Smallcap beta 1.70)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 11 Sep 2026: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.5%; NIFTY minus Smallcap +0.2 pts (20-day -4.3 pts); breadth 0.36 (872 up / 1,575 down of 2,484; 10-day 0.41); VIX 12.3 (day +4.2%, 5-day +15.1%, 51st percentile); environment: Mixed / ranging.
- Pick day: Tue 15 Sep 2026: NIFTY -1.2%, Midcap -2.1% (3.7 sd fall), Smallcap -2.4% (3.5 sd fall); NIFTY minus Smallcap +1.2 pts (20-day -2.5 pts); breadth 0.14 (351 up / 2,126 down of 2,488; 10-day 0.39); VIX 13.4 (day +9.3%, 5-day +20.3%, 64th percentile); environment: HIGH STRESS (direction: Broad bearish) - Smallcap -3.5 sd day.
- The stock: day before +0.4%, pick day -8.3% (-5.8 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.005, pred_mae_q20 -0.097, pred_mae_q50 -0.045, pred_mae_q80 -0.018, pred_mfe_q20 0.037, pred_mfe_q50 0.088, pred_mfe_q80 0.118, prob_big 0.692, prob_deep 0.256, prob_trap 0.008, prob_win 0.621

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 15 Sep | -8.3% | -8.4% | -1.2% | -2.1% | -2.4% | 0.14 | 13.4 | HIGH STRESS | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 16 Sep | +8.0% | +7.8% | +0.4% | 0.0% | -0.2% | 0.46 | 13.2 | Broad bearish | +8.2 pts | -15 / +793 | 100% | +760 | +760 | buy open |
| 2 | Thu 17 Sep | +5.1% | +4.8% | +0.2% | +0.9% | +0.8% | 0.67 | 12.3 | Broad bearish | +4.3 pts | +139 / +369 | 100% | +548 | +1308 |  |
| 3 | Fri 18 Sep | +0.3% | +0.2% | +0.3% | +1.5% | +1.5% | 0.68 | 11.4 | Mixed / ranging | -1.3 pts | +263 / -235 | 100% | +32 | +1340 |  |
| 4 | Mon 21 Sep | +1.2% | +1.2% | +0.3% | -0.4% | 0.0% | 0.48 | 11.2 | Mixed / ranging | +1.2 pts | -8 / +128 | 100% | +136 | +1476 |  |
| 5 | Tue 22 Sep | -2.7% | -2.7% | -0.4% | -0.1% | -0.1% | 0.43 | 11.0 | Mixed / ranging | -2.6 pts | -17 / -253 | 0% | -328 | +1148 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 16 Sep 2026 at the open 106.45; sold Tue 22 Sep 2026 at the close 119.04. Gross +11.83%, costs -35 bp, net +1148 bp.
- Over the same hold: NIFTY +0.5%, Midcap +1.7%, Smallcap +2.1%; VIX -18.1%; breadth averaged 0.54; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY +1128 bp, Midcap +1009 bp, Smallcap +969 bp.
- Split: market part +3.64% = beta 1.70 x Smallcap 250 +2.14%; stock part +8.19% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+793 bp beyond its market); weakest: session 5 (-253 bp).

_Pick day Tue 15 Sep 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -2.4%, breadth 0.14, VIX 13.4 (+20% in 5 days) -> D rank 2 MOREPENLAB (moves with Smallcap 250, beta 1.70) -> bought Wed 16 Sep 2026 open, sold Tue 22 Sep 2026 close: gross +11.83%, net +1148 bp -> during the hold NIFTY +0.5%, Smallcap +2.1% -> market part +3.64%, stock part +8.19%: mostly the stock itself._

## D-20260915-3 - WELENT - net +513 bp (gross +5.48%) - WINNER

- D rank 3 (score 0.024) | the other engine ranked it 6 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.18, correlation 0.55; NIFTY beta 1.18, Smallcap beta 1.18)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 11 Sep 2026: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.5%; NIFTY minus Smallcap +0.2 pts (20-day -4.3 pts); breadth 0.36 (872 up / 1,575 down of 2,484; 10-day 0.41); VIX 12.3 (day +4.2%, 5-day +15.1%, 51st percentile); environment: Mixed / ranging.
- Pick day: Tue 15 Sep 2026: NIFTY -1.2%, Midcap -2.1% (3.7 sd fall), Smallcap -2.4% (3.5 sd fall); NIFTY minus Smallcap +1.2 pts (20-day -2.5 pts); breadth 0.14 (351 up / 2,126 down of 2,488; 10-day 0.39); VIX 13.4 (day +9.3%, 5-day +20.3%, 64th percentile); environment: HIGH STRESS (direction: Broad bearish) - Smallcap -3.5 sd day.
- The stock: day before -1.5%, pick day -6.2% (-3.7 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.001, pred_mae_q20 -0.085, pred_mae_q50 -0.043, pred_mae_q80 -0.017, pred_mfe_q20 0.029, pred_mfe_q50 0.073, pred_mfe_q80 0.110, prob_big 0.642, prob_deep 0.192, prob_trap 0.002, prob_win 0.471

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 15 Sep | -6.2% | -6.7% | -1.2% | -2.1% | -2.4% | 0.14 | 13.4 | HIGH STRESS | -3.7 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 16 Sep | +4.1% | +3.4% | +0.4% | 0.0% | -0.2% | 0.46 | 13.2 | Broad bearish | +4.3 pts | -10 / +347 | 100% | +319 | +319 | buy open |
| 2 | Thu 17 Sep | +1.4% | +1.3% | +0.2% | +0.9% | +0.8% | 0.67 | 12.3 | Broad bearish | +0.6 pts | +96 / +43 | 100% | +144 | +463 |  |
| 3 | Fri 18 Sep | +5.7% | +5.0% | +0.3% | +1.5% | +1.5% | 0.68 | 11.4 | Mixed / ranging | +4.2 pts | +182 / +391 | 100% | +601 | +1064 |  |
| 4 | Mon 21 Sep | -4.7% | -5.5% | +0.3% | -0.4% | 0.0% | 0.48 | 11.2 | Mixed / ranging | -4.6 pts | -5 / -464 | 100% | -520 | +544 |  |
| 5 | Tue 22 Sep | -0.1% | -0.6% | -0.4% | -0.1% | -0.1% | 0.43 | 11.0 | Mixed / ranging | 0.0 pts | -12 / -0 | 0% | -30 | +513 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 16 Sep 2026 at the open 743.00; sold Tue 22 Sep 2026 at the close 783.75. Gross +5.48%, costs -35 bp, net +513 bp.
- Over the same hold: NIFTY +0.5%, Midcap +1.7%, Smallcap +2.1%; VIX -18.1%; breadth averaged 0.54; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY +494 bp, Midcap +375 bp, Smallcap +335 bp.
- Split: market part +2.52% = beta 1.18 x Smallcap 250 +2.14%; stock part +2.97% -> **market and stock together**.
- The stock's own strongest day: session 3 (+391 bp beyond its market); weakest: session 4 (-464 bp).

_Pick day Tue 15 Sep 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -2.4%, breadth 0.14, VIX 13.4 (+20% in 5 days) -> D rank 3 WELENT (moves with Smallcap 250, beta 1.18) -> bought Wed 16 Sep 2026 open, sold Tue 22 Sep 2026 close: gross +5.48%, net +513 bp -> during the hold NIFTY +0.5%, Smallcap +2.1% -> market part +2.52%, stock part +2.97%: market and stock together._

## ENS-20260915-1 - MOREPENLAB - net +1148 bp (gross +11.83%) - WINNER

- ENS rank 1 (score 1.000) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.70, correlation 0.46; NIFTY beta 1.39, Smallcap beta 1.70)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 11 Sep 2026: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.5%; NIFTY minus Smallcap +0.2 pts (20-day -4.3 pts); breadth 0.36 (872 up / 1,575 down of 2,484; 10-day 0.41); VIX 12.3 (day +4.2%, 5-day +15.1%, 51st percentile); environment: Mixed / ranging.
- Pick day: Tue 15 Sep 2026: NIFTY -1.2%, Midcap -2.1% (3.7 sd fall), Smallcap -2.4% (3.5 sd fall); NIFTY minus Smallcap +1.2 pts (20-day -2.5 pts); breadth 0.14 (351 up / 2,126 down of 2,488; 10-day 0.39); VIX 13.4 (day +9.3%, 5-day +20.3%, 64th percentile); environment: HIGH STRESS (direction: Broad bearish) - Smallcap -3.5 sd day.
- The stock: day before +0.4%, pick day -8.3% (-5.8 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.001, pred_mae_q20 -0.102, pred_mae_q50 -0.043, pred_mae_q80 -0.015, pred_mfe_q20 0.034, pred_mfe_q50 0.077, pred_mfe_q80 0.115, prob_big 0.696, prob_deep 0.287, prob_trap 0.005, prob_win 0.606

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 15 Sep | -8.3% | -8.4% | -1.2% | -2.1% | -2.4% | 0.14 | 13.4 | HIGH STRESS | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 16 Sep | +8.0% | +7.8% | +0.4% | 0.0% | -0.2% | 0.46 | 13.2 | Broad bearish | +8.2 pts | -15 / +793 | 100% | +760 | +760 | buy open |
| 2 | Thu 17 Sep | +5.1% | +4.8% | +0.2% | +0.9% | +0.8% | 0.67 | 12.3 | Broad bearish | +4.3 pts | +139 / +369 | 100% | +548 | +1308 |  |
| 3 | Fri 18 Sep | +0.3% | +0.2% | +0.3% | +1.5% | +1.5% | 0.68 | 11.4 | Mixed / ranging | -1.3 pts | +263 / -235 | 100% | +32 | +1340 |  |
| 4 | Mon 21 Sep | +1.2% | +1.2% | +0.3% | -0.4% | 0.0% | 0.48 | 11.2 | Mixed / ranging | +1.2 pts | -8 / +128 | 100% | +136 | +1476 |  |
| 5 | Tue 22 Sep | -2.7% | -2.7% | -0.4% | -0.1% | -0.1% | 0.43 | 11.0 | Mixed / ranging | -2.6 pts | -17 / -253 | 0% | -328 | +1148 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 16 Sep 2026 at the open 106.45; sold Tue 22 Sep 2026 at the close 119.04. Gross +11.83%, costs -35 bp, net +1148 bp.
- Over the same hold: NIFTY +0.5%, Midcap +1.7%, Smallcap +2.1%; VIX -18.1%; breadth averaged 0.54; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY +1128 bp, Midcap +1009 bp, Smallcap +969 bp.
- Split: market part +3.64% = beta 1.70 x Smallcap 250 +2.14%; stock part +8.19% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+793 bp beyond its market); weakest: session 5 (-253 bp).

_Pick day Tue 15 Sep 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -2.4%, breadth 0.14, VIX 13.4 (+20% in 5 days) -> ENS rank 1 MOREPENLAB (moves with Smallcap 250, beta 1.70) -> bought Wed 16 Sep 2026 open, sold Tue 22 Sep 2026 close: gross +11.83%, net +1148 bp -> during the hold NIFTY +0.5%, Smallcap +2.1% -> market part +3.64%, stock part +8.19%: mostly the stock itself._

## ENS-20260915-2 - IOLCP - net +975 bp (gross +10.10%) - WINNER

- ENS rank 2 (score 0.996) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.30, correlation 0.39; NIFTY beta 0.99, Smallcap beta 1.30)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 11 Sep 2026: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.5%; NIFTY minus Smallcap +0.2 pts (20-day -4.3 pts); breadth 0.36 (872 up / 1,575 down of 2,484; 10-day 0.41); VIX 12.3 (day +4.2%, 5-day +15.1%, 51st percentile); environment: Mixed / ranging.
- Pick day: Tue 15 Sep 2026: NIFTY -1.2%, Midcap -2.1% (3.7 sd fall), Smallcap -2.4% (3.5 sd fall); NIFTY minus Smallcap +1.2 pts (20-day -2.5 pts); breadth 0.14 (351 up / 2,126 down of 2,488; 10-day 0.39); VIX 13.4 (day +9.3%, 5-day +20.3%, 64th percentile); environment: HIGH STRESS (direction: Broad bearish) - Smallcap -3.5 sd day.
- The stock: day before -8.1%, pick day -7.6% (-5.2 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.003, pred_mae_q20 -0.096, pred_mae_q50 -0.042, pred_mae_q80 -0.015, pred_mfe_q20 0.035, pred_mfe_q50 0.076, pred_mfe_q80 0.117, prob_big 0.708, prob_deep 0.265, prob_trap 0.003, prob_win 0.613

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 15 Sep | -7.6% | -8.0% | -1.2% | -2.1% | -2.4% | 0.14 | 13.4 | HIGH STRESS | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 16 Sep | +8.4% | +6.9% | +0.4% | 0.0% | -0.2% | 0.46 | 13.2 | Broad bearish | +8.5 pts | -11 / +702 | 100% | +673 | +673 | buy open |
| 2 | Thu 17 Sep | +1.5% | +1.3% | +0.2% | +0.9% | +0.8% | 0.67 | 12.3 | Broad bearish | +0.7 pts | +107 / +44 | 100% | +160 | +834 |  |
| 3 | Fri 18 Sep | +2.9% | +2.3% | +0.3% | +1.5% | +1.5% | 0.68 | 11.4 | Mixed / ranging | +1.3 pts | +201 / +85 | 100% | +311 | +1145 |  |
| 4 | Mon 21 Sep | -0.1% | -0.1% | +0.3% | -0.4% | 0.0% | 0.48 | 11.2 | Mixed / ranging | -0.1 pts | -6 / -6 | 100% | -13 | +1131 |  |
| 5 | Tue 22 Sep | -1.2% | -1.3% | -0.4% | -0.1% | -0.1% | 0.43 | 11.0 | Mixed / ranging | -1.1 pts | -13 / -111 | 0% | -156 | +975 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 16 Sep 2026 at the open 182.00; sold Tue 22 Sep 2026 at the close 200.39. Gross +10.10%, costs -35 bp, net +975 bp.
- Over the same hold: NIFTY +0.5%, Midcap +1.7%, Smallcap +2.1%; VIX -18.1%; breadth averaged 0.54; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY +956 bp, Midcap +836 bp, Smallcap +797 bp.
- Split: market part +2.79% = beta 1.30 x Smallcap 250 +2.14%; stock part +7.32% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+702 bp beyond its market); weakest: session 5 (-111 bp).

_Pick day Tue 15 Sep 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -2.4%, breadth 0.14, VIX 13.4 (+20% in 5 days) -> ENS rank 2 IOLCP (moves with Smallcap 250, beta 1.30) -> bought Wed 16 Sep 2026 open, sold Tue 22 Sep 2026 close: gross +10.10%, net +975 bp -> during the hold NIFTY +0.5%, Smallcap +2.1% -> market part +2.79%, stock part +7.32%: mostly the stock itself._

## ENS-20260915-3 - IFCI - net -198 bp (gross -1.63%) - LOSER

- ENS rank 3 (score 0.994) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.88, correlation 0.53; NIFTY beta 1.87, Smallcap beta 1.88)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 11 Sep 2026: NIFTY -0.3%, Midcap -0.2%, Smallcap -0.5%; NIFTY minus Smallcap +0.2 pts (20-day -4.3 pts); breadth 0.36 (872 up / 1,575 down of 2,484; 10-day 0.41); VIX 12.3 (day +4.2%, 5-day +15.1%, 51st percentile); environment: Mixed / ranging.
- Pick day: Tue 15 Sep 2026: NIFTY -1.2%, Midcap -2.1% (3.7 sd fall), Smallcap -2.4% (3.5 sd fall); NIFTY minus Smallcap +1.2 pts (20-day -2.5 pts); breadth 0.14 (351 up / 2,126 down of 2,488; 10-day 0.39); VIX 13.4 (day +9.3%, 5-day +20.3%, 64th percentile); environment: HIGH STRESS (direction: Broad bearish) - Smallcap -3.5 sd day.
- The stock: day before -3.4%, pick day -6.5% (-4.1 pts vs Smallcap 250)

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.002, pred_mae_q20 -0.099, pred_mae_q50 -0.043, pred_mae_q80 -0.016, pred_mfe_q20 0.033, pred_mfe_q50 0.075, pred_mfe_q80 0.119, prob_big 0.687, prob_deep 0.266, prob_trap 0.004, prob_win 0.624

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 15 Sep | -6.5% | -7.3% | -1.2% | -2.1% | -2.4% | 0.14 | 13.4 | HIGH STRESS | -4.1 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 16 Sep | -2.5% | -2.8% | +0.4% | 0.0% | -0.2% | 0.46 | 13.2 | Broad bearish | -2.3 pts | -16 / -261 | 100% | -295 | -295 | buy open |
| 2 | Thu 17 Sep | +2.7% | +2.5% | +0.2% | +0.9% | +0.8% | 0.67 | 12.3 | Broad bearish | +1.9 pts | +153 / +117 | 100% | +263 | -32 |  |
| 3 | Fri 18 Sep | -0.8% | -1.4% | +0.3% | +1.5% | +1.5% | 0.68 | 11.4 | Mixed / ranging | -2.3 pts | +290 / -365 | 100% | -75 | -107 |  |
| 4 | Mon 21 Sep | -3.0% | -1.5% | +0.3% | -0.4% | 0.0% | 0.48 | 11.2 | Mixed / ranging | -2.9 pts | -9 / -287 | 100% | -293 | -400 |  |
| 5 | Tue 22 Sep | +2.3% | +2.0% | -0.4% | -0.1% | -0.1% | 0.43 | 11.0 | Mixed / ranging | +2.4 pts | -19 / +247 | 0% | +201 | -198 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 16 Sep 2026 at the open 77.20; sold Tue 22 Sep 2026 at the close 75.94. Gross -1.63%, costs -35 bp, net -198 bp.
- Over the same hold: NIFTY +0.5%, Midcap +1.7%, Smallcap +2.1%; VIX -18.1%; breadth averaged 0.54; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -218 bp, Midcap -337 bp, Smallcap -377 bp.
- Split: market part +4.01% = beta 1.88 x Smallcap 250 +2.14%; stock part -5.64% -> **market and stock pulled opposite ways**.
- The stock's own strongest day: session 5 (+247 bp beyond its market); weakest: session 3 (-365 bp).

_Pick day Tue 15 Sep 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -2.4%, breadth 0.14, VIX 13.4 (+20% in 5 days) -> ENS rank 3 IFCI (moves with Smallcap 250, beta 1.88) -> bought Wed 16 Sep 2026 open, sold Tue 22 Sep 2026 close: gross -1.63%, net -198 bp -> during the hold NIFTY +0.5%, Smallcap +2.1% -> market part +4.01%, stock part -5.64%: market and stock pulled opposite ways._

