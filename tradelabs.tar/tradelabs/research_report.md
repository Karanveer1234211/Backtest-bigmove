# Research: why D / ENS trades win or lose in different markets

tl_research v1.2 (tradelab v1.2), 2026-10-24T18:18:05; export TLX_20261024_001; declaration ee11568ce928dcf7 (research-declaration-2 (2026-10-24)). Traded picks only (ranks 1-3, finished): D 4,964, ENS 4,964.

**Question:** can the market conditions behind the worst losses be seen BEFORE entry, and would avoiding them cut drawdown without destroying the edge? This report observes only: nothing is filtered, the plan is unchanged, and every threshold below was declared on 24 Oct 2026 before any real run (research-declaration-2 after a review: purged training, known inputs only, Bonferroni, money view).

**What the numbers are:** trade nets are pick_meta's recorded plan nets (flat 35 bp round trip). Returns and drawdowns are tradelab's money view of the plan (compounded, cash-limited) - NOT stage E's execution backtest (EXEC_20260930_001, the -47.64% baseline). Lower-circuit exits follow stage E's own rule.

## Verdict first

- **D**: walk-forward (each year judged by signs chosen on earlier years only): no warning sign survives out of sample; all qualified signs together: money-view return change +0.00% (summed over qualified years), worst drawdown improved in 0 of 0 qualified year(s).
- **ENS**: walk-forward (each year judged by signs chosen on earlier years only): no warning sign survives out of sample; all qualified signs together: money-view return change +0.00% (summed over qualified years), worst drawdown improved in 0 of 0 qualified year(s).
- A CANDIDATE is not a rule: next comes a replay in stage E's execution simulator (the -47.64% baseline; the -25% target can only be judged there), then a declared forward paper test (month-6 checkpoint).

## 1. Winners, losers and severe losers

Severe loser = net <= -500 bp after costs. Market / stock part: beta to the home index x that index over the same hold, and the rest.

| engine | group | trades | share | mean net bp | sum net bp | median MAE | market part bp | stock part bp | driven by market |
|---|---|---|---|---|---|---|---|---|---|
| D | winner | 2,504 | 50.4% | +712.4 [+661.5, +765.0] | +1,783,788 | -2.03% | +140.2 | +607.2 | 15% |
| D | loser | 1,550 | 31.2% | -209.6 [-221.2, -198.5] | -324,804 | -4.24% | -16.4 | -158.1 | 14% |
| D | severe_loser | 910 | 18.3% | -1014.2 [-1091.1, -943.8] | -922,897 | -10.82% | -306.5 | -672.7 | 18% |
| ENS | winner | 2,552 | 51.4% | +700.1 [+648.3, +755.0] | +1,786,771 | -1.95% | +344.6 | +390.6 | 15% |
| ENS | loser | 1,528 | 30.8% | -219.9 [-228.4, -211.3] | -336,060 | -4.37% | -26.1 | -158.9 | 13% |
| ENS | severe_loser | 884 | 17.8% | -1010.1 [-1085.3, -939.9] | -892,936 | -10.69% | -324.9 | -650.2 | 18% |

## 2. What the market looked like before entry, by outcome

Means (shares for categories) of pre-entry values. 'sd gap' = (severe losers - winners) / pooled sd: about 0.2 is small, 0.5 medium. Descriptive - many fields are compared.

#### D

| field | winners | losers | severe losers | sd gap |
|---|---|---|---|---|
| breadth, 10-day A/D | 0.48 | 0.49 | 0.47 | -0.12 |
| breadth on the pick day | 0.48 | 0.49 | 0.47 | -0.04 |
| VIX | 17.6 | 16.3 | 17.8 | +0.02 |
| VIX 5-day change | +0.55% | -0.45% | +2.87% | +0.16 |
| VIX percentile | 0.47 | 0.43 | 0.51 | +0.11 |
| NIFTY minus Smallcap, 20 days | -0.68% | -1.43% | -0.75% | -0.02 |
| NIFTY minus Midcap, 20 days | -0.68% | -1.11% | -0.72% | -0.02 |
| Smallcap pick-day move | +0.06% | +0.16% | 0.00% | -0.04 |
| Smallcap move the day before | +0.05% | +0.20% | -0.02% | -0.06 |
| Smallcap 5 days | +0.32% | +0.88% | +0.04% | -0.08 |
| NIFTY vs its 50-day average | +0.96% | +1.72% | +0.27% | -0.14 |
| Smallcap vs its 50-day average | +1.77% | +3.29% | +0.93% | -0.12 |
| beta to the home index | 1.11 | 1.03 | 1.19 | +0.13 |
| correlation with the home index | 0.41 | 0.39 | 0.40 | -0.07 |
| the stock's pick-day move | -1.54% | -0.95% | -1.57% | -0.01 |
| environment = broad_bearish | 14.2% | 11.1% | 19.3% | |
| environment = broad_bullish | 29.8% | 37.1% | 23.8% | |
| environment = high_stress | 16.2% | 10.3% | 16.4% | |
| environment = mixed | 12.5% | 13.0% | 15.6% | |
| environment = narrow_bullish | 27.3% | 28.5% | 24.8% | |
| high stress = no | 83.8% | 89.7% | 83.6% | |
| high stress = yes | 16.2% | 10.3% | 16.4% | |
| size class (AMFI) = no list | 100.0% | 100.0% | 100.0% | |
| home index = Midcap 150 | 19.3% | 21.3% | 19.7% | |
| home index = NIFTY 50 | 8.0% | 13.1% | 4.6% | |
| home index = Smallcap 250 | 72.6% | 65.6% | 75.7% | |

#### ENS

| field | winners | losers | severe losers | sd gap |
|---|---|---|---|---|
| breadth, 10-day A/D | 0.48 | 0.49 | 0.47 | -0.12 |
| breadth on the pick day | 0.48 | 0.49 | 0.47 | -0.06 |
| VIX | 17.8 | 16.3 | 17.3 | -0.06 |
| VIX 5-day change | +0.54% | -0.21% | +2.53% | +0.13 |
| VIX percentile | 0.48 | 0.43 | 0.49 | +0.04 |
| NIFTY minus Smallcap, 20 days | -0.69% | -1.39% | -0.81% | -0.03 |
| NIFTY minus Midcap, 20 days | -0.70% | -1.06% | -0.75% | -0.02 |
| Smallcap pick-day move | +0.08% | +0.16% | -0.03% | -0.08 |
| Smallcap move the day before | +0.05% | +0.19% | -0.01% | -0.05 |
| Smallcap 5 days | +0.32% | +0.87% | +0.05% | -0.08 |
| NIFTY vs its 50-day average | +1.01% | +1.73% | +0.12% | -0.19 |
| Smallcap vs its 50-day average | +1.83% | +3.24% | +0.89% | -0.14 |
| beta to the home index | 2.03 | 1.06 | 1.25 | -0.03 |
| correlation with the home index | 0.41 | 0.40 | 0.42 | +0.01 |
| the stock's pick-day move | -1.82% | -1.29% | -2.02% | -0.05 |
| environment = broad_bearish | 14.1% | 10.8% | 20.1% | |
| environment = broad_bullish | 29.9% | 36.5% | 24.8% | |
| environment = high_stress | 16.2% | 10.3% | 16.2% | |
| environment = mixed | 12.0% | 13.8% | 16.0% | |
| environment = narrow_bullish | 27.8% | 28.6% | 23.0% | |
| high stress = no | 83.8% | 89.7% | 83.8% | |
| high stress = yes | 16.2% | 10.3% | 16.2% | |
| size class (AMFI) = no list | 100.0% | 100.0% | 100.0% | |
| home index = (blank) | 0.0% | 0.1% | 0.0% | |
| home index = Midcap 150 | 20.4% | 22.1% | 17.4% | |
| home index = NIFTY 50 | 7.3% | 10.7% | 4.9% | |
| home index = Smallcap 250 | 72.3% | 67.1% | 77.7% | |

## 3. Warning signs on ALL trades (in-sample: the same history)

Each sign is a yes/no condition known before entry. 'catches' = severe losers it flags; 'costs' = winners it flags too. 'difference' = mean net of flagged minus KNOWN unflagged trades (blank inputs left out of both; 'unknown' counts them) with its 95% interval and one-sided p. 'skip' = what skipping the flagged trades would have done: P&L in bp (one slot each, summed) and the money view's worst drawdown with and without them. A sign that also flags many winners destroys the edge it protects.

#### D

| sign | flags (unknown) | catches severe | costs winners | severe rate flagged / all | difference bp (p) | P&L if skipped bp | money view: worst drawdown -> if skipped |
|---|---|---|---|---|---|---|---|
| W1 high stress at the pick | 714 (14.4%; 0) | 149/910 (16%) | 405/2504 (16%) | 20.9% / 18.3% | +90.7 [-125.1, +307.1] (p 0.7975) | -132,524 | -45.77% -> -34.79% |
| W2 broad bearish at the pick | 1,025 (20.6%; 0) | 256/910 (28%) | 541/2504 (22%) | 25.0% / 18.3% | -25.4 [-195.1, +141.1] (p 0.3875) | -90,066 | -45.77% -> -27.87% |
| W3 narrow bullish at the pick | 1,524 (30.7%; 0) | 251/910 (28%) | 786/2504 (31%) | 16.5% / 18.3% | +36.1 [-55.9, +128.7] (p 0.7820) | -202,667 | -45.77% -> -45.06% |
| W4 weak breadth: 10-day A/D below 0.40 | 525 (10.6%; 0) | 135/910 (15%) | 305/2504 (12%) | 25.7% / 18.3% | +51.9 [-220.8, +309.6] (p 0.6750) | -81,048 | -45.77% -> -32.84% |
| W5 VIX up 15% or more in 5 days | 381 (7.7%; 0) | 95/910 (10%) | 206/2504 (8%) | 24.9% / 18.3% | -55.9 [-326.1, +208.0] (p 0.3680) | -21,471 | -45.77% -> -32.69% |
| W6 Smallcap fell 1.5% or more on the pick day | 450 (9.1%; 0) | 102/910 (11%) | 251/2504 (10%) | 22.7% / 18.3% | +31.8 [-133.3, +195.0] (p 0.6760) | -61,610 | -45.77% -> -29.81% |
| W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days | 756 (15.2%; 0) | 155/910 (17%) | 420/2504 (17%) | 20.5% / 18.3% | +127.0 [-39.5, +313.9] (p 0.9205) | -163,012 | -45.77% -> -48.16% |
| W8 high-beta pick: beta to its home index 1.5 or more | 894 (18.0%; 0) | 202/910 (22%) | 441/2504 (18%) | 22.6% / 18.3% | -64.2 [-191.6, +51.3] (p 0.1520) | -49,490 | -45.77% -> -22.39% |

#### ENS

| sign | flags (unknown) | catches severe | costs winners | severe rate flagged / all | difference bp (p) | P&L if skipped bp | money view: worst drawdown -> if skipped |
|---|---|---|---|---|---|---|---|
| W1 high stress at the pick | 714 (14.4%; 0) | 143/884 (16%) | 414/2552 (16%) | 20.0% / 17.8% | +126.9 [-82.3, +334.6] (p 0.8845) | -157,772 | -39.10% -> -36.00% |
| W2 broad bearish at the pick | 1,025 (20.6%; 0) | 260/884 (29%) | 549/2552 (22%) | 25.4% / 17.8% | -4.7 [-166.9, +165.9] (p 0.4810) | -111,342 | -39.10% -> -28.23% |
| W3 narrow bullish at the pick | 1,524 (30.7%; 0) | 226/884 (26%) | 809/2552 (32%) | 14.8% / 17.8% | +48.2 [-43.0, +138.6] (p 0.8380) | -222,154 | -39.10% -> -39.04% |
| W4 weak breadth: 10-day A/D below 0.40 | 525 (10.6%; 0) | 127/884 (14%) | 310/2552 (12%) | 24.2% / 17.8% | +59.2 [-177.3, +297.6] (p 0.7115) | -86,794 | -39.10% -> -33.58% |
| W5 VIX up 15% or more in 5 days | 381 (7.7%; 0) | 87/884 (10%) | 207/2552 (8%) | 22.8% / 17.8% | -12.4 [-251.0, +223.9] (p 0.4925) | -38,464 | -39.10% -> -34.26% |
| W6 Smallcap fell 1.5% or more on the pick day | 450 (9.1%; 0) | 101/884 (11%) | 255/2552 (10%) | 22.4% / 17.8% | +12.3 [-129.1, +151.6] (p 0.5885) | -55,586 | -39.10% -> -31.78% |
| W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days | 756 (15.2%; 0) | 136/884 (15%) | 426/2552 (17%) | 18.0% / 17.8% | +184.0 [+7.5, +380.3] (p 0.9790) | -202,857 | -39.10% -> -39.43% |
| W8 high-beta pick: beta to its home index 1.5 or more | 933 (18.8%; 1) | 216/884 (24%) | 464/2552 (18%) | 23.2% / 17.8% | -35.5 [-142.2, +73.6] (p 0.2840) | -77,956 | -39.10% -> -27.84% |

## 4. Out of sample, in time order (walk-forward)

For each year: a test year is qualified only on trades whose actual exit (incl. lower-circuit delays) came before 1 Jan of that year; a sign QUALIFIES on the purged training trades: >= 30 flagged trades on >= 20 signal days, and the one-sided bootstrap p-value of (flagged - unflagged mean net) < 0 at most 0.05 / 8 = 0.00625 (Bonferroni over the 8 signs; 10,000 circular-block resamples over signal days). A qualified sign is then judged on that year alone in the money view (fresh capital): the year's return and worst drawdown with and without its flagged trades. Verdict rule: qualified in at least 2 test years; over those years skipping its flagged trades did not lower the money view's return (summed) and improved the year's worst drawdown in at least half of them -> a CANDIDATE for a stage E replay (the execution simulator), then a declared forward paper test; otherwise NOT SUPPORTED or NEVER QUALIFIED. Nothing is ever applied automatically.

| engine | sign | qualified years | return change (money view) | P&L change bp | severe avoided | winners forgone | drawdown improved | verdict |
|---|---|---|---|---|---|---|---|---|
| D | W1 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W2 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W3 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W4 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W5 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W6 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W7 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W8 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | ANY | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W1 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W2 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W3 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W4 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W5 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W6 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W7 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W8 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | ANY | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
Purged from training (exited inside the test year): D 90 trade-folds, ENS 91 trade-folds.

## 5. The plan's money view by market environment

the plan's own fills through tradelab's money layer: Rs 10 lakh, 1/15 of the previous close's equity a new position, integer shares, 25% minimum order, flat 35 bp, compounded and cash-limited; a skipped trade's money stays in cash; each test year starts from fresh capital. Not stage E's simulator. the money view by environment: each day labelled with the environment known at the previous close. Mean day return in bp with a 95% block-bootstrap interval; worst drawdown inside = that environment's days chained together; positions = trades held at the close; exposure = invested / equity.

| engine | environment (previous close) | days | mean day bp | total | worst drawdown inside | worst day bp | avg / max positions |
|---|---|---|---|---|---|---|---|
| D | broad_bullish | 513 (31%) | +25.80 [+12.68, +38.71] | +255.02% | -14.14% | -592 | 12.0 / 14 |
| D | narrow_bullish | 450 (27%) | +23.18 [+9.80, +36.41] | +166.45% | -16.41% | -500 | 12.1 / 14 |
| D | mixed | 221 (13%) | +16.63 [-3.10, +37.76] | +39.00% | -16.61% | -602 | 12.0 / 15 |
| D | broad_bearish | 237 (14%) | -2.93 [-34.80, +25.88] | -12.77% | -33.00% | -685 | 12.0 / 15 |
| D | high_stress | 238 (14%) | +29.34 [-17.34, +72.46] | +83.17% | -42.75% | -1061 | 12.2 / 15 |
| ENS | broad_bullish | 513 (31%) | +28.58 [+15.77, +41.37] | +311.33% | -14.15% | -655 | 12.0 / 15 |
| ENS | narrow_bullish | 450 (27%) | +26.33 [+11.69, +40.38] | +208.17% | -15.61% | -589 | 12.0 / 14 |
| ENS | mixed | 221 (13%) | +10.93 [-11.69, +33.05] | +22.01% | -21.11% | -599 | 12.0 / 15 |
| ENS | broad_bearish | 237 (14%) | -6.85 [-40.60, +24.59] | -20.70% | -34.74% | -628 | 12.1 / 15 |
| ENS | high_stress | 238 (14%) | +33.77 [-8.17, +79.56] | +103.31% | -35.89% | -885 | 12.2 / 16 |

**The book's worst drawdown and the environments during it**

- D: -45.77% from 2020-01-24 to 2020-03-24; environments (previous close) on those days: high_stress 50%, mixed 38%, narrow_bullish 7%, broad_bullish 5%
- ENS: -39.10% from 2020-02-20 to 2020-03-24; environments (previous close) on those days: high_stress 86%, mixed 14%

## How much to trust this

- Same 2020-2026 history the engines were built and studied on: sections 1-3 and 5 describe it. Section 4 is the honest test - each year judged only by signs chosen on earlier years - but it is still the same history; the forward paper ledger is the only untouched evidence.
- 8 signs are tested per engine and year: qualification uses a Bonferroni p-value (0.05 / 8), so luck alone qualifies a sign in about 5% of engine-years at most; the descriptive 95% intervals in section 3 are not corrected.
- Breadth counts the stocks in your cache (survivors), not NSE's official advance/decline. Size class is AMFI's list in force on the pick day, blank where no list was given.
- Returns and drawdowns are tradelab's money view (compounded, cash-limited, flat 35 bp), not stage E's execution simulator; a CANDIDATE has to be replayed there before it can speak to the -25% target.

## Files

- outcome_groups.csv, outcome_profiles.csv, warning_signs.csv, walk_forward.csv (+ walk_forward_verdicts.csv), book_by_environment.csv, severe_losers.md / .html
