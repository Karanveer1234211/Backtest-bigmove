## ENS-20250220-3 SUMMITSEC - plan

ENS rank 3, signal day 2025-02-20, mode daily. Status: **ok**.

Result: **net -1114.6 bp** of the target size (gross -1079.6, costs 35.0); bought 100% of the target, average entry 1639.00, last sale 1462.05 (time, session 5); MFE +3.36% (session 1), MAE -12.28% (session 5).

### What happened, in order

- 2025-02-21 09:15  **BUY open** 100% of the target @ 1639.00 (open: at the session 1 open)
- 2025-02-28 15:30  **SELL time** 100% of the position @ 1462.05 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-02-20 | 1599.50 | 1690.75 | 1580.00 | 1649.95 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-02-21 | 1639.00 | 1694.05 | 1600.00 | 1620.00 | 100% | -133.4 | -133.4 | buy open@1639.0000 |
| 2 | 2025-02-24 | 1619.00 | 1619.00 | 1552.70 | 1573.05 | 100% | -286.5 | -419.9 |  |
| 3 | 2025-02-25 | 1575.00 | 1601.10 | 1552.00 | 1574.05 | 100% | +6.1 | -413.8 |  |
| 4 | 2025-02-27 | 1574.05 | 1590.00 | 1493.05 | 1507.30 | 100% | -407.3 | -821.0 |  |
| 5 | 2025-02-28 | 1510.00 | 1528.45 | 1437.65 | 1462.05 | 0% | -293.6 | -1114.6 | sell time@1462.0500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Wed 19 Feb 2025: NIFTY -0.1%, Midcap +1.5%, Smallcap +2.2%; NIFTY minus Smallcap -2.3 pts (20-day +9.6 pts); breadth 0.78 (1,666 up / 461 down of 2,149; 10-day 0.33); VIX 15.4 (day -1.6%, 5-day +3.5%, 74th percentile); environment: Broad bearish.
- Pick day: Thu 20 Feb 2025: NIFTY -0.1%, Midcap +1.3%, Smallcap +1.2%; NIFTY minus Smallcap -1.3 pts (20-day +6.9 pts); breadth 0.72 (1,538 up / 586 down of 2,146; 10-day 0.35); VIX 14.7 (day -4.8%, 5-day -1.9%, 64th percentile); environment: Broad bearish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.64, correlation 0.60).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Wed 19 Feb 2025 | +4.6% | -0.1% | +1.5% | +2.2% | 0.78 | 15.4 | Broad bearish | +2.4 pts | 0% |  |
| 0 | Thu 20 Feb 2025 | +3.5% | -0.1% | +1.3% | +1.2% | 0.72 | 14.7 | Broad bearish | +2.2 pts | 0% | +0 |
| 1 | Fri 21 Feb 2025 | -1.8% | -0.5% | -1.1% | -0.6% | 0.33 | 14.5 | Broad bearish | -1.2 pts | 100% | -133 |
| 2 | Mon 24 Feb 2025 | -2.9% | -1.1% | -0.9% | -1.2% | 0.22 | 14.4 | Broad bearish | -1.7 pts | 100% | -286 |
| 3 | Tue 25 Feb 2025 | +0.1% | 0.0% | -0.5% | -0.4% | 0.36 | 13.7 | Broad bearish | +0.5 pts | 100% | +6 |
| 4 | Thu 27 Feb 2025 | -4.2% | 0.0% | -1.3% | -1.7% | 0.18 | 13.3 | Broad bearish | -2.6 pts | 100% | -407 |
| 5 | Fri 28 Feb 2025 | -3.0% | -1.9% | -2.3% | -2.5% | 0.12 | 13.9 | HIGH STRESS | -0.5 pts | 0% | -294 |

- From the first buy to the last sale: NIFTY -3.2%, Midcap -5.9%, Smallcap -6.2%; the trade made -10.80% gross on the money it used.
- Split (on the money used): market part -10.11% = beta 1.64 x Smallcap 250 -6.15%; stock part -0.69% -> mostly the market.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (LOW, 9 sessions, deteriorating) -> UNKNOWN pending | S10 breakdown CONFIRMED (4d) | volatility elevated**
- Emerging bearish trend began 10 Feb 2025, confirmed 11 Feb 2025 (before it: UNKNOWN); required 2 of 3 hold, supporting 9 of 10 (support 90%), conflicts: none
- What would end it: 2 sessions in a row closing above 3,171.93 (the last swing high 3,140.00 plus 0.25 ATR), or at / above EMA50 2,286.73 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 55-session low 1,694.95 4 sessions ago, volume 2.0x normal - CONFIRMED on 19 Feb
- Transitions before the pick: S03 -> S07 (27 Dec) -> UNKNOWN (07 Jan) -> S09 (09 Jan) -> S08 (29 Jan) -> UNKNOWN (07 Feb) -> S09 (11 Feb)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 20 Feb 2025 | 1,649.95 | S09 | UNKNOWN | LOW | deteriorating | S10 breakdown confirmed |  |
| 1 | Fri 21 Feb 2025 | 1,620.00 | UNKNOWN | UNKNOWN | UNKNOWN |  | S10 breakdown confirmed |  |
| 2 | Mon 24 Feb 2025 | 1,573.05 | UNKNOWN | S08 | UNKNOWN |  | S10 breakdown confirmed |  |
| 3 | Tue 25 Feb 2025 | 1,574.05 | S08 | S08 | MEDIUM | early | S10 breakdown confirmed |  |
| 4 | Thu 27 Feb 2025 | 1,507.30 | S08 | S08 | HIGH | early | S10 breakdown confirmed |  |
| 5 | Fri 28 Feb 2025 | 1,462.05 | S08 | S08 | HIGH | early | S10 breakdown new |  |
