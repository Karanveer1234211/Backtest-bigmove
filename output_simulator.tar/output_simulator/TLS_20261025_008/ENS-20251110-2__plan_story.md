## ENS-20251110-2 TSFINV - plan

ENS rank 2, signal day 2025-11-10, mode daily. Status: **ok**.

Result: **net -616.2 bp** of the target size (gross -581.2, costs 35.0); bought 100% of the target, average entry 560.00, last sale 527.45 (time, session 5); MFE +0.89% (session 1), MAE -9.11% (session 1).

### What happened, in order

- 2025-11-11 09:15  **BUY open** 100% of the target @ 560.00 (open: at the session 1 open)
- 2025-11-17 15:30  **SELL time** 100% of the position @ 527.45 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-11-10 | 588.00 | 596.00 | 555.10 | 559.80 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-11-11 | 560.00 | 565.00 | 509.00 | 521.30 | 100% | -708.6 | -708.6 | buy open@560.0000 |
| 2 | 2025-11-12 | 522.00 | 537.45 | 512.50 | 525.80 | 100% | +80.4 | -628.2 |  |
| 3 | 2025-11-13 | 525.80 | 554.00 | 523.30 | 540.75 | 100% | +267.0 | -361.3 |  |
| 4 | 2025-11-14 | 538.80 | 540.30 | 525.80 | 534.10 | 100% | -118.7 | -480.0 |  |
| 5 | 2025-11-17 | 532.00 | 546.25 | 523.55 | 527.45 | 0% | -136.2 | -616.2 | sell time@527.4500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Fri 07 Nov 2025: NIFTY -0.1%, Midcap +0.5%, Smallcap -0.2%; NIFTY minus Smallcap +0.2 pts (20-day +1.4 pts); breadth 0.49 (1,128 up / 1,151 down of 2,307; 10-day 0.42); VIX 12.6 (day +1.2%, 5-day +4.1%, 35th percentile); environment: Narrow bullish.
- Pick day: Mon 10 Nov 2025: NIFTY +0.3%, Midcap +0.5%, Smallcap 0.0%; NIFTY minus Smallcap +0.3 pts (20-day +1.5 pts); breadth 0.46 (1,055 up / 1,231 down of 2,317; 10-day 0.43); VIX 12.3 (day -2.1%, 5-day +1.2%, 32nd percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.49, correlation 0.37).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Fri 07 Nov 2025 | +0.4% | -0.1% | +0.5% | -0.2% | 0.49 | 12.6 | Narrow bullish | +0.6 pts | 0% |  |
| 0 | Mon 10 Nov 2025 | -5.1% | +0.3% | +0.5% | 0.0% | 0.46 | 12.3 | Narrow bullish | -5.1 pts | 0% | +0 |
| 1 | Tue 11 Nov 2025 | -6.9% | +0.5% | +0.4% | -0.1% | 0.48 | 12.5 | Narrow bullish | -6.7 pts | 100% | -709 |
| 2 | Wed 12 Nov 2025 | +0.9% | +0.7% | +0.8% | +0.7% | 0.64 | 12.1 | Narrow bullish | +0.1 pts | 100% | +80 |
| 3 | Thu 13 Nov 2025 | +2.8% | 0.0% | -0.3% | -0.4% | 0.40 | 12.2 | Narrow bullish | +3.2 pts | 100% | +267 |
| 4 | Fri 14 Nov 2025 | -1.2% | +0.1% | 0.0% | +0.2% | 0.45 | 11.9 | Narrow bullish | -1.4 pts | 100% | -119 |
| 5 | Mon 17 Nov 2025 | -1.2% | +0.4% | +0.7% | +0.7% | 0.53 | 11.8 | Narrow bullish | -1.9 pts | 0% | -136 |

- From the first buy to the last sale: NIFTY +1.5%, Midcap +1.4%, Smallcap +0.9%; the trade made -5.81% gross on the money it used.
- Split (on the money used): market part +1.36% = beta 1.49 x Smallcap 250 +0.91%; stock part -7.17% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (MEDIUM, 4 sessions, early) | S10 breakdown NEW today | risk: large down candle in the last 5 sessions | volatility extreme**
- Emerging bearish trend began 04 Nov 2025, confirmed 06 Nov 2025 (before it: S03); required 3 of 3 hold, supporting 7 of 10 (support 70%), conflicts: none
- What would end it: 2 sessions in a row closing above 704.34 (the last swing high 697.00 plus 0.25 ATR), or at / above EMA50 605.62 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 20-session low 580.05 today, volume 0.7x normal - NEW (not yet confirmed)
- Risk flags: large down candle in the last 5 sessions
- Transitions before the pick: S09 -> S07 (13 Aug) -> S03 (04 Sep) -> S02 (09 Sep) -> S01 (13 Oct) -> S03 (23 Oct) -> S09 (06 Nov)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Mon 10 Nov 2025 | 559.80 | S09 | S09 | MEDIUM | early | S10 breakdown new | large down candle in the last 5 sessions |
| 1 | Tue 11 Nov 2025 | 521.30 | S09 | S09 | HIGH | early | S10 breakdown new | stretched far below EMA20; large down candle in the last 5 sessions |
| 2 | Wed 12 Nov 2025 | 525.80 | S09 | S09 | HIGH | mature | S10 breakdown new |  |
| 3 | Thu 13 Nov 2025 | 540.75 | S09 | S09 | HIGH | mature | S10 breakdown confirmed |  |
| 4 | Fri 14 Nov 2025 | 534.10 | S09 | UNKNOWN | LOW | deteriorating | S10 breakdown confirmed |  |
| 5 | Mon 17 Nov 2025 | 527.45 | UNKNOWN | UNKNOWN | UNKNOWN |  | S10 breakdown confirmed |  |
