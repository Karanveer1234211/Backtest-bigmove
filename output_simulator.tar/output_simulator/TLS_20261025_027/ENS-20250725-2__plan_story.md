## ENS-20250725-2 NACLIND - plan

ENS rank 2, signal day 2025-07-25, mode daily. Status: **ok**.

Result: **net +714.2 bp** of the target size (gross +749.2, costs 35.0); bought 100% of the target, average entry 262.55, last sale 282.22 (time, session 5); MFE +18.53% (session 5), MAE -6.42% (session 1).

### What happened, in order

- 2025-07-28 09:15  **BUY open** 100% of the target @ 262.55 (open: at the session 1 open)
- 2025-08-01 15:30  **SELL time** 100% of the position @ 282.22 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-07-25 | 261.27 | 267.60 | 254.95 | 256.06 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-07-28 | 262.55 | 268.56 | 245.69 | 256.04 | 100% | -265.5 | -265.5 | buy open@262.5500 |
| 2 | 2025-07-29 | 268.83 | 268.83 | 268.83 | 268.83 | 100% | +487.1 | +221.7 |  |
| 3 | 2025-07-30 | 282.27 | 282.27 | 282.27 | 282.27 | 100% | +511.9 | +733.6 |  |
| 4 | 2025-07-31 | 288.68 | 296.38 | 280.61 | 296.38 | 100% | +537.4 | +1271.0 |  |
| 5 | 2025-08-01 | 299.59 | 311.19 | 281.58 | 282.22 | 0% | -556.8 | +714.2 | sell time@282.2200 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Thu 24 Jul 2025: NIFTY -0.6%, Midcap -0.4%, Smallcap -0.7%; NIFTY minus Smallcap 0.0 pts (20-day -3.2 pts); breadth 0.33 (723 up / 1,484 down of 2,230; 10-day 0.45); VIX 10.7 (day +1.9%, 5-day -4.6%, 1st percentile); environment: Narrow bullish.
- Pick day: Fri 25 Jul 2025: NIFTY -0.9%, Midcap -1.6%, Smallcap -2.0% (2.2 sd fall); NIFTY minus Smallcap +1.1 pts (20-day -1.6 pts); breadth 0.15 (338 up / 1,881 down of 2,231; 10-day 0.44); VIX 11.3 (day +5.2%, 5-day -1.0%, 3rd percentile); environment: Mixed / ranging.
- The pick: size class no list; moves most with Smallcap 250 (beta 0.56, correlation 0.15).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Thu 24 Jul 2025 | -3.1% | -0.6% | -0.4% | -0.7% | 0.33 | 10.7 | Narrow bullish | -2.4 pts | 0% |  |
| 0 | Fri 25 Jul 2025 | -4.6% | -0.9% | -1.6% | -2.0% | 0.15 | 11.3 | Mixed / ranging | -2.6 pts | 0% | +0 |
| 1 | Mon 28 Jul 2025 | 0.0% | -0.6% | -0.9% | -1.2% | 0.21 | 12.1 | Broad bearish | +1.2 pts | 100% | -265 |
| 2 | Tue 29 Jul 2025 | +5.0% | +0.6% | +0.9% | +0.9% | 0.69 | 11.5 | Broad bearish | +4.1 pts | 100% | +487 |
| 3 | Wed 30 Jul 2025 | +5.0% | +0.1% | +0.2% | -0.1% | 0.51 | 11.2 | Broad bearish | +5.1 pts | 100% | +512 |
| 4 | Thu 31 Jul 2025 | +5.0% | -0.3% | -0.8% | -0.9% | 0.30 | 11.5 | Broad bearish | +5.9 pts | 100% | +537 |
| 5 | Fri 01 Aug 2025 | -4.8% | -0.8% | -1.3% | -1.6% | 0.21 | 12.0 | Broad bearish | -3.1 pts | 0% | -557 |

- From the first buy to the last sale: NIFTY -0.9%, Midcap -1.8%, Smallcap -2.7%; the trade made +7.49% gross on the money it used.
- Split (on the money used): market part -1.52% = beta 0.56 x Smallcap 250 -2.74%; stock part +9.02% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (LOW, 13 sessions, deteriorating) | S04 breakout CONFIRMED (7d) | risk: bearish divergence candidate (RSI)**
- Strong bullish continuation began 09 Jul 2025, confirmed 10 Jul 2025 (before it: UNKNOWN); required 5 of 5 hold, supporting 10 of 10 (support 100%), conflicts: bearish divergence candidate: a higher swing high with RSI 5+ points lower (swing known in the last 20 sessions); momentum decelerating (10-session move 1.5+ ATR smaller than the 10 before)
- What would end it: 2 sessions in a row closing below 204.02 (the last higher low 207.65 less 0.25 ATR) or at / below EMA50 208.11; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S04 breakout: closed above the 55-session high 243.30 7 sessions ago, volume 2.4x normal - CONFIRMED on 21 Jul
- Risk flags: bearish divergence candidate (RSI)
- Transitions before the pick: S01 -> UNKNOWN (04 Jun) -> S03 (16 Jun) -> UNKNOWN (19 Jun) -> S03 (25 Jun) -> UNKNOWN (27 Jun) -> S01 (10 Jul)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Fri 25 Jul 2025 | 256.06 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 1 | Mon 28 Jul 2025 | 256.04 | S01 | S01 | MEDIUM | mature | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 2 | Tue 29 Jul 2025 | 268.83 | S01 | S01 | MEDIUM | mature | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 3 | Wed 30 Jul 2025 | 282.27 | S01 | S01 | MEDIUM | mature | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 4 | Thu 31 Jul 2025 | 296.38 | S01 | S01 | MEDIUM | mature | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 5 | Fri 01 Aug 2025 | 282.22 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed | bearish divergence candidate (RSI) |
