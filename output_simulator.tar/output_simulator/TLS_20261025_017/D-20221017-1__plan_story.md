## D-20221017-1 PUNJABCHEM - plan

D rank 1, signal day 2022-10-17, mode daily. Status: **ok**.

Result: **net +971.9 bp** of the target size (gross +1006.9, costs 35.0); bought 100% of the target, average entry 1055.20, last sale 1161.45 (time, session 5); MFE +11.07% (session 3), MAE -2.28% (session 1).

### What happened, in order

- 2022-10-18 09:15  **BUY open** 100% of the target @ 1055.20 (open: at the session 1 open)
- 2022-10-24 15:30  **SELL time** 100% of the position @ 1161.45 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2022-10-17 | 1095.00 | 1097.85 | 1023.00 | 1053.80 | 0% | +0.0 | +0.0 |  |
| 1 | 2022-10-18 | 1055.20 | 1073.75 | 1031.10 | 1049.60 | 100% | -70.6 | -70.6 | buy open@1055.2000 |
| 2 | 2022-10-19 | 1037.00 | 1094.80 | 1035.00 | 1070.20 | 100% | +195.2 | +124.7 |  |
| 3 | 2022-10-20 | 1083.00 | 1172.00 | 1075.00 | 1099.90 | 100% | +281.5 | +406.1 |  |
| 4 | 2022-10-21 | 1103.00 | 1139.90 | 1062.00 | 1134.35 | 100% | +326.5 | +732.6 |  |
| 5 | 2022-10-24 | 1150.00 | 1169.95 | 1145.00 | 1161.45 | 0% | +239.3 | +971.9 | sell time@1161.4500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Fri 14 Oct 2022: NIFTY +1.0%, Midcap -0.1%, Smallcap 0.0%; NIFTY minus Smallcap +1.0 pts (20-day +1.0 pts); breadth 0.48 (817 up / 888 down of 1,764; 10-day 0.49); VIX 18.3 (day -10.0%, 5-day -2.9%, 35th percentile); environment: Broad bearish.
- Pick day: Mon 17 Oct 2022: NIFTY +0.7%, Midcap +0.2%, Smallcap +0.3%; NIFTY minus Smallcap +0.5 pts (20-day +1.2 pts); breadth 0.44 (768 up / 960 down of 1,772; 10-day 0.46); VIX 18.4 (day +0.9%, 5-day -6.1%, 39th percentile); environment: Broad bearish.
- The pick: size class no list; moves most with Midcap 150 (beta 0.61, correlation 0.37).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Fri 14 Oct 2022 | -5.0% | +1.0% | -0.1% | 0.0% | 0.48 | 18.3 | Broad bearish | -5.0 pts | 0% |  |
| 0 | Mon 17 Oct 2022 | -2.9% | +0.7% | +0.2% | +0.3% | 0.44 | 18.4 | Broad bearish | -3.1 pts | 0% | +0 |
| 1 | Tue 18 Oct 2022 | -0.4% | +1.0% | +1.0% | +0.8% | 0.65 | 17.4 | Mixed / ranging | -1.4 pts | 100% | -71 |
| 2 | Wed 19 Oct 2022 | +2.0% | +0.1% | +0.1% | 0.0% | 0.45 | 17.5 | Narrow bullish | +1.9 pts | 100% | +195 |
| 3 | Thu 20 Oct 2022 | +2.8% | +0.3% | -0.3% | +0.1% | 0.47 | 17.2 | Narrow bullish | +3.0 pts | 100% | +281 |
| 4 | Fri 21 Oct 2022 | +3.1% | +0.1% | -0.6% | -0.4% | 0.31 | 17.3 | Narrow bullish | +3.7 pts | 100% | +326 |
| 5 | Mon 24 Oct 2022 | +2.4% | +0.9% | +0.6% | +0.9% | 0.83 | 17.4 | Narrow bullish | +1.8 pts | 0% | +239 |

- From the first buy to the last sale: NIFTY +1.7%, Midcap +0.1%, Smallcap +0.9%; the trade made +10.07% gross on the money it used.
- Split (on the money used): market part +0.07% = beta 0.61 x Midcap 150 +0.12%; stock part +10.00% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (HIGH, 6 sessions, mature) | S10 breakdown NEW (2d) | volatility elevated**
- Emerging bearish trend began 10 Oct 2022, confirmed 11 Oct 2022 (before it: UNKNOWN); required 3 of 3 hold, supporting 8 of 10 (support 80%), conflicts: none
- What would end it: 2 sessions in a row closing above 1,271.60 (the last swing high 1,259.00 plus 0.25 ATR), or at / above EMA50 1,250.59 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 55-session low 1,183.10 2 sessions ago, volume 2.1x normal - NEW (not yet confirmed)
- Transitions before the pick: S02 -> S01 (03 Aug) -> S09 (11 Aug) -> S07 (17 Aug) -> S09 (22 Sep) -> UNKNOWN (06 Oct) -> S09 (11 Oct)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Mon 17 Oct 2022 | 1,053.80 | S09 | S09 | HIGH | mature | S10 breakdown new |  |
| 1 | Tue 18 Oct 2022 | 1,049.60 | S09 | S09 | HIGH | mature | S10 breakdown confirmed |  |
| 2 | Wed 19 Oct 2022 | 1,070.20 | S09 | S09 | HIGH | mature | S10 breakdown confirmed |  |
| 3 | Thu 20 Oct 2022 | 1,099.90 | S09 | UNKNOWN | LOW | deteriorating | S10 breakdown confirmed |  |
| 4 | Fri 21 Oct 2022 | 1,134.35 | UNKNOWN | UNKNOWN | UNKNOWN |  | S10 breakdown confirmed |  |
| 5 | Mon 24 Oct 2022 | 1,161.45 | UNKNOWN | UNKNOWN | UNKNOWN |  | S10 breakdown confirmed |  |
