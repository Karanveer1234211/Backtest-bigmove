## ENS-20230316-1 PARACABLES - plan

ENS rank 1, signal day 2023-03-16, mode daily. Status: **ok**.

Result: **net +1420.8 bp** of the target size (gross +1455.8, costs 35.0); bought 100% of the target, average entry 28.85, last sale 33.05 (time, session 5); MFE +14.56% (session 5), MAE -3.29% (session 2).

### What happened, in order

- 2023-03-17 09:15  **BUY open** 100% of the target @ 28.85 (open: at the session 1 open)
- 2023-03-23 15:30  **SELL time** 100% of the position @ 33.05 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2023-03-16 | 30.95 | 30.95 | 29.40 | 29.40 | 0% | +0.0 | +0.0 |  |
| 1 | 2023-03-17 | 28.85 | 29.90 | 28.30 | 28.80 | 100% | -34.8 | -34.8 | buy open@28.8500 |
| 2 | 2023-03-20 | 29.70 | 29.70 | 27.90 | 28.60 | 100% | -69.3 | -104.2 |  |
| 3 | 2023-03-21 | 29.20 | 30.00 | 28.50 | 30.00 | 100% | +485.3 | +381.1 |  |
| 4 | 2023-03-22 | 31.00 | 31.50 | 31.00 | 31.50 | 100% | +519.9 | +901.0 |  |
| 5 | 2023-03-23 | 33.05 | 33.05 | 33.05 | 33.05 | 0% | +519.8 | +1420.8 | sell time@33.0500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Wed 15 Mar 2023: NIFTY -0.4%, Midcap 0.0%, Smallcap +0.2%; NIFTY minus Smallcap -0.6 pts (20-day -2.9 pts); breadth 0.43 (759 up / 1,022 down of 1,822; 10-day 0.46); VIX 16.3 (day +0.5%, 5-day +30.9%, 36th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX +31% in 5 sessions.
- Pick day: Thu 16 Mar 2023: NIFTY +0.1%, Midcap 0.0%, Smallcap -0.7%; NIFTY minus Smallcap +0.8 pts (20-day -2.2 pts); breadth 0.37 (662 up / 1,134 down of 1,832; 10-day 0.41); VIX 16.2 (day -0.5%, 5-day +27.4%, 36th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX +27% in 5 sessions.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.28, correlation 0.32).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Wed 15 Mar 2023 | -4.9% | -0.4% | 0.0% | +0.2% | 0.43 | 16.3 | HIGH STRESS | -5.1 pts | 0% |  |
| 0 | Thu 16 Mar 2023 | -5.0% | +0.1% | 0.0% | -0.7% | 0.37 | 16.2 | HIGH STRESS | -4.3 pts | 0% | +0 |
| 1 | Fri 17 Mar 2023 | -2.0% | +0.7% | +0.4% | +0.7% | 0.62 | 14.8 | Broad bearish | -2.7 pts | 100% | -35 |
| 2 | Mon 20 Mar 2023 | -0.7% | -0.7% | -1.0% | -0.9% | 0.23 | 16.0 | Broad bearish | +0.2 pts | 100% | -69 |
| 3 | Tue 21 Mar 2023 | +4.9% | +0.7% | +0.6% | +0.5% | 0.61 | 15.1 | Broad bearish | +4.4 pts | 100% | +485 |
| 4 | Wed 22 Mar 2023 | +5.0% | +0.3% | +0.3% | +0.6% | 0.62 | 14.8 | Broad bearish | +4.4 pts | 100% | +520 |
| 5 | Thu 23 Mar 2023 | +4.9% | -0.4% | -0.4% | -0.3% | 0.35 | 14.5 | Broad bearish | +5.2 pts | 0% | +520 |

- From the first buy to the last sale: NIFTY -0.2%, Midcap -0.7%, Smallcap -0.2%; the trade made +14.56% gross on the money it used.
- Split (on the money used): market part -0.19% = beta 1.28 x Smallcap 250 -0.15%; stock part +14.75% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (MEDIUM, 2 sessions, early) | S10 breakdown NEW today**
- Emerging bearish trend began 15 Mar 2023, confirmed 16 Mar 2023 (before it: S07); required 3 of 3 hold, supporting 8 of 10 (support 80%), conflicts: none
- What would end it: 2 sessions in a row closing above 38.27 (the last swing high 37.80 plus 0.25 ATR), or at / above EMA50 34.29 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 55-session low 29.80 today, volume 2.3x normal - NEW (not yet confirmed)
- Transitions before the pick: S03 -> UNKNOWN (09 Feb) -> S09 (14 Feb) -> S07 (17 Feb) -> S03 (21 Feb) -> S07 (14 Mar) -> S09 (16 Mar)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 16 Mar 2023 | 29.40 | S09 | S09 | MEDIUM | early | S10 breakdown new |  |
| 1 | Fri 17 Mar 2023 | 28.80 | S09 | S09 | HIGH | early | S10 breakdown new |  |
| 2 | Mon 20 Mar 2023 | 28.60 | S09 | S09 | HIGH | early | S10 breakdown new |  |
| 3 | Tue 21 Mar 2023 | 30.00 | S09 | S09 | HIGH | early | S10 breakdown new |  |
| 4 | Wed 22 Mar 2023 | 31.50 | S09 | S09 | HIGH | mature | failed breakdown (bear trap) |  |
| 5 | Thu 23 Mar 2023 | 33.05 | S09 | S09 | MEDIUM | mature | failed breakdown (bear trap) |  |
