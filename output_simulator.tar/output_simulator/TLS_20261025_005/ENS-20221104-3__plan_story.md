## ENS-20221104-3 JWL - plan

ENS rank 3, signal day 2022-11-04, mode daily. Status: **ok**.

Result: **net +891.3 bp** of the target size (gross +926.3, costs 35.0); bought 100% of the target, average entry 73.95, last sale 80.80 (time, session 5); MFE +10.75% (session 5), MAE -2.64% (session 1).

### What happened, in order

- 2022-11-07 09:15  **BUY open** 100% of the target @ 73.95 (open: at the session 1 open)
- 2022-11-14 15:30  **SELL time** 100% of the position @ 80.80 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2022-11-04 | 73.35 | 74.00 | 71.65 | 73.10 | 0% | +0.0 | +0.0 |  |
| 1 | 2022-11-07 | 73.95 | 74.00 | 72.00 | 73.55 | 100% | -71.6 | -71.6 | buy open@73.9500 |
| 2 | 2022-11-09 | 74.00 | 77.20 | 73.95 | 77.20 | 100% | +493.6 | +422.0 |  |
| 3 | 2022-11-10 | 79.20 | 81.00 | 75.10 | 78.55 | 100% | +182.6 | +604.5 |  |
| 4 | 2022-11-11 | 79.65 | 79.65 | 75.55 | 78.00 | 100% | -74.4 | +530.2 |  |
| 5 | 2022-11-14 | 81.90 | 81.90 | 79.00 | 80.80 | 0% | +361.1 | +891.3 | sell time@80.8000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Thu 03 Nov 2022: NIFTY -0.2%, Midcap +0.2%, Smallcap +0.1%; NIFTY minus Smallcap -0.3 pts (20-day +3.3 pts); breadth 0.46 (791 up / 927 down of 1,772; 10-day 0.49); VIX 15.9 (day -4.3%, 5-day -4.0%, 4th percentile); environment: Narrow bullish.
- Pick day: Fri 04 Nov 2022: NIFTY +0.4%, Midcap -0.1%, Smallcap +0.5%; NIFTY minus Smallcap -0.1 pts (20-day +3.9 pts); breadth 0.57 (988 up / 743 down of 1,775; 10-day 0.50); VIX 15.7 (day -1.8%, 5-day -1.6%, 2nd percentile); environment: Broad bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.57, correlation 0.43).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Thu 03 Nov 2022 | +0.6% | -0.2% | +0.2% | +0.1% | 0.46 | 15.9 | Narrow bullish | +0.4 pts | 0% |  |
| 0 | Fri 04 Nov 2022 | +0.2% | +0.4% | -0.1% | +0.5% | 0.57 | 15.7 | Broad bullish | -0.3 pts | 0% | +0 |
| 1 | Mon 07 Nov 2022 | +0.6% | +0.5% | +0.7% | +0.7% | 0.60 | 15.6 | Broad bullish | -0.1 pts | 100% | -72 |
| 2 | Wed 09 Nov 2022 | +5.0% | -0.3% | -0.6% | -0.4% | 0.45 | 15.9 | Narrow bullish | +5.4 pts | 100% | +494 |
| 3 | Thu 10 Nov 2022 | +1.7% | -0.7% | -0.9% | -1.2% | 0.27 | 15.6 | Narrow bullish | +3.0 pts | 100% | +183 |
| 4 | Fri 11 Nov 2022 | -0.7% | +1.8% | +0.1% | +0.3% | 0.54 | 14.4 | Narrow bullish | -1.0 pts | 100% | -74 |
| 5 | Mon 14 Nov 2022 | +3.6% | -0.1% | 0.0% | +0.5% | 0.45 | 14.9 | Narrow bullish | +3.1 pts | 0% | +361 |

- From the first buy to the last sale: NIFTY +0.6%, Midcap -1.2%, Smallcap -0.6%; the trade made +9.26% gross on the money it used.
- Split (on the money used): market part -0.95% = beta 1.57 x Smallcap 250 -0.61%; stock part +10.21% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S03 Bullish consolidation (LOW, 18 sessions, deteriorating) -> S07 pending | volatility compressed**
- Bullish consolidation began 11 Oct 2022, confirmed 12 Oct 2022 (before it: S07); required 4 of 5 hold, supporting 6 of 7 (support 86%), conflicts: none
- What would end it: 2 sessions in a row closing below 69.50 (the last swing low 70.30 less 0.25 ATR) or below 70.32 (EMA50 71.92 less 0.5 ATR) ends it downward; the 15-session range (70.30 - 77.50) widening past 3.5 ATR ends it either way - upward with an S04 breakout
- Notes: volatility compressed
- Transitions before the pick: UNKNOWN -> S02 (12 Sep) -> UNKNOWN (22 Sep) -> S09 (30 Sep) -> UNKNOWN (06 Oct) -> S07 (10 Oct) -> S03 (12 Oct)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Fri 04 Nov 2022 | 73.10 | S03 | S07 | LOW | deteriorating |  |  |
| 1 | Mon 07 Nov 2022 | 73.55 | S07 | S07 | MEDIUM | early |  |  |
| 2 | Wed 09 Nov 2022 | 77.20 | S07 | S07 | MEDIUM | early |  |  |
| 3 | Thu 10 Nov 2022 | 78.55 | S07 | S02 | LOW | deteriorating | S04 breakout new |  |
| 4 | Fri 11 Nov 2022 | 78.00 | UNKNOWN | UNKNOWN | UNKNOWN |  | S04 breakout new |  |
| 5 | Mon 14 Nov 2022 | 80.80 | UNKNOWN | S02 | UNKNOWN |  | S04 breakout new |  |
