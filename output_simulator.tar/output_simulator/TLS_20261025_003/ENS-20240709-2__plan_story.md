## ENS-20240709-2 GMRP&UI - plan

ENS rank 2, signal day 2024-07-09, mode daily. Status: **ok**.

Result: **net +743.0 bp** of the target size (gross +778.0, costs 35.0); bought 100% of the target, average entry 95.50, last sale 102.93 (time, session 5); MFE +12.57% (session 4), MAE -5.76% (session 1).

### What happened, in order

- 2024-07-10 09:15  **BUY open** 100% of the target @ 95.50 (open: at the session 1 open)
- 2024-07-16 15:30  **SELL time** 100% of the position @ 102.93 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2024-07-09 | 94.37 | 96.70 | 92.25 | 94.74 | 0% | +0.0 | +0.0 |  |
| 1 | 2024-07-10 | 95.50 | 99.00 | 90.00 | 93.57 | 100% | -219.6 | -219.6 | buy open@95.5000 |
| 2 | 2024-07-11 | 98.24 | 98.24 | 96.20 | 98.24 | 100% | +489.0 | +269.4 |  |
| 3 | 2024-07-12 | 101.92 | 103.15 | 99.80 | 103.15 | 100% | +514.1 | +783.5 |  |
| 4 | 2024-07-15 | 105.40 | 107.50 | 99.45 | 102.15 | 100% | -104.7 | +678.8 |  |
| 5 | 2024-07-16 | 103.50 | 106.85 | 102.00 | 102.93 | 0% | +64.2 | +743.0 | sell time@102.9300 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 08 Jul 2024: NIFTY 0.0%, Midcap -0.3%, Smallcap -0.3%; NIFTY minus Smallcap +0.2 pts (20-day -5.3 pts); breadth 0.39 (781 up / 1,224 down of 2,025; 10-day 0.51); VIX 13.6 (day +7.1%, 5-day -1.7%, 62nd percentile); environment: Broad bullish.
- Pick day: Tue 09 Jul 2024: NIFTY +0.5%, Midcap +0.3%, Smallcap +0.2%; NIFTY minus Smallcap +0.2 pts (20-day -3.5 pts); breadth 0.52 (1,028 up / 964 down of 2,019; 10-day 0.52); VIX 14.3 (day +5.0%, 5-day +4.7%, 72nd percentile); environment: Broad bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.58, correlation 0.60).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 08 Jul 2024 | +5.0% | 0.0% | -0.3% | -0.3% | 0.39 | 13.6 | Broad bullish | +5.3 pts | 0% |  |
| 0 | Tue 09 Jul 2024 | +0.3% | +0.5% | +0.3% | +0.2% | 0.52 | 14.3 | Broad bullish | 0.0 pts | 0% | +0 |
| 1 | Wed 10 Jul 2024 | -1.2% | -0.4% | -0.4% | -0.7% | 0.29 | 14.4 | Broad bullish | -0.5 pts | 100% | -220 |
| 2 | Thu 11 Jul 2024 | +5.0% | 0.0% | +0.2% | +0.6% | 0.61 | 14.0 | Broad bullish | +4.4 pts | 100% | +489 |
| 3 | Fri 12 Jul 2024 | +5.0% | +0.8% | -0.1% | -0.1% | 0.39 | 13.7 | Broad bullish | +5.1 pts | 100% | +514 |
| 4 | Mon 15 Jul 2024 | -1.0% | +0.3% | +0.7% | +0.4% | 0.53 | 14.2 | Narrow bullish | -1.3 pts | 100% | -105 |
| 5 | Tue 16 Jul 2024 | +0.8% | +0.1% | 0.0% | +0.2% | 0.50 | 14.2 | Narrow bullish | +0.6 pts | 0% | +64 |

- From the first buy to the last sale: NIFTY +0.6%, Midcap +0.1%, Smallcap -0.1%; the trade made +7.78% gross on the money it used.
- Split (on the money used): market part -0.14% = beta 1.58 x Smallcap 250 -0.09%; stock part +7.92% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S03 Bullish consolidation (MEDIUM, 2 sessions, early)**
- Bullish consolidation began 08 Jul 2024, confirmed 09 Jul 2024 (before it: S01); required 5 of 5 hold, supporting 5 of 7 (support 71%), conflicts: none
- What would end it: 2 sessions in a row closing below 81.00 (the last swing low 82.11 less 0.25 ATR) or below 74.19 (EMA50 76.41 less 0.5 ATR) ends it downward; the 15-session range (82.11 - 97.50) widening past 3.5 ATR ends it either way - upward with an S04 breakout
- Transitions before the pick: S01 -> S02 (13 May) -> UNKNOWN (17 May) -> S03 (04 Jun) -> UNKNOWN (11 Jun) -> S01 (04 Jul) -> S03 (09 Jul)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 09 Jul 2024 | 94.74 | S03 | S03 | MEDIUM | early |  |  |
| 1 | Wed 10 Jul 2024 | 93.57 | S03 | S01 | LOW | deteriorating |  |  |
| 2 | Thu 11 Jul 2024 | 98.24 | S01 | S01 | MEDIUM | early |  |  |
| 3 | Fri 12 Jul 2024 | 103.15 | S01 | S01 | HIGH | early | S04 breakout new |  |
| 4 | Mon 15 Jul 2024 | 102.15 | S01 | S01 | HIGH | early | S04 breakout new |  |
| 5 | Tue 16 Jul 2024 | 102.93 | S01 | S01 | HIGH | early | S04 breakout new |  |
