## ENS-20250407-3 BLUEJET - plan

ENS rank 3, signal day 2025-04-07, mode daily. Status: **ok**.

Result: **net +956.2 bp** of the target size (gross +991.2, costs 35.0); bought 100% of the target, average entry 679.95, last sale 747.35 (time, session 5); MFE +10.66% (session 5), MAE -8.07% (session 2).

### What happened, in order

- 2025-04-08 09:15  **BUY open** 100% of the target @ 679.95 (open: at the session 1 open)
- 2025-04-16 15:30  **SELL time** 100% of the position @ 747.35 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-04-07 | 653.60 | 688.95 | 653.60 | 655.70 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-04-08 | 679.95 | 719.70 | 679.00 | 694.55 | 100% | +197.2 | +197.2 | buy open@679.9500 |
| 2 | 2025-04-09 | 690.00 | 690.35 | 625.10 | 626.05 | 100% | -1007.4 | -810.2 |  |
| 3 | 2025-04-11 | 679.00 | 688.65 | 655.00 | 683.55 | 100% | +845.7 | +35.4 |  |
| 4 | 2025-04-15 | 709.60 | 751.90 | 682.05 | 736.45 | 100% | +778.0 | +813.4 |  |
| 5 | 2025-04-16 | 738.70 | 752.40 | 725.00 | 747.35 | 0% | +142.8 | +956.2 | sell time@747.3500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Fri 04 Apr 2025: NIFTY -1.5%, Midcap -2.9% (2.1 sd fall), Smallcap -3.3%; NIFTY minus Smallcap +1.8 pts (20-day -0.9 pts); breadth 0.12 (262 up / 1,896 down of 2,174; 10-day 0.49); VIX 13.8 (day +1.2%, 5-day +3.5%, 39th percentile); environment: Broad bearish.
- Pick day: Mon 07 Apr 2025: NIFTY -3.2% (4.2 sd fall), Midcap -3.6% (2.4 sd fall), Smallcap -4.0% (2.3 sd fall); NIFTY minus Smallcap +0.8 pts (20-day +0.5 pts); breadth 0.06 (127 up / 2,042 down of 2,176; 10-day 0.41); VIX 22.8 (day +65.6%, 5-day +79.2%, 98th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 98th percentile of 250 sessions; VIX +79% in 5 sessions; NIFTY -4.2 sd day.
- The pick: size class no list; moves most with Midcap 150 (beta 1.39, correlation 0.54).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Fri 04 Apr 2025 | -5.0% | -1.5% | -2.9% | -3.3% | 0.12 | 13.8 | Broad bearish | -2.1 pts | 0% |  |
| 0 | Mon 07 Apr 2025 | -9.7% | -3.2% | -3.6% | -4.0% | 0.06 | 22.8 | HIGH STRESS | -6.1 pts | 0% | +0 |
| 1 | Tue 08 Apr 2025 | +5.9% | +1.7% | +2.1% | +2.2% | 0.86 | 20.4 | HIGH STRESS | +3.8 pts | 100% | +197 |
| 2 | Wed 09 Apr 2025 | -9.9% | -0.6% | -0.6% | -1.1% | 0.31 | 21.4 | HIGH STRESS | -9.2 pts | 100% | -1007 |
| 3 | Fri 11 Apr 2025 | +9.2% | +1.9% | +1.9% | +3.1% | 0.87 | 20.1 | HIGH STRESS | +7.3 pts | 100% | +846 |
| 4 | Tue 15 Apr 2025 | +7.7% | +2.2% | +3.0% | +3.1% | 0.92 | 16.1 | Broad bullish | +4.7 pts | 100% | +778 |
| 5 | Wed 16 Apr 2025 | +1.5% | +0.5% | +0.7% | +0.9% | 0.72 | 15.9 | Broad bullish | +0.7 pts | 0% | +143 |

- From the first buy to the last sale: NIFTY +4.4%, Midcap +5.1%, Smallcap +5.9%; the trade made +9.91% gross on the money it used.
- Split (on the money used): market part +7.08% = beta 1.39 x Midcap 150 +5.08%; stock part +2.83% -> mostly the market.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (MEDIUM, 3 sessions, early) | S10 breakdown NEW (2d) | risk: stretched far below EMA20; repeated large gaps | volatility extreme**
- Emerging bearish trend began 03 Apr 2025, confirmed 04 Apr 2025 (before it: S01); required 3 of 3 hold, supporting 6 of 10 (support 60%), conflicts: none
- What would end it: 2 sessions in a row closing above 980.02 (the last swing high 968.30 plus 0.25 ATR), or at / above EMA50 776.31 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 20-session low 765.05 2 sessions ago, volume 2.7x normal - NEW (not yet confirmed)
- Risk flags: stretched far below EMA20; repeated large gaps
- Transitions before the pick: S01 -> UNKNOWN (24 Jan) -> S07 (28 Jan) -> UNKNOWN (31 Jan) -> S03 (20 Feb) -> S01 (18 Mar) -> S09 (04 Apr)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Mon 07 Apr 2025 | 655.70 | S09 | S09 | MEDIUM | early | S10 breakdown new | stretched far below EMA20; repeated large gaps |
| 1 | Tue 08 Apr 2025 | 694.55 | S09 | S09 | MEDIUM | early | S10 breakdown confirmed | repeated large gaps |
| 2 | Wed 09 Apr 2025 | 626.05 | S09 | S09 | HIGH | early | S10 breakdown new | stretched far below EMA20; repeated large gaps |
| 3 | Fri 11 Apr 2025 | 683.55 | S09 | S09 | MEDIUM | mature | failed breakdown (bear trap) | repeated large gaps |
| 4 | Tue 15 Apr 2025 | 736.45 | S09 | S09 | MEDIUM | mature | failed breakdown (bear trap) | repeated large gaps |
| 5 | Wed 16 Apr 2025 | 747.35 | S09 | S07 | LOW | deteriorating | failed breakdown (bear trap) | repeated large gaps |
