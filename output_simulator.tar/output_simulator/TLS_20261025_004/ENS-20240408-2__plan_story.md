## ENS-20240408-2 PSB - plan

ENS rank 2, signal day 2024-04-08, mode daily. Status: **ok**.

Result: **net -677.1 bp** of the target size (gross -642.1, costs 35.0); bought 100% of the target, average entry 63.85, last sale 59.75 (time, session 5); MFE +0.63% (session 1), MAE -10.65% (session 4).

### What happened, in order

- 2024-04-09 09:15  **BUY open** 100% of the target @ 63.85 (open: at the session 1 open)
- 2024-04-16 15:30  **SELL time** 100% of the position @ 59.75 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2024-04-08 | 65.15 | 65.40 | 63.05 | 63.55 | 0% | +0.0 | +0.0 |  |
| 1 | 2024-04-09 | 63.85 | 64.25 | 60.25 | 61.15 | 100% | -440.4 | -440.4 | buy open@63.8500 |
| 2 | 2024-04-10 | 61.40 | 62.85 | 60.40 | 62.15 | 100% | +156.6 | -283.7 |  |
| 3 | 2024-04-12 | 61.70 | 62.60 | 60.25 | 60.65 | 100% | -234.9 | -518.7 |  |
| 4 | 2024-04-15 | 58.55 | 60.20 | 57.05 | 59.05 | 100% | -250.6 | -769.3 |  |
| 5 | 2024-04-16 | 57.50 | 61.00 | 57.50 | 59.75 | 0% | +92.1 | -677.1 | sell time@59.7500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Fri 05 Apr 2024: NIFTY 0.0%, Midcap +0.5%, Smallcap +0.6%; NIFTY minus Smallcap -0.6 pts (20-day -1.1 pts); breadth 0.59 (1,161 up / 795 down of 1,992; 10-day 0.64); VIX 11.3 (day +1.1%, 5-day -11.6%, 30th percentile); environment: Broad bullish.
- Pick day: Mon 08 Apr 2024: NIFTY +0.7%, Midcap +0.2%, Smallcap +0.3%; NIFTY minus Smallcap +0.4 pts (20-day -3.2 pts); breadth 0.45 (884 up / 1,088 down of 1,997; 10-day 0.60); VIX 11.6 (day +2.4%, 5-day -3.9%, 39th percentile); environment: Broad bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.94, correlation 0.61).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Fri 05 Apr 2024 | +2.5% | 0.0% | +0.5% | +0.6% | 0.59 | 11.3 | Broad bullish | +1.9 pts | 0% |  |
| 0 | Mon 08 Apr 2024 | -1.6% | +0.7% | +0.2% | +0.3% | 0.45 | 11.6 | Broad bullish | -1.9 pts | 0% | +0 |
| 1 | Tue 09 Apr 2024 | -3.8% | -0.1% | -0.2% | 0.0% | 0.37 | 11.4 | Broad bullish | -3.8 pts | 100% | -440 |
| 2 | Wed 10 Apr 2024 | +1.6% | +0.5% | +0.9% | +0.6% | 0.54 | 11.1 | Broad bullish | +1.0 pts | 100% | +157 |
| 3 | Fri 12 Apr 2024 | -2.4% | -1.0% | -0.5% | -0.4% | 0.30 | 11.5 | Broad bullish | -2.0 pts | 100% | -235 |
| 4 | Mon 15 Apr 2024 | -2.6% | -1.1% | -1.4% | -1.5% | 0.14 | 12.5 | Broad bullish | -1.1 pts | 100% | -251 |
| 5 | Tue 16 Apr 2024 | +1.2% | -0.6% | -0.1% | +0.6% | 0.60 | 12.6 | Mixed / ranging | +0.5 pts | 0% | +92 |

- From the first buy to the last sale: NIFTY -2.7%, Midcap -1.8%, Smallcap -1.3%; the trade made -6.42% gross on the money it used.
- Split (on the money used): market part -2.43% = beta 1.94 x Smallcap 250 -1.25%; stock part -3.99% -> market and stock together.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S03 Bullish consolidation (MEDIUM, 6 sessions, mature)**
- Bullish consolidation began 01 Apr 2024, confirmed 02 Apr 2024 (before it: S07); required 5 of 5 hold, supporting 5 of 7 (support 71%), conflicts: none
- What would end it: 2 sessions in a row closing below 54.09 (the last swing low 55.00 less 0.25 ATR) or below 57.61 (EMA50 59.44 less 0.5 ATR) ends it downward; the 15-session range (55.00 - 66.90) widening past 3.5 ATR ends it either way - upward with an S04 breakout
- Transitions before the pick: UNKNOWN -> S02 (19 Feb) -> UNKNOWN (21 Feb) -> S03 (02 Mar) -> S09 (13 Mar) -> S07 (27 Mar) -> S03 (02 Apr)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Mon 08 Apr 2024 | 63.55 | S03 | S03 | MEDIUM | mature |  |  |
| 1 | Tue 09 Apr 2024 | 61.15 | S03 | S03 | MEDIUM | mature |  |  |
| 2 | Wed 10 Apr 2024 | 62.15 | S03 | S03 | MEDIUM | mature |  |  |
| 3 | Fri 12 Apr 2024 | 60.65 | S03 | S03 | MEDIUM | mature |  |  |
| 4 | Mon 15 Apr 2024 | 59.05 | S03 | S03 | LOW | deteriorating |  |  |
| 5 | Tue 16 Apr 2024 | 59.75 | S03 | S03 | MEDIUM | mature |  |  |
