## ENS-20251205-2 SHAKTIPUMP - plan

ENS rank 2, signal day 2025-12-05, mode daily. Status: **ok**.

Result: **net +746.9 bp** of the target size (gross +781.9, costs 35.0); bought 100% of the target, average entry 603.00, last sale 650.15 (time, session 5); MFE +9.70% (session 5), MAE -9.05% (session 3).

### What happened, in order

- 2025-12-08 09:15  **BUY open** 100% of the target @ 603.00 (open: at the session 1 open)
- 2025-12-12 15:30  **SELL time** 100% of the position @ 650.15 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-12-05 | 618.85 | 624.00 | 600.00 | 602.70 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-12-08 | 603.00 | 607.00 | 569.60 | 574.20 | 100% | -495.1 | -495.1 | buy open@603.0000 |
| 2 | 2025-12-09 | 575.00 | 582.20 | 556.15 | 572.15 | 100% | -34.0 | -529.1 |  |
| 3 | 2025-12-10 | 570.00 | 580.50 | 548.45 | 551.05 | 100% | -349.9 | -879.0 |  |
| 4 | 2025-12-11 | 551.35 | 646.30 | 550.00 | 628.20 | 100% | +1279.4 | +400.4 |  |
| 5 | 2025-12-12 | 619.00 | 661.50 | 591.00 | 650.15 | 0% | +346.5 | +746.9 | sell time@650.1500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Thu 04 Dec 2025: NIFTY +0.2%, Midcap 0.0%, Smallcap -0.2%; NIFTY minus Smallcap +0.4 pts (20-day +4.9 pts); breadth 0.42 (967 up / 1,325 down of 2,338; 10-day 0.40); VIX 10.8 (day -3.5%, 5-day -8.2%, 10th percentile); environment: Narrow bullish.
- Pick day: Fri 05 Dec 2025: NIFTY +0.6%, Midcap +0.4%, Smallcap -0.5%; NIFTY minus Smallcap +1.1 pts (20-day +5.8 pts); breadth 0.40 (927 up / 1,393 down of 2,339; 10-day 0.42); VIX 10.3 (day -4.6%, 5-day -11.2%, 5th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 0.92, correlation 0.33).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Thu 04 Dec 2025 | -2.4% | +0.2% | 0.0% | -0.2% | 0.42 | 10.8 | Narrow bullish | -2.2 pts | 0% |  |
| 0 | Fri 05 Dec 2025 | -2.6% | +0.6% | +0.4% | -0.5% | 0.40 | 10.3 | Narrow bullish | -2.1 pts | 0% | +0 |
| 1 | Mon 08 Dec 2025 | -4.7% | -0.9% | -1.7% | -2.3% | 0.12 | 11.1 | HIGH STRESS | -2.5 pts | 100% | -495 |
| 2 | Tue 09 Dec 2025 | -0.4% | -0.5% | +0.4% | +1.0% | 0.67 | 10.9 | Narrow bullish | -1.4 pts | 100% | -34 |
| 3 | Wed 10 Dec 2025 | -3.7% | -0.3% | -0.9% | -0.7% | 0.38 | 10.9 | Narrow bullish | -3.0 pts | 100% | -350 |
| 4 | Thu 11 Dec 2025 | +14.0% | +0.5% | +0.9% | +0.6% | 0.64 | 10.4 | Narrow bullish | +13.4 pts | 100% | +1279 |
| 5 | Fri 12 Dec 2025 | +3.5% | +0.6% | +1.2% | +0.8% | 0.68 | 10.1 | Narrow bullish | +2.7 pts | 0% | +347 |

- From the first buy to the last sale: NIFTY -0.4%, Midcap -0.3%, Smallcap -0.6%; the trade made +7.82% gross on the money it used.
- Split (on the money used): market part -0.57% = beta 0.92 x Smallcap 250 -0.63%; stock part +8.39% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S08 Bearish continuation (HIGH, 17 sessions, mature) | S10 breakdown CONFIRMED (4d) | risk: stretched far below EMA20**
- Bearish continuation began 13 Nov 2025, confirmed 14 Nov 2025 (before it: UNKNOWN); required 5 of 5 hold, supporting 10 of 10 (support 100%), conflicts: none
- What would end it: 2 sessions in a row closing above 828.49 (the last lower high 823.30 plus 0.25 ATR) or at / above EMA50 746.55; also the lower-high / lower-low structure or the falling EMA50 failing
- Event: S10 breakdown: closed below the 55-session low 670.05 4 sessions ago, volume 2.0x normal - CONFIRMED on 04 Dec
- Risk flags: stretched far below EMA20
- Transitions before the pick: S06 -> S07 (25 Sep) -> S06 (03 Oct) -> UNKNOWN (09 Oct) -> S08 (16 Oct) -> UNKNOWN (24 Oct) -> S08 (14 Nov)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Fri 05 Dec 2025 | 602.70 | S08 | S08 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 1 | Mon 08 Dec 2025 | 574.20 | S08 | S08 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 2 | Tue 09 Dec 2025 | 572.15 | S08 | S08 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 3 | Wed 10 Dec 2025 | 551.05 | S08 | S08 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 4 | Thu 11 Dec 2025 | 628.20 | S08 | UNKNOWN | LOW | deteriorating | failed breakdown (bear trap) |  |
| 5 | Fri 12 Dec 2025 | 650.15 | UNKNOWN | UNKNOWN | UNKNOWN |  | failed breakdown (bear trap) |  |
