## ENS-20241112-2 WEBELSOLAR - plan

ENS rank 2, signal day 2024-11-12, mode daily. Status: **ok**.

Result: **net +655.5 bp** of the target size (gross +690.5, costs 35.0); bought 100% of the target, average entry 128.90, last sale 137.80 (time, session 5); MFE +9.46% (session 5), MAE -9.15% (session 3).

### What happened, in order

- 2024-11-13 09:15  **BUY open** 100% of the target @ 128.90 (open: at the session 1 open)
- 2024-11-21 15:30  **SELL time** 100% of the position @ 137.80 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2024-11-12 | 136.50 | 140.70 | 135.70 | 135.70 | 0% | +0.0 | +0.0 |  |
| 1 | 2024-11-13 | 128.90 | 133.00 | 128.90 | 128.90 | 100% | -17.5 | -17.5 | buy open@128.9000 |
| 2 | 2024-11-14 | 122.50 | 122.50 | 122.50 | 122.50 | 100% | -496.5 | -514.0 |  |
| 3 | 2024-11-18 | 118.10 | 128.60 | 117.10 | 128.60 | 100% | +473.2 | -40.8 |  |
| 4 | 2024-11-19 | 131.20 | 135.00 | 130.50 | 134.30 | 100% | +442.2 | +401.4 |  |
| 5 | 2024-11-21 | 134.50 | 141.10 | 129.60 | 137.80 | 0% | +254.0 | +655.5 | sell time@137.8000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 11 Nov 2024: NIFTY 0.0%, Midcap -0.8%, Smallcap -1.2%; NIFTY minus Smallcap +1.2 pts (20-day +0.7 pts); breadth 0.27 (571 up / 1,507 down of 2,101; 10-day 0.54); VIX 14.3 (day -1.4%, 5-day -14.5%, 59th percentile); environment: Mixed / ranging.
- Pick day: Tue 12 Nov 2024: NIFTY -1.1%, Midcap -0.9%, Smallcap -1.3%; NIFTY minus Smallcap +0.2 pts (20-day +2.2 pts); breadth 0.21 (441 up / 1,644 down of 2,097; 10-day 0.50); VIX 14.6 (day +2.2%, 5-day -9.5%, 68th percentile); environment: Mixed / ranging.
- The pick: size class no list; moves most with Smallcap 250 (beta 0.86, correlation 0.34).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 11 Nov 2024 | -5.1% | 0.0% | -0.8% | -1.2% | 0.27 | 14.3 | Mixed / ranging | -3.9 pts | 0% |  |
| 0 | Tue 12 Nov 2024 | -5.0% | -1.1% | -0.9% | -1.3% | 0.21 | 14.6 | Mixed / ranging | -3.7 pts | 0% | +0 |
| 1 | Wed 13 Nov 2024 | -5.0% | -1.4% | -2.7% | -3.1% | 0.09 | 15.4 | HIGH STRESS | -2.0 pts | 100% | -18 |
| 2 | Thu 14 Nov 2024 | -5.0% | -0.1% | +0.5% | +0.8% | 0.55 | 14.8 | Broad bearish | -5.8 pts | 100% | -497 |
| 3 | Mon 18 Nov 2024 | +5.0% | -0.3% | -0.2% | -0.6% | 0.36 | 15.2 | Broad bearish | +5.6 pts | 100% | +473 |
| 4 | Tue 19 Nov 2024 | +4.4% | +0.3% | +0.9% | +0.9% | 0.67 | 15.7 | Broad bearish | +3.5 pts | 100% | +442 |
| 5 | Thu 21 Nov 2024 | +2.6% | -0.7% | -0.4% | -0.6% | 0.24 | 16.0 | Broad bearish | +3.2 pts | 0% | +254 |

- From the first buy to the last sale: NIFTY -2.0%, Midcap -1.5%, Smallcap -2.2%; the trade made +6.90% gross on the money it used.
- Split (on the money used): market part -1.88% = beta 0.86 x Smallcap 250 -2.18%; stock part +8.79% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (MEDIUM, 12 sessions, mature) | S04 breakout CONFIRMED (9d)**
- Strong bullish continuation began 28 Oct 2024, confirmed 29 Oct 2024 (before it: UNKNOWN); required 5 of 5 hold, supporting 6 of 10 (support 60%), conflicts: none
- What would end it: 2 sessions in a row closing below 111.00 (the last higher low 113.00 less 0.25 ATR) or at / below EMA50 119.36; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S04 breakout: closed above the 55-session high 131.40 9 sessions ago, volume 0.2x normal - CONFIRMED on 04 Nov
- Transitions before the pick: S02 -> S01 (18 Sep) -> UNKNOWN (24 Sep) -> S03 (03 Oct) -> S01 (09 Oct) -> UNKNOWN (14 Oct) -> S01 (29 Oct)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 12 Nov 2024 | 135.70 | S01 | S01 | MEDIUM | mature | S04 breakout confirmed |  |
| 1 | Wed 13 Nov 2024 | 128.90 | S01 | S01 | MEDIUM | mature | S04 breakout confirmed |  |
| 2 | Thu 14 Nov 2024 | 122.50 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed |  |
| 3 | Mon 18 Nov 2024 | 128.60 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed |  |
| 4 | Tue 19 Nov 2024 | 134.30 | S01 | S01 | MEDIUM | mature | S04 breakout confirmed |  |
| 5 | Thu 21 Nov 2024 | 137.80 | S01 | S01 | MEDIUM | mature |  |  |
