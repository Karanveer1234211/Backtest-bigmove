## D-20240425-2 V2RETAIL - plan

D rank 2, signal day 2024-04-25, mode daily. Status: **ok**.

Result: **net -643.4 bp** of the target size (gross -608.4, costs 35.0); bought 100% of the target, average entry 52.60, last sale 49.40 (time, session 5); MFE +1.33% (session 1), MAE -7.03% (session 5).

### What happened, in order

- 2024-04-26 09:15  **BUY open** 100% of the target @ 52.60 (open: at the session 1 open)
- 2024-05-03 15:30  **SELL time** 100% of the position @ 49.40 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2024-04-25 | 53.80 | 54.00 | 52.50 | 52.50 | 0% | +0.0 | +0.0 |  |
| 1 | 2024-04-26 | 52.60 | 53.30 | 51.00 | 51.70 | 100% | -188.6 | -188.6 | buy open@52.6000 |
| 2 | 2024-04-29 | 51.50 | 53.00 | 49.20 | 49.80 | 100% | -361.2 | -549.8 |  |
| 3 | 2024-04-30 | 50.00 | 51.00 | 49.20 | 49.50 | 100% | -57.0 | -606.9 |  |
| 4 | 2024-05-02 | 49.60 | 50.60 | 49.20 | 50.20 | 100% | +133.1 | -473.8 |  |
| 5 | 2024-05-03 | 50.20 | 50.20 | 48.90 | 49.40 | 0% | -169.6 | -643.4 | sell time@49.4000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Wed 24 Apr 2024: NIFTY +0.2%, Midcap +0.8%, Smallcap +0.8%; NIFTY minus Smallcap -0.6 pts (20-day -9.3 pts); breadth 0.63 (1,223 up / 732 down of 1,999; 10-day 0.48); VIX 10.3 (day +0.8%, 5-day -18.5%, 2nd percentile); environment: Narrow bullish.
- Pick day: Thu 25 Apr 2024: NIFTY +0.7%, Midcap +0.4%, Smallcap +0.8%; NIFTY minus Smallcap -0.1 pts (20-day -9.0 pts); breadth 0.55 (1,091 up / 878 down of 2,000; 10-day 0.50); VIX 10.7 (day +4.4%, 5-day -17.7%, 7th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 0.65, correlation 0.27).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Wed 24 Apr 2024 | +1.7% | +0.2% | +0.8% | +0.8% | 0.63 | 10.3 | Narrow bullish | +0.9 pts | 0% |  |
| 0 | Thu 25 Apr 2024 | -2.4% | +0.7% | +0.4% | +0.8% | 0.55 | 10.7 | Narrow bullish | -3.2 pts | 0% | +0 |
| 1 | Fri 26 Apr 2024 | -1.5% | -0.7% | +0.7% | +0.5% | 0.49 | 10.9 | Narrow bullish | -2.0 pts | 100% | -189 |
| 2 | Mon 29 Apr 2024 | -3.7% | +1.0% | +0.3% | +0.1% | 0.51 | 12.2 | Broad bullish | -3.7 pts | 100% | -361 |
| 3 | Tue 30 Apr 2024 | -0.6% | -0.2% | +0.2% | +0.1% | 0.44 | 12.9 | HIGH STRESS | -0.7 pts | 100% | -57 |
| 4 | Thu 02 May 2024 | +1.4% | +0.2% | +0.4% | +0.1% | 0.49 | 13.4 | HIGH STRESS | +1.3 pts | 100% | +133 |
| 5 | Fri 03 May 2024 | -1.6% | -0.8% | -0.4% | -0.3% | 0.31 | 14.6 | HIGH STRESS | -1.2 pts | 0% | -170 |

- From the first buy to the last sale: NIFTY -0.6%, Midcap +1.1%, Smallcap -0.1%; the trade made -6.08% gross on the money it used.
- Split (on the money used): market part -0.06% = beta 0.65 x Smallcap 250 -0.10%; stock part -6.02% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (HIGH, 14 sessions, mature) | S04 breakout NEW (2d)**
- Strong bullish continuation began 04 Apr 2024, confirmed 05 Apr 2024 (before it: UNKNOWN); required 5 of 5 hold, supporting 10 of 10 (support 100%), conflicts: none
- What would end it: 2 sessions in a row closing below 44.46 (the last higher low 45.10 less 0.25 ATR) or at / below EMA50 43.11; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S04 breakout: closed above the 55-session high 52.00 2 sessions ago, volume 0.7x normal - NEW (not yet confirmed)
- Transitions before the pick: S03 -> UNKNOWN (05 Feb) -> S03 (19 Feb) -> UNKNOWN (11 Mar) -> S03 (15 Mar) -> UNKNOWN (20 Mar) -> S01 (05 Apr)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 25 Apr 2024 | 52.50 | S01 | S01 | HIGH | mature | S04 breakout new |  |
| 1 | Fri 26 Apr 2024 | 51.70 | S01 | S03 | LOW | deteriorating | S04 breakout new |  |
| 2 | Mon 29 Apr 2024 | 49.80 | S03 | S03 | MEDIUM | early | S11 failed breakout (bull trap) |  |
| 3 | Tue 30 Apr 2024 | 49.50 | S03 | S03 | HIGH | early | S11 failed breakout (bull trap) |  |
| 4 | Thu 02 May 2024 | 50.20 | S03 | S01 | LOW | deteriorating | S11 failed breakout (bull trap) |  |
| 5 | Fri 03 May 2024 | 49.40 | S01 | S01 | MEDIUM | early | S11 failed breakout (bull trap) |  |
