## D-20240328-3 GFLLIMITED - plan

D rank 3, signal day 2024-03-28, mode daily. Status: **ok**.

Result: **net +1271.2 bp** of the target size (gross +1306.2, costs 35.0); bought 100% of the target, average entry 68.90, last sale 77.90 (time, session 5); MFE +15.97% (session 3), MAE +0.00% (session 1).

### What happened, in order

- 2024-04-01 09:15  **BUY open** 100% of the target @ 68.90 (open: at the session 1 open)
- 2024-04-05 15:30  **SELL time** 100% of the position @ 77.90 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2024-03-28 | 69.80 | 72.00 | 67.15 | 67.80 | 0% | +0.0 | +0.0 |  |
| 1 | 2024-04-01 | 68.90 | 74.10 | 68.90 | 73.80 | 100% | +693.7 | +693.7 | buy open@68.9000 |
| 2 | 2024-04-02 | 74.90 | 79.55 | 73.80 | 77.60 | 100% | +551.5 | +1245.2 |  |
| 3 | 2024-04-03 | 77.00 | 79.90 | 76.20 | 78.30 | 100% | +101.6 | +1346.8 |  |
| 4 | 2024-04-04 | 79.10 | 79.90 | 77.30 | 78.30 | 100% | +0.0 | +1346.8 |  |
| 5 | 2024-04-05 | 78.30 | 78.50 | 76.50 | 77.90 | 0% | -75.6 | +1271.2 | sell time@77.9000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Wed 27 Mar 2024: NIFTY +0.5%, Midcap +0.1%, Smallcap +0.8%; NIFTY minus Smallcap -0.3 pts (20-day +5.6 pts); breadth 0.45 (881 up / 1,083 down of 1,986; 10-day 0.48); VIX 12.7 (day -0.9%, 5-day -10.0%, 65th percentile); environment: Narrow bullish.
- Pick day: Thu 28 Mar 2024: NIFTY +0.9%, Midcap +0.5%, Smallcap +0.3%; NIFTY minus Smallcap +0.6 pts (20-day +5.5 pts); breadth 0.54 (1,053 up / 904 down of 1,987; 10-day 0.53); VIX 12.8 (day +1.0%, 5-day -4.8%, 68th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.27, correlation 0.45).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Wed 27 Mar 2024 | -1.6% | +0.5% | +0.1% | +0.8% | 0.45 | 12.7 | Narrow bullish | -2.5 pts | 0% |  |
| 0 | Thu 28 Mar 2024 | -1.6% | +0.9% | +0.5% | +0.3% | 0.54 | 12.8 | Narrow bullish | -1.9 pts | 0% | +0 |
| 1 | Mon 01 Apr 2024 | +8.8% | +0.6% | +1.8% | +3.0% | 0.89 | 12.1 | Broad bullish | +5.8 pts | 100% | +694 |
| 2 | Tue 02 Apr 2024 | +5.1% | 0.0% | +1.1% | +1.0% | 0.76 | 11.7 | Broad bullish | +4.2 pts | 100% | +552 |
| 3 | Wed 03 Apr 2024 | +0.9% | -0.1% | +0.5% | +1.1% | 0.73 | 11.4 | Broad bullish | -0.2 pts | 100% | +102 |
| 4 | Thu 04 Apr 2024 | 0.0% | +0.4% | 0.0% | +0.6% | 0.61 | 11.2 | Broad bullish | -0.6 pts | 100% | +0 |
| 5 | Fri 05 Apr 2024 | -0.5% | 0.0% | +0.5% | +0.6% | 0.59 | 11.3 | Broad bullish | -1.1 pts | 0% | -76 |

- From the first buy to the last sale: NIFTY +0.3%, Midcap +3.2%, Smallcap +5.5%; the trade made +13.06% gross on the money it used.
- Split (on the money used): market part +6.96% = beta 1.27 x Smallcap 250 +5.46%; stock part +6.10% -> market and stock together.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S08 Bearish continuation (MEDIUM, 3 sessions, early) | S10 breakdown NEW today | volatility elevated**
- Bearish continuation began 26 Mar 2024, confirmed 27 Mar 2024 (before it: S09); required 5 of 5 hold, supporting 9 of 10 (support 90%), conflicts: momentum accelerating (10-session move 1.5+ ATR larger than the 10 before)
- What would end it: 2 sessions in a row closing above 85.70 (the last lower high 84.70 plus 0.25 ATR) or at / above EMA50 82.11; also the lower-high / lower-low structure or the falling EMA50 failing
- Event: S10 breakdown: closed below the 55-session low 68.00 today, volume 2.1x normal - NEW (not yet confirmed)
- Transitions before the pick: UNKNOWN -> S09 (05 Feb) -> UNKNOWN (09 Feb) -> S09 (13 Feb) -> UNKNOWN (16 Feb) -> S09 (29 Feb) -> S08 (27 Mar)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 28 Mar 2024 | 67.80 | S08 | S08 | MEDIUM | early | S10 breakdown new |  |
| 1 | Mon 01 Apr 2024 | 73.80 | S08 | S08 | MEDIUM | early | failed breakdown (bear trap) |  |
| 2 | Tue 02 Apr 2024 | 77.60 | S08 | S08 | MEDIUM | early | failed breakdown (bear trap) |  |
| 3 | Wed 03 Apr 2024 | 78.30 | S08 | UNKNOWN | LOW | deteriorating | failed breakdown (bear trap) |  |
| 4 | Thu 04 Apr 2024 | 78.30 | UNKNOWN | UNKNOWN | UNKNOWN |  | failed breakdown (bear trap) |  |
| 5 | Fri 05 Apr 2024 | 77.90 | UNKNOWN | S06 | UNKNOWN |  | failed breakdown (bear trap) |  |
