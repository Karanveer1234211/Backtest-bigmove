## D-20260814-1 KPEL - plan

D rank 1, signal day 2026-08-14, mode daily. Status: **ok**.

Result: **net +218.1 bp** of the target size (gross +253.1, costs 35.0); bought 100% of the target, average entry 252.90, last sale 259.30 (time, session 5); MFE +7.95% (session 3), MAE -5.10% (session 2).

### What happened, in order

- 2026-08-17 09:15  **BUY open** 100% of the target @ 252.90 (open: at the session 1 open)
- 2026-08-21 15:30  **SELL time** 100% of the position @ 259.30 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2026-08-14 | 256.00 | 257.00 | 251.00 | 252.10 | 0% | +0.0 | +0.0 |  |
| 1 | 2026-08-17 | 252.90 | 254.70 | 240.10 | 243.75 | 100% | -379.3 | -379.3 | buy open@252.9000 |
| 2 | 2026-08-18 | 243.70 | 264.95 | 240.00 | 262.30 | 100% | +733.5 | +354.2 |  |
| 3 | 2026-08-19 | 267.95 | 273.00 | 256.85 | 268.20 | 100% | +233.3 | +587.5 |  |
| 4 | 2026-08-20 | 268.20 | 271.00 | 255.15 | 256.65 | 100% | -456.7 | +130.8 |  |
| 5 | 2026-08-21 | 257.90 | 265.50 | 257.00 | 259.30 | 0% | +87.3 | +218.1 | sell time@259.3000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Thu 13 Aug 2026: NIFTY -0.2%, Midcap +0.1%, Smallcap +0.2%; NIFTY minus Smallcap -0.3 pts (20-day -0.1 pts); breadth 0.49 (1,196 up / 1,259 down of 2,487; 10-day 0.52); VIX 11.4 (day -2.3%, 5-day -6.1%, 27th percentile); environment: Broad bullish.
- Pick day: Fri 14 Aug 2026: NIFTY -0.1%, Midcap -0.5%, Smallcap -0.5%; NIFTY minus Smallcap +0.4 pts (20-day -1.4 pts); breadth 0.40 (974 up / 1,486 down of 2,487; 10-day 0.49); VIX 11.3 (day -1.0%, 5-day -7.0%, 24th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.64, correlation 0.70).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Thu 13 Aug 2026 | -1.3% | -0.2% | +0.1% | +0.2% | 0.49 | 11.4 | Broad bullish | -1.5 pts | 0% |  |
| 0 | Fri 14 Aug 2026 | -1.6% | -0.1% | -0.5% | -0.5% | 0.40 | 11.3 | Narrow bullish | -1.1 pts | 0% | +0 |
| 1 | Mon 17 Aug 2026 | -3.3% | -0.3% | +0.1% | +0.2% | 0.46 | 11.3 | Narrow bullish | -3.5 pts | 100% | -379 |
| 2 | Tue 18 Aug 2026 | +7.6% | -0.5% | -0.4% | +0.2% | 0.41 | 11.4 | Narrow bullish | +7.4 pts | 100% | +733 |
| 3 | Wed 19 Aug 2026 | +2.2% | -0.3% | -0.3% | -0.6% | 0.32 | 11.3 | Mixed / ranging | +2.9 pts | 100% | +233 |
| 4 | Thu 20 Aug 2026 | -4.3% | +0.6% | +0.4% | +0.6% | 0.61 | 10.8 | Narrow bullish | -4.9 pts | 100% | -457 |
| 5 | Fri 21 Aug 2026 | +1.0% | +0.1% | +0.1% | +0.4% | 0.50 | 11.2 | Narrow bullish | +0.6 pts | 0% | +87 |

- From the first buy to the last sale: NIFTY -0.4%, Midcap 0.0%, Smallcap +0.7%; the trade made +2.53% gross on the money it used.
- Split (on the money used): market part +1.14% = beta 1.64 x Smallcap 250 +0.69%; stock part +1.39% -> market and stock together.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (HIGH, 5 sessions, early) | S10 breakdown NEW today | risk: stretched far below EMA20**
- Emerging bearish trend began 10 Aug 2026, confirmed 11 Aug 2026 (before it: UNKNOWN); required 3 of 3 hold, supporting 8 of 10 (support 80%), conflicts: none
- What would end it: 2 sessions in a row closing above 328.39 (the last swing high 325.40 plus 0.25 ATR), or at / above EMA50 314.41 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 55-session low 255.05 today, volume 1.8x normal - NEW (not yet confirmed)
- Risk flags: stretched far below EMA20
- Transitions before the pick: S03 -> S07 (17 Jun) -> S03 (22 Jun) -> S09 (30 Jun) -> S08 (21 Jul) -> UNKNOWN (05 Aug) -> S09 (11 Aug)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Fri 14 Aug 2026 | 252.10 | S09 | S09 | HIGH | early | S10 breakdown new | stretched far below EMA20 |
| 1 | Mon 17 Aug 2026 | 243.75 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 2 | Tue 18 Aug 2026 | 262.30 | S09 | S09 | HIGH | mature | failed breakdown (bear trap) |  |
| 3 | Wed 19 Aug 2026 | 268.20 | S09 | S09 | MEDIUM | mature | failed breakdown (bear trap) |  |
| 4 | Thu 20 Aug 2026 | 256.65 | S09 | S09 | HIGH | mature | failed breakdown (bear trap) |  |
| 5 | Fri 21 Aug 2026 | 259.30 | S09 | UNKNOWN | LOW | deteriorating | failed breakdown (bear trap) |  |
