## D-20231116-1 BAJAJ-AUTO - plan

D rank 1, signal day 2023-11-16, mode daily. Status: **ok**.

Result: **net +628.3 bp** of the target size (gross +663.3, costs 35.0); bought 100% of the target, average entry 5419.50, last sale 5779.00 (time, session 5); MFE +6.98% (session 5), MAE -1.39% (session 1).

### What happened, in order

- 2023-11-17 09:15  **BUY open** 100% of the target @ 5419.50 (open: at the session 1 open)
- 2023-11-23 15:30  **SELL time** 100% of the position @ 5779.00 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2023-11-16 | 5383.50 | 5445.50 | 5361.00 | 5413.50 | 0% | +0.0 | +0.0 |  |
| 1 | 2023-11-17 | 5419.50 | 5534.50 | 5344.00 | 5492.50 | 100% | +117.2 | +117.2 | buy open@5419.5000 |
| 2 | 2023-11-20 | 5471.50 | 5535.50 | 5467.50 | 5510.50 | 100% | +33.2 | +150.4 |  |
| 3 | 2023-11-21 | 5501.00 | 5566.50 | 5500.50 | 5545.50 | 100% | +64.6 | +215.0 |  |
| 4 | 2023-11-22 | 5539.50 | 5622.50 | 5521.50 | 5609.50 | 100% | +118.1 | +333.1 |  |
| 5 | 2023-11-23 | 5656.50 | 5798.00 | 5640.00 | 5779.00 | 0% | +295.3 | +628.3 | sell time@5779.0000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Wed 15 Nov 2023: NIFTY +1.2% (2.1 sd rise), Midcap +0.9%, Smallcap +1.1%; NIFTY minus Smallcap +0.1 pts (20-day -3.5 pts); breadth 0.64 (1,206 up / 675 down of 1,920; 10-day 0.59); VIX 11.1 (day -0.4%, 5-day +0.9%, 22nd percentile); environment: Broad bullish.
- Pick day: Thu 16 Nov 2023: NIFTY +0.5%, Midcap +0.7%, Smallcap +0.4%; NIFTY minus Smallcap 0.0 pts (20-day -3.1 pts); breadth 0.52 (974 up / 899 down of 1,922; 10-day 0.57); VIX 11.7 (day +4.6%, 5-day +6.1%, 38th percentile); environment: Broad bullish.
- The pick: size class no list; moves most with NIFTY 50 (beta 0.69, correlation 0.29).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Wed 15 Nov 2023 | +2.1% | +1.2% | +0.9% | +1.1% | 0.64 | 11.1 | Broad bullish | +0.9 pts | 0% |  |
| 0 | Thu 16 Nov 2023 | +0.2% | +0.5% | +0.7% | +0.4% | 0.52 | 11.7 | Broad bullish | -0.2 pts | 0% | +0 |
| 1 | Fri 17 Nov 2023 | +1.5% | -0.2% | +0.3% | +0.3% | 0.51 | 11.8 | Broad bullish | +1.6 pts | 100% | +117 |
| 2 | Mon 20 Nov 2023 | +0.3% | -0.2% | 0.0% | 0.0% | 0.47 | 12.2 | Broad bullish | +0.5 pts | 100% | +33 |
| 3 | Tue 21 Nov 2023 | +0.6% | +0.5% | 0.0% | +0.2% | 0.55 | 12.2 | Broad bullish | +0.2 pts | 100% | +65 |
| 4 | Wed 22 Nov 2023 | +1.2% | +0.1% | +0.2% | -0.8% | 0.41 | 11.9 | Broad bullish | +1.0 pts | 100% | +118 |
| 5 | Thu 23 Nov 2023 | +3.0% | 0.0% | +0.1% | +0.5% | 0.54 | 11.3 | Broad bullish | +3.1 pts | 0% | +295 |

- From the first buy to the last sale: NIFTY +0.6%, Midcap +0.8%, Smallcap +0.2%; the trade made +6.63% gross on the money it used.
- Split (on the money used): market part +0.45% = beta 0.69 x NIFTY 50 +0.65%; stock part +6.19% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S03 Bullish consolidation (LOW, 6 sessions, deteriorating) -> UNKNOWN pending | S04 breakout NEW (1d) | volatility compressed**
- Bullish consolidation began 09 Nov 2023, confirmed 10 Nov 2023 (before it: UNKNOWN); required 4 of 5 hold, supporting 6 of 7 (support 86%), conflicts: none
- What would end it: 2 sessions in a row closing below 5,194.52 (the last swing low 5,217.00 less 0.25 ATR) or below 5,012.43 (EMA50 5,057.40 less 0.5 ATR) ends it downward; the 15-session range (5,135.00 - 5,445.50) widening past 3.5 ATR ends it either way - upward with an S04 breakout
- Event: S04 breakout: closed above the 55-session high 5,374.00 1 session ago, volume 1.8x normal - NEW (not yet confirmed)
- Notes: volatility compressed
- Transitions before the pick: S03 -> S02 (12 Sep) -> UNKNOWN (05 Oct) -> S02 (18 Oct) -> S01 (01 Nov) -> UNKNOWN (07 Nov) -> S03 (10 Nov)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 16 Nov 2023 | 5,413.50 | S03 | UNKNOWN | LOW | deteriorating | S04 breakout new |  |
| 1 | Fri 17 Nov 2023 | 5,492.50 | UNKNOWN | UNKNOWN | UNKNOWN |  | S04 breakout new |  |
| 2 | Mon 20 Nov 2023 | 5,510.50 | UNKNOWN | UNKNOWN | UNKNOWN |  | S04 breakout new |  |
| 3 | Tue 21 Nov 2023 | 5,545.50 | UNKNOWN | UNKNOWN | UNKNOWN |  | S04 breakout new |  |
| 4 | Wed 22 Nov 2023 | 5,609.50 | UNKNOWN | UNKNOWN | UNKNOWN |  | S04 breakout new |  |
| 5 | Thu 23 Nov 2023 | 5,779.00 | UNKNOWN | UNKNOWN | UNKNOWN |  | S04 breakout new | S05 overextended |
