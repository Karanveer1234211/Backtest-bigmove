## D-20241010-3 PCJEWELLER - plan

D rank 3, signal day 2024-10-10, mode daily. Status: **ok**.

Result: **net +2250.3 bp** of the target size (gross +2285.3, costs 35.0); bought 100% of the target, average entry 15.14, last sale 18.60 (time, session 5); MFE +22.99% (session 5), MAE -0.59% (session 1).

### What happened, in order

- 2024-10-11 09:15  **BUY open** 100% of the target @ 15.14 (open: at the session 1 open)
- 2024-10-17 15:30  **SELL time** 100% of the position @ 18.60 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2024-10-10 | 16.00 | 16.08 | 15.15 | 15.52 | 0% | +0.0 | +0.0 |  |
| 1 | 2024-10-11 | 15.14 | 15.80 | 15.05 | 15.32 | 100% | +101.4 | +101.4 | buy open@15.1400 |
| 2 | 2024-10-14 | 15.32 | 16.09 | 15.32 | 16.09 | 100% | +508.6 | +610.0 |  |
| 3 | 2024-10-15 | 16.44 | 16.89 | 16.12 | 16.89 | 100% | +528.4 | +1138.4 |  |
| 4 | 2024-10-16 | 17.26 | 17.74 | 17.15 | 17.74 | 100% | +561.4 | +1699.8 |  |
| 5 | 2024-10-17 | 18.18 | 18.62 | 17.61 | 18.60 | 0% | +550.5 | +2250.3 | sell time@18.6000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Wed 09 Oct 2024: NIFTY -0.1%, Midcap +1.1%, Smallcap +1.2%; NIFTY minus Smallcap -1.4 pts (20-day +1.3 pts); breadth 0.68 (1,405 up / 653 down of 2,080; 10-day 0.43); VIX 14.1 (day -3.2%, 5-day +17.8%, 62nd percentile); environment: Mixed / ranging.
- Pick day: Thu 10 Oct 2024: NIFTY +0.1%, Midcap -0.1%, Smallcap +0.1%; NIFTY minus Smallcap -0.1 pts (20-day +0.9 pts); breadth 0.54 (1,107 up / 944 down of 2,080; 10-day 0.44); VIX 13.5 (day -4.4%, 5-day +2.5%, 46th percentile); environment: Mixed / ranging.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.08, correlation 0.42).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Wed 09 Oct 2024 | -1.3% | -0.1% | +1.1% | +1.2% | 0.68 | 14.1 | Mixed / ranging | -2.5 pts | 0% |  |
| 0 | Thu 10 Oct 2024 | -0.7% | +0.1% | -0.1% | +0.1% | 0.54 | 13.5 | Mixed / ranging | -0.8 pts | 0% | +0 |
| 1 | Fri 11 Oct 2024 | -1.3% | -0.1% | +0.4% | +0.5% | 0.51 | 13.2 | Mixed / ranging | -1.8 pts | 100% | +101 |
| 2 | Mon 14 Oct 2024 | +5.0% | +0.7% | +0.4% | +0.3% | 0.50 | 13.0 | Narrow bullish | +4.7 pts | 100% | +509 |
| 3 | Tue 15 Oct 2024 | +5.0% | -0.3% | +0.3% | +1.1% | 0.49 | 13.0 | Mixed / ranging | +3.9 pts | 100% | +528 |
| 4 | Wed 16 Oct 2024 | +5.0% | -0.3% | -0.2% | +0.2% | 0.49 | 13.1 | Mixed / ranging | +4.8 pts | 100% | +561 |
| 5 | Thu 17 Oct 2024 | +4.8% | -0.9% | -1.7% | -1.4% | 0.20 | 13.4 | Mixed / ranging | +6.3 pts | 0% | +551 |

- From the first buy to the last sale: NIFTY -0.9%, Midcap -0.9%, Smallcap +0.4%; the trade made +22.85% gross on the money it used.
- Split (on the money used): market part +0.46% = beta 1.08 x Smallcap 250 +0.43%; stock part +22.39% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (LOW, 40 sessions, deteriorating) | S04 breakout CONFIRMED (10d) | risk: bearish divergence candidate (RSI) | volatility elevated**
- Strong bullish continuation began 14 Aug 2024, confirmed 16 Aug 2024 (before it: S02); required 5 of 5 hold, supporting 8 of 10 (support 80%), conflicts: bearish divergence candidate: a higher swing high with RSI 5+ points lower (swing known in the last 20 sessions); momentum decelerating (10-session move 1.5+ ATR smaller than the 10 before)
- What would end it: 2 sessions in a row closing below 13.38 (the last higher low 13.60 less 0.25 ATR) or at / below EMA50 12.83; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S04 breakout: closed above the 55-session high 15.38 10 sessions ago, volume 1.0x normal - CONFIRMED on 30 Sep
- Risk flags: bearish divergence candidate (RSI)
- Transitions before the pick: S09 -> S07 (02 Jul) -> UNKNOWN (04 Jul) -> S06 (08 Jul) -> UNKNOWN (23 Jul) -> S02 (26 Jul) -> S01 (16 Aug)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 10 Oct 2024 | 15.52 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 1 | Fri 11 Oct 2024 | 15.32 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 2 | Mon 14 Oct 2024 | 16.09 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 3 | Tue 15 Oct 2024 | 16.89 | S01 | S01 | LOW | deteriorating | S04 breakout confirmed | bearish divergence candidate (RSI) |
| 4 | Wed 16 Oct 2024 | 17.74 | S01 | S01 | MEDIUM | mature |  | bearish divergence candidate (RSI) |
| 5 | Thu 17 Oct 2024 | 18.60 | S01 | S01 | MEDIUM | mature |  | S05 overextended; bearish divergence candidate (RSI) |
