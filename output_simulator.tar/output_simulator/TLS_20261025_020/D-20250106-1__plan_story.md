## D-20250106-1 JAICORPLTD - plan

D rank 1, signal day 2025-01-06, mode daily. Status: **ok**.

Result: **net -1646.6 bp** of the target size (gross -1611.6, costs 35.0); bought 100% of the target, average entry 199.80, last sale 167.60 (time, session 6); MFE +4.30% (session 1), MAE -17.74% (session 5).

### What happened, in order

- 2025-01-07 09:15  **BUY open** 100% of the target @ 199.80 (open: at the session 1 open)
- 2025-01-14 09:15  **SELL time** 100% of the position @ 167.60 (locked_open: time: close locked at the lower band; first unlocked open)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-01-06 | 220.00 | 222.10 | 203.00 | 203.00 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-01-07 | 199.80 | 208.40 | 185.70 | 202.55 | 100% | +120.1 | +120.1 | buy open@199.8000 |
| 2 | 2025-01-08 | 201.10 | 207.70 | 198.75 | 203.45 | 100% | +45.0 | +165.2 |  |
| 3 | 2025-01-09 | 202.90 | 203.35 | 190.00 | 192.20 | 100% | -563.1 | -397.9 |  |
| 4 | 2025-01-10 | 191.50 | 191.50 | 173.00 | 173.00 | 100% | -961.0 | -1358.8 |  |
| 5 | 2025-01-13 | 179.00 | 180.50 | 164.35 | 164.35 | 100% | -432.9 | -1791.8 |  |
| 6 | 2025-01-14 | 167.60 | 167.60 | 157.60 | 160.00 | 0% | +145.2 | -1646.6 | sell time@167.6000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Fri 03 Jan 2025: NIFTY -0.8%, Midcap -0.3%, Smallcap -0.2%; NIFTY minus Smallcap -0.6 pts (20-day -1.4 pts); breadth 0.50 (1,051 up / 1,056 down of 2,128; 10-day 0.47); VIX 13.5 (day -1.5%, 5-day +2.3%, 33rd percentile); environment: Mixed / ranging.
- Pick day: Mon 06 Jan 2025: NIFTY -1.6% (2.0 sd fall), Midcap -2.5% (2.7 sd fall), Smallcap -2.9% (2.5 sd fall); NIFTY minus Smallcap +1.3 pts (20-day +0.5 pts); breadth 0.08 (170 up / 1,946 down of 2,131; 10-day 0.47); VIX 15.7 (day +15.6%, 5-day +12.0%, 80th percentile); environment: HIGH STRESS (direction: Broad bearish) - Smallcap -2.5 sd day.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.82, correlation 0.54).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Fri 03 Jan 2025 | -9.2% | -0.8% | -0.3% | -0.2% | 0.50 | 13.5 | Mixed / ranging | -9.0 pts | 0% |  |
| 0 | Mon 06 Jan 2025 | -10.0% | -1.6% | -2.5% | -2.9% | 0.08 | 15.7 | HIGH STRESS | -7.1 pts | 0% | +0 |
| 1 | Tue 07 Jan 2025 | -0.2% | +0.4% | +0.9% | +1.4% | 0.76 | 14.7 | Mixed / ranging | -1.6 pts | 100% | +120 |
| 2 | Wed 08 Jan 2025 | +0.4% | -0.1% | -1.0% | -1.4% | 0.28 | 14.5 | Broad bearish | +1.8 pts | 100% | +45 |
| 3 | Thu 09 Jan 2025 | -5.5% | -0.7% | -0.8% | -1.2% | 0.24 | 14.7 | Broad bearish | -4.4 pts | 100% | -563 |
| 4 | Fri 10 Jan 2025 | -10.0% | -0.4% | -2.0% | -2.4% | 0.13 | 14.9 | Broad bearish | -7.5 pts | 100% | -961 |
| 5 | Mon 13 Jan 2025 | -5.0% | -1.5% | -3.9% | -4.0% | 0.06 | 16.0 | HIGH STRESS | -1.0 pts | 100% | -433 |
| 6 | Tue 14 Jan 2025 | -2.6% | +0.4% | +2.2% | +1.6% | 0.79 | 15.5 | Broad bearish | -4.3 pts | 0% | +145 |

- From the first buy to the last sale: NIFTY -2.2%, Midcap -6.7%, Smallcap -7.3%; the trade made -16.12% gross on the money it used.
- Split (on the money used): market part -13.25% = beta 1.82 x Smallcap 250 -7.29%; stock part -2.87% -> mostly the market.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (HIGH, 11 sessions, mature) | S10 breakdown NEW (2d) | risk: stretched far below EMA20; large down candle in the last 5 sessions | volatility extreme**
- Emerging bearish trend began 20 Dec 2024, confirmed 23 Dec 2024 (before it: S06); required 3 of 3 hold, supporting 10 of 10 (support 100%), conflicts: none
- What would end it: 2 sessions in a row closing above 355.50 (the last swing high 349.90 plus 0.25 ATR), or at / above EMA50 328.37 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 55-session low 288.10 2 sessions ago, volume 27.5x normal - NEW (not yet confirmed)
- Risk flags: stretched far below EMA20; large down candle in the last 5 sessions
- Transitions before the pick: UNKNOWN -> S09 (14 Nov) -> UNKNOWN (26 Nov) -> S06 (02 Dec) -> S02 (13 Dec) -> S06 (17 Dec) -> S09 (23 Dec)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Mon 06 Jan 2025 | 203.00 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20; large down candle in the last 5 sessions |
| 1 | Tue 07 Jan 2025 | 202.55 | S09 | S09 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20; large down candle in the last 5 sessions |
| 2 | Wed 08 Jan 2025 | 203.45 | S09 | S09 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20; large down candle in the last 5 sessions |
| 3 | Thu 09 Jan 2025 | 192.20 | S09 | S09 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 4 | Fri 10 Jan 2025 | 173.00 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 5 | Mon 13 Jan 2025 | 164.35 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 6 | Tue 14 Jan 2025 | 160.00 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
