## D-20250227-2 ASHOKA - plan

D rank 2, signal day 2025-02-27, mode daily. Status: **ok**.

Result: **net +458.2 bp** of the target size (gross +493.2, costs 35.0); bought 100% of the target, average entry 176.00, last sale 184.68 (time, session 5); MFE +7.05% (session 5), MAE -9.47% (session 3).

### What happened, in order

- 2025-02-28 09:15  **BUY open** 100% of the target @ 176.00 (open: at the session 1 open)
- 2025-03-06 15:30  **SELL time** 100% of the position @ 184.68 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-02-27 | 190.00 | 190.90 | 180.50 | 181.35 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-02-28 | 176.00 | 179.55 | 170.10 | 172.15 | 100% | -236.2 | -236.2 | buy open@176.0000 |
| 2 | 2025-03-03 | 172.74 | 174.16 | 162.22 | 165.79 | 100% | -361.4 | -597.6 |  |
| 3 | 2025-03-04 | 162.00 | 175.55 | 159.34 | 170.48 | 100% | +266.5 | -331.1 |  |
| 4 | 2025-03-05 | 170.48 | 182.85 | 170.48 | 182.22 | 100% | +667.0 | +335.9 |  |
| 5 | 2025-03-06 | 183.51 | 188.40 | 180.70 | 184.68 | 0% | +122.3 | +458.2 | sell time@184.6800 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Tue 25 Feb 2025: NIFTY 0.0%, Midcap -0.5%, Smallcap -0.4%; NIFTY minus Smallcap +0.4 pts (20-day +4.8 pts); breadth 0.36 (772 up / 1,354 down of 2,150; 10-day 0.39); VIX 13.7 (day -5.0%, 5-day -12.4%, 35th percentile); environment: Broad bearish.
- Pick day: Thu 27 Feb 2025: NIFTY 0.0%, Midcap -1.3%, Smallcap -1.7%; NIFTY minus Smallcap +1.7 pts (20-day +5.9 pts); breadth 0.18 (380 up / 1,759 down of 2,157; 10-day 0.37); VIX 13.3 (day -3.0%, 5-day -13.7%, 25th percentile); environment: Broad bearish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.31, correlation 0.62).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Tue 25 Feb 2025 | -1.6% | 0.0% | -0.5% | -0.4% | 0.36 | 13.7 | Broad bearish | -1.2 pts | 0% |  |
| 0 | Thu 27 Feb 2025 | -5.0% | 0.0% | -1.3% | -1.7% | 0.18 | 13.3 | Broad bearish | -3.4 pts | 0% | +0 |
| 1 | Fri 28 Feb 2025 | -5.1% | -1.9% | -2.3% | -2.5% | 0.12 | 13.9 | HIGH STRESS | -2.6 pts | 100% | -236 |
| 2 | Mon 03 Mar 2025 | -3.7% | 0.0% | +0.2% | -0.6% | 0.31 | 13.8 | Broad bearish | -3.1 pts | 100% | -361 |
| 3 | Tue 04 Mar 2025 | +2.8% | -0.2% | +0.2% | +1.2% | 0.61 | 13.8 | Broad bearish | +1.7 pts | 100% | +266 |
| 4 | Wed 05 Mar 2025 | +6.9% | +1.2% | +2.4% | +2.7% | 0.89 | 13.7 | Broad bearish | +4.2 pts | 100% | +667 |
| 5 | Thu 06 Mar 2025 | +1.4% | +0.9% | +0.6% | +1.5% | 0.82 | 13.7 | Broad bearish | -0.1 pts | 0% | +122 |

- From the first buy to the last sale: NIFTY +0.5%, Midcap +1.8%, Smallcap +3.1%; the trade made +4.93% gross on the money it used.
- Split (on the money used): market part +4.09% = beta 1.31 x Smallcap 250 +3.12%; stock part +0.84% -> mostly the market.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (HIGH, 10 sessions, mature) | S10 breakdown NEW today | risk: stretched far below EMA20 | volatility extreme**
- Emerging bearish trend began 13 Feb 2025, confirmed 14 Feb 2025 (before it: UNKNOWN); required 3 of 3 hold, supporting 9 of 10 (support 90%), conflicts: none
- What would end it: 2 sessions in a row closing above 255.74 (the last swing high 252.75 plus 0.25 ATR), or at / above EMA50 240.86 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 55-session low 188.70 today, volume 1.0x normal - NEW (not yet confirmed)
- Risk flags: stretched far below EMA20
- Transitions before the pick: S02 -> S09 (13 Jan) -> S02 (15 Jan) -> S07 (17 Jan) -> S09 (23 Jan) -> UNKNOWN (07 Feb) -> S09 (14 Feb)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 27 Feb 2025 | 181.35 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 1 | Fri 28 Feb 2025 | 172.15 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 2 | Mon 03 Mar 2025 | 165.79 | S09 | S09 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 3 | Tue 04 Mar 2025 | 170.48 | S09 | S09 | HIGH | mature | S10 breakdown confirmed |  |
| 4 | Wed 05 Mar 2025 | 182.22 | S09 | S09 | MEDIUM | mature | S10 breakdown confirmed |  |
| 5 | Thu 06 Mar 2025 | 184.68 | S09 | S09 | MEDIUM | mature | S10 breakdown confirmed |  |
