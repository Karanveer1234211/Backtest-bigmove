## ENS-20230221-1 UCOBANK - plan

ENS rank 1, signal day 2023-02-21, mode daily. Status: **ok**.

Result: **net +870.3 bp** of the target size (gross +905.3, costs 35.0); bought 100% of the target, average entry 23.75, last sale 25.90 (time, session 5); MFE +11.58% (session 5), MAE -0.84% (session 1).

### What happened, in order

- 2023-02-22 09:15  **BUY open** 100% of the target @ 23.75 (open: at the session 1 open)
- 2023-02-28 15:30  **SELL time** 100% of the position @ 25.90 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2023-02-21 | 25.65 | 25.65 | 23.95 | 24.15 | 0% | +0.0 | +0.0 |  |
| 1 | 2023-02-22 | 23.75 | 25.60 | 23.55 | 24.45 | 100% | +277.2 | +277.2 | buy open@23.7500 |
| 2 | 2023-02-23 | 24.55 | 25.70 | 23.90 | 25.45 | 100% | +421.1 | +698.3 |  |
| 3 | 2023-02-24 | 25.70 | 25.95 | 24.90 | 25.00 | 100% | -189.5 | +508.8 |  |
| 4 | 2023-02-27 | 24.95 | 25.40 | 24.45 | 25.10 | 100% | +42.1 | +550.9 |  |
| 5 | 2023-02-28 | 25.25 | 26.50 | 25.10 | 25.90 | 0% | +319.3 | +870.3 | sell time@25.9000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 20 Feb 2023: NIFTY -0.6%, Midcap 0.0%, Smallcap -0.3%; NIFTY minus Smallcap -0.2 pts (20-day +1.3 pts); breadth 0.34 (612 up / 1,164 down of 1,822; 10-day 0.45); VIX 13.4 (day +2.2%, 5-day -2.2%, 4th percentile); environment: Broad bearish.
- Pick day: Tue 21 Feb 2023: NIFTY -0.1%, Midcap -0.3%, Smallcap -0.3%; NIFTY minus Smallcap +0.2 pts (20-day +0.9 pts); breadth 0.38 (675 up / 1,091 down of 1,815; 10-day 0.45); VIX 14.0 (day +4.7%, 5-day +4.2%, 12th percentile); environment: Broad bearish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.53, correlation 0.35).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 20 Feb 2023 | -2.7% | -0.6% | 0.0% | -0.3% | 0.34 | 13.4 | Broad bearish | -2.4 pts | 0% |  |
| 0 | Tue 21 Feb 2023 | -5.1% | -0.1% | -0.3% | -0.3% | 0.38 | 14.0 | Broad bearish | -4.8 pts | 0% | +0 |
| 1 | Wed 22 Feb 2023 | +1.2% | -1.5% | -1.0% | -1.1% | 0.19 | 15.6 | Broad bearish | +2.4 pts | 100% | +277 |
| 2 | Thu 23 Feb 2023 | +4.1% | -0.2% | -0.2% | +0.2% | 0.44 | 15.1 | Broad bearish | +3.9 pts | 100% | +421 |
| 3 | Fri 24 Feb 2023 | -1.8% | -0.3% | -0.2% | -0.2% | 0.39 | 14.2 | Broad bearish | -1.6 pts | 100% | -189 |
| 4 | Mon 27 Feb 2023 | +0.4% | -0.4% | -0.6% | -1.2% | 0.19 | 13.9 | Broad bearish | +1.6 pts | 100% | +42 |
| 5 | Tue 28 Feb 2023 | +3.2% | -0.5% | +0.6% | +0.3% | 0.50 | 14.0 | Broad bearish | +2.8 pts | 0% | +319 |

- From the first buy to the last sale: NIFTY -2.5%, Midcap -1.1%, Smallcap -1.6%; the trade made +9.05% gross on the money it used.
- Split (on the money used): market part -2.48% = beta 1.53 x Smallcap 250 -1.62%; stock part +11.53% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (HIGH, 18 sessions, mature) | S10 breakdown NEW (1d) | volatility elevated**
- Emerging bearish trend began 27 Jan 2023, confirmed 30 Jan 2023 (before it: S03); required 3 of 3 hold, supporting 9 of 10 (support 90%), conflicts: none
- What would end it: 2 sessions in a row closing above 29.77 (the last swing high 29.40 plus 0.25 ATR), or at / above EMA50 27.29 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 20-session low 25.65 1 session ago, volume 0.4x normal - NEW (not yet confirmed)
- Transitions before the pick: S09 -> S07 (19 Oct) -> UNKNOWN (27 Oct) -> S02 (21 Nov) -> S01 (09 Dec) -> S03 (09 Jan) -> S09 (30 Jan)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 21 Feb 2023 | 24.15 | S09 | S09 | HIGH | mature | S10 breakdown new |  |
| 1 | Wed 22 Feb 2023 | 24.45 | S09 | S09 | HIGH | mature | S10 breakdown new |  |
| 2 | Thu 23 Feb 2023 | 25.45 | S09 | S09 | HIGH | mature | S10 breakdown confirmed |  |
| 3 | Fri 24 Feb 2023 | 25.00 | S09 | S09 | HIGH | mature | S10 breakdown confirmed |  |
| 4 | Mon 27 Feb 2023 | 25.10 | S09 | S09 | MEDIUM | mature | S10 breakdown confirmed |  |
| 5 | Tue 28 Feb 2023 | 25.90 | S09 | S08 | LOW | deteriorating | S10 breakdown confirmed |  |
