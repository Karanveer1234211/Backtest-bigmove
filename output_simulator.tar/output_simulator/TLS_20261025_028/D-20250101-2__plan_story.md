## D-20250101-2 BIRLAMONEY - plan

D rank 2, signal day 2025-01-01, mode daily. Status: **ok**.

Result: **net -888.4 bp** of the target size (gross -853.4, costs 35.0); bought 100% of the target, average entry 255.45, last sale 233.65 (time, session 5); MFE +0.96% (session 3), MAE -9.43% (session 4).

### What happened, in order

- 2025-01-02 09:15  **BUY open** 100% of the target @ 255.45 (open: at the session 1 open)
- 2025-01-08 15:30  **SELL time** 100% of the position @ 233.65 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-01-01 | 269.90 | 274.00 | 256.40 | 256.60 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-01-02 | 255.45 | 255.65 | 243.80 | 243.80 | 100% | -473.6 | -473.6 | buy open@255.4500 |
| 2 | 2025-01-03 | 234.70 | 255.95 | 233.60 | 255.95 | 100% | +475.6 | +2.1 |  |
| 3 | 2025-01-06 | 256.00 | 257.90 | 243.15 | 243.50 | 100% | -487.4 | -485.3 |  |
| 4 | 2025-01-07 | 236.55 | 254.50 | 231.35 | 244.85 | 100% | +52.8 | -432.5 |  |
| 5 | 2025-01-08 | 238.00 | 242.60 | 232.60 | 233.65 | 0% | -455.9 | -888.4 | sell time@233.6500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Tue 31 Dec 2024: NIFTY 0.0%, Midcap +0.2%, Smallcap +0.6%; NIFTY minus Smallcap -0.6 pts (20-day -2.1 pts); breadth 0.64 (1,338 up / 764 down of 2,126; 10-day 0.37); VIX 14.4 (day +3.4%, 5-day +6.9%, 60th percentile); environment: Mixed / ranging.
- Pick day: Wed 01 Jan 2025: NIFTY +0.4%, Midcap +0.5%, Smallcap +0.9%; NIFTY minus Smallcap -0.5 pts (20-day -2.4 pts); breadth 0.74 (1,555 up / 551 down of 2,128; 10-day 0.42); VIX 14.5 (day +0.4%, 5-day +10.1%, 62nd percentile); environment: Mixed / ranging.
- The pick: size class no list; moves most with Smallcap 250 (beta 0.83, correlation 0.25).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Tue 31 Dec 2024 | +0.5% | 0.0% | +0.2% | +0.6% | 0.64 | 14.4 | Mixed / ranging | -0.1 pts | 0% |  |
| 0 | Wed 01 Jan 2025 | -4.9% | +0.4% | +0.5% | +0.9% | 0.74 | 14.5 | Mixed / ranging | -5.8 pts | 0% | +0 |
| 1 | Thu 02 Jan 2025 | -5.0% | +1.9% | +1.1% | +0.6% | 0.65 | 13.7 | Narrow bullish | -5.5 pts | 100% | -474 |
| 2 | Fri 03 Jan 2025 | +5.0% | -0.8% | -0.3% | -0.2% | 0.50 | 13.5 | Mixed / ranging | +5.2 pts | 100% | +476 |
| 3 | Mon 06 Jan 2025 | -4.9% | -1.6% | -2.5% | -2.9% | 0.08 | 15.7 | HIGH STRESS | -2.0 pts | 100% | -487 |
| 4 | Tue 07 Jan 2025 | +0.6% | +0.4% | +0.9% | +1.4% | 0.76 | 14.7 | Mixed / ranging | -0.9 pts | 100% | +53 |
| 5 | Wed 08 Jan 2025 | -4.6% | -0.1% | -1.0% | -1.4% | 0.28 | 14.5 | Broad bearish | -3.2 pts | 0% | -456 |

- From the first buy to the last sale: NIFTY -0.4%, Midcap -2.1%, Smallcap -2.7%; the trade made -8.53% gross on the money it used.
- Split (on the money used): market part -2.26% = beta 0.83 x Smallcap 250 -2.73%; stock part -6.28% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (MEDIUM, 4 sessions, early) | S11 failed breakout (bull trap) (5d) | volatility extreme**
- Strong bullish continuation began 27 Dec 2024, confirmed 30 Dec 2024 (before it: S02); required 5 of 5 hold, supporting 9 of 10 (support 90%), conflicts: momentum decelerating (10-session move 1.5+ ATR smaller than the 10 before)
- What would end it: 2 sessions in a row closing below 212.12 (the last higher low 217.00 less 0.25 ATR) or at / below EMA50 209.65; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S11 failed breakout (bull trap): broke out 5 sessions ago at 288.99 (55-session level), closed back below it on 26 Dec
- Transitions before the pick: S09 -> S07 (14 Oct) -> UNKNOWN (16 Oct) -> S02 (08 Nov) -> UNKNOWN (14 Nov) -> S02 (26 Nov) -> S01 (30 Dec)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Wed 01 Jan 2025 | 256.60 | S01 | S01 | MEDIUM | early | S11 failed breakout (bull trap) |  |
| 1 | Thu 02 Jan 2025 | 243.80 | S01 | S01 | MEDIUM | early | S11 failed breakout (bull trap) |  |
| 2 | Fri 03 Jan 2025 | 255.95 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 3 | Mon 06 Jan 2025 | 243.50 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 4 | Tue 07 Jan 2025 | 244.85 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 5 | Wed 08 Jan 2025 | 233.65 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
