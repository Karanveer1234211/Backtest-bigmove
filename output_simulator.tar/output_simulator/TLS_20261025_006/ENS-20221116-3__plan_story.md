## ENS-20221116-3 DCW - plan

ENS rank 3, signal day 2022-11-16, mode daily. Status: **ok**.

Result: **net +451.6 bp** of the target size (gross +486.6, costs 35.0); bought 100% of the target, average entry 50.35, last sale 52.80 (time, session 5); MFE +9.24% (session 5), MAE -1.59% (session 1).

### What happened, in order

- 2022-11-17 09:15  **BUY open** 100% of the target @ 50.35 (open: at the session 1 open)
- 2022-11-23 15:30  **SELL time** 100% of the position @ 52.80 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2022-11-16 | 50.85 | 52.30 | 49.75 | 50.10 | 0% | +0.0 | +0.0 |  |
| 1 | 2022-11-17 | 50.35 | 50.80 | 49.55 | 50.40 | 100% | -7.6 | -7.6 | buy open@50.3500 |
| 2 | 2022-11-18 | 50.95 | 53.70 | 50.85 | 52.65 | 100% | +446.9 | +439.3 |  |
| 3 | 2022-11-21 | 52.70 | 53.00 | 51.00 | 51.25 | 100% | -278.1 | +161.2 |  |
| 4 | 2022-11-22 | 51.50 | 51.90 | 50.55 | 51.50 | 100% | +49.7 | +210.9 |  |
| 5 | 2022-11-23 | 54.05 | 55.00 | 52.40 | 52.80 | 0% | +240.7 | +451.6 | sell time@52.8000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Tue 15 Nov 2022: NIFTY +0.4%, Midcap 0.0%, Smallcap +0.1%; NIFTY minus Smallcap +0.3 pts (20-day +4.7 pts); breadth 0.49 (846 up / 893 down of 1,785; 10-day 0.49); VIX 14.6 (day -1.8%, 5-day -6.1%, 1st percentile); environment: Narrow bullish.
- Pick day: Wed 16 Nov 2022: NIFTY 0.0%, Midcap -0.6%, Smallcap -0.3%; NIFTY minus Smallcap +0.4 pts (20-day +4.5 pts); breadth 0.37 (653 up / 1,100 down of 1,785; 10-day 0.47); VIX 15.1 (day +3.1%, 5-day -5.2%, 2nd percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Midcap 150 (beta 1.27, correlation 0.40).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Tue 15 Nov 2022 | -1.1% | +0.4% | 0.0% | +0.1% | 0.49 | 14.6 | Narrow bullish | -1.0 pts | 0% |  |
| 0 | Wed 16 Nov 2022 | -1.2% | 0.0% | -0.6% | -0.3% | 0.37 | 15.1 | Narrow bullish | -0.6 pts | 0% | +0 |
| 1 | Thu 17 Nov 2022 | +0.6% | -0.4% | -0.4% | -0.1% | 0.36 | 14.9 | Narrow bullish | +1.0 pts | 100% | -8 |
| 2 | Fri 18 Nov 2022 | +4.5% | -0.2% | -0.4% | -0.4% | 0.34 | 14.4 | Narrow bullish | +4.9 pts | 100% | +447 |
| 3 | Mon 21 Nov 2022 | -2.7% | -0.8% | 0.0% | +0.1% | 0.37 | 14.8 | Narrow bullish | -2.7 pts | 100% | -278 |
| 4 | Tue 22 Nov 2022 | +0.5% | +0.5% | +0.4% | -0.1% | 0.47 | 13.8 | Narrow bullish | +0.1 pts | 100% | +50 |
| 5 | Wed 23 Nov 2022 | +2.5% | +0.1% | +0.2% | +0.6% | 0.57 | 14.0 | Narrow bullish | +2.3 pts | 0% | +241 |

- From the first buy to the last sale: NIFTY -0.5%, Midcap -0.1%, Smallcap +0.1%; the trade made +4.87% gross on the money it used.
- Split (on the money used): market part -0.18% = beta 1.27 x Midcap 150 -0.14%; stock part +5.05% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (MEDIUM, 5 sessions, early) | S10 breakdown CONFIRMED (3d)**
- Emerging bearish trend began 10 Nov 2022, confirmed 11 Nov 2022 (before it: S03); required 3 of 3 hold, supporting 7 of 10 (support 70%), conflicts: none
- What would end it: 2 sessions in a row closing above 63.15 (the last swing high 62.50 plus 0.25 ATR), or at / above EMA50 54.26 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 20-session low 54.40 3 sessions ago, volume 2.8x normal - CONFIRMED on 16 Nov
- Transitions before the pick: S06 -> S02 (10 Aug) -> S01 (29 Aug) -> S03 (27 Sep) -> S01 (12 Oct) -> S03 (31 Oct) -> S09 (11 Nov)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Wed 16 Nov 2022 | 50.10 | S09 | S09 | MEDIUM | early | S10 breakdown confirmed |  |
| 1 | Thu 17 Nov 2022 | 50.40 | S09 | S09 | MEDIUM | mature | S10 breakdown confirmed |  |
| 2 | Fri 18 Nov 2022 | 52.65 | S09 | S09 | MEDIUM | mature | S10 breakdown confirmed |  |
| 3 | Mon 21 Nov 2022 | 51.25 | S09 | S09 | MEDIUM | mature | S10 breakdown confirmed |  |
| 4 | Tue 22 Nov 2022 | 51.50 | S09 | UNKNOWN | LOW | deteriorating | S10 breakdown confirmed |  |
| 5 | Wed 23 Nov 2022 | 52.80 | UNKNOWN | UNKNOWN | UNKNOWN |  | S10 breakdown confirmed |  |
