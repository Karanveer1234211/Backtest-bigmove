## ENS-20260714-2 AEGISLOG - plan

ENS rank 2, signal day 2026-07-14, mode daily. Status: **ok**.

Result: **net +634.3 bp** of the target size (gross +669.3, costs 35.0); bought 100% of the target, average entry 1231.10, last sale 1313.50 (time, session 5); MFE +16.52% (session 4), MAE +0.00% (session 1).

### What happened, in order

- 2026-07-15 09:15  **BUY open** 100% of the target @ 1231.10 (open: at the session 1 open)
- 2026-07-21 15:30  **SELL time** 100% of the position @ 1313.50 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2026-07-14 | 1289.90 | 1303.30 | 1164.40 | 1222.50 | 0% | +0.0 | +0.0 |  |
| 1 | 2026-07-15 | 1231.10 | 1336.00 | 1231.10 | 1321.10 | 100% | +713.6 | +713.6 | buy open@1231.1000 |
| 2 | 2026-07-16 | 1311.00 | 1343.00 | 1265.80 | 1297.50 | 100% | -191.7 | +521.9 |  |
| 3 | 2026-07-17 | 1306.80 | 1358.00 | 1293.00 | 1349.10 | 100% | +419.1 | +941.0 |  |
| 4 | 2026-07-20 | 1344.00 | 1434.50 | 1339.40 | 1383.90 | 100% | +282.7 | +1223.7 |  |
| 5 | 2026-07-21 | 1383.90 | 1389.10 | 1290.10 | 1313.50 | 0% | -589.3 | +634.3 | sell time@1313.5000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 13 Jul 2026: NIFTY 0.0%, Midcap 0.0%, Smallcap +0.3%; NIFTY minus Smallcap -0.3 pts (20-day -3.9 pts); breadth 0.52 (1,267 up / 1,183 down of 2,481; 10-day 0.53); VIX 13.3 (day +8.4%, 5-day +12.4%, 62nd percentile); environment: Broad bullish.
- Pick day: Tue 14 Jul 2026: NIFTY -0.7%, Midcap -0.5%, Smallcap -1.1%; NIFTY minus Smallcap +0.4 pts (20-day -3.1 pts); breadth 0.25 (621 up / 1,831 down of 2,480; 10-day 0.50); VIX 13.8 (day +3.5%, 5-day +18.0%, 68th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with NIFTY 50 (beta 1.37, correlation 0.46).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 13 Jul 2026 | +3.8% | 0.0% | 0.0% | +0.3% | 0.52 | 13.3 | Broad bullish | +3.8 pts | 0% |  |
| 0 | Tue 14 Jul 2026 | -5.5% | -0.7% | -0.5% | -1.1% | 0.25 | 13.8 | Narrow bullish | -4.8 pts | 0% | +0 |
| 1 | Wed 15 Jul 2026 | +8.1% | +0.1% | +0.4% | +0.7% | 0.55 | 13.3 | Narrow bullish | +8.0 pts | 100% | +714 |
| 2 | Thu 16 Jul 2026 | -1.8% | 0.0% | -0.4% | +0.1% | 0.43 | 12.9 | Narrow bullish | -1.8 pts | 100% | -192 |
| 3 | Fri 17 Jul 2026 | +4.0% | +1.1% | -0.4% | -0.6% | 0.35 | 13.2 | Narrow bullish | +2.9 pts | 100% | +419 |
| 4 | Mon 20 Jul 2026 | +2.6% | -0.4% | +0.5% | +0.1% | 0.54 | 13.0 | Narrow bullish | +3.0 pts | 100% | +283 |
| 5 | Tue 21 Jul 2026 | -5.1% | -0.2% | +0.4% | +0.4% | 0.52 | 12.6 | Narrow bullish | -4.9 pts | 0% | -589 |

- From the first buy to the last sale: NIFTY +0.4%, Midcap +0.2%, Smallcap +0.3%; the trade made +6.69% gross on the money it used.
- Split (on the money used): market part +0.58% = beta 1.37 x NIFTY 50 +0.42%; stock part +6.11% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (LOW, 16 sessions, deteriorating) | S11 failed breakout (bull trap) (6d) | risk: large down candle in the last 5 sessions | volatility extreme**
- Strong bullish continuation began 22 Jun 2026, confirmed 23 Jun 2026 (before it: S02); required 5 of 5 hold, supporting 9 of 10 (support 90%), conflicts: momentum decelerating (10-session move 1.5+ ATR smaller than the 10 before); a 2.0+ ATR down candle in the last 5 sessions
- What would end it: 2 sessions in a row closing below 727.53 (the last higher low 747.55 less 0.25 ATR) or at / below EMA50 996.50; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S11 failed breakout (bull trap): broke out 6 sessions ago at 1,346.80 (55-session level), closed back below it on 08 Jul
- Risk flags: large down candle in the last 5 sessions
- Transitions before the pick: S06 -> S02 (19 May) -> S07 (21 May) -> S06 (25 May) -> S07 (29 May) -> S02 (02 Jun) -> S01 (23 Jun)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 14 Jul 2026 | 1,222.50 | S01 | S01 | LOW | deteriorating | S11 failed breakout (bull trap) | large down candle in the last 5 sessions |
| 1 | Wed 15 Jul 2026 | 1,321.10 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 2 | Thu 16 Jul 2026 | 1,297.50 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 3 | Fri 17 Jul 2026 | 1,349.10 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 4 | Mon 20 Jul 2026 | 1,383.90 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 5 | Tue 21 Jul 2026 | 1,313.50 | S01 | S03 | LOW | deteriorating | S11 failed breakout (bull trap) |  |
