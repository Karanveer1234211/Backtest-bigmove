## D-20260728-1 AQYLON - plan

D rank 1, signal day 2026-07-28, mode daily. Status: **ok**.

Result: **net -515.8 bp** of the target size (gross -480.8, costs 35.0); bought 100% of the target, average entry 25.79, last sale 24.55 (time, session 6); MFE +8.88% (session 5), MAE -8.88% (session 2).

### What happened, in order

- 2026-07-29 09:15  **BUY open** 100% of the target @ 25.79 (open: at the session 1 open)
- 2026-08-05 09:15  **SELL time** 100% of the position @ 24.55 (locked_open: time: close locked at the lower band; first unlocked open)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2026-07-28 | 24.94 | 25.84 | 24.06 | 25.16 | 0% | +0.0 | +0.0 |  |
| 1 | 2026-07-29 | 25.79 | 26.05 | 23.91 | 24.10 | 100% | -672.8 | -672.8 | buy open@25.7900 |
| 2 | 2026-07-30 | 24.00 | 25.30 | 23.50 | 25.27 | 100% | +453.7 | -219.1 |  |
| 3 | 2026-07-31 | 25.93 | 26.06 | 25.15 | 25.49 | 100% | +85.3 | -133.8 |  |
| 4 | 2026-08-03 | 25.81 | 26.76 | 24.22 | 26.75 | 100% | +488.6 | +354.7 |  |
| 5 | 2026-08-04 | 26.69 | 28.08 | 25.42 | 25.42 | 100% | -515.7 | -161.0 |  |
| 6 | 2026-08-05 | 24.55 | 26.69 | 24.15 | 26.68 | 0% | -354.8 | -515.8 | sell time@24.5500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 27 Jul 2026: NIFTY +1.0%, Midcap +1.1%, Smallcap +1.3%; NIFTY minus Smallcap -0.3 pts (20-day -1.0 pts); breadth 0.71 (1,740 up / 707 down of 2,481; 10-day 0.44); VIX 12.7 (day -9.8%, 5-day -2.5%, 54th percentile); environment: Narrow bullish.
- Pick day: Tue 28 Jul 2026: NIFTY 0.0%, Midcap 0.0%, Smallcap -0.5%; NIFTY minus Smallcap +0.4 pts (20-day +0.4 pts); breadth 0.30 (731 up / 1,719 down of 2,480; 10-day 0.44); VIX 12.6 (day -0.8%, 5-day -0.3%, 53rd percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Midcap 150 (beta 0.97, correlation 0.32).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 27 Jul 2026 | -4.8% | +1.0% | +1.1% | +1.3% | 0.71 | 12.7 | Narrow bullish | -5.9 pts | 0% |  |
| 0 | Tue 28 Jul 2026 | +0.7% | 0.0% | 0.0% | -0.5% | 0.30 | 12.6 | Narrow bullish | +0.7 pts | 0% | +0 |
| 1 | Wed 29 Jul 2026 | -4.2% | +1.1% | +0.8% | +1.3% | 0.65 | 12.0 | Narrow bullish | -5.1 pts | 100% | -673 |
| 2 | Thu 30 Jul 2026 | +4.9% | +0.3% | -0.4% | -0.7% | 0.35 | 12.2 | Narrow bullish | +5.3 pts | 100% | +454 |
| 3 | Fri 31 Jul 2026 | +0.9% | +0.3% | +0.5% | +0.4% | 0.63 | 11.8 | Narrow bullish | +0.4 pts | 100% | +85 |
| 4 | Mon 03 Aug 2026 | +4.9% | +1.6% | +1.2% | +1.4% | 0.74 | 11.9 | Narrow bullish | +3.7 pts | 100% | +489 |
| 5 | Tue 04 Aug 2026 | -5.0% | -0.6% | -0.3% | +0.2% | 0.45 | 12.2 | Narrow bullish | -4.7 pts | 100% | -516 |
| 6 | Wed 05 Aug 2026 | +5.0% | 0.0% | +0.2% | +0.7% | 0.59 | 12.1 | Broad bullish | +4.7 pts | 0% | -355 |

- From the first buy to the last sale: NIFTY +2.0%, Midcap +1.9%, Smallcap +2.6%; the trade made -4.81% gross on the money it used.
- Split (on the money used): market part +1.85% = beta 0.97 x Midcap 150 +1.91%; stock part -6.65% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S08 Bearish continuation (HIGH, 19 sessions, mature) | S10 breakdown CONFIRMED (9d) | risk: stretched far below EMA20 | volatility elevated**
- Bearish continuation began 02 Jul 2026, confirmed 03 Jul 2026 (before it: UNKNOWN); required 5 of 5 hold, supporting 9 of 10 (support 90%), conflicts: none
- What would end it: 2 sessions in a row closing above 45.99 (the last lower high 45.43 plus 0.25 ATR) or at / above EMA50 44.71; also the lower-high / lower-low structure or the falling EMA50 failing
- Event: S10 breakdown: closed below the 55-session low 37.70 9 sessions ago, volume 0.4x normal - CONFIRMED on 20 Jul
- Risk flags: stretched far below EMA20
- Transitions before the pick: S09 -> S08 (15 Apr) -> S06 (21 Apr) -> UNKNOWN (24 Apr) -> S06 (15 May) -> UNKNOWN (16 Jun) -> S08 (03 Jul)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 28 Jul 2026 | 25.16 | S08 | S08 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 1 | Wed 29 Jul 2026 | 24.10 | S08 | S08 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 2 | Thu 30 Jul 2026 | 25.27 | S08 | S08 | MEDIUM | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 3 | Fri 31 Jul 2026 | 25.49 | S08 | S08 | MEDIUM | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 4 | Mon 03 Aug 2026 | 26.75 | S08 | S08 | LOW | deteriorating | S10 breakdown confirmed |  |
| 5 | Tue 04 Aug 2026 | 25.42 | S08 | S08 | LOW | deteriorating |  |  |
| 6 | Wed 05 Aug 2026 | 26.68 | S08 | S08 | LOW | deteriorating |  |  |
