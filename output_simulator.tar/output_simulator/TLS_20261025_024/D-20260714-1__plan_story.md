## D-20260714-1 BLISSGVS - plan

D rank 1, signal day 2026-07-14, mode daily. Status: **ok**.

Result: **net -1215.6 bp** of the target size (gross -1180.6, costs 35.0); bought 100% of the target, average entry 529.80, last sale 467.25 (time, session 5); MFE +0.00% (session 1), MAE -13.06% (session 4).

### What happened, in order

- 2026-07-15 09:15  **BUY open** 100% of the target @ 529.80 (open: at the session 1 open)
- 2026-07-21 15:30  **SELL time** 100% of the position @ 467.25 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2026-07-14 | 532.00 | 532.00 | 515.05 | 522.90 | 0% | +0.0 | +0.0 |  |
| 1 | 2026-07-15 | 529.80 | 529.80 | 506.00 | 513.65 | 100% | -322.3 | -322.3 | buy open@529.8000 |
| 2 | 2026-07-16 | 522.00 | 522.00 | 500.20 | 503.85 | 100% | -185.0 | -507.3 |  |
| 3 | 2026-07-17 | 514.00 | 514.00 | 479.00 | 482.50 | 100% | -403.0 | -910.3 |  |
| 4 | 2026-07-20 | 483.00 | 500.00 | 460.60 | 489.35 | 100% | +129.3 | -781.0 |  |
| 5 | 2026-07-21 | 478.95 | 484.95 | 465.55 | 467.25 | 0% | -434.6 | -1215.6 | sell time@467.2500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 13 Jul 2026: NIFTY 0.0%, Midcap 0.0%, Smallcap +0.3%; NIFTY minus Smallcap -0.3 pts (20-day -3.9 pts); breadth 0.52 (1,267 up / 1,183 down of 2,481; 10-day 0.53); VIX 13.3 (day +8.4%, 5-day +12.4%, 62nd percentile); environment: Broad bullish.
- Pick day: Tue 14 Jul 2026: NIFTY -0.7%, Midcap -0.5%, Smallcap -1.1%; NIFTY minus Smallcap +0.4 pts (20-day -3.1 pts); breadth 0.25 (621 up / 1,831 down of 2,480; 10-day 0.50); VIX 13.8 (day +3.5%, 5-day +18.0%, 68th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Midcap 150 (beta 1.29, correlation 0.43).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 13 Jul 2026 | +0.1% | 0.0% | 0.0% | +0.3% | 0.52 | 13.3 | Broad bullish | +0.1 pts | 0% |  |
| 0 | Tue 14 Jul 2026 | +0.2% | -0.7% | -0.5% | -1.1% | 0.25 | 13.8 | Narrow bullish | +0.7 pts | 0% | +0 |
| 1 | Wed 15 Jul 2026 | -1.8% | +0.1% | +0.4% | +0.7% | 0.55 | 13.3 | Narrow bullish | -2.2 pts | 100% | -322 |
| 2 | Thu 16 Jul 2026 | -1.9% | 0.0% | -0.4% | +0.1% | 0.43 | 12.9 | Narrow bullish | -1.5 pts | 100% | -185 |
| 3 | Fri 17 Jul 2026 | -4.2% | +1.1% | -0.4% | -0.6% | 0.35 | 13.2 | Narrow bullish | -3.8 pts | 100% | -403 |
| 4 | Mon 20 Jul 2026 | +1.4% | -0.4% | +0.5% | +0.1% | 0.54 | 13.0 | Narrow bullish | +0.9 pts | 100% | +129 |
| 5 | Tue 21 Jul 2026 | -4.5% | -0.2% | +0.4% | +0.4% | 0.52 | 12.6 | Narrow bullish | -4.9 pts | 0% | -435 |

- From the first buy to the last sale: NIFTY +0.4%, Midcap +0.2%, Smallcap +0.3%; the trade made -11.81% gross on the money it used.
- Split (on the money used): market part +0.30% = beta 1.29 x Midcap 150 +0.23%; stock part -12.10% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (MEDIUM, 37 sessions, mature) | S11 failed breakout (bull trap) (11d)**
- Strong bullish continuation began 21 May 2026, confirmed 22 May 2026 (before it: S03); required 5 of 5 hold, supporting 9 of 10 (support 90%), conflicts: momentum decelerating (10-session move 1.5+ ATR smaller than the 10 before)
- What would end it: 2 sessions in a row closing below 465.84 (the last higher low 472.20 less 0.25 ATR) or at / below EMA50 426.44; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S11 failed breakout (bull trap): broke out 11 sessions ago at 495.00 (55-session level), closed back below it on 06 Jul
- Transitions before the pick: S03 -> S07 (24 Mar) -> S03 (30 Mar) -> UNKNOWN (08 Apr) -> S01 (27 Apr) -> S03 (05 May) -> S01 (22 May)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 14 Jul 2026 | 522.90 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 1 | Wed 15 Jul 2026 | 513.65 | S01 | S01 | MEDIUM | mature | S11 failed breakout (bull trap) |  |
| 2 | Thu 16 Jul 2026 | 503.85 | S01 | UNKNOWN | LOW | deteriorating | S11 failed breakout (bull trap) |  |
| 3 | Fri 17 Jul 2026 | 482.50 | S03 | S03 | MEDIUM | early | S11 failed breakout (bull trap) |  |
| 4 | Mon 20 Jul 2026 | 489.35 | S03 | S03 | HIGH | early | S11 failed breakout (bull trap) |  |
| 5 | Tue 21 Jul 2026 | 467.25 | S03 | UNKNOWN | LOW | deteriorating |  |  |
