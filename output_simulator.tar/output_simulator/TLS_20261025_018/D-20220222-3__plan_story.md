## D-20220222-3 GULPOLY - plan

D rank 3, signal day 2022-02-22, mode daily. Status: **ok**.

Result: **net +1049.3 bp** of the target size (gross +1084.3, costs 35.0); bought 100% of the target, average entry 246.25, last sale 272.95 (time, session 5); MFE +14.62% (session 4), MAE +0.00% (session 1).

### What happened, in order

- 2022-02-23 09:15  **BUY open** 100% of the target @ 246.25 (open: at the session 1 open)
- 2022-03-02 15:30  **SELL time** 100% of the position @ 272.95 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2022-02-22 | 250.00 | 254.15 | 235.10 | 241.20 | 0% | +0.0 | +0.0 |  |
| 1 | 2022-02-23 | 246.25 | 265.30 | 246.25 | 265.30 | 100% | +756.1 | +756.1 | buy open@246.2500 |
| 2 | 2022-02-24 | 252.50 | 278.55 | 252.05 | 256.05 | 100% | -375.6 | +380.5 |  |
| 3 | 2022-02-25 | 268.85 | 268.85 | 268.85 | 268.85 | 100% | +519.8 | +900.3 |  |
| 4 | 2022-02-28 | 268.85 | 282.25 | 258.35 | 274.30 | 100% | +221.3 | +1121.6 |  |
| 5 | 2022-03-02 | 271.65 | 279.00 | 268.35 | 272.95 | 0% | -72.3 | +1049.3 | sell time@272.9500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 21 Feb 2022: NIFTY -0.4%, Midcap -1.1%, Smallcap -2.6%; NIFTY minus Smallcap +2.2 pts (20-day +7.8 pts); breadth 0.12 (198 up / 1,472 down of 1,690; 10-day 0.36); VIX 22.9 (day +3.3%, 5-day -0.3%, 93rd percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 93rd percentile of 250 sessions.
- Pick day: Tue 22 Feb 2022: NIFTY -0.7%, Midcap -0.9%, Smallcap -1.9%; NIFTY minus Smallcap +1.3 pts (20-day +7.3 pts); breadth 0.15 (250 up / 1,410 down of 1,680; 10-day 0.35); VIX 26.7 (day +16.4%, 5-day +29.4%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +29% in 5 sessions.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.15, correlation 0.46).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 21 Feb 2022 | -6.6% | -0.4% | -1.1% | -2.6% | 0.12 | 22.9 | HIGH STRESS | -4.0 pts | 0% |  |
| 0 | Tue 22 Feb 2022 | -7.3% | -0.7% | -0.9% | -1.9% | 0.15 | 26.7 | HIGH STRESS | -5.4 pts | 0% | +0 |
| 1 | Wed 23 Feb 2022 | +10.0% | -0.2% | +0.4% | +1.2% | 0.72 | 24.5 | HIGH STRESS | +8.8 pts | 100% | +756 |
| 2 | Thu 24 Feb 2022 | -3.5% | -4.8% | -5.4% | -5.9% | 0.03 | 32.0 | HIGH STRESS | +2.4 pts | 100% | -376 |
| 3 | Fri 25 Feb 2022 | +5.0% | +2.5% | +3.9% | +4.3% | 0.90 | 26.7 | HIGH STRESS | +0.7 pts | 100% | +520 |
| 4 | Mon 28 Feb 2022 | +2.0% | +0.8% | +0.9% | +0.8% | 0.64 | 28.6 | HIGH STRESS | +1.2 pts | 100% | +221 |
| 5 | Wed 02 Mar 2022 | -0.5% | -1.1% | -0.2% | +0.3% | 0.46 | 29.2 | HIGH STRESS | -0.8 pts | 0% | -72 |

- From the first buy to the last sale: NIFTY -3.4%, Midcap -1.5%, Smallcap -0.6%; the trade made +10.84% gross on the money it used.
- Split (on the money used): market part -0.65% = beta 1.15 x Smallcap 250 -0.56%; stock part +11.49% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (MEDIUM, 2 sessions, early) | S10 breakdown NEW (1d) | volatility extreme**
- Emerging bearish trend began 21 Feb 2022, confirmed 22 Feb 2022 (before it: UNKNOWN); required 3 of 3 hold, supporting 9 of 10 (support 90%), conflicts: none
- What would end it: 2 sessions in a row closing above 305.93 (the last swing high 301.45 plus 0.25 ATR), or at / above EMA50 281.84 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 20-session low 265.30 1 session ago, volume 1.1x normal - NEW (not yet confirmed)
- Transitions before the pick: UNKNOWN -> S07 (31 Dec) -> S02 (04 Jan) -> UNKNOWN (24 Jan) -> S02 (01 Feb) -> UNKNOWN (10 Feb) -> S09 (22 Feb)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 22 Feb 2022 | 241.20 | S09 | S09 | MEDIUM | early | S10 breakdown new |  |
| 1 | Wed 23 Feb 2022 | 265.30 | S09 | S09 | HIGH | early | S10 breakdown new |  |
| 2 | Thu 24 Feb 2022 | 256.05 | S09 | S09 | HIGH | early | S10 breakdown confirmed |  |
| 3 | Fri 25 Feb 2022 | 268.85 | S09 | S09 | MEDIUM | early | S10 breakdown confirmed |  |
| 4 | Mon 28 Feb 2022 | 274.30 | S09 | S09 | MEDIUM | mature | failed breakdown (bear trap) |  |
| 5 | Wed 02 Mar 2022 | 272.95 | S09 | S09 | MEDIUM | mature | failed breakdown (bear trap) |  |
