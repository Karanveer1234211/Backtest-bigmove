## D-20220330-3 NITINSPIN - plan

D rank 3, signal day 2022-03-30, mode daily. Status: **ok**.

Result: **net +598.1 bp** of the target size (gross +633.1, costs 35.0); bought 100% of the target, average entry 234.55, last sale 249.40 (time, session 5); MFE +9.02% (session 4), MAE -4.07% (session 1).

### What happened, in order

- 2022-03-31 09:15  **BUY open** 100% of the target @ 234.55 (open: at the session 1 open)
- 2022-04-06 15:30  **SELL time** 100% of the position @ 249.40 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2022-03-30 | 237.05 | 243.00 | 227.05 | 231.35 | 0% | +0.0 | +0.0 |  |
| 1 | 2022-03-31 | 234.55 | 234.55 | 225.00 | 226.40 | 100% | -365.0 | -365.0 | buy open@234.5500 |
| 2 | 2022-04-01 | 227.00 | 237.70 | 227.00 | 237.70 | 100% | +481.8 | +116.8 |  |
| 3 | 2022-04-04 | 244.60 | 249.55 | 240.25 | 247.90 | 100% | +434.9 | +551.7 |  |
| 4 | 2022-04-05 | 252.00 | 255.70 | 241.00 | 254.55 | 100% | +283.5 | +835.2 |  |
| 5 | 2022-04-06 | 252.00 | 255.00 | 245.10 | 249.40 | 0% | -237.1 | +598.1 | sell time@249.4000 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Tue 29 Mar 2022: NIFTY +0.6%, Midcap +0.6%, Smallcap +0.6%; NIFTY minus Smallcap 0.0 pts (20-day -1.6 pts); breadth 0.44 (743 up / 929 down of 1,697; 10-day 0.45); VIX 21.3 (day -5.8%, 5-day -11.5%, 82nd percentile); environment: Narrow bullish.
- Pick day: Wed 30 Mar 2022: NIFTY +1.0%, Midcap +0.9%, Smallcap +0.9%; NIFTY minus Smallcap +0.1 pts (20-day -1.5 pts); breadth 0.66 (1,105 up / 559 down of 1,693; 10-day 0.49); VIX 20.6 (day -3.2%, 5-day -16.7%, 77th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.26, correlation 0.61).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Tue 29 Mar 2022 | -4.9% | +0.6% | +0.6% | +0.6% | 0.44 | 21.3 | Narrow bullish | -5.5 pts | 0% |  |
| 0 | Wed 30 Mar 2022 | -2.4% | +1.0% | +0.9% | +0.9% | 0.66 | 20.6 | Narrow bullish | -3.3 pts | 0% | +0 |
| 1 | Thu 31 Mar 2022 | -2.1% | -0.2% | +0.4% | +0.5% | 0.43 | 20.6 | Narrow bullish | -2.6 pts | 100% | -365 |
| 2 | Fri 01 Apr 2022 | +5.0% | +1.2% | +1.3% | +1.9% | 0.85 | 18.4 | Narrow bullish | +3.1 pts | 100% | +482 |
| 3 | Mon 04 Apr 2022 | +4.3% | +2.2% | +1.5% | +1.5% | 0.81 | 17.9 | Broad bullish | +2.8 pts | 100% | +435 |
| 4 | Tue 05 Apr 2022 | +2.7% | -0.5% | +1.5% | +1.0% | 0.70 | 18.5 | Broad bullish | +1.7 pts | 100% | +284 |
| 5 | Wed 06 Apr 2022 | -2.0% | -0.8% | +0.4% | +0.4% | 0.60 | 19.0 | Broad bullish | -2.4 pts | 0% | -237 |

- From the first buy to the last sale: NIFTY +1.6%, Midcap +4.8%, Smallcap +4.9%; the trade made +6.33% gross on the money it used.
- Split (on the money used): market part +6.19% = beta 1.26 x Smallcap 250 +4.90%; stock part +0.14% -> mostly the market.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S09 Emerging bearish trend (MEDIUM, 2 sessions, early) | S10 breakdown NEW (1d)**
- Emerging bearish trend began 29 Mar 2022, confirmed 30 Mar 2022 (before it: S07); required 3 of 3 hold, supporting 8 of 10 (support 80%), conflicts: none
- What would end it: 2 sessions in a row closing above 280.10 (the last swing high 277.00 plus 0.25 ATR), or at / above EMA50 269.50 once EMA20 stops falling; it becomes S08 once the structure is established
- Event: S10 breakdown: closed below the 55-session low 242.20 1 session ago, volume 2.0x normal - NEW (not yet confirmed)
- Transitions before the pick: S01 -> S07 (21 Feb) -> S09 (25 Feb) -> S07 (21 Mar) -> S03 (24 Mar) -> S07 (28 Mar) -> S09 (30 Mar)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Wed 30 Mar 2022 | 231.35 | S09 | S09 | MEDIUM | early | S10 breakdown new |  |
| 1 | Thu 31 Mar 2022 | 226.40 | S09 | S09 | HIGH | early | S10 breakdown new |  |
| 2 | Fri 01 Apr 2022 | 237.70 | S09 | S09 | MEDIUM | early | S10 breakdown confirmed |  |
| 3 | Mon 04 Apr 2022 | 247.90 | S09 | UNKNOWN | LOW | deteriorating | failed breakdown (bear trap) |  |
| 4 | Tue 05 Apr 2022 | 254.55 | UNKNOWN | UNKNOWN | UNKNOWN |  | failed breakdown (bear trap) |  |
| 5 | Wed 06 Apr 2022 | 249.40 | UNKNOWN | UNKNOWN | UNKNOWN |  | failed breakdown (bear trap) |  |
