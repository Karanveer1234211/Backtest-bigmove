## ENS-20221020-1 JKIL - plan

ENS rank 1, signal day 2022-10-20, mode daily. Status: **ok**.

Result: **net +1352.2 bp** of the target size (gross +1387.2, costs 35.0); bought 100% of the target, average entry 226.00, last sale 257.35 (time, session 5); MFE +15.88% (session 5), MAE -4.20% (session 1).

### What happened, in order

- 2022-10-21 09:15  **BUY open** 100% of the target @ 226.00 (open: at the session 1 open)
- 2022-10-28 15:30  **SELL time** 100% of the position @ 257.35 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2022-10-20 | 230.10 | 232.05 | 226.45 | 227.95 | 0% | +0.0 | +0.0 |  |
| 1 | 2022-10-21 | 226.00 | 227.00 | 216.50 | 218.15 | 100% | -364.8 | -364.8 | buy open@226.0000 |
| 2 | 2022-10-24 | 220.00 | 228.40 | 220.00 | 222.65 | 100% | +199.1 | -165.7 |  |
| 3 | 2022-10-25 | 218.00 | 230.20 | 218.00 | 224.30 | 100% | +73.0 | -92.7 |  |
| 4 | 2022-10-27 | 235.00 | 245.00 | 230.60 | 243.60 | 100% | +854.0 | +761.3 |  |
| 5 | 2022-10-28 | 246.90 | 261.90 | 245.60 | 257.35 | 0% | +590.9 | +1352.2 | sell time@257.3500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Wed 19 Oct 2022: NIFTY +0.1%, Midcap +0.1%, Smallcap 0.0%; NIFTY minus Smallcap +0.1 pts (20-day +0.3 pts); breadth 0.45 (786 up / 945 down of 1,773; 10-day 0.46); VIX 17.5 (day +0.2%, 5-day -13.3%, 22nd percentile); environment: Narrow bullish.
- Pick day: Thu 20 Oct 2022: NIFTY +0.3%, Midcap -0.3%, Smallcap +0.1%; NIFTY minus Smallcap +0.2 pts (20-day +0.4 pts); breadth 0.47 (814 up / 913 down of 1,774; 10-day 0.43); VIX 17.2 (day -1.5%, 5-day -15.1%, 18th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 1.26, correlation 0.49).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Wed 19 Oct 2022 | +1.0% | +0.1% | +0.1% | 0.0% | 0.45 | 17.5 | Narrow bullish | +1.0 pts | 0% |  |
| 0 | Thu 20 Oct 2022 | -2.3% | +0.3% | -0.3% | +0.1% | 0.47 | 17.2 | Narrow bullish | -2.4 pts | 0% | +0 |
| 1 | Fri 21 Oct 2022 | -4.3% | +0.1% | -0.6% | -0.4% | 0.31 | 17.3 | Narrow bullish | -3.9 pts | 100% | -365 |
| 2 | Mon 24 Oct 2022 | +2.1% | +0.9% | +0.6% | +0.9% | 0.83 | 17.4 | Narrow bullish | +1.1 pts | 100% | +199 |
| 3 | Tue 25 Oct 2022 | +0.7% | -0.4% | +0.1% | -0.2% | 0.35 | 16.9 | Narrow bullish | +0.9 pts | 100% | +73 |
| 4 | Thu 27 Oct 2022 | +8.6% | +0.5% | +0.6% | +0.4% | 0.55 | 16.6 | Narrow bullish | +8.2 pts | 100% | +854 |
| 5 | Fri 28 Oct 2022 | +5.6% | +0.3% | -0.6% | -0.6% | 0.36 | 15.9 | Narrow bullish | +6.3 pts | 0% | +591 |

- From the first buy to the last sale: NIFTY +0.9%, Midcap -0.2%, Smallcap -0.2%; the trade made +13.87% gross on the money it used.
- Split (on the money used): market part -0.29% = beta 1.26 x Smallcap 250 -0.23%; stock part +14.16% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S08 Bearish continuation (HIGH, 8 sessions, mature) | S10 breakdown CONFIRMED (4d) | risk: stretched far below EMA20**
- Bearish continuation began 11 Oct 2022, confirmed 12 Oct 2022 (before it: S09); required 5 of 5 hold, supporting 9 of 10 (support 90%), conflicts: none
- What would end it: 2 sessions in a row closing above 307.03 (the last lower high 303.95 plus 0.25 ATR) or at / above EMA50 281.27; also the lower-high / lower-low structure or the falling EMA50 failing
- Event: S10 breakdown: closed below the 55-session low 266.45 4 sessions ago, volume 2.2x normal - CONFIRMED on 19 Oct
- Risk flags: stretched far below EMA20
- Transitions before the pick: UNKNOWN -> S09 (26 Aug) -> UNKNOWN (14 Sep) -> S09 (20 Sep) -> S07 (30 Sep) -> S09 (04 Oct) -> S08 (12 Oct)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Thu 20 Oct 2022 | 227.95 | S08 | S08 | HIGH | mature | S10 breakdown confirmed | stretched far below EMA20 |
| 1 | Fri 21 Oct 2022 | 218.15 | S08 | S08 | HIGH | mature | S10 breakdown new | stretched far below EMA20 |
| 2 | Mon 24 Oct 2022 | 222.65 | S08 | S08 | HIGH | mature | S10 breakdown new |  |
| 3 | Tue 25 Oct 2022 | 224.30 | S08 | S08 | HIGH | mature | S10 breakdown new |  |
| 4 | Thu 27 Oct 2022 | 243.60 | S08 | S08 | HIGH | mature | failed breakdown (bear trap) |  |
| 5 | Fri 28 Oct 2022 | 257.35 | S08 | S08 | MEDIUM | mature | failed breakdown (bear trap) |  |
