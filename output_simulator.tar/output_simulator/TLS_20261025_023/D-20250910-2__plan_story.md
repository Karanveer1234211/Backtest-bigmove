## D-20250910-2 CUPID - plan

D rank 2, signal day 2025-09-10, mode daily. Status: **ok**.

Result: **net +260.9 bp** of the target size (gross +295.9, costs 35.0); bought 100% of the target, average entry 40.55, last sale 41.75 (time, session 5); MFE +4.93% (session 5), MAE -5.80% (session 2).

### What happened, in order

- 2025-09-11 09:15  **BUY open** 100% of the target @ 40.55 (open: at the session 1 open)
- 2025-09-17 15:30  **SELL time** 100% of the position @ 41.75 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2025-09-10 | 39.40 | 40.80 | 38.75 | 40.55 | 0% | +0.0 | +0.0 |  |
| 1 | 2025-09-11 | 40.55 | 40.90 | 39.65 | 40.30 | 100% | -79.2 | -79.2 | buy open@40.5500 |
| 2 | 2025-09-12 | 40.40 | 41.20 | 38.20 | 39.65 | 100% | -160.3 | -239.4 |  |
| 3 | 2025-09-15 | 39.90 | 41.60 | 39.65 | 41.50 | 100% | +456.2 | +216.8 |  |
| 4 | 2025-09-16 | 41.80 | 42.05 | 40.30 | 40.95 | 100% | -135.6 | +81.1 |  |
| 5 | 2025-09-17 | 41.10 | 42.55 | 40.50 | 41.75 | 0% | +179.8 | +260.9 | sell time@41.7500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Tue 09 Sep 2025: NIFTY +0.4%, Midcap +0.2%, Smallcap +0.3%; NIFTY minus Smallcap +0.1 pts (20-day -0.6 pts); breadth 0.47 (1,049 up / 1,190 down of 2,264; 10-day 0.48); VIX 10.7 (day -1.4%, 5-day -6.2%, 1st percentile); environment: Broad bearish.
- Pick day: Wed 10 Sep 2025: NIFTY +0.4%, Midcap +1.0%, Smallcap +0.7%; NIFTY minus Smallcap -0.2 pts (20-day -1.3 pts); breadth 0.62 (1,390 up / 851 down of 2,264; 10-day 0.52); VIX 10.5 (day -1.4%, 5-day -3.6%, 1st percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 0.65, correlation 0.26).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Tue 09 Sep 2025 | +4.5% | +0.4% | +0.2% | +0.3% | 0.47 | 10.7 | Broad bearish | +4.3 pts | 0% |  |
| 0 | Wed 10 Sep 2025 | +3.2% | +0.4% | +1.0% | +0.7% | 0.62 | 10.5 | Narrow bullish | +2.5 pts | 0% | +0 |
| 1 | Thu 11 Sep 2025 | -0.6% | +0.1% | 0.0% | 0.0% | 0.49 | 10.4 | Narrow bullish | -0.6 pts | 100% | -79 |
| 2 | Fri 12 Sep 2025 | -1.6% | +0.4% | +0.3% | +0.3% | 0.51 | 10.1 | Narrow bullish | -1.9 pts | 100% | -160 |
| 3 | Mon 15 Sep 2025 | +4.7% | -0.2% | +0.4% | +0.6% | 0.56 | 10.4 | Broad bullish | +4.0 pts | 100% | +456 |
| 4 | Tue 16 Sep 2025 | -1.3% | +0.7% | +0.6% | +0.7% | 0.66 | 10.3 | Broad bullish | -2.1 pts | 100% | -136 |
| 5 | Wed 17 Sep 2025 | +2.0% | +0.4% | +0.2% | +0.5% | 0.59 | 10.2 | Broad bullish | +1.4 pts | 0% | +180 |

- From the first buy to the last sale: NIFTY +1.5%, Midcap +1.4%, Smallcap +2.0%; the trade made +2.96% gross on the money it used.
- Split (on the money used): market part +1.29% = beta 0.65 x Smallcap 250 +2.00%; stock part +1.67% -> market and stock together.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (HIGH, 4 sessions, early) | S04 breakout NEW (2d)**
- Strong bullish continuation began 05 Sep 2025, confirmed 08 Sep 2025 (before it: UNKNOWN); required 5 of 5 hold, supporting 10 of 10 (support 100%), conflicts: none
- What would end it: 2 sessions in a row closing below 31.36 (the last higher low 31.80 less 0.25 ATR) or at / below EMA50 31.23; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S04 breakout: closed above the 55-session high 37.40 2 sessions ago, volume 2.4x normal - NEW (not yet confirmed)
- Transitions before the pick: S01 -> UNKNOWN (10 Jul) -> S01 (25 Jul) -> UNKNOWN (28 Aug) -> S03 (01 Sep) -> UNKNOWN (03 Sep) -> S01 (08 Sep)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Wed 10 Sep 2025 | 40.55 | S01 | S01 | HIGH | early | S04 breakout new |  |
| 1 | Thu 11 Sep 2025 | 40.30 | S01 | S01 | HIGH | early | S04 breakout confirmed |  |
| 2 | Fri 12 Sep 2025 | 39.65 | S01 | S01 | HIGH | mature | S04 breakout confirmed |  |
| 3 | Mon 15 Sep 2025 | 41.50 | S01 | S01 | HIGH | mature | S04 breakout new |  |
| 4 | Tue 16 Sep 2025 | 40.95 | S01 | S01 | HIGH | mature | S04 breakout new |  |
| 5 | Wed 17 Sep 2025 | 41.75 | S01 | S01 | HIGH | mature | S04 breakout new |  |
