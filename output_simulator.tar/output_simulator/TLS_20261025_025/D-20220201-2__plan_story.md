## D-20220201-2 URJA - plan

D rank 2, signal day 2022-02-01, mode daily. Status: **ok**.

Result: **net +2102.0 bp** of the target size (gross +2137.0, costs 35.0); bought 100% of the target, average entry 18.25, last sale 22.15 (time, session 5); MFE +21.37% (session 5), MAE -4.93% (session 2).

### What happened, in order

- 2022-02-02 09:15  **BUY open** 100% of the target @ 18.25 (open: at the session 1 open)
- 2022-02-08 15:30  **SELL time** 100% of the position @ 22.15 (close: time exit at the session 5 close)

### Day by day (official daily prices)

| session | date | open | high | low | close | position | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 2022-02-01 | 19.20 | 19.20 | 19.20 | 19.20 | 0% | +0.0 | +0.0 |  |
| 1 | 2022-02-02 | 18.25 | 18.25 | 18.25 | 18.25 | 100% | -17.5 | -17.5 | buy open@18.2500 |
| 2 | 2022-02-03 | 17.35 | 19.15 | 17.35 | 19.15 | 100% | +493.2 | +475.7 |  |
| 3 | 2022-02-04 | 20.10 | 20.10 | 20.10 | 20.10 | 100% | +520.5 | +996.2 |  |
| 4 | 2022-02-07 | 20.70 | 21.10 | 20.50 | 21.10 | 100% | +547.9 | +1544.1 |  |
| 5 | 2022-02-08 | 22.15 | 22.15 | 20.05 | 22.15 | 0% | +557.8 | +2102.0 | sell time@22.1500 |

### The market around the trade (pre = known before entry; the table's later rows = observed after)

- Day before: Mon 31 Jan 2022: NIFTY +1.4%, Midcap +1.5%, Smallcap +1.0%; NIFTY minus Smallcap +0.4 pts (20-day +0.2 pts); breadth 0.58 (956 up / 701 down of 1,683; 10-day 0.42); VIX 21.9 (day +6.0%, 5-day +16.2%, 83rd percentile); environment: Mixed / ranging.
- Pick day: Tue 01 Feb 2022: NIFTY +1.4%, Midcap +1.0%, Smallcap +0.7%; NIFTY minus Smallcap +0.6 pts (20-day +0.5 pts); breadth 0.57 (939 up / 704 down of 1,669; 10-day 0.42); VIX 20.0 (day -9.0%, 5-day -12.5%, 69th percentile); environment: Narrow bullish.
- The pick: size class no list; moves most with Smallcap 250 (beta 0.89, correlation 0.29).

| s | date | stock | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | position | day P&L bp |
|---|---|---|---|---|---|---|---|---|---|---|---|
| -1 | Mon 31 Jan 2022 | -4.9% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -5.9 pts | 0% |  |
| 0 | Tue 01 Feb 2022 | -5.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | 0% | +0 |
| 1 | Wed 02 Feb 2022 | -4.9% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | -6.6 pts | 100% | -18 |
| 2 | Thu 03 Feb 2022 | +4.9% | -1.2% | -1.0% | 0.0% | 0.42 | 19.2 | Narrow bullish | +4.9 pts | 100% | +493 |
| 3 | Fri 04 Feb 2022 | +5.0% | -0.2% | -0.8% | -0.6% | 0.36 | 18.9 | Narrow bullish | +5.5 pts | 100% | +521 |
| 4 | Mon 07 Feb 2022 | +5.0% | -1.7% | -0.9% | -1.1% | 0.30 | 20.4 | Mixed / ranging | +6.1 pts | 100% | +548 |
| 5 | Tue 08 Feb 2022 | +5.0% | +0.3% | -0.8% | -1.5% | 0.24 | 19.7 | Broad bearish | +6.5 pts | 0% | +558 |

- From the first buy to the last sale: NIFTY -2.5%, Midcap -2.8%, Smallcap -2.4%; the trade made +21.37% gross on the money it used.
- Split (on the money used): market part -2.08% = beta 0.89 x Smallcap 250 -2.35%; stock part +23.45% -> mostly the stock itself.

### The stock's state (tl_state - session 0 is known before entry; later rows were observed after entry: they explain, they never select)

- At the pick: **S01 Strong bullish continuation (LOW, 29 sessions, deteriorating) -> S12 pending | S10 breakdown NEW (1d) | risk: stretched far below EMA20; repeated large gaps | volatility elevated**
- Strong bullish continuation began 22 Dec 2021, confirmed 23 Dec 2021 (before it: S02); required 4 of 5 hold, supporting 5 of 10 (support 50%), conflicts: momentum decelerating (10-session move 1.5+ ATR smaller than the 10 before); close 1.0+ ATR below EMA20
- What would end it: 2 sessions in a row closing below 7.25 (the last higher low 7.55 less 0.25 ATR) or at / below EMA50 19.52; also the higher-high / higher-low structure or the rising EMA50 failing
- Event: S10 breakdown: closed below the 20-session low 20.70 1 session ago, volume 1.1x normal - NEW (not yet confirmed)
- Risk flags: stretched far below EMA20; repeated large gaps
- Notes: price down, volume flow up (candidate)
- Transitions before the pick: S06 -> UNKNOWN (29 Oct) -> S07 (02 Nov) -> S02 (08 Nov) -> S07 (12 Nov) -> S02 (26 Nov) -> S01 (23 Dec)

| s | date | close | state | that day's reading | confidence | phase | event | risk flags |
|---|---|---|---|---|---|---|---|---|
| 0 | Tue 01 Feb 2022 | 19.20 | S01 | S12 | LOW | deteriorating | S10 breakdown new | stretched far below EMA20; repeated large gaps |
| 1 | Wed 02 Feb 2022 | 18.25 | UNKNOWN | UNKNOWN | UNKNOWN |  | S10 breakdown new | stretched far below EMA20; repeated large gaps |
| 2 | Thu 03 Feb 2022 | 19.15 | UNKNOWN | UNKNOWN | UNKNOWN |  | S10 breakdown confirmed | repeated large gaps |
| 3 | Fri 04 Feb 2022 | 20.10 | UNKNOWN | S01 | UNKNOWN |  | S10 breakdown confirmed |  |
| 4 | Mon 07 Feb 2022 | 21.10 | S01 | S01 | LOW | deteriorating | failed breakdown (bear trap) |  |
| 5 | Tue 08 Feb 2022 | 22.15 | S01 | S01 | LOW | deteriorating | failed breakdown (bear trap) |  |
