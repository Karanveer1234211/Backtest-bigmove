# The 20 worst trades per engine - with the warning signs that fired before entry

How to read a card: s = session (0 = the pick day, the model ranks at its close; 1 = entry day, bought at the open; 5 = sold at the close unless the lower circuit locked it). Sections 1-2 were known BEFORE entry; sections 3-4 were observed after. Breadth = advancers / (advancers + decliners) over the cached stocks. 'stock - home' = the stock's day return minus its home index's. 'held: market / stock bp' = the part of the day the position was held, split into beta x the home index (market) and the rest (stock). Size = AMFI's list in force on the pick day (blank when none was given - never filled). Environment labels and the high-stress flag are defined in tl_context.py (declared 24 Oct 2026).

## D-20260302-3 - AQYLON - net -4638 bp (gross -46.03%) - SEVERE LOSER

- D rank 3 (score 0.026) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 0.81, correlation 0.15; NIFTY beta 0.81, Smallcap beta 0.02)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 27 Feb 2026: NIFTY -1.2%, Midcap -1.1%, Smallcap -1.0%; NIFTY minus Smallcap -0.2 pts (20-day -1.6 pts); breadth 0.30 (703 up / 1,648 down of 2,382; 10-day 0.44); VIX 13.7 (day +4.9%, 5-day -4.6%, 73rd percentile); environment: Broad bearish.
- Pick day: Mon 02 Mar 2026: NIFTY -1.2%, Midcap -1.7%, Smallcap -1.9%; NIFTY minus Smallcap +0.7 pts (20-day -1.4 pts); breadth 0.13 (310 up / 2,068 down of 2,385; 10-day 0.41); VIX 17.1 (day +25.0%, 5-day +20.9%, 90th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 90th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-3.8 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 10 sessions, mature) | S10 breakdown CONFIRMED (3d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W5 VIX up 15% or more in 5 days; W6 Smallcap fell 1.5% or more on the pick day

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.015, pred_mae_q20 -0.107, pred_mae_q50 -0.053, pred_mae_q80 -0.020, pred_mfe_q20 0.037, pred_mfe_q50 0.092, pred_mfe_q80 0.134, prob_big 0.742, prob_deep 0.366, prob_trap 0.209, prob_win 0.629

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 02 Mar | -5.0% | 0.0% | -1.2% | -1.7% | -1.9% | 0.13 | 17.1 | HIGH STRESS | -3.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 04 Mar | -5.0% | -1.0% | -1.5% | -2.2% | -2.1% | 0.14 | 21.1 | HIGH STRESS | -3.4 pts | +31 / -131 | 100% | -118 | -118 | buy open |
| 2 | Thu 05 Mar | +5.0% | +4.4% | +1.2% | +1.5% | +1.4% | 0.70 | 17.9 | HIGH STRESS | +3.8 pts | +95 / +403 | 100% | +493 | +375 |  |
| 3 | Fri 06 Mar | -4.5% | -6.5% | -1.3% | -0.7% | -0.3% | 0.35 | 19.9 | HIGH STRESS | -3.2 pts | -104 / -344 | 100% | -466 | -91 |  |
| 4 | Mon 09 Mar | -5.0% | 0.0% | -1.7% | -2.0% | -2.3% | 0.14 | 23.4 | HIGH STRESS | -3.2 pts | -141 / -356 | 100% | -493 | -584 |  |
| 5 | Tue 10 Mar | -4.9% | 0.0% | +1.0% | +1.6% | +2.1% | 0.84 | 18.9 | HIGH STRESS | -5.9 pts | +79 / -573 | 100% | -466 | -1049 |  |
| 6 | Wed 11 Mar | -5.0% | 0.0% | -1.6% | -1.1% | -0.4% | 0.38 | 21.1 | HIGH STRESS | -3.4 pts | -132 / -367 | 100% | -447 | -1497 |  |
| 7 | Thu 12 Mar | -4.9% | 0.0% | -1.0% | -0.2% | -0.4% | 0.34 | 21.5 | HIGH STRESS | -4.0 pts | -78 / -415 | 100% | -420 | -1917 |  |
| 8 | Fri 13 Mar | -5.0% | 0.0% | -2.1% | -2.7% | -2.7% | 0.10 | 22.6 | HIGH STRESS | -2.9 pts | -168 / -328 | 100% | -402 | -2319 |  |
| 9 | Mon 16 Mar | -5.0% | 0.0% | +1.1% | -0.4% | -0.4% | 0.34 | 21.6 | HIGH STRESS | -6.1 pts | +91 / -589 | 100% | -384 | -2702 |  |
| 10 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts | +60 / -559 | 100% | -365 | -3068 |  |
| 11 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +68 / -567 | 100% | -347 | -3415 |  |
| 12 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -266 / -232 | 100% | -329 | -3744 |  |
| 13 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +40 / -535 | 100% | -311 | -4054 |  |
| 14 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -212 / -278 | 100% | -292 | -4346 |  |
| 15 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +132 / -615 | 0% | -291 | -4638 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 04 Mar 2026 at the open 109.50; sold Tue 24 Mar 2026 at the open 59.10 (lower-circuit lock: sold at the first free open). Gross -46.03%, costs -35 bp, net -4638 bp.
- Over the same hold: NIFTY -6.2%, Midcap -6.1%, Smallcap -5.2%; VIX +56.0%; breadth averaged 0.42; 15 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3983 bp, Midcap -3991 bp, Smallcap -4082 bp.
- Split: market part -5.04% = beta 0.81 x NIFTY 50 -6.19%; stock part -40.99% -> **mostly the stock itself**.
- The stock's own strongest day: session 2 (+403 bp beyond its market); weakest: session 15 (-615 bp).

_Pick day Mon 02 Mar 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -1.9%, breadth 0.13, VIX 17.1 (+21% in 5 days) -> D rank 3 AQYLON (moves with NIFTY 50, beta 0.81) -> bought Wed 04 Mar 2026 open, sold Tue 24 Mar 2026 open: gross -46.03%, net -4638 bp -> during the hold NIFTY -6.2%, Smallcap -5.2%, 15 high-stress day(s) -> market part -5.04%, stock part -40.99%: mostly the stock itself._

## D-20260317-1 - AQYLON - net -3847 bp (gross -38.12%) - SEVERE LOSER

- D rank 1 (score 0.045) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.19, correlation 0.24; NIFTY beta 1.19, Smallcap beta 0.30)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 16 Mar 2026: NIFTY +1.1%, Midcap -0.4%, Smallcap -0.4%; NIFTY minus Smallcap +1.5 pts (20-day -0.7 pts); breadth 0.34 (805 up / 1,580 down of 2,402; 10-day 0.35); VIX 21.6 (day -4.6%, 5-day -7.5%, 98th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 98th percentile of 250 sessions.
- Pick day: Tue 17 Mar 2026: NIFTY +0.7%, Midcap +1.0%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day -1.4 pts); breadth 0.63 (1,487 up / 889 down of 2,399; 10-day 0.40); VIX 19.8 (day -8.4%, 5-day +4.7%, 95th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 95th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-5.7 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 20 sessions, mature) | S10 breakdown CONFIRMED (6d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.014, pred_mae_q20 -0.107, pred_mae_q50 -0.044, pred_mae_q80 -0.016, pred_mfe_q20 0.035, pred_mfe_q50 0.095, pred_mfe_q80 0.192, prob_big 0.670, prob_deep 0.311, prob_trap 0.294, prob_win 0.533

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +73 / -73 | 100% | -18 | -18 | buy open |
| 2 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -387 / -110 | 100% | -498 | -515 |  |
| 3 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +58 / -553 | 100% | -470 | -986 |  |
| 4 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -309 / -181 | 100% | -443 | -1428 |  |
| 5 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +211 / -710 | 100% | -429 | -1857 |  |
| 6 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +204 / -696 | 100% | -401 | -2258 |  |
| 7 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -248 / -251 | 100% | -387 | -2645 |  |
| 8 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -254 / -234 | 100% | -360 | -3005 |  |
| 9 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +185 / -684 | 100% | -350 | -3355 |  |
| 10 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +18 / -516 | 100% | -332 | -3687 |  |
| 11 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +133 / -632 | 100% | -315 | -4002 |  |
| 12 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +80 / -579 | 100% | -300 | -4302 |  |
| 13 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +449 / -30 | 100% | +239 | -4063 |  |
| 14 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -44 / +436 | 0% | +216 | -3847 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 18 Mar 2026 at the open 72.30; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -38.12%, costs -35 bp, net -3847 bp.
- Over the same hold: NIFTY +1.2%, Midcap +2.5%, Smallcap +3.7%; VIX -0.5%; breadth averaged 0.56; 14 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3929 bp, Midcap -4061 bp, Smallcap -4180 bp.
- Split: market part +1.39% = beta 1.19 x NIFTY 50 +1.17%; stock part -39.51% -> **mostly the stock itself**.
- The stock's own strongest day: session 14 (+436 bp beyond its market); weakest: session 5 (-710 bp).

_Pick day Tue 17 Mar 2026 [HIGH STRESS]: NIFTY +0.7%, Smallcap +0.6%, breadth 0.63, VIX 19.8 (+5% in 5 days) -> D rank 1 AQYLON (moves with NIFTY 50, beta 1.19) -> bought Wed 18 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -38.12%, net -3847 bp -> during the hold NIFTY +1.2%, Smallcap +3.7%, 14 high-stress day(s) -> market part +1.39%, stock part -39.51%: mostly the stock itself._

## D-20200313-3 - ORISSAMINE - net -3612 bp (gross -35.77%) - SEVERE LOSER

- D rank 3 (score 0.064) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.04, correlation 0.27; NIFTY beta 0.92, Smallcap beta 1.04)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 12 Mar 2020: NIFTY -8.3% (7.0 sd fall), Midcap -7.8% (7.1 sd fall), Smallcap -8.9% (7.4 sd fall); NIFTY minus Smallcap +0.6 pts (20-day +1.9 pts); breadth 0.04 (52 up / 1,358 down of 1,442; 10-day 0.28); VIX 41.2 (day +30.4%, 5-day +69.9%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +70% in 5 sessions; NIFTY -7.0 sd day; Smallcap -7.4 sd day.
- Pick day: Fri 13 Mar 2020: NIFTY +3.8% (2.4 sd rise), Midcap +2.3%, Smallcap +0.7%; NIFTY minus Smallcap +3.1 pts (20-day +3.6 pts); breadth 0.56 (773 up / 610 down of 1,432; 10-day 0.30); VIX 51.5 (day +25.0%, 5-day +121.4%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +121% in 5 sessions.
- The stock: day before -5.0%, pick day -4.1% (-4.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (MEDIUM, 5 sessions, early) | S10 breakdown NEW today | risk: bearish divergence candidate (RSI) | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40; W5 VIX up 15% or more in 5 days; W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 13 Mar | -4.1% | +1.0% | +3.8% | +2.3% | +0.7% | 0.56 | 51.5 | HIGH STRESS | -4.8 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 16 Mar | -5.0% | -3.2% | -7.6% | -5.9% | -5.4% | 0.12 | 58.9 | HIGH STRESS | +0.4 pts | -194 / -125 | 100% | -337 | -337 | buy open |
| 2 | Tue 17 Mar | -5.0% | -1.3% | -2.5% | -2.4% | -2.3% | 0.29 | 62.9 | HIGH STRESS | -2.7 pts | -241 / -258 | 100% | -484 | -821 |  |
| 3 | Wed 18 Mar | -5.0% | 0.0% | -5.6% | -5.4% | -6.1% | 0.11 | 64.0 | HIGH STRESS | +1.1 pts | -631 / +131 | 100% | -460 | -1280 |  |
| 4 | Thu 19 Mar | -5.0% | 0.0% | -2.4% | -4.0% | -5.2% | 0.19 | 72.2 | HIGH STRESS | +0.2 pts | -544 / +44 | 100% | -437 | -1717 |  |
| 5 | Fri 20 Mar | -5.0% | 0.0% | +5.8% | +4.4% | +2.2% | 0.67 | 67.1 | HIGH STRESS | -7.2 pts | +233 / -733 | 100% | -415 | -2132 |  |
| 6 | Mon 23 Mar | -5.0% | 0.0% | -13.0% | -13.0% | -12.4% | 0.04 | 72.0 | HIGH STRESS | +7.4 pts | -1286 / +786 | 100% | -394 | -2526 |  |
| 7 | Tue 24 Mar | -5.0% | 0.0% | +2.5% | +1.0% | -1.0% | 0.43 | 83.6 | HIGH STRESS | -4.0 pts | -100 / -400 | 100% | -374 | -2901 |  |
| 8 | Wed 25 Mar | -5.0% | 0.0% | +6.6% | +3.3% | +2.5% | 0.65 | 77.6 | HIGH STRESS | -7.5 pts | +259 / -759 | 100% | -356 | -3256 |  |
| 9 | Thu 26 Mar | -5.0% | 0.0% | +3.9% | +3.7% | +3.5% | 0.74 | 71.5 | HIGH STRESS | -8.5 pts | +360 / -860 | 100% | -338 | -3594 |  |
| 10 | Fri 27 Mar | -5.0% | -5.0% | +0.2% | -0.4% | +0.9% | 0.54 | 70.4 | HIGH STRESS | -5.9 pts | +330 / -330 | 0% | -18 | -3612 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 16 Mar 2020 at the open 1488.00; sold Fri 27 Mar 2020 at the open 955.75 (lower-circuit lock: sold at the first free open). Gross -35.77%, costs -35 bp, net -3612 bp.
- Over the same hold: NIFTY -6.7%, Midcap -12.4%, Smallcap -17.2%; VIX +39.0%; breadth averaged 0.38; 10 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2911 bp, Midcap -2335 bp, Smallcap -1854 bp.
- Split: market part -17.85% = beta 1.04 x Smallcap 250 -17.23%; stock part -17.92% -> **market and stock together**.
- The stock's own strongest day: session 6 (+786 bp beyond its market); weakest: session 9 (-860 bp).

_Pick day Fri 13 Mar 2020 [HIGH STRESS]: NIFTY +3.8%, Smallcap +0.7%, breadth 0.56, VIX 51.5 (+121% in 5 days) -> D rank 3 ORISSAMINE (moves with Smallcap 250, beta 1.04) -> bought Mon 16 Mar 2020 open, sold Fri 27 Mar 2020 open: gross -35.77%, net -3612 bp -> during the hold NIFTY -6.7%, Smallcap -17.2%, 10 high-stress day(s) -> market part -17.85%, stock part -17.92%: market and stock together._

## D-20260318-1 - AQYLON - net -3523 bp (gross -34.88%) - SEVERE LOSER

- D rank 1 (score 0.022) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.11, correlation 0.23; NIFTY beta 1.11, Smallcap beta 0.22)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 17 Mar 2026: NIFTY +0.7%, Midcap +1.0%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day -1.4 pts); breadth 0.63 (1,487 up / 889 down of 2,399; 10-day 0.40); VIX 19.8 (day -8.4%, 5-day +4.7%, 95th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 95th percentile of 250 sessions.
- Pick day: Wed 18 Mar 2026: NIFTY +0.8%, Midcap +1.9%, Smallcap +1.8%; NIFTY minus Smallcap -0.9 pts (20-day -1.7 pts); breadth 0.85 (2,024 up / 361 down of 2,403; 10-day 0.47); VIX 18.7 (day -5.4%, 5-day -11.1%, 93rd percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 93rd percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-5.8 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 21 sessions, mature) | S10 breakdown CONFIRMED (7d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.006, pred_mae_q20 -0.127, pred_mae_q50 -0.047, pred_mae_q80 -0.014, pred_mfe_q20 0.012, pred_mfe_q50 0.086, pred_mfe_q80 0.176, prob_big 0.656, prob_deep 0.408, prob_trap 0.328, prob_win 0.482

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -93 / +93 | 100% | -18 | -18 | buy open |
| 2 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +54 / -549 | 100% | -495 | -512 |  |
| 3 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -288 / -202 | 100% | -466 | -978 |  |
| 4 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +197 / -696 | 100% | -451 | -1429 |  |
| 5 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +191 / -682 | 100% | -422 | -1852 |  |
| 6 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -231 / -268 | 100% | -408 | -2259 |  |
| 7 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -237 / -251 | 100% | -378 | -2638 |  |
| 8 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +173 / -672 | 100% | -368 | -3006 |  |
| 9 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +16 / -515 | 100% | -349 | -3355 |  |
| 10 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +124 / -623 | 100% | -332 | -3687 |  |
| 11 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +75 / -574 | 100% | -316 | -4003 |  |
| 12 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +419 / +0 | 100% | +252 | -3751 |  |
| 13 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -41 / +433 | 0% | +228 | -3523 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 19 Mar 2026 at the open 68.70; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -34.88%, costs -35 bp, net -3523 bp.
- Over the same hold: NIFTY +3.1%, Midcap +2.4%, Smallcap +3.8%; VIX +5.2%; breadth averaged 0.53; 13 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3794 bp, Midcap -3731 bp, Smallcap -3867 bp.
- Split: market part +3.40% = beta 1.11 x NIFTY 50 +3.07%; stock part -38.27% -> **mostly the stock itself**.
- The stock's own strongest day: session 13 (+433 bp beyond its market); weakest: session 4 (-696 bp).

_Pick day Wed 18 Mar 2026 [HIGH STRESS]: NIFTY +0.8%, Smallcap +1.8%, breadth 0.85, VIX 18.7 (-11% in 5 days) -> D rank 1 AQYLON (moves with NIFTY 50, beta 1.11) -> bought Thu 19 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -34.88%, net -3523 bp -> during the hold NIFTY +3.1%, Smallcap +3.8%, 13 high-stress day(s) -> market part +3.40%, stock part -38.27%: mostly the stock itself._

## D-20220117-2 - TTML - net -3411 bp (gross -33.76%) - SEVERE LOSER

- D rank 2 (score 0.027) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.63, correlation 0.18; NIFTY beta 0.29, Smallcap beta 0.63)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 14 Jan 2022: NIFTY 0.0%, Midcap 0.0%, Smallcap +0.7%; NIFTY minus Smallcap -0.7 pts (20-day -2.1 pts); breadth 0.60 (989 up / 650 down of 1,666; 10-day 0.57); VIX 16.6 (day -0.9%, 5-day -5.9%, 42nd percentile); environment: Broad bullish.
- Pick day: Mon 17 Jan 2022: NIFTY +0.3%, Midcap +0.3%, Smallcap +0.5%; NIFTY minus Smallcap -0.2 pts (20-day -3.8 pts); breadth 0.62 (1,018 up / 629 down of 1,682; 10-day 0.55); VIX 16.8 (day +1.3%, 5-day -5.1%, 46th percentile); environment: Broad bullish.
- The stock: day before -5.0%, pick day -5.0% (-5.4 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S01 Strong bullish continuation (MEDIUM, 40 sessions, mature) | S04 breakout CONFIRMED (12d) | risk: repeated large gaps
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.013, pred_mae_q20 -0.134, pred_mae_q50 -0.073, pred_mae_q80 -0.025, pred_mfe_q20 0.013, pred_mfe_q50 0.047, pred_mfe_q80 0.108, prob_big 0.463, prob_deep 0.521, prob_trap 0.412, prob_win 0.359

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 17 Jan | -5.0% | 0.0% | +0.3% | +0.3% | +0.5% | 0.62 | 16.8 | Broad bullish | -5.4 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 18 Jan | -5.0% | 0.0% | -1.1% | -1.9% | -2.0% | 0.19 | 17.8 | Broad bullish | -2.9 pts | -153 / +153 | 100% | -18 | -18 | buy open |
| 2 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts | +14 / -513 | 100% | -499 | -516 |  |
| 3 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -7 / -492 | 100% | -474 | -990 |  |
| 4 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -118 / -380 | 100% | -450 | -1440 |  |
| 5 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -290 / -208 | 100% | -427 | -1867 |  |
| 6 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +67 / -566 | 100% | -407 | -2274 |  |
| 7 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -29 / -468 | 100% | -385 | -2659 |  |
| 8 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +33 / -532 | 100% | -367 | -3027 |  |
| 9 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +60 / -560 | 100% | -349 | -3376 |  |
| 10 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +47 / -546 | 100% | -332 | -3708 |  |
| 11 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +51 / +446 | 0% | +296 | -3411 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 18 Jan 2022 at the open 224.65; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -33.76%, costs -35 bp, net -3411 bp.
- Over the same hold: NIFTY -3.4%, Midcap -4.4%, Smallcap -5.2%; VIX +19.1%; breadth averaged 0.45; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3032 bp, Midcap -2934 bp, Smallcap -2857 bp.
- Split: market part -3.26% = beta 0.63 x Smallcap 250 -5.20%; stock part -30.50% -> **mostly the stock itself**.
- The stock's own strongest day: session 11 (+446 bp beyond its market); weakest: session 6 (-566 bp).

_Pick day Mon 17 Jan 2022 [Broad bullish]: NIFTY +0.3%, Smallcap +0.5%, breadth 0.62, VIX 16.8 (-5% in 5 days) -> D rank 2 TTML (moves with Smallcap 250, beta 0.63) -> bought Tue 18 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -33.76%, net -3411 bp -> during the hold NIFTY -3.4%, Smallcap -5.2%, 1 high-stress day(s) -> market part -3.26%, stock part -30.50%: mostly the stock itself._

## D-20220720-3 - STEELXIND - net -3265 bp (gross -32.30%) - SEVERE LOSER

- D rank 3 (score 0.019) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.67, correlation 0.31; NIFTY beta 0.59, Smallcap beta 0.67)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 19 Jul 2022: NIFTY +0.4%, Midcap +0.7%, Smallcap +0.8%; NIFTY minus Smallcap -0.5 pts (20-day -4.3 pts); breadth 0.64 (1,083 up / 622 down of 1,738; 10-day 0.57); VIX 17.2 (day +0.2%, 5-day -7.3%, 37th percentile); environment: Broad bullish.
- Pick day: Wed 20 Jul 2022: NIFTY +1.1%, Midcap +0.1%, Smallcap +0.6%; NIFTY minus Smallcap +0.5 pts (20-day -3.4 pts); breadth 0.59 (992 up / 694 down of 1,740; 10-day 0.56); VIX 16.8 (day -2.2%, 5-day -9.2%, 33rd percentile); environment: Broad bullish.
- The stock: day before -1.3%, pick day -2.0% (-2.6 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S06 Bullish reversal attempt (LOW, 15 sessions, deteriorating) -> S02 pending | S11 failed breakout (bull trap) (6d)
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.022, pred_mae_q20 -0.093, pred_mae_q50 -0.067, pred_mae_q80 -0.021, pred_mfe_q20 0.015, pred_mfe_q50 0.050, pred_mfe_q80 0.120, prob_big 0.409, prob_deep 0.227, prob_trap 0.064, prob_win 0.495

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 20 Jul | -2.0% | -2.8% | +1.1% | +0.1% | +0.6% | 0.59 | 16.8 | Broad bullish | -2.6 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 21 Jul | -0.4% | -0.7% | +0.5% | +1.3% | +0.8% | 0.63 | 16.9 | Broad bullish | -1.2 pts | +32 / -98 | 100% | -84 | -84 | buy open |
| 2 | Fri 22 Jul | -4.9% | -6.6% | +0.7% | +0.2% | +0.3% | 0.53 | 16.6 | Broad bullish | -5.2 pts | +19 / -509 | 100% | -487 | -571 |  |
| 3 | Mon 25 Jul | -2.8% | -2.1% | -0.5% | -0.1% | -0.4% | 0.39 | 17.7 | Broad bullish | -2.4 pts | -28 / -253 | 100% | -265 | -836 |  |
| 4 | Tue 26 Jul | -4.8% | 0.0% | -0.9% | -1.1% | -1.0% | 0.24 | 18.2 | Broad bullish | -3.8 pts | -69 / -413 | 100% | -442 | -1279 |  |
| 5 | Wed 27 Jul | -4.8% | 0.0% | +1.0% | +0.9% | 0.0% | 0.56 | 18.1 | Broad bullish | -4.8 pts | -0 / -481 | 100% | -420 | -1699 |  |
| 6 | Thu 28 Jul | -4.8% | 0.0% | +1.7% | +0.7% | +0.8% | 0.61 | 17.0 | Broad bullish | -5.5 pts | +51 / -530 | 100% | -398 | -2097 |  |
| 7 | Fri 29 Jul | -4.7% | 0.0% | +1.4% | +1.4% | +1.4% | 0.69 | 16.6 | Broad bullish | -6.2 pts | +96 / -571 | 100% | -376 | -2473 |  |
| 8 | Mon 01 Aug | -5.0% | 0.0% | +1.1% | +1.5% | +1.6% | 0.75 | 17.5 | Broad bullish | -6.6 pts | +111 / -609 | 100% | -376 | -2849 |  |
| 9 | Tue 02 Aug | -4.9% | 0.0% | 0.0% | +0.5% | +0.6% | 0.56 | 18.5 | Broad bullish | -5.6 pts | +42 / -535 | 100% | -354 | -3203 |  |
| 10 | Wed 03 Aug | -4.9% | 0.0% | +0.2% | -0.5% | -0.4% | 0.33 | 18.4 | Broad bullish | -4.5 pts | -27 / -460 | 100% | -332 | -3535 |  |
| 11 | Thu 04 Aug | +4.8% | +0.3% | 0.0% | +0.5% | -0.3% | 0.46 | 19.3 | Broad bullish | +5.0 pts | +35 / +408 | 0% | +270 | -3265 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 21 Jul 2022 at the open 22.60; sold Thu 04 Aug 2022 at the open 15.30 (lower-circuit lock: sold at the first free open). Gross -32.30%, costs -35 bp, net -3265 bp.
- Over the same hold: NIFTY +5.7%, Midcap +5.2%, Smallcap +3.9%; VIX +9.7%; breadth averaged 0.52; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3799 bp, Midcap -3751 bp, Smallcap -3621 bp.
- Split: market part +2.64% = beta 0.67 x Smallcap 250 +3.91%; stock part -34.94% -> **mostly the stock itself**.
- The stock's own strongest day: session 11 (+408 bp beyond its market); weakest: session 8 (-609 bp).

_Pick day Wed 20 Jul 2022 [Broad bullish]: NIFTY +1.1%, Smallcap +0.6%, breadth 0.59, VIX 16.8 (-9% in 5 days) -> D rank 3 STEELXIND (moves with Smallcap 250, beta 0.67) -> bought Thu 21 Jul 2022 open, sold Thu 04 Aug 2022 open: gross -32.30%, net -3265 bp -> during the hold NIFTY +5.7%, Smallcap +3.9% -> market part +2.64%, stock part -34.94%: mostly the stock itself._

## D-20251201-3 - KAYNES - net -2944 bp (gross -29.09%) - SEVERE LOSER

- D rank 3 (score 0.011) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 1.09, correlation 0.34; NIFTY beta 1.25, Smallcap beta 0.97)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 28 Nov 2025: NIFTY 0.0%, Midcap -0.1%, Smallcap -0.2%; NIFTY minus Smallcap +0.2 pts (20-day +5.2 pts); breadth 0.45 (1,027 up / 1,264 down of 2,333; 10-day 0.43); VIX 11.6 (day -1.4%, 5-day -14.7%, 20th percentile); environment: Narrow bullish.
- Pick day: Mon 01 Dec 2025: NIFTY -0.1%, Midcap -0.1%, Smallcap +0.2%; NIFTY minus Smallcap -0.3 pts (20-day +4.9 pts); breadth 0.41 (951 up / 1,360 down of 2,338; 10-day 0.41); VIX 11.6 (day +0.1%, 5-day -12.2%, 21st percentile); environment: Narrow bullish.
- The stock: day before -1.5%, pick day -2.4% (-2.3 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): S08 Bearish continuation (HIGH, 14 sessions, mature) | S10 breakdown NEW (2d) | risk: stretched far below EMA20
- Warning signs that fired before entry: W3 narrow bullish at the pick; W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.002, pred_mae_q20 -0.055, pred_mae_q50 -0.031, pred_mae_q80 -0.007, pred_mfe_q20 0.021, pred_mfe_q50 0.051, pred_mfe_q80 0.078, prob_big 0.503, prob_deep 0.128, prob_trap 0.002, prob_win 0.577

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 01 Dec | -2.4% | -2.7% | -0.1% | -0.1% | +0.2% | 0.41 | 11.6 | Narrow bullish | -2.3 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 02 Dec | +0.9% | +0.7% | -0.5% | -0.2% | -0.4% | 0.29 | 11.2 | Narrow bullish | +1.1 pts | -24 / +97 | 100% | +56 | +56 | buy open |
| 2 | Wed 03 Dec | -1.9% | -2.1% | -0.2% | -0.9% | -0.4% | 0.29 | 11.2 | Narrow bullish | -1.0 pts | -97 / -91 | 100% | -189 | -133 |  |
| 3 | Thu 04 Dec | -6.2% | -6.2% | +0.2% | 0.0% | -0.2% | 0.42 | 10.8 | Narrow bullish | -6.2 pts | -5 / -615 | 100% | -613 | -746 |  |
| 4 | Fri 05 Dec | -12.5% | -10.5% | +0.6% | +0.4% | -0.5% | 0.40 | 10.3 | Narrow bullish | -12.9 pts | +43 / -1297 | 100% | -1163 | -1909 |  |
| 5 | Mon 08 Dec | -12.6% | -13.7% | -0.9% | -1.7% | -2.3% | 0.12 | 11.1 | HIGH STRESS | -10.9 pts | -185 / -1070 | 0% | -1035 | -2944 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 02 Dec 2025 at the open 5369.00; sold Mon 08 Dec 2025 at the close 3807.00. Gross -29.09%, costs -35 bp, net -2944 bp.
- Over the same hold: NIFTY -0.5%, Midcap -2.4%, Smallcap -3.8%; VIX -4.3%; breadth averaged 0.30; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2860 bp, Midcap -2665 bp, Smallcap -2525 bp.
- Split: market part -2.66% = beta 1.09 x Midcap 150 -2.44%; stock part -26.43% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+97 bp beyond its market); weakest: session 4 (-1297 bp).

_Pick day Mon 01 Dec 2025 [Narrow bullish]: NIFTY -0.1%, Smallcap +0.2%, breadth 0.41, VIX 11.6 (-12% in 5 days) -> D rank 3 KAYNES (moves with Midcap 150, beta 1.09) -> bought Tue 02 Dec 2025 open, sold Mon 08 Dec 2025 close: gross -29.09%, net -2944 bp -> during the hold NIFTY -0.5%, Smallcap -3.8%, 1 high-stress day(s) -> market part -2.66%, stock part -26.43%: mostly the stock itself._

## D-20260320-3 - AQYLON - net -2830 bp (gross -27.95%) - SEVERE LOSER

- D rank 3 (score 0.018) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.13, correlation 0.24; NIFTY beta 1.13, Smallcap beta 0.29)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 19 Mar 2026: NIFTY -3.3% (3.6 sd fall), Midcap -3.1% (2.7 sd fall), Smallcap -2.6% (2.1 sd fall); NIFTY minus Smallcap -0.6 pts (20-day -2.1 pts); breadth 0.09 (224 up / 2,155 down of 2,397; 10-day 0.41); VIX 22.8 (day +21.8%, 5-day +5.9%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; NIFTY -3.6 sd day.
- Pick day: Fri 20 Mar 2026: NIFTY +0.5%, Midcap +0.6%, Smallcap +0.3%; NIFTY minus Smallcap +0.2 pts (20-day -1.7 pts); breadth 0.59 (1,409 up / 963 down of 2,402; 10-day 0.43); VIX 22.8 (day 0.0%, 5-day +0.7%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -4.9% (-5.4 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 23 sessions, mature) | S10 breakdown CONFIRMED (9d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.002, pred_mae_q20 -0.121, pred_mae_q50 -0.049, pred_mae_q80 -0.014, pred_mfe_q20 0.013, pred_mfe_q50 0.093, pred_mfe_q80 0.161, prob_big 0.694, prob_deep 0.377, prob_trap 0.277, prob_win 0.483

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -155 / +155 | 100% | -18 | -18 | buy open |
| 2 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +201 / -701 | 100% | -499 | -517 |  |
| 3 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +195 / -687 | 100% | -467 | -984 |  |
| 4 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -237 / -262 | 100% | -451 | -1435 |  |
| 5 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -243 / -245 | 100% | -419 | -1853 |  |
| 6 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +177 / -676 | 100% | -407 | -2261 |  |
| 7 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +17 / -515 | 100% | -386 | -2647 |  |
| 8 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +127 / -626 | 100% | -367 | -3014 |  |
| 9 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +77 / -576 | 100% | -349 | -3364 |  |
| 10 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +428 / -10 | 100% | +279 | -3085 |  |
| 11 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -42 / +434 | 0% | +255 | -2830 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 23 Mar 2026 at the open 62.10; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -27.95%, costs -35 bp, net -2830 bp.
- Over the same hold: NIFTY +4.8%, Midcap +4.6%, Smallcap +5.8%; VIX -13.6%; breadth averaged 0.57; 11 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3271 bp, Midcap -3252 bp, Smallcap -3376 bp.
- Split: market part +5.39% = beta 1.13 x NIFTY 50 +4.75%; stock part -33.34% -> **mostly the stock itself**.
- The stock's own strongest day: session 11 (+434 bp beyond its market); weakest: session 2 (-701 bp).

_Pick day Fri 20 Mar 2026 [HIGH STRESS]: NIFTY +0.5%, Smallcap +0.3%, breadth 0.59, VIX 22.8 (+1% in 5 days) -> D rank 3 AQYLON (moves with NIFTY 50, beta 1.13) -> bought Mon 23 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -27.95%, net -2830 bp -> during the hold NIFTY +4.8%, Smallcap +5.8%, 11 high-stress day(s) -> market part +5.39%, stock part -33.34%: mostly the stock itself._

## D-20220722-2 - STEELXIND - net -2818 bp (gross -27.83%) - SEVERE LOSER

- D rank 2 (score 0.015) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.65, correlation 0.30; NIFTY beta 0.57, Smallcap beta 0.65)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 21 Jul 2022: NIFTY +0.5%, Midcap +1.3%, Smallcap +0.8%; NIFTY minus Smallcap -0.3 pts (20-day -3.4 pts); breadth 0.63 (1,071 up / 618 down of 1,738; 10-day 0.55); VIX 16.9 (day +0.2%, 5-day -8.1%, 34th percentile); environment: Broad bullish.
- Pick day: Fri 22 Jul 2022: NIFTY +0.7%, Midcap +0.2%, Smallcap +0.3%; NIFTY minus Smallcap +0.4 pts (20-day -2.1 pts); breadth 0.53 (897 up / 797 down of 1,736; 10-day 0.55); VIX 16.6 (day -1.2%, 5-day -5.4%, 30th percentile); environment: Broad bullish.
- The stock: day before -0.4%, pick day -4.9% (-5.2 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S02 Emerging bullish trend (HIGH, 3 sessions, early) | S11 failed breakout (bull trap) (8d)
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.021, pred_mae_q20 -0.094, pred_mae_q50 -0.064, pred_mae_q80 -0.020, pred_mfe_q20 0.021, pred_mfe_q50 0.058, pred_mfe_q80 0.115, prob_big 0.458, prob_deep 0.253, prob_trap 0.052, prob_win 0.518

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 22 Jul | -4.9% | -6.6% | +0.7% | +0.2% | +0.3% | 0.53 | 16.6 | Broad bullish | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 25 Jul | -2.8% | -2.1% | -0.5% | -0.1% | -0.4% | 0.39 | 17.7 | Broad bullish | -2.4 pts | -31 / -182 | 100% | -230 | -230 | buy open |
| 2 | Tue 26 Jul | -4.8% | 0.0% | -0.9% | -1.1% | -1.0% | 0.24 | 18.2 | Broad bullish | -3.8 pts | -67 / -415 | 100% | -472 | -701 |  |
| 3 | Wed 27 Jul | -4.8% | 0.0% | +1.0% | +0.9% | 0.0% | 0.56 | 18.1 | Broad bullish | -4.8 pts | -0 / -481 | 100% | -448 | -1150 |  |
| 4 | Thu 28 Jul | -4.8% | 0.0% | +1.7% | +0.7% | +0.8% | 0.61 | 17.0 | Broad bullish | -5.5 pts | +49 / -528 | 100% | -425 | -1574 |  |
| 5 | Fri 29 Jul | -4.7% | 0.0% | +1.4% | +1.4% | +1.4% | 0.69 | 16.6 | Broad bullish | -6.2 pts | +93 / -567 | 100% | -401 | -1975 |  |
| 6 | Mon 01 Aug | -5.0% | 0.0% | +1.1% | +1.5% | +1.6% | 0.75 | 17.5 | Broad bullish | -6.6 pts | +107 / -606 | 100% | -401 | -2376 |  |
| 7 | Tue 02 Aug | -4.9% | 0.0% | 0.0% | +0.5% | +0.6% | 0.56 | 18.5 | Broad bullish | -5.6 pts | +40 / -534 | 100% | -377 | -2753 |  |
| 8 | Wed 03 Aug | -4.9% | 0.0% | +0.2% | -0.5% | -0.4% | 0.33 | 18.4 | Broad bullish | -4.5 pts | -26 / -461 | 100% | -354 | -3107 |  |
| 9 | Thu 04 Aug | +4.8% | +0.3% | 0.0% | +0.5% | -0.3% | 0.46 | 19.3 | Broad bullish | +5.0 pts | +34 / +410 | 0% | +289 | -2818 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 25 Jul 2022 at the open 21.20; sold Thu 04 Aug 2022 at the open 15.30 (lower-circuit lock: sold at the first free open). Gross -27.83%, costs -35 bp, net -2818 bp.
- Over the same hold: NIFTY +4.8%, Midcap +3.8%, Smallcap +3.1%; VIX +10.8%; breadth averaged 0.51; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3263 bp, Midcap -3160 bp, Smallcap -3090 bp.
- Split: market part +2.01% = beta 0.65 x Smallcap 250 +3.07%; stock part -29.84% -> **mostly the stock itself**.
- The stock's own strongest day: session 9 (+410 bp beyond its market); weakest: session 6 (-606 bp).

_Pick day Fri 22 Jul 2022 [Broad bullish]: NIFTY +0.7%, Smallcap +0.3%, breadth 0.53, VIX 16.6 (-5% in 5 days) -> D rank 2 STEELXIND (moves with Smallcap 250, beta 0.65) -> bought Mon 25 Jul 2022 open, sold Thu 04 Aug 2022 open: gross -27.83%, net -2818 bp -> during the hold NIFTY +4.8%, Smallcap +3.1% -> market part +2.01%, stock part -29.84%: mostly the stock itself._

## D-20210803-2 - VEEDOL - net -2814 bp (gross -27.79%) - SEVERE LOSER

- D rank 2 (score 0.018) | the other engine ranked it 6 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.43, correlation 0.11; NIFTY beta 0.41, Smallcap beta 0.43)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 02 Aug 2021: NIFTY +0.8%, Midcap +1.3%, Smallcap +0.8%; NIFTY minus Smallcap 0.0 pts (20-day -6.3 pts); breadth 0.68 (1,056 up / 501 down of 1,595; 10-day 0.48); VIX 12.8 (day +0.1%, 5-day +2.9%, 6th percentile); environment: Narrow bullish.
- Pick day: Tue 03 Aug 2021: NIFTY +1.5% (2.5 sd rise), Midcap +0.2%, Smallcap -0.2%; NIFTY minus Smallcap +1.8 pts (20-day -4.0 pts); breadth 0.51 (790 up / 749 down of 1,581; 10-day 0.49); VIX 13.8 (day +7.3%, 5-day +3.9%, 11th percentile); environment: Narrow bullish.
- The stock: day before -5.0%, pick day +0.6% (+0.9 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): UNKNOWN - evidence conflicts (8 sessions) | risk: price up, volume flow down (candidate) | volatility extreme
- Warning signs that fired before entry: W3 narrow bullish at the pick

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 03 Aug | +0.6% | +0.8% | +1.5% | +0.2% | -0.2% | 0.51 | 13.8 | Narrow bullish | +0.9 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 04 Aug | -3.0% | -3.8% | +0.8% | -1.0% | -1.1% | 0.26 | 13.2 | Broad bullish | -1.9 pts | -74 / -301 | 100% | -393 | -393 | buy open |
| 2 | Thu 05 Aug | -5.0% | -4.8% | +0.2% | 0.0% | -0.5% | 0.32 | 12.9 | Narrow bullish | -4.5 pts | -23 / -476 | 100% | -481 | -874 |  |
| 3 | Fri 06 Aug | -5.0% | 0.0% | -0.3% | 0.0% | +0.1% | 0.55 | 12.6 | Narrow bullish | -5.1 pts | +6 / -506 | 100% | -457 | -1332 |  |
| 4 | Mon 09 Aug | -5.0% | -0.9% | +0.1% | -0.7% | -1.0% | 0.32 | 12.6 | Narrow bullish | -4.0 pts | -45 / -455 | 100% | -434 | -1766 |  |
| 5 | Tue 10 Aug | -5.0% | 0.0% | +0.1% | -1.1% | -2.6% | 0.14 | 12.7 | HIGH STRESS | -2.4 pts | -112 / -388 | 100% | -412 | -2178 |  |
| 6 | Wed 11 Aug | -5.0% | 0.0% | 0.0% | -0.4% | -0.5% | 0.33 | 12.7 | Narrow bullish | -4.5 pts | -23 / -477 | 100% | -392 | -2570 |  |
| 7 | Thu 12 Aug | -0.2% | +3.0% | +0.5% | +1.0% | +2.3% | 0.83 | 12.4 | HIGH STRESS | -2.4 pts | +19 / -323 | 0% | -243 | -2814 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 04 Aug 2021 at the open 2998.00; sold Thu 12 Aug 2021 at the open 2165.00 (lower-circuit lock: sold at the first free open). Gross -27.79%, costs -35 bp, net -2814 bp.
- Over the same hold: NIFTY +0.7%, Midcap -3.2%, Smallcap -5.7%; VIX -7.6%; breadth averaged 0.39; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2845 bp, Midcap -2454 bp, Smallcap -2205 bp.
- Split: market part -2.48% = beta 0.43 x Smallcap 250 -5.74%; stock part -25.30% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (-301 bp beyond its market); weakest: session 3 (-506 bp).

_Pick day Tue 03 Aug 2021 [Narrow bullish]: NIFTY +1.5%, Smallcap -0.2%, breadth 0.51, VIX 13.8 (+4% in 5 days) -> D rank 2 VEEDOL (moves with Smallcap 250, beta 0.43) -> bought Wed 04 Aug 2021 open, sold Thu 12 Aug 2021 open: gross -27.79%, net -2814 bp -> during the hold NIFTY +0.7%, Smallcap -5.7%, 2 high-stress day(s) -> market part -2.48%, stock part -25.30%: mostly the stock itself._

## D-20230120-2 - KIRIINDUS - net -2732 bp (gross -26.97%) - SEVERE LOSER

- D rank 2 (score 0.017) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 0.27, correlation 0.14; NIFTY beta 0.22, Smallcap beta 0.26)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 19 Jan 2023: NIFTY -0.3%, Midcap -0.1%, Smallcap -0.3%; NIFTY minus Smallcap 0.0 pts (20-day -0.4 pts); breadth 0.39 (679 up / 1,072 down of 1,804; 10-day 0.45); VIX 14.0 (day -2.9%, 5-day -8.6%, 7th percentile); environment: Broad bearish.
- Pick day: Fri 20 Jan 2023: NIFTY -0.4%, Midcap -0.7%, Smallcap -0.6%; NIFTY minus Smallcap +0.1 pts (20-day -3.0 pts); breadth 0.35 (616 up / 1,143 down of 1,808; 10-day 0.45); VIX 13.8 (day -1.2%, 5-day -4.6%, 6th percentile); environment: Broad bearish.
- The stock: day before -2.8%, pick day -7.7% (-6.9 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 14 sessions, mature) | S10 breakdown CONFIRMED (4d) | risk: stretched far below EMA20; large down candle in the last 5 sessions
- Warning signs that fired before entry: W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.015, pred_mae_q20 -0.062, pred_mae_q50 -0.025, pred_mae_q80 -0.010, pred_mfe_q20 0.024, pred_mfe_q50 0.052, pred_mfe_q80 0.094, prob_big 0.456, prob_deep 0.114, prob_trap 0.002, prob_win 0.644

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 20 Jan | -7.7% | -7.8% | -0.4% | -0.7% | -0.6% | 0.35 | 13.8 | Broad bearish | -6.9 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 23 Jan | -1.2% | -1.2% | +0.5% | +0.2% | -0.1% | 0.44 | 13.6 | Broad bearish | -1.4 pts | +1 / -122 | 100% | -139 | -139 | buy open |
| 2 | Tue 24 Jan | -2.4% | -0.9% | 0.0% | -0.3% | -0.4% | 0.38 | 13.7 | Broad bearish | -2.0 pts | -9 / -228 | 100% | -235 | -374 |  |
| 3 | Wed 25 Jan | -8.7% | -8.5% | -1.2% | -1.3% | -0.9% | 0.20 | 14.7 | Broad bearish | -7.5 pts | -34 / -838 | 100% | -841 | -1214 |  |
| 4 | Fri 27 Jan | -15.7% | -15.7% | -1.6% | -1.2% | -1.8% | 0.15 | 17.3 | Broad bearish | -14.5 pts | -34 / -1537 | 100% | -1382 | -2597 |  |
| 5 | Mon 30 Jan | -1.6% | -2.1% | +0.3% | -0.2% | -0.2% | 0.41 | 17.7 | HIGH STRESS | -1.4 pts | -4 / -154 | 0% | -135 | -2732 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 23 Jan 2023 at the open 383.05; sold Mon 30 Jan 2023 at the close 279.75. Gross -26.97%, costs -35 bp, net -2732 bp.
- Over the same hold: NIFTY -2.6%, Midcap -2.9%, Smallcap -3.8%; VIX +28.4%; breadth averaged 0.32; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2438 bp, Midcap -2404 bp, Smallcap -2321 bp.
- Split: market part -0.80% = beta 0.27 x Midcap 150 -2.93%; stock part -26.17% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (-122 bp beyond its market); weakest: session 4 (-1537 bp).

_Pick day Fri 20 Jan 2023 [Broad bearish]: NIFTY -0.4%, Smallcap -0.6%, breadth 0.35, VIX 13.8 (-5% in 5 days) -> D rank 2 KIRIINDUS (moves with Midcap 150, beta 0.27) -> bought Mon 23 Jan 2023 open, sold Mon 30 Jan 2023 close: gross -26.97%, net -2732 bp -> during the hold NIFTY -2.6%, Smallcap -3.8%, 1 high-stress day(s) -> market part -0.80%, stock part -26.17%: mostly the stock itself._

## D-20210802-2 - INDOAMIN - net -2725 bp (gross -26.90%) - SEVERE LOSER

- D rank 2 (score 0.023) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.57, correlation 0.40; NIFTY beta 1.60, Smallcap beta 1.57)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 30 Jul 2021: NIFTY -0.1%, Midcap +0.9%, Smallcap +0.5%; NIFTY minus Smallcap -0.6 pts (20-day -6.9 pts); breadth 0.52 (807 up / 738 down of 1,578; 10-day 0.47); VIX 12.8 (day -1.2%, 5-day +8.8%, 5th percentile); environment: Narrow bullish.
- Pick day: Mon 02 Aug 2021: NIFTY +0.8%, Midcap +1.3%, Smallcap +0.8%; NIFTY minus Smallcap 0.0 pts (20-day -6.3 pts); breadth 0.68 (1,056 up / 501 down of 1,595; 10-day 0.48); VIX 12.8 (day +0.1%, 5-day +2.9%, 6th percentile); environment: Narrow bullish.
- The stock: day before +5.0%, pick day -5.0% (-5.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): UNKNOWN - evidence conflicts (6 sessions) | risk: S05 extremely overextended; repeated large gaps
- Warning signs that fired before entry: W3 narrow bullish at the pick; W8 high-beta pick: beta to its home index 1.5 or more

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 02 Aug | -5.0% | 0.0% | +0.8% | +1.3% | +0.8% | 0.68 | 12.8 | Narrow bullish | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 03 Aug | -5.0% | 0.0% | +1.5% | +0.2% | -0.2% | 0.51 | 13.8 | Narrow bullish | -4.7 pts | -115 / +115 | 100% | -18 | -18 | buy open |
| 2 | Wed 04 Aug | -5.0% | 0.0% | +0.8% | -1.0% | -1.1% | 0.26 | 13.2 | Broad bullish | -3.9 pts | -175 / -326 | 100% | -501 | -518 |  |
| 3 | Thu 05 Aug | -5.0% | 0.0% | +0.2% | 0.0% | -0.5% | 0.32 | 12.9 | Narrow bullish | -4.4 pts | -85 / -414 | 100% | -474 | -992 |  |
| 4 | Fri 06 Aug | -5.0% | 0.0% | -0.3% | 0.0% | +0.1% | 0.55 | 12.6 | Narrow bullish | -5.1 pts | +21 / -520 | 100% | -450 | -1442 |  |
| 5 | Mon 09 Aug | -5.0% | 0.0% | +0.1% | -0.7% | -1.0% | 0.32 | 12.6 | Narrow bullish | -3.9 pts | -164 / -333 | 100% | -427 | -1869 |  |
| 6 | Tue 10 Aug | -5.0% | 0.0% | +0.1% | -1.1% | -2.6% | 0.14 | 12.7 | HIGH STRESS | -2.4 pts | -406 / -96 | 100% | -409 | -2278 |  |
| 7 | Wed 11 Aug | -5.0% | 0.0% | 0.0% | -0.4% | -0.5% | 0.33 | 12.7 | Narrow bullish | -4.4 pts | -84 / -413 | 100% | -385 | -2663 |  |
| 8 | Thu 12 Aug | +3.2% | +8.6% | +0.5% | +1.0% | +2.3% | 0.83 | 12.4 | HIGH STRESS | +0.9 pts | +357 / -39 | 100% | +234 | -2429 |  |
| 9 | Fri 13 Aug | -1.4% | +3.7% | +1.0% | -0.1% | -0.1% | 0.46 | 13.0 | Narrow bullish | -1.4 pts | -11 / -134 | 100% | -110 | -2538 |  |
| 10 | Mon 16 Aug | -5.0% | -2.8% | +0.2% | -0.3% | -0.9% | 0.31 | 13.5 | Narrow bullish | -4.1 pts | +20 / -246 | 0% | -186 | -2725 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 03 Aug 2021 at the open 168.80; sold Mon 16 Aug 2021 at the open 123.40 (lower-circuit lock: sold at the first free open). Gross -26.90%, costs -35 bp, net -2725 bp.
- Over the same hold: NIFTY +3.6%, Midcap -2.2%, Smallcap -4.1%; VIX +1.4%; breadth averaged 0.40; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3045 bp, Midcap -2465 bp, Smallcap -2281 bp.
- Split: market part -6.40% = beta 1.57 x Smallcap 250 -4.08%; stock part -20.50% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+115 bp beyond its market); weakest: session 4 (-520 bp).

_Pick day Mon 02 Aug 2021 [Narrow bullish]: NIFTY +0.8%, Smallcap +0.8%, breadth 0.68, VIX 12.8 (+3% in 5 days) -> D rank 2 INDOAMIN (moves with Smallcap 250, beta 1.57) -> bought Tue 03 Aug 2021 open, sold Mon 16 Aug 2021 open: gross -26.90%, net -2725 bp -> during the hold NIFTY +3.6%, Smallcap -4.1%, 2 high-stress day(s) -> market part -6.40%, stock part -20.50%: mostly the stock itself._

## D-20230124-1 - KIRIINDUS - net -2701 bp (gross -26.66%) - SEVERE LOSER

- D rank 1 (score 0.019) | size: no list (no AMFI class) | moves most with Midcap 150 (beta 0.33, correlation 0.17; NIFTY beta 0.26, Smallcap beta 0.32)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 23 Jan 2023: NIFTY +0.5%, Midcap +0.2%, Smallcap -0.1%; NIFTY minus Smallcap +0.6 pts (20-day -0.2 pts); breadth 0.44 (788 up / 990 down of 1,820; 10-day 0.44); VIX 13.6 (day -1.2%, 5-day -9.3%, 5th percentile); environment: Broad bearish.
- Pick day: Tue 24 Jan 2023: NIFTY 0.0%, Midcap -0.3%, Smallcap -0.4%; NIFTY minus Smallcap +0.4 pts (20-day +0.8 pts); breadth 0.38 (672 up / 1,091 down of 1,812; 10-day 0.44); VIX 13.7 (day +0.3%, 5-day -6.4%, 6th percentile); environment: Broad bearish.
- The stock: day before -1.2%, pick day -2.4% (-2.0 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): S08 Bearish continuation (MEDIUM, 2 sessions, early) | S10 breakdown CONFIRMED (6d) | risk: stretched far below EMA20; large down candle in the last 5 sessions
- Warning signs that fired before entry: W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.003, pred_mae_q20 -0.057, pred_mae_q50 -0.023, pred_mae_q80 -0.009, pred_mfe_q20 0.020, pred_mfe_q50 0.050, pred_mfe_q80 0.106, prob_big 0.498, prob_deep 0.112, prob_trap 0.002, prob_win 0.604

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 24 Jan | -2.4% | -0.9% | 0.0% | -0.3% | -0.4% | 0.38 | 13.7 | Broad bearish | -2.0 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 25 Jan | -8.7% | -8.5% | -1.2% | -1.3% | -0.9% | 0.20 | 14.7 | Broad bearish | -7.5 pts | -37 / -812 | 100% | -867 | -867 | buy open |
| 2 | Fri 27 Jan | -15.7% | -15.7% | -1.6% | -1.2% | -1.8% | 0.15 | 17.3 | Broad bearish | -14.5 pts | -41 / -1530 | 100% | -1437 | -2304 |  |
| 3 | Mon 30 Jan | -1.6% | -2.1% | +0.3% | -0.2% | -0.2% | 0.41 | 17.7 | HIGH STRESS | -1.4 pts | -5 / -153 | 100% | -122 | -2426 |  |
| 4 | Tue 31 Jan | +1.1% | -1.2% | +0.1% | +1.5% | +2.6% | 0.78 | 16.9 | HIGH STRESS | -0.4 pts | +50 / +64 | 100% | +87 | -2339 |  |
| 5 | Wed 01 Feb | -4.5% | -5.2% | -0.3% | -0.9% | -1.1% | 0.27 | 16.8 | Broad bearish | -3.6 pts | -28 / -421 | 0% | -362 | -2701 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 25 Jan 2023 at the open 368.50; sold Wed 01 Feb 2023 at the close 270.25. Gross -26.66%, costs -35 bp, net -2701 bp.
- Over the same hold: NIFTY -2.6%, Midcap -1.9%, Smallcap -1.4%; VIX +22.8%; breadth averaged 0.36; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2403 bp, Midcap -2479 bp, Smallcap -2524 bp.
- Split: market part -0.61% = beta 0.33 x Midcap 150 -1.87%; stock part -26.05% -> **mostly the stock itself**.
- The stock's own strongest day: session 4 (+64 bp beyond its market); weakest: session 2 (-1530 bp).

_Pick day Tue 24 Jan 2023 [Broad bearish]: NIFTY 0.0%, Smallcap -0.4%, breadth 0.38, VIX 13.7 (-6% in 5 days) -> D rank 1 KIRIINDUS (moves with Midcap 150, beta 0.33) -> bought Wed 25 Jan 2023 open, sold Wed 01 Feb 2023 close: gross -26.66%, net -2701 bp -> during the hold NIFTY -2.6%, Smallcap -1.4%, 2 high-stress day(s) -> market part -0.61%, stock part -26.05%: mostly the stock itself._

## D-20220119-1 - TTML - net -2698 bp (gross -26.63%) - SEVERE LOSER

- D rank 1 (score 0.024) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.66, correlation 0.19; NIFTY beta 0.38, Smallcap beta 0.66)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 18 Jan 2022: NIFTY -1.1%, Midcap -1.9%, Smallcap -2.0%; NIFTY minus Smallcap +1.0 pts (20-day -2.3 pts); breadth 0.19 (311 up / 1,341 down of 1,670; 10-day 0.52); VIX 17.8 (day +6.0%, 5-day +0.1%, 58th percentile); environment: Broad bullish.
- Pick day: Wed 19 Jan 2022: NIFTY -1.0%, Midcap -0.2%, Smallcap +0.2%; NIFTY minus Smallcap -1.2 pts (20-day -3.0 pts); breadth 0.44 (721 up / 927 down of 1,669; 10-day 0.51); VIX 17.8 (day +0.2%, 5-day +3.7%, 58th percentile); environment: Broad bullish.
- The stock: day before -5.0%, pick day -5.0% (-5.2 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S01 Strong bullish continuation (MEDIUM, 42 sessions, mature) | risk: repeated large gaps
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.004, pred_mae_q20 -0.123, pred_mae_q50 -0.059, pred_mae_q80 -0.011, pred_mfe_q20 0.021, pred_mfe_q50 0.081, pred_mfe_q80 0.155, prob_big 0.671, prob_deep 0.467, prob_trap 0.385, prob_win 0.420

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -9 / +9 | 100% | -18 | -18 | buy open |
| 2 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -124 / -374 | 100% | -498 | -516 |  |
| 3 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -306 / -192 | 100% | -473 | -989 |  |
| 4 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +70 / -570 | 100% | -451 | -1440 |  |
| 5 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -31 / -467 | 100% | -427 | -1867 |  |
| 6 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +35 / -534 | 100% | -407 | -2273 |  |
| 7 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +64 / -563 | 100% | -387 | -2660 |  |
| 8 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +50 / -549 | 100% | -367 | -3028 |  |
| 9 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +54 / +443 | 0% | +330 | -2698 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 20 Jan 2022 at the open 202.80; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -26.63%, costs -35 bp, net -2698 bp.
- Over the same hold: NIFTY -1.2%, Midcap -2.0%, Smallcap -3.1%; VIX +12.1%; breadth averaged 0.48; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2543 bp, Midcap -2462 bp, Smallcap -2355 bp.
- Split: market part -2.04% = beta 0.66 x Smallcap 250 -3.07%; stock part -24.59% -> **mostly the stock itself**.
- The stock's own strongest day: session 9 (+443 bp beyond its market); weakest: session 4 (-570 bp).

_Pick day Wed 19 Jan 2022 [Broad bullish]: NIFTY -1.0%, Smallcap +0.2%, breadth 0.44, VIX 17.8 (+4% in 5 days) -> D rank 1 TTML (moves with Smallcap 250, beta 0.66) -> bought Thu 20 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -26.63%, net -2698 bp -> during the hold NIFTY -1.2%, Smallcap -3.1%, 1 high-stress day(s) -> market part -2.04%, stock part -24.59%: mostly the stock itself._

## D-20200316-1 - V2RETAIL - net -2688 bp (gross -26.53%) - SEVERE LOSER

- D rank 1 (score 0.067) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 2.04, correlation 0.63; NIFTY beta 1.84, Smallcap beta 2.04)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 13 Mar 2020: NIFTY +3.8% (2.4 sd rise), Midcap +2.3%, Smallcap +0.7%; NIFTY minus Smallcap +3.1 pts (20-day +3.6 pts); breadth 0.56 (773 up / 610 down of 1,432; 10-day 0.30); VIX 51.5 (day +25.0%, 5-day +121.4%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +121% in 5 sessions.
- Pick day: Mon 16 Mar 2020: NIFTY -7.6% (4.6 sd fall), Midcap -5.9% (3.9 sd fall), Smallcap -5.4% (3.3 sd fall); NIFTY minus Smallcap -2.2 pts (20-day +1.7 pts); breadth 0.12 (168 up / 1,236 down of 1,443; 10-day 0.30); VIX 58.9 (day +14.4%, 5-day +129.6%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +130% in 5 sessions; NIFTY -4.6 sd day; Smallcap -3.3 sd day.
- The stock: day before +1.8%, pick day -19.0% (-13.5 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 8 sessions, mature) | S10 breakdown CONFIRMED (4d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40; W5 VIX up 15% or more in 5 days; W6 Smallcap fell 1.5% or more on the pick day; W8 high-beta pick: beta to its home index 1.5 or more

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 16 Mar | -19.0% | -9.6% | -7.6% | -5.9% | -5.4% | 0.12 | 58.9 | HIGH STRESS | -13.5 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 17 Mar | -8.5% | -12.2% | -2.5% | -2.4% | -2.3% | 0.29 | 62.9 | HIGH STRESS | -6.2 pts | -405 / -820 | 100% | -1242 | -1242 | buy open |
| 2 | Wed 18 Mar | -9.3% | -11.4% | -5.6% | -5.4% | -6.1% | 0.11 | 64.0 | HIGH STRESS | -3.2 pts | -1245 / +315 | 100% | -816 | -2058 |  |
| 3 | Thu 19 Mar | -7.7% | -5.3% | -2.4% | -4.0% | -5.2% | 0.19 | 72.2 | HIGH STRESS | -2.4 pts | -1072 / +303 | 100% | -612 | -2671 |  |
| 4 | Fri 20 Mar | +8.3% | +2.6% | +5.8% | +4.4% | +2.2% | 0.67 | 67.1 | HIGH STRESS | +6.1 pts | +459 / +374 | 100% | +612 | -2058 |  |
| 5 | Mon 23 Mar | -7.7% | 0.0% | -13.0% | -13.0% | -12.4% | 0.04 | 72.0 | HIGH STRESS | +4.7 pts | -2537 / +1768 | 0% | -630 | -2688 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 17 Mar 2020 at the open 4.90; sold Mon 23 Mar 2020 at the close 3.60. Gross -26.53%, costs -35 bp, net -2688 bp.
- Over the same hold: NIFTY -18.0%, Midcap -19.6%, Smallcap -21.9%; VIX +22.3%; breadth averaged 0.26; 5 high-stress session(s).
- Against each index (gross minus the index): NIFTY -849 bp, Midcap -690 bp, Smallcap -464 bp.
- Split: market part -44.75% = beta 2.04 x Smallcap 250 -21.89%; stock part +18.22% -> **mostly the market**.
- The stock's own strongest day: session 5 (+1768 bp beyond its market); weakest: session 1 (-820 bp).

_Pick day Mon 16 Mar 2020 [HIGH STRESS]: NIFTY -7.6%, Smallcap -5.4%, breadth 0.12, VIX 58.9 (+130% in 5 days) -> D rank 1 V2RETAIL (moves with Smallcap 250, beta 2.04) -> bought Tue 17 Mar 2020 open, sold Mon 23 Mar 2020 close: gross -26.53%, net -2688 bp -> during the hold NIFTY -18.0%, Smallcap -21.9%, 5 high-stress day(s) -> market part -44.75%, stock part +18.22%: mostly the market._

## D-20230202-1 - ADANIPOWER - net -2639 bp (gross -26.04%) - SEVERE LOSER

- D rank 1 (score 0.032) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 1.21, correlation 0.40; NIFTY beta 1.14, Smallcap beta 1.09)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 01 Feb 2023: NIFTY -0.3%, Midcap -0.9%, Smallcap -1.1%; NIFTY minus Smallcap +0.9 pts (20-day +0.9 pts); breadth 0.27 (491 up / 1,306 down of 1,818; 10-day 0.39); VIX 16.8 (day -0.6%, 5-day +22.8%, 27th percentile); environment: Broad bearish.
- Pick day: Thu 02 Feb 2023: NIFTY 0.0%, Midcap +0.2%, Smallcap +0.4%; NIFTY minus Smallcap -0.5 pts (20-day +0.6 pts); breadth 0.47 (832 up / 957 down of 1,820; 10-day 0.38); VIX 15.7 (day -6.3%, 5-day +7.3%, 22nd percentile); environment: Broad bearish.
- The stock: day before -4.9%, pick day -5.1% (-5.2 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): UNKNOWN - evidence conflicts (12 sessions) | S10 breakdown CONFIRMED (4d) | risk: stretched far below EMA20; repeated large gaps
- Warning signs that fired before entry: W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.010, pred_mae_q20 -0.090, pred_mae_q50 -0.043, pred_mae_q80 -0.011, pred_mfe_q20 0.021, pred_mfe_q50 0.075, pred_mfe_q80 0.150, prob_big 0.624, prob_deep 0.297, prob_trap 0.062, prob_win 0.474

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 02 Feb | -5.1% | 0.0% | 0.0% | +0.2% | +0.4% | 0.47 | 15.7 | Broad bearish | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 03 Feb | -5.0% | 0.0% | +1.4% | -0.1% | -0.4% | 0.36 | 14.4 | Broad bearish | -4.8 pts | -46 / +46 | 100% | -18 | -18 | buy open |
| 2 | Mon 06 Feb | -5.1% | 0.0% | -0.5% | +0.9% | +0.3% | 0.54 | 14.7 | Broad bearish | -5.9 pts | +103 / -611 | 100% | -508 | -525 |  |
| 3 | Tue 07 Feb | -4.9% | 0.0% | -0.2% | 0.0% | -0.4% | 0.41 | 14.1 | Broad bearish | -4.9 pts | -1 / -492 | 100% | -469 | -994 |  |
| 4 | Wed 08 Feb | +5.1% | +5.1% | +0.8% | +0.8% | +0.8% | 0.65 | 13.6 | Broad bearish | +4.2 pts | +102 / +403 | 100% | +456 | -538 |  |
| 5 | Thu 09 Feb | -5.1% | 0.0% | +0.1% | +0.1% | -0.3% | 0.48 | 13.0 | Broad bearish | -5.2 pts | +10 / -519 | 100% | -482 | -1020 |  |
| 6 | Fri 10 Feb | -4.9% | 0.0% | -0.2% | +0.2% | +0.5% | 0.51 | 12.8 | Broad bearish | -5.2 pts | +30 / -522 | 100% | -443 | -1463 |  |
| 7 | Mon 13 Feb | -5.0% | 0.0% | -0.5% | -1.3% | -1.2% | 0.26 | 13.7 | Broad bearish | -3.7 pts | -158 / -345 | 100% | -430 | -1892 |  |
| 8 | Tue 14 Feb | -5.0% | 0.0% | +0.9% | -0.4% | -0.5% | 0.33 | 13.4 | Broad bearish | -4.5 pts | -52 / -445 | 100% | -404 | -2296 |  |
| 9 | Wed 15 Feb | -5.1% | 0.0% | +0.5% | +0.5% | +0.4% | 0.56 | 12.9 | Broad bearish | -5.5 pts | +58 / -564 | 100% | -391 | -2687 |  |
| 10 | Thu 16 Feb | +5.0% | +4.0% | +0.1% | +0.8% | +0.8% | 0.59 | 12.9 | Broad bearish | +4.2 pts | +49 / +40 | 0% | +48 | -2639 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 03 Feb 2023 at the open 38.40; sold Thu 16 Feb 2023 at the open 28.40 (lower-circuit lock: sold at the first free open). Gross -26.04%, costs -35 bp, net -2639 bp.
- Over the same hold: NIFTY +2.1%, Midcap +0.8%, Smallcap -0.8%; VIX -18.2%; breadth averaged 0.47; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2815 bp, Midcap -2681 bp, Smallcap -2525 bp.
- Split: market part +0.93% = beta 1.21 x Midcap 150 +0.77%; stock part -26.98% -> **mostly the stock itself**.
- The stock's own strongest day: session 4 (+403 bp beyond its market); weakest: session 2 (-611 bp).

_Pick day Thu 02 Feb 2023 [Broad bearish]: NIFTY 0.0%, Smallcap +0.4%, breadth 0.47, VIX 15.7 (+7% in 5 days) -> D rank 1 ADANIPOWER (moves with Midcap 150, beta 1.21) -> bought Fri 03 Feb 2023 open, sold Thu 16 Feb 2023 open: gross -26.04%, net -2639 bp -> during the hold NIFTY +2.1%, Smallcap -0.8% -> market part +0.93%, stock part -26.98%: mostly the stock itself._

## D-20200311-1 - ITDC - net -2629 bp (gross -25.94%) - SEVERE LOSER

- D rank 1 (score 0.068) | the other engine ranked it 3 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.51, correlation 0.36; NIFTY beta 1.51, Smallcap beta 1.55)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 09 Mar 2020: NIFTY -4.9% (4.8 sd fall), Midcap -4.2% (4.3 sd fall), Smallcap -4.7% (4.5 sd fall); NIFTY minus Smallcap -0.2 pts (20-day +1.8 pts); breadth 0.09 (124 up / 1,292 down of 1,445; 10-day 0.29); VIX 30.8 (day +20.1%, 5-day +22.2%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; NIFTY -4.8 sd day; Smallcap -4.5 sd day.
- Pick day: Wed 11 Mar 2020: NIFTY +0.1%, Midcap -0.7%, Smallcap -0.3%; NIFTY minus Smallcap +0.3 pts (20-day +2.0 pts); breadth 0.42 (583 up / 804 down of 1,445; 10-day 0.30); VIX 31.6 (day +2.5%, 5-day +28.6%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; VIX +29% in 5 sessions.
- The stock: day before -9.4%, pick day -0.2% (-0.3 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 8 sessions, mature) | S10 breakdown NEW (2d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40; W5 VIX up 15% or more in 5 days; W8 high-beta pick: beta to its home index 1.5 or more

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 11 Mar | -0.2% | +3.0% | +0.1% | -0.7% | -0.3% | 0.42 | 31.6 | HIGH STRESS | -0.3 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 12 Mar | -10.0% | -4.5% | -8.3% | -7.8% | -8.9% | 0.04 | 41.2 | HIGH STRESS | -1.7 pts | -677 / +227 | 100% | -468 | -468 | buy open |
| 2 | Fri 13 Mar | -3.5% | +7.2% | +3.8% | +2.3% | +0.7% | 0.56 | 51.5 | HIGH STRESS | -7.3 pts | +575 / -924 | 100% | -333 | -801 |  |
| 3 | Mon 16 Mar | -6.6% | -1.9% | -7.6% | -5.9% | -5.4% | 0.12 | 58.9 | HIGH STRESS | +1.0 pts | -1150 / +487 | 100% | -611 | -1412 |  |
| 4 | Tue 17 Mar | -5.7% | -5.6% | -2.5% | -2.4% | -2.3% | 0.29 | 62.9 | HIGH STRESS | -3.2 pts | -378 / -189 | 100% | -488 | -1901 |  |
| 5 | Wed 18 Mar | -8.8% | -8.7% | -5.6% | -5.4% | -6.1% | 0.11 | 64.0 | HIGH STRESS | -3.2 pts | -840 / -36 | 0% | -728 | -2629 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 12 Mar 2020 at the open 171.00; sold Wed 18 Mar 2020 at the close 126.65. Gross -25.94%, costs -35 bp, net -2629 bp.
- Over the same hold: NIFTY -15.6%, Midcap -14.6%, Smallcap -16.5%; VIX +102.7%; breadth averaged 0.22; 5 high-stress session(s).
- Against each index (gross minus the index): NIFTY -1029 bp, Midcap -1136 bp, Smallcap -945 bp.
- Split: market part -23.65% = beta 1.51 x NIFTY 50 -15.65%; stock part -2.29% -> **mostly the market**.
- The stock's own strongest day: session 3 (+487 bp beyond its market); weakest: session 2 (-924 bp).

_Pick day Wed 11 Mar 2020 [HIGH STRESS]: NIFTY +0.1%, Smallcap -0.3%, breadth 0.42, VIX 31.6 (+29% in 5 days) -> D rank 1 ITDC (moves with NIFTY 50, beta 1.51) -> bought Thu 12 Mar 2020 open, sold Wed 18 Mar 2020 close: gross -25.94%, net -2629 bp -> during the hold NIFTY -15.6%, Smallcap -16.5%, 5 high-stress day(s) -> market part -23.65%, stock part -2.29%: mostly the market._

## D-20241107-1 - WEBELSOLAR - net -2626 bp (gross -25.91%) - SEVERE LOSER

- D rank 1 (score 0.024) | the other engine ranked it 7 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.78, correlation 0.31; NIFTY beta 0.48, Smallcap beta 0.78)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 06 Nov 2024: NIFTY +1.1%, Midcap +2.1% (2.3 sd rise), Smallcap +1.9%; NIFTY minus Smallcap -0.8 pts (20-day -1.6 pts); breadth 0.83 (1,727 up / 357 down of 2,097; 10-day 0.57); VIX 14.9 (day -7.8%, 5-day -4.1%, 72nd percentile); environment: Mixed / ranging.
- Pick day: Thu 07 Nov 2024: NIFTY -1.2%, Midcap -0.5%, Smallcap -0.6%; NIFTY minus Smallcap -0.5 pts (20-day -2.0 pts); breadth 0.35 (733 up / 1,348 down of 2,097; 10-day 0.57); VIX 14.9 (day +0.5%, 5-day -3.9%, 72nd percentile); environment: Mixed / ranging.
- The stock: day before -1.3%, pick day +3.2% (+3.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S01 Strong bullish continuation (HIGH, 9 sessions, mature) | S04 breakout CONFIRMED (6d)
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.027, pred_mae_q20 -0.136, pred_mae_q50 -0.064, pred_mae_q80 -0.024, pred_mfe_q20 0.013, pred_mfe_q50 0.048, pred_mfe_q80 0.108, prob_big 0.482, prob_deep 0.459, prob_trap 0.187, prob_win 0.399

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 07 Nov | +3.2% | +2.9% | -1.2% | -0.5% | -0.6% | 0.35 | 14.9 | Mixed / ranging | +3.8 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 08 Nov | -5.0% | -5.6% | -0.2% | -1.3% | -1.6% | 0.24 | 14.5 | Mixed / ranging | -3.4 pts | -135 / -430 | 100% | -582 | -582 | buy open |
| 2 | Mon 11 Nov | -5.1% | 0.0% | 0.0% | -0.8% | -1.2% | 0.27 | 14.3 | Mixed / ranging | -3.9 pts | -93 / -412 | 100% | -477 | -1059 |  |
| 3 | Tue 12 Nov | -5.0% | -0.6% | -1.1% | -0.9% | -1.3% | 0.21 | 14.6 | Mixed / ranging | -3.7 pts | -102 / -395 | 100% | -445 | -1504 |  |
| 4 | Wed 13 Nov | -5.0% | 0.0% | -1.4% | -2.7% | -3.1% | 0.09 | 15.4 | HIGH STRESS | -2.0 pts | -239 / -262 | 100% | -427 | -1931 |  |
| 5 | Thu 14 Nov | -5.0% | 0.0% | -0.1% | +0.5% | +0.8% | 0.55 | 14.8 | Broad bearish | -5.8 pts | +62 / -558 | 100% | -402 | -2332 |  |
| 6 | Mon 18 Nov | +5.0% | +8.9% | -0.3% | -0.2% | -0.6% | 0.36 | 15.2 | Broad bearish | +5.6 pts | +7 / -366 | 0% | -294 | -2626 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 08 Nov 2024 at the open 159.40; sold Mon 18 Nov 2024 at the open 118.10 (lower-circuit lock: sold at the first free open). Gross -25.91%, costs -35 bp, net -2626 bp.
- Over the same hold: NIFTY -2.5%, Midcap -4.9%, Smallcap -6.3%; VIX -1.1%; breadth averaged 0.29; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2342 bp, Midcap -2097 bp, Smallcap -1963 bp.
- Split: market part -4.91% = beta 0.78 x Smallcap 250 -6.28%; stock part -21.00% -> **mostly the stock itself**.
- The stock's own strongest day: session 4 (-262 bp beyond its market); weakest: session 5 (-558 bp).

_Pick day Thu 07 Nov 2024 [Mixed / ranging]: NIFTY -1.2%, Smallcap -0.6%, breadth 0.35, VIX 14.9 (-4% in 5 days) -> D rank 1 WEBELSOLAR (moves with Smallcap 250, beta 0.78) -> bought Fri 08 Nov 2024 open, sold Mon 18 Nov 2024 open: gross -25.91%, net -2626 bp -> during the hold NIFTY -2.5%, Smallcap -6.3%, 1 high-stress day(s) -> market part -4.91%, stock part -21.00%: mostly the stock itself._

## D-20250131-1 - VAKRANGEE - net -2555 bp (gross -25.20%) - SEVERE LOSER

- D rank 1 (score 0.039) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.34, correlation 0.38; NIFTY beta 1.36, Smallcap beta 1.34)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 30 Jan 2025: NIFTY +0.4%, Midcap +0.2%, Smallcap -0.2%; NIFTY minus Smallcap +0.5 pts (20-day +9.6 pts); breadth 0.54 (1,149 up / 974 down of 2,139; 10-day 0.41); VIX 17.4 (day -6.7%, 5-day +4.1%, 90th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 90th percentile of 250 sessions.
- Pick day: Fri 31 Jan 2025: NIFTY +1.1%, Midcap +1.7%, Smallcap +1.7%; NIFTY minus Smallcap -0.6 pts (20-day +9.7 pts); breadth 0.77 (1,636 up / 478 down of 2,130; 10-day 0.44); VIX 16.2 (day -6.6%, 5-day -3.0%, 84th percentile); environment: Broad bearish.
- The stock: day before -0.6%, pick day -10.0% (-11.7 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 5 sessions, early) | S10 breakdown NEW today | volatility extreme
- Warning signs that fired before entry: W2 broad bearish at the pick; W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.012, pred_mae_q20 -0.108, pred_mae_q50 -0.051, pred_mae_q80 -0.020, pred_mfe_q20 0.035, pred_mfe_q50 0.102, pred_mfe_q80 0.172, prob_big 0.691, prob_deep 0.347, prob_trap 0.140, prob_win 0.549

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 31 Jan | -10.0% | -9.7% | +1.1% | +1.7% | +1.7% | 0.77 | 16.2 | Broad bearish | -11.7 pts |  | 0% | +0 | +0 |  |
| 1 | Sat 01 Feb | -5.0% | 0.0% | -0.1% | -0.4% | +0.7% | 0.51 | 14.1 | Broad bearish | -5.7 pts | +45 / -45 | 100% | -18 | -18 | buy open |
| 2 | Mon 03 Feb | -5.0% | 0.0% | -0.5% | -1.0% | -1.7% | 0.24 | 14.3 | Broad bearish | -3.3 pts | -233 / -268 | 100% | -501 | -519 |  |
| 3 | Tue 04 Feb | -5.0% | 0.0% | +1.6% | +1.4% | +1.1% | 0.71 | 14.0 | Broad bearish | -6.1 pts | +152 / -652 | 100% | -475 | -994 |  |
| 4 | Wed 05 Feb | -5.0% | 0.0% | -0.2% | +0.7% | +1.6% | 0.71 | 14.1 | Broad bearish | -6.6 pts | +210 / -712 | 100% | -453 | -1447 |  |
| 5 | Thu 06 Feb | -5.0% | -4.6% | -0.4% | -1.0% | 0.0% | 0.44 | 14.2 | Mixed / ranging | -5.0 pts | -5 / -498 | 100% | -431 | -1878 |  |
| 6 | Fri 07 Feb | -5.0% | 0.0% | -0.2% | +0.1% | -0.4% | 0.33 | 13.7 | Mixed / ranging | -4.6 pts | -52 / -450 | 100% | -409 | -2287 |  |
| 7 | Mon 10 Feb | -5.0% | -1.8% | -0.8% | -2.1% | -2.1% | 0.15 | 14.4 | Mixed / ranging | -2.9 pts | -10 / -314 | 0% | -268 | -2555 | sell time |

**4. Verdict** (observed after entry)

- Bought Sat 01 Feb 2025 at the open 22.74; sold Mon 10 Feb 2025 at the open 17.01 (lower-circuit lock: sold at the first free open). Gross -25.20%, costs -35 bp, net -2555 bp.
- Over the same hold: NIFTY +0.1%, Midcap -0.6%, Smallcap +0.8%; VIX -15.8%; breadth averaged 0.44; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2526 bp, Midcap -2462 bp, Smallcap -2596 bp.
- Split: market part +1.02% = beta 1.34 x Smallcap 250 +0.76%; stock part -26.22% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (-45 bp beyond its market); weakest: session 4 (-712 bp).

_Pick day Fri 31 Jan 2025 [Broad bearish]: NIFTY +1.1%, Smallcap +1.7%, breadth 0.77, VIX 16.2 (-3% in 5 days) -> D rank 1 VAKRANGEE (moves with Smallcap 250, beta 1.34) -> bought Sat 01 Feb 2025 open, sold Mon 10 Feb 2025 open: gross -25.20%, net -2555 bp -> during the hold NIFTY +0.1%, Smallcap +0.8% -> market part +1.02%, stock part -26.22%: mostly the stock itself._

## D-20200304-2 - DWARKESH - net -2545 bp (gross -25.10%) - SEVERE LOSER

- D rank 2 (score 0.041) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.59, correlation 0.45; NIFTY beta 1.18, Smallcap beta 1.59)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 03 Mar 2020: NIFTY +1.5%, Midcap +1.7%, Smallcap +1.2%; NIFTY minus Smallcap +0.4 pts (20-day +1.2 pts); breadth 0.56 (775 up / 597 down of 1,432; 10-day 0.36); VIX 24.5 (day -2.6%, 5-day +45.2%, 94th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 94th percentile of 250 sessions; VIX +45% in 5 sessions.
- Pick day: Wed 04 Mar 2020: NIFTY -0.5%, Midcap -1.5%, Smallcap -1.6%; NIFTY minus Smallcap +1.1 pts (20-day +1.7 pts); breadth 0.22 (310 up / 1,084 down of 1,431; 10-day 0.35); VIX 24.2 (day -1.3%, 5-day +32.7%, 94th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 94th percentile of 250 sessions; VIX +33% in 5 sessions.
- The stock: day before -0.2%, pick day -4.4% (-2.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 8 sessions, mature) | S10 breakdown NEW today | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40; W5 VIX up 15% or more in 5 days; W6 Smallcap fell 1.5% or more on the pick day; W8 high-beta pick: beta to its home index 1.5 or more

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 04 Mar | -4.4% | -5.6% | -0.5% | -1.5% | -1.6% | 0.22 | 24.2 | HIGH STRESS | -2.8 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 05 Mar | +2.0% | +1.4% | +0.2% | +0.2% | +0.4% | 0.54 | 23.2 | HIGH STRESS | +1.5 pts | -21 / +159 | 100% | +121 | +121 | buy open |
| 2 | Fri 06 Mar | -4.1% | +0.4% | -2.5% | -2.0% | -2.3% | 0.16 | 25.6 | HIGH STRESS | -1.8 pts | -365 / -44 | 100% | -415 | -294 |  |
| 3 | Mon 09 Mar | -14.4% | -7.1% | -4.9% | -4.2% | -4.7% | 0.09 | 30.8 | HIGH STRESS | -9.8 pts | -739 / -704 | 100% | -1403 | -1697 |  |
| 4 | Wed 11 Mar | -1.0% | -0.2% | +0.1% | -0.7% | -0.3% | 0.42 | 31.6 | HIGH STRESS | -0.7 pts | -44 / -51 | 100% | -79 | -1776 |  |
| 5 | Thu 12 Mar | -9.8% | -1.8% | -8.3% | -7.8% | -8.9% | 0.04 | 41.2 | HIGH STRESS | -1.0 pts | -1403 / +420 | 100% | -810 | -2587 |  |
| 6 | Fri 13 Mar | +4.5% | +15.9% | +3.8% | +2.3% | +0.7% | 0.56 | 51.5 | HIGH STRESS | +3.8 pts | +108 / +344 | 100% | +336 | -2251 |  |
| 7 | Mon 16 Mar | -8.1% | -4.7% | -7.6% | -5.9% | -5.4% | 0.12 | 58.9 | HIGH STRESS | -2.7 pts | -574 / +218 | 0% | -294 | -2545 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 05 Mar 2020 at the open 25.30; sold Mon 16 Mar 2020 at the open 18.95 (lower-circuit lock: sold at the first free open). Gross -25.10%, costs -35 bp, net -2545 bp.
- Over the same hold: NIFTY -15.2%, Midcap -15.5%, Smallcap -18.0%; VIX +112.4%; breadth averaged 0.28; 7 high-stress session(s).
- Against each index (gross minus the index): NIFTY -990 bp, Midcap -961 bp, Smallcap -714 bp.
- Split: market part -28.47% = beta 1.59 x Smallcap 250 -17.96%; stock part +3.37% -> **mostly the market**.
- The stock's own strongest day: session 5 (+420 bp beyond its market); weakest: session 3 (-704 bp).

_Pick day Wed 04 Mar 2020 [HIGH STRESS]: NIFTY -0.5%, Smallcap -1.6%, breadth 0.22, VIX 24.2 (+33% in 5 days) -> D rank 2 DWARKESH (moves with Smallcap 250, beta 1.59) -> bought Thu 05 Mar 2020 open, sold Mon 16 Mar 2020 open: gross -25.10%, net -2545 bp -> during the hold NIFTY -15.2%, Smallcap -18.0%, 7 high-stress day(s) -> market part -28.47%, stock part +3.37%: mostly the market._

## ENS-20230120-2 - PCJEWELLER - net -6262 bp (gross -62.27%) - SEVERE LOSER

- ENS rank 2 (score 0.995) | the other engine ranked it 10 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 1.08, correlation 0.33; NIFTY beta 0.87, Smallcap beta 0.94)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 19 Jan 2023: NIFTY -0.3%, Midcap -0.1%, Smallcap -0.3%; NIFTY minus Smallcap 0.0 pts (20-day -0.4 pts); breadth 0.39 (679 up / 1,072 down of 1,804; 10-day 0.45); VIX 14.0 (day -2.9%, 5-day -8.6%, 7th percentile); environment: Broad bearish.
- Pick day: Fri 20 Jan 2023: NIFTY -0.4%, Midcap -0.7%, Smallcap -0.6%; NIFTY minus Smallcap +0.1 pts (20-day -3.0 pts); breadth 0.35 (616 up / 1,143 down of 1,808; 10-day 0.45); VIX 13.8 (day -1.2%, 5-day -4.6%, 6th percentile); environment: Broad bearish.
- The stock: day before -5.0%, pick day -5.0% (-4.3 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (MEDIUM, 2 sessions, early) | S10 breakdown NEW today
- Warning signs that fired before entry: W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.007, pred_mae_q20 -0.098, pred_mae_q50 -0.056, pred_mae_q80 -0.016, pred_mfe_q20 0.022, pred_mfe_q50 0.063, pred_mfe_q80 0.112, prob_big 0.582, prob_deep 0.348, prob_trap 0.098, prob_win 0.551

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 20 Jan | -5.0% | -1.4% | -0.4% | -0.7% | -0.6% | 0.35 | 13.8 | Broad bearish | -4.3 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 23 Jan | -5.0% | 0.0% | +0.5% | +0.2% | -0.1% | 0.44 | 13.6 | Broad bearish | -5.1 pts | +3 / -3 | 100% | -18 | -18 | buy open |
| 2 | Tue 24 Jan | -5.1% | 0.0% | 0.0% | -0.3% | -0.4% | 0.38 | 13.7 | Broad bearish | -4.7 pts | -38 / -468 | 100% | -506 | -524 |  |
| 3 | Wed 25 Jan | -5.0% | 0.0% | -1.2% | -1.3% | -0.9% | 0.20 | 14.7 | Broad bearish | -3.8 pts | -135 / -366 | 100% | -475 | -999 |  |
| 4 | Fri 27 Jan | -4.9% | 0.0% | -1.6% | -1.2% | -1.8% | 0.15 | 17.3 | Broad bearish | -3.7 pts | -134 / -359 | 100% | -445 | -1444 |  |
| 5 | Mon 30 Jan | -5.0% | 0.0% | +0.3% | -0.2% | -0.2% | 0.41 | 17.7 | HIGH STRESS | -4.9 pts | -16 / -485 | 100% | -429 | -1873 |  |
| 6 | Tue 31 Jan | -5.1% | 0.0% | +0.1% | +1.5% | +2.6% | 0.78 | 16.9 | HIGH STRESS | -6.6 pts | +165 / -673 | 100% | -414 | -2287 |  |
| 7 | Wed 01 Feb | -4.8% | 0.0% | -0.3% | -0.9% | -1.1% | 0.27 | 16.8 | Broad bearish | -3.9 pts | -92 / -384 | 100% | -368 | -2656 |  |
| 8 | Thu 02 Feb | -5.0% | 0.0% | 0.0% | +0.2% | +0.4% | 0.47 | 15.7 | Broad bearish | -5.2 pts | +19 / -519 | 100% | -368 | -3024 |  |
| 9 | Fri 03 Feb | -5.0% | 0.0% | +1.4% | -0.1% | -0.4% | 0.36 | 14.4 | Broad bearish | -4.9 pts | -13 / -492 | 100% | -353 | -3376 |  |
| 10 | Mon 06 Feb | -4.8% | 0.0% | -0.5% | +0.9% | +0.3% | 0.54 | 14.7 | Broad bearish | -5.7 pts | +92 / -577 | 100% | -322 | -3698 |  |
| 11 | Tue 07 Feb | -5.1% | 0.0% | -0.2% | 0.0% | -0.4% | 0.41 | 14.1 | Broad bearish | -5.1 pts | -1 / -508 | 100% | -322 | -4021 |  |
| 12 | Wed 08 Feb | -4.9% | 0.0% | +0.8% | +0.8% | +0.8% | 0.65 | 13.6 | Broad bearish | -5.7 pts | +91 / -577 | 100% | -291 | -4312 |  |
| 13 | Thu 09 Feb | -5.1% | 0.0% | +0.1% | +0.1% | -0.3% | 0.48 | 13.0 | Broad bearish | -5.2 pts | +9 / -520 | 100% | -291 | -4603 |  |
| 14 | Fri 10 Feb | -4.8% | 0.0% | -0.2% | +0.2% | +0.5% | 0.51 | 12.8 | Broad bearish | -5.1 pts | +27 / -508 | 100% | -261 | -4864 |  |
| 15 | Mon 13 Feb | -5.1% | 0.0% | -0.5% | -1.3% | -1.2% | 0.26 | 13.7 | Broad bearish | -3.8 pts | -141 / -365 | 100% | -261 | -5125 |  |
| 16 | Tue 14 Feb | -5.0% | 0.0% | +0.9% | -0.4% | -0.5% | 0.33 | 13.4 | Broad bearish | -4.6 pts | -47 / -455 | 100% | -245 | -5370 |  |
| 17 | Wed 15 Feb | -5.0% | 0.0% | +0.5% | +0.5% | +0.4% | 0.56 | 12.9 | Broad bearish | -5.4 pts | +52 / -547 | 100% | -230 | -5600 |  |
| 18 | Thu 16 Feb | -4.9% | 0.0% | +0.1% | +0.8% | +0.8% | 0.59 | 12.9 | Broad bearish | -5.6 pts | +83 / -569 | 100% | -215 | -5815 |  |
| 19 | Fri 17 Feb | -5.1% | 0.0% | -0.5% | -0.6% | -0.3% | 0.35 | 13.1 | Broad bearish | -4.5 pts | -68 / -443 | 100% | -215 | -6030 |  |
| 20 | Mon 20 Feb | -4.6% | 0.0% | -0.6% | 0.0% | -0.3% | 0.34 | 13.4 | Broad bearish | -4.6 pts | +0 / -462 | 100% | -184 | -6214 |  |
| 21 | Tue 21 Feb | -4.8% | 0.0% | -0.1% | -0.3% | -0.3% | 0.38 | 14.0 | Broad bearish | -4.6 pts | -29 / -455 | 100% | -184 | -6398 |  |
| 22 | Wed 22 Feb | -5.1% | 0.0% | -1.5% | -1.0% | -1.1% | 0.19 | 15.6 | Broad bearish | -4.1 pts | -108 / -400 | 100% | -184 | -6582 |  |
| 23 | Thu 23 Feb | +4.9% | +10.3% | -0.2% | -0.2% | +0.2% | 0.44 | 15.1 | Broad bearish | +5.2 pts | -26 / +517 | 100% | +169 | -6413 |  |
| 24 | Fri 24 Feb | +4.7% | 0.0% | -0.3% | -0.2% | -0.2% | 0.39 | 14.2 | Broad bearish | +4.9 pts | +31 / +437 | 0% | +151 | -6262 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 23 Jan 2023 at the open 6.52; sold Fri 24 Feb 2023 at the open 2.46 (lower-circuit lock: sold at the first free open). Gross -62.27%, costs -35 bp, net -6262 bp.
- Over the same hold: NIFTY -2.9%, Midcap -2.6%, Smallcap -3.5%; VIX +9.4%; breadth averaged 0.41; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -5936 bp, Midcap -5969 bp, Smallcap -5873 bp.
- Split: market part -2.78% = beta 1.08 x Midcap 150 -2.58%; stock part -59.49% -> **mostly the stock itself**.
- The stock's own strongest day: session 23 (+517 bp beyond its market); weakest: session 6 (-673 bp).

_Pick day Fri 20 Jan 2023 [Broad bearish]: NIFTY -0.4%, Smallcap -0.6%, breadth 0.35, VIX 13.8 (-5% in 5 days) -> ENS rank 2 PCJEWELLER (moves with Midcap 150, beta 1.08) -> bought Mon 23 Jan 2023 open, sold Fri 24 Feb 2023 open: gross -62.27%, net -6262 bp -> during the hold NIFTY -2.9%, Smallcap -3.5%, 2 high-stress day(s) -> market part -2.78%, stock part -59.49%: mostly the stock itself._

## ENS-20260302-2 - AQYLON - net -4638 bp (gross -46.03%) - SEVERE LOSER

- ENS rank 2 (score 0.999) | the other engine ranked it 3 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 0.81, correlation 0.15; NIFTY beta 0.81, Smallcap beta 0.02)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 27 Feb 2026: NIFTY -1.2%, Midcap -1.1%, Smallcap -1.0%; NIFTY minus Smallcap -0.2 pts (20-day -1.6 pts); breadth 0.30 (703 up / 1,648 down of 2,382; 10-day 0.44); VIX 13.7 (day +4.9%, 5-day -4.6%, 73rd percentile); environment: Broad bearish.
- Pick day: Mon 02 Mar 2026: NIFTY -1.2%, Midcap -1.7%, Smallcap -1.9%; NIFTY minus Smallcap +0.7 pts (20-day -1.4 pts); breadth 0.13 (310 up / 2,068 down of 2,385; 10-day 0.41); VIX 17.1 (day +25.0%, 5-day +20.9%, 90th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 90th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-3.8 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 10 sessions, mature) | S10 breakdown CONFIRMED (3d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W5 VIX up 15% or more in 5 days; W6 Smallcap fell 1.5% or more on the pick day

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.035, pred_mae_q20 -0.115, pred_mae_q50 -0.050, pred_mae_q80 -0.017, pred_mfe_q20 0.040, pred_mfe_q50 0.094, pred_mfe_q80 0.164, prob_big 0.760, prob_deep 0.420, prob_trap 0.164, prob_win 0.660

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 02 Mar | -5.0% | 0.0% | -1.2% | -1.7% | -1.9% | 0.13 | 17.1 | HIGH STRESS | -3.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 04 Mar | -5.0% | -1.0% | -1.5% | -2.2% | -2.1% | 0.14 | 21.1 | HIGH STRESS | -3.4 pts | +31 / -131 | 100% | -118 | -118 | buy open |
| 2 | Thu 05 Mar | +5.0% | +4.4% | +1.2% | +1.5% | +1.4% | 0.70 | 17.9 | HIGH STRESS | +3.8 pts | +95 / +403 | 100% | +493 | +375 |  |
| 3 | Fri 06 Mar | -4.5% | -6.5% | -1.3% | -0.7% | -0.3% | 0.35 | 19.9 | HIGH STRESS | -3.2 pts | -104 / -344 | 100% | -466 | -91 |  |
| 4 | Mon 09 Mar | -5.0% | 0.0% | -1.7% | -2.0% | -2.3% | 0.14 | 23.4 | HIGH STRESS | -3.2 pts | -141 / -356 | 100% | -493 | -584 |  |
| 5 | Tue 10 Mar | -4.9% | 0.0% | +1.0% | +1.6% | +2.1% | 0.84 | 18.9 | HIGH STRESS | -5.9 pts | +79 / -573 | 100% | -466 | -1049 |  |
| 6 | Wed 11 Mar | -5.0% | 0.0% | -1.6% | -1.1% | -0.4% | 0.38 | 21.1 | HIGH STRESS | -3.4 pts | -132 / -367 | 100% | -447 | -1497 |  |
| 7 | Thu 12 Mar | -4.9% | 0.0% | -1.0% | -0.2% | -0.4% | 0.34 | 21.5 | HIGH STRESS | -4.0 pts | -78 / -415 | 100% | -420 | -1917 |  |
| 8 | Fri 13 Mar | -5.0% | 0.0% | -2.1% | -2.7% | -2.7% | 0.10 | 22.6 | HIGH STRESS | -2.9 pts | -168 / -328 | 100% | -402 | -2319 |  |
| 9 | Mon 16 Mar | -5.0% | 0.0% | +1.1% | -0.4% | -0.4% | 0.34 | 21.6 | HIGH STRESS | -6.1 pts | +91 / -589 | 100% | -384 | -2702 |  |
| 10 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts | +60 / -559 | 100% | -365 | -3068 |  |
| 11 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +68 / -567 | 100% | -347 | -3415 |  |
| 12 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -266 / -232 | 100% | -329 | -3744 |  |
| 13 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +40 / -535 | 100% | -311 | -4054 |  |
| 14 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -212 / -278 | 100% | -292 | -4346 |  |
| 15 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +132 / -615 | 0% | -291 | -4638 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 04 Mar 2026 at the open 109.50; sold Tue 24 Mar 2026 at the open 59.10 (lower-circuit lock: sold at the first free open). Gross -46.03%, costs -35 bp, net -4638 bp.
- Over the same hold: NIFTY -6.2%, Midcap -6.1%, Smallcap -5.2%; VIX +56.0%; breadth averaged 0.42; 15 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3983 bp, Midcap -3991 bp, Smallcap -4082 bp.
- Split: market part -5.04% = beta 0.81 x NIFTY 50 -6.19%; stock part -40.99% -> **mostly the stock itself**.
- The stock's own strongest day: session 2 (+403 bp beyond its market); weakest: session 15 (-615 bp).

_Pick day Mon 02 Mar 2026 [HIGH STRESS]: NIFTY -1.2%, Smallcap -1.9%, breadth 0.13, VIX 17.1 (+21% in 5 days) -> ENS rank 2 AQYLON (moves with NIFTY 50, beta 0.81) -> bought Wed 04 Mar 2026 open, sold Tue 24 Mar 2026 open: gross -46.03%, net -4638 bp -> during the hold NIFTY -6.2%, Smallcap -5.2%, 15 high-stress day(s) -> market part -5.04%, stock part -40.99%: mostly the stock itself._

## ENS-20230202-3 - PCJEWELLER - net -4354 bp (gross -43.19%) - SEVERE LOSER

- ENS rank 3 (score 0.996) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 0.99, correlation 0.29; NIFTY beta 0.83, Smallcap beta 0.82)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 01 Feb 2023: NIFTY -0.3%, Midcap -0.9%, Smallcap -1.1%; NIFTY minus Smallcap +0.9 pts (20-day +0.9 pts); breadth 0.27 (491 up / 1,306 down of 1,818; 10-day 0.39); VIX 16.8 (day -0.6%, 5-day +22.8%, 27th percentile); environment: Broad bearish.
- Pick day: Thu 02 Feb 2023: NIFTY 0.0%, Midcap +0.2%, Smallcap +0.4%; NIFTY minus Smallcap -0.5 pts (20-day +0.6 pts); breadth 0.47 (832 up / 957 down of 1,820; 10-day 0.38); VIX 15.7 (day -6.3%, 5-day +7.3%, 22nd percentile); environment: Broad bearish.
- The stock: day before -4.8%, pick day -5.0% (-5.2 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 10 sessions, mature) | S10 breakdown CONFIRMED (8d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.005, pred_mae_q20 -0.143, pred_mae_q50 -0.062, pred_mae_q80 -0.013, pred_mfe_q20 0.021, pred_mfe_q50 0.088, pred_mfe_q80 0.162, prob_big 0.670, prob_deep 0.484, prob_trap 0.393, prob_win 0.447

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 02 Feb | -5.0% | 0.0% | 0.0% | +0.2% | +0.4% | 0.47 | 15.7 | Broad bearish | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 03 Feb | -5.0% | 0.0% | +1.4% | -0.1% | -0.4% | 0.36 | 14.4 | Broad bearish | -4.9 pts | -37 / +37 | 100% | -18 | -18 | buy open |
| 2 | Mon 06 Feb | -4.8% | 0.0% | -0.5% | +0.9% | +0.3% | 0.54 | 14.7 | Broad bearish | -5.7 pts | +84 / -569 | 100% | -485 | -502 |  |
| 3 | Tue 07 Feb | -5.1% | 0.0% | -0.2% | 0.0% | -0.4% | 0.41 | 14.1 | Broad bearish | -5.1 pts | -1 / -509 | 100% | -485 | -987 |  |
| 4 | Wed 08 Feb | -4.9% | 0.0% | +0.8% | +0.8% | +0.8% | 0.65 | 13.6 | Broad bearish | -5.7 pts | +83 / -569 | 100% | -439 | -1426 |  |
| 5 | Thu 09 Feb | -5.1% | 0.0% | +0.1% | +0.1% | -0.3% | 0.48 | 13.0 | Broad bearish | -5.2 pts | +9 / -519 | 100% | -439 | -1865 |  |
| 6 | Fri 10 Feb | -4.8% | 0.0% | -0.2% | +0.2% | +0.5% | 0.51 | 12.8 | Broad bearish | -5.1 pts | +24 / -506 | 100% | -393 | -2258 |  |
| 7 | Mon 13 Feb | -5.1% | 0.0% | -0.5% | -1.3% | -1.2% | 0.26 | 13.7 | Broad bearish | -3.8 pts | -129 / -377 | 100% | -393 | -2650 |  |
| 8 | Tue 14 Feb | -5.0% | 0.0% | +0.9% | -0.4% | -0.5% | 0.33 | 13.4 | Broad bearish | -4.6 pts | -42 / -459 | 100% | -370 | -3020 |  |
| 9 | Wed 15 Feb | -5.0% | 0.0% | +0.5% | +0.5% | +0.4% | 0.56 | 12.9 | Broad bearish | -5.4 pts | +47 / -542 | 100% | -346 | -3366 |  |
| 10 | Thu 16 Feb | -4.9% | 0.0% | +0.1% | +0.8% | +0.8% | 0.59 | 12.9 | Broad bearish | -5.6 pts | +76 / -562 | 100% | -323 | -3690 |  |
| 11 | Fri 17 Feb | -5.1% | 0.0% | -0.5% | -0.6% | -0.3% | 0.35 | 13.1 | Broad bearish | -4.5 pts | -62 / -449 | 100% | -323 | -4013 |  |
| 12 | Mon 20 Feb | -4.6% | 0.0% | -0.6% | 0.0% | -0.3% | 0.34 | 13.4 | Broad bearish | -4.6 pts | +0 / -462 | 100% | -277 | -4290 |  |
| 13 | Tue 21 Feb | -4.8% | 0.0% | -0.1% | -0.3% | -0.3% | 0.38 | 14.0 | Broad bearish | -4.6 pts | -26 / -458 | 100% | -277 | -4567 |  |
| 14 | Wed 22 Feb | -5.1% | 0.0% | -1.5% | -1.0% | -1.1% | 0.19 | 15.6 | Broad bearish | -4.1 pts | -99 / -410 | 100% | -277 | -4844 |  |
| 15 | Thu 23 Feb | +4.9% | +10.3% | -0.2% | -0.2% | +0.2% | 0.44 | 15.1 | Broad bearish | +5.2 pts | -24 / +515 | 100% | +254 | -4590 |  |
| 16 | Fri 24 Feb | +4.7% | 0.0% | -0.3% | -0.2% | -0.2% | 0.39 | 14.2 | Broad bearish | +4.9 pts | +28 / +440 | 0% | +237 | -4354 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 03 Feb 2023 at the open 4.33; sold Fri 24 Feb 2023 at the open 2.46 (lower-circuit lock: sold at the first free open). Gross -43.19%, costs -35 bp, net -4354 bp.
- Over the same hold: NIFTY -0.7%, Midcap -0.7%, Smallcap -1.9%; VIX -4.1%; breadth averaged 0.42; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -4245 bp, Midcap -4246 bp, Smallcap -4125 bp.
- Split: market part -0.72% = beta 0.99 x Midcap 150 -0.73%; stock part -42.47% -> **mostly the stock itself**.
- The stock's own strongest day: session 15 (+515 bp beyond its market); weakest: session 2 (-569 bp).

_Pick day Thu 02 Feb 2023 [Broad bearish]: NIFTY 0.0%, Smallcap +0.4%, breadth 0.47, VIX 15.7 (+7% in 5 days) -> ENS rank 3 PCJEWELLER (moves with Midcap 150, beta 0.99) -> bought Fri 03 Feb 2023 open, sold Fri 24 Feb 2023 open: gross -43.19%, net -4354 bp -> during the hold NIFTY -0.7%, Smallcap -1.9% -> market part -0.72%, stock part -42.47%: mostly the stock itself._

## ENS-20220112-1 - TTML - net -4353 bp (gross -43.18%) - SEVERE LOSER

- ENS rank 1 (score 0.996) | the other engine ranked it 6 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.63, correlation 0.18; NIFTY beta 0.20, Smallcap beta 0.63)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 11 Jan 2022: NIFTY +0.3%, Midcap +0.2%, Smallcap +0.1%; NIFTY minus Smallcap +0.2 pts (20-day +0.6 pts); breadth 0.46 (748 up / 895 down of 1,669; 10-day 0.57); VIX 17.8 (day +0.5%, 5-day +10.2%, 56th percentile); environment: Broad bullish.
- Pick day: Wed 12 Jan 2022: NIFTY +0.9%, Midcap +1.2%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day +1.1 pts); breadth 0.54 (893 up / 748 down of 1,668; 10-day 0.57); VIX 17.2 (day -3.3%, 5-day -0.3%, 48th percentile); environment: Broad bullish.
- The stock: day before +5.0%, pick day -5.0% (-5.6 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S01 Strong bullish continuation (HIGH, 37 sessions, mature) | S04 breakout CONFIRMED (9d) | risk: S05 extremely overextended; repeated large gaps
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.009, pred_mae_q20 -0.124, pred_mae_q50 -0.066, pred_mae_q80 -0.023, pred_mfe_q20 0.017, pred_mfe_q50 0.064, pred_mfe_q80 0.134, prob_big 0.558, prob_deep 0.524, prob_trap 0.141, prob_win 0.378

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 12 Jan | -5.0% | 0.0% | +0.9% | +1.2% | +0.6% | 0.54 | 17.2 | Broad bullish | -5.6 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 13 Jan | -5.0% | 0.0% | +0.2% | +0.5% | +0.6% | 0.53 | 16.7 | Broad bullish | -5.6 pts | +16 / -16 | 100% | -18 | -18 | buy open |
| 2 | Fri 14 Jan | -5.0% | 0.0% | 0.0% | 0.0% | +0.7% | 0.60 | 16.6 | Broad bullish | -5.7 pts | +43 / -542 | 100% | -498 | -516 |  |
| 3 | Mon 17 Jan | -5.0% | 0.0% | +0.3% | +0.3% | +0.5% | 0.62 | 16.8 | Broad bullish | -5.4 pts | +29 / -527 | 100% | -473 | -989 |  |
| 4 | Tue 18 Jan | -5.0% | 0.0% | -1.1% | -1.9% | -2.0% | 0.19 | 17.8 | Broad bullish | -2.9 pts | -129 / -370 | 100% | -451 | -1440 |  |
| 5 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts | +14 / -513 | 100% | -428 | -1867 |  |
| 6 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -7 / -492 | 100% | -407 | -2274 |  |
| 7 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -118 / -380 | 100% | -386 | -2660 |  |
| 8 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -291 / -207 | 100% | -367 | -3026 |  |
| 9 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +67 / -567 | 100% | -349 | -3376 |  |
| 10 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -29 / -468 | 100% | -330 | -3706 |  |
| 11 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +33 / -532 | 100% | -315 | -4021 |  |
| 12 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +61 / -560 | 100% | -300 | -4321 |  |
| 13 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +47 / -547 | 100% | -284 | -4605 |  |
| 14 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +51 / +446 | 0% | +252 | -4353 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 13 Jan 2022 at the open 261.90; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -43.18%, costs -35 bp, net -4353 bp.
- Over the same hold: NIFTY -3.0%, Midcap -3.5%, Smallcap -3.5%; VIX +16.3%; breadth averaged 0.48; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -4017 bp, Midcap -3965 bp, Smallcap -3970 bp.
- Split: market part -2.20% = beta 0.63 x Smallcap 250 -3.48%; stock part -40.99% -> **mostly the stock itself**.
- The stock's own strongest day: session 14 (+446 bp beyond its market); weakest: session 9 (-567 bp).

_Pick day Wed 12 Jan 2022 [Broad bullish]: NIFTY +0.9%, Smallcap +0.6%, breadth 0.54, VIX 17.2 (0% in 5 days) -> ENS rank 1 TTML (moves with Smallcap 250, beta 0.63) -> bought Thu 13 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -43.18%, net -4353 bp -> during the hold NIFTY -3.0%, Smallcap -3.5%, 1 high-stress day(s) -> market part -2.20%, stock part -40.99%: mostly the stock itself._

## ENS-20260306-1 - AQYLON - net -4314 bp (gross -42.79%) - SEVERE LOSER

- ENS rank 1 (score 0.999) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.14, correlation 0.22; NIFTY beta 1.14, Smallcap beta 0.22)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 05 Mar 2026: NIFTY +1.2%, Midcap +1.5%, Smallcap +1.4%; NIFTY minus Smallcap -0.2 pts (20-day -0.1 pts); breadth 0.70 (1,653 up / 721 down of 2,393; 10-day 0.37); VIX 17.9 (day -15.5%, 5-day +32.4%, 93rd percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 93rd percentile of 250 sessions; VIX +32% in 5 sessions.
- Pick day: Fri 06 Mar 2026: NIFTY -1.3%, Midcap -0.7%, Smallcap -0.3%; NIFTY minus Smallcap -1.0 pts (20-day -1.5 pts); breadth 0.35 (837 up / 1,536 down of 2,392; 10-day 0.39); VIX 19.9 (day +11.3%, 5-day +52.2%, 97th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 97th percentile of 250 sessions; VIX +52% in 5 sessions.
- The stock: day before +5.0%, pick day -4.5% (-3.2 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 13 sessions, mature) | S10 breakdown CONFIRMED (6d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40; W5 VIX up 15% or more in 5 days

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.021, pred_mae_q20 -0.177, pred_mae_q50 -0.071, pred_mae_q80 -0.026, pred_mfe_q20 0.031, pred_mfe_q50 0.074, pred_mfe_q80 0.155, prob_big 0.673, prob_deep 0.555, prob_trap 0.171, prob_win 0.583

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 06 Mar | -4.5% | -6.5% | -1.3% | -0.7% | -0.3% | 0.35 | 19.9 | HIGH STRESS | -3.2 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 09 Mar | -5.0% | 0.0% | -1.7% | -2.0% | -2.3% | 0.14 | 23.4 | HIGH STRESS | -3.2 pts | +76 / -76 | 100% | -18 | -18 | buy open |
| 2 | Tue 10 Mar | -4.9% | 0.0% | +1.0% | +1.6% | +2.1% | 0.84 | 18.9 | HIGH STRESS | -5.9 pts | +111 / -604 | 100% | -494 | -511 |  |
| 3 | Wed 11 Mar | -5.0% | 0.0% | -1.6% | -1.1% | -0.4% | 0.38 | 21.1 | HIGH STRESS | -3.4 pts | -185 / -314 | 100% | -474 | -986 |  |
| 4 | Thu 12 Mar | -4.9% | 0.0% | -1.0% | -0.2% | -0.4% | 0.34 | 21.5 | HIGH STRESS | -4.0 pts | -109 / -384 | 100% | -445 | -1431 |  |
| 5 | Fri 13 Mar | -5.0% | 0.0% | -2.1% | -2.7% | -2.7% | 0.10 | 22.6 | HIGH STRESS | -2.9 pts | -235 / -261 | 100% | -426 | -1857 |  |
| 6 | Mon 16 Mar | -5.0% | 0.0% | +1.1% | -0.4% | -0.4% | 0.34 | 21.6 | HIGH STRESS | -6.1 pts | +127 / -625 | 100% | -407 | -2263 |  |
| 7 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts | +84 / -583 | 100% | -387 | -2651 |  |
| 8 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +95 / -594 | 100% | -368 | -3018 |  |
| 9 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -371 / -127 | 100% | -348 | -3367 |  |
| 10 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +56 / -551 | 100% | -329 | -3696 |  |
| 11 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -296 / -194 | 100% | -310 | -4006 |  |
| 12 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +185 / -668 | 0% | -308 | -4314 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 09 Mar 2026 at the open 103.30; sold Tue 24 Mar 2026 at the open 59.10 (lower-circuit lock: sold at the first free open). Gross -42.79%, costs -35 bp, net -4314 bp.
- Over the same hold: NIFTY -4.1%, Midcap -4.4%, Smallcap -3.9%; VIX +34.5%; breadth averaged 0.43; 12 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3864 bp, Midcap -3836 bp, Smallcap -3889 bp.
- Split: market part -4.72% = beta 1.14 x NIFTY 50 -4.15%; stock part -38.07% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (-76 bp beyond its market); weakest: session 12 (-668 bp).

_Pick day Fri 06 Mar 2026 [HIGH STRESS]: NIFTY -1.3%, Smallcap -0.3%, breadth 0.35, VIX 19.9 (+52% in 5 days) -> ENS rank 1 AQYLON (moves with NIFTY 50, beta 1.14) -> bought Mon 09 Mar 2026 open, sold Tue 24 Mar 2026 open: gross -42.79%, net -4314 bp -> during the hold NIFTY -4.1%, Smallcap -3.9%, 12 high-stress day(s) -> market part -4.72%, stock part -38.07%: mostly the stock itself._

## ENS-20260317-1 - AQYLON - net -3847 bp (gross -38.12%) - SEVERE LOSER

- ENS rank 1 (score 1.000) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.19, correlation 0.24; NIFTY beta 1.19, Smallcap beta 0.30)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 16 Mar 2026: NIFTY +1.1%, Midcap -0.4%, Smallcap -0.4%; NIFTY minus Smallcap +1.5 pts (20-day -0.7 pts); breadth 0.34 (805 up / 1,580 down of 2,402; 10-day 0.35); VIX 21.6 (day -4.6%, 5-day -7.5%, 98th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 98th percentile of 250 sessions.
- Pick day: Tue 17 Mar 2026: NIFTY +0.7%, Midcap +1.0%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day -1.4 pts); breadth 0.63 (1,487 up / 889 down of 2,399; 10-day 0.40); VIX 19.8 (day -8.4%, 5-day +4.7%, 95th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 95th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-5.7 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 20 sessions, mature) | S10 breakdown CONFIRMED (6d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.032, pred_mae_q20 -0.133, pred_mae_q50 -0.047, pred_mae_q80 -0.022, pred_mfe_q20 0.030, pred_mfe_q50 0.099, pred_mfe_q80 0.188, prob_big 0.708, prob_deep 0.311, prob_trap 0.347, prob_win 0.467

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 17 Mar | -5.0% | 0.0% | +0.7% | +1.0% | +0.6% | 0.63 | 19.8 | HIGH STRESS | -5.7 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts | +73 / -73 | 100% | -18 | -18 | buy open |
| 2 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -387 / -110 | 100% | -498 | -515 |  |
| 3 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +58 / -553 | 100% | -470 | -986 |  |
| 4 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -309 / -181 | 100% | -443 | -1428 |  |
| 5 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +211 / -710 | 100% | -429 | -1857 |  |
| 6 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +204 / -696 | 100% | -401 | -2258 |  |
| 7 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -248 / -251 | 100% | -387 | -2645 |  |
| 8 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -254 / -234 | 100% | -360 | -3005 |  |
| 9 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +185 / -684 | 100% | -350 | -3355 |  |
| 10 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +18 / -516 | 100% | -332 | -3687 |  |
| 11 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +133 / -632 | 100% | -315 | -4002 |  |
| 12 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +80 / -579 | 100% | -300 | -4302 |  |
| 13 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +449 / -30 | 100% | +239 | -4063 |  |
| 14 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -44 / +436 | 0% | +216 | -3847 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 18 Mar 2026 at the open 72.30; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -38.12%, costs -35 bp, net -3847 bp.
- Over the same hold: NIFTY +1.2%, Midcap +2.5%, Smallcap +3.7%; VIX -0.5%; breadth averaged 0.56; 14 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3929 bp, Midcap -4061 bp, Smallcap -4180 bp.
- Split: market part +1.39% = beta 1.19 x NIFTY 50 +1.17%; stock part -39.51% -> **mostly the stock itself**.
- The stock's own strongest day: session 14 (+436 bp beyond its market); weakest: session 5 (-710 bp).

_Pick day Tue 17 Mar 2026 [HIGH STRESS]: NIFTY +0.7%, Smallcap +0.6%, breadth 0.63, VIX 19.8 (+5% in 5 days) -> ENS rank 1 AQYLON (moves with NIFTY 50, beta 1.19) -> bought Wed 18 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -38.12%, net -3847 bp -> during the hold NIFTY +1.2%, Smallcap +3.7%, 14 high-stress day(s) -> market part +1.39%, stock part -39.51%: mostly the stock itself._

## ENS-20241105-2 - TRU - net -3676 bp (gross -36.41%) - SEVERE LOSER

- ENS rank 2 (score 0.992) | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.38, correlation 0.16; NIFTY beta 0.21, Smallcap beta 0.38)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 04 Nov 2024: NIFTY -1.3%, Midcap -1.2%, Smallcap -1.8%; NIFTY minus Smallcap +0.6 pts (20-day -3.8 pts); breadth 0.20 (412 up / 1,675 down of 2,099; 10-day 0.49); VIX 16.7 (day +5.0%, 5-day +16.8%, 90th percentile); environment: Broad bearish.
- Pick day: Tue 05 Nov 2024: NIFTY +0.9%, Midcap +0.5%, Smallcap +0.5%; NIFTY minus Smallcap +0.4 pts (20-day -2.1 pts); breadth 0.66 (1,359 up / 713 down of 2,094; 10-day 0.54); VIX 16.1 (day -3.4%, 5-day +11.0%, 87th percentile); environment: Mixed / ranging.
- The stock: day before +3.9%, pick day +3.3% (+2.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S08 Bearish continuation (HIGH, 21 sessions, mature) | S10 breakdown CONFIRMED (7d)
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.010, pred_mae_q20 -0.080, pred_mae_q50 -0.045, pred_mae_q80 -0.022, pred_mfe_q20 0.020, pred_mfe_q50 0.053, pred_mfe_q80 0.132, prob_big 0.537, prob_deep 0.128, prob_trap 0.012, prob_win 0.483

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 05 Nov | +3.3% | +2.3% | +0.9% | +0.5% | +0.5% | 0.66 | 16.1 | Mixed / ranging | +2.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 06 Nov | -4.7% | -8.0% | +1.1% | +2.1% | +1.9% | 0.83 | 14.9 | Mixed / ranging | -6.6 pts | +52 / -848 | 100% | -813 | -813 | buy open |
| 2 | Thu 07 Nov | -2.0% | 0.0% | -1.2% | -0.5% | -0.6% | 0.35 | 14.9 | Mixed / ranging | -1.4 pts | -24 / -178 | 100% | -185 | -998 |  |
| 3 | Fri 08 Nov | -2.0% | 0.0% | -0.2% | -1.3% | -1.6% | 0.24 | 14.5 | Mixed / ranging | -0.4 pts | -59 / -142 | 100% | -181 | -1180 |  |
| 4 | Mon 11 Nov | -2.0% | 0.0% | 0.0% | -0.8% | -1.2% | 0.27 | 14.3 | Mixed / ranging | -0.8 pts | -45 / -156 | 100% | -178 | -1357 |  |
| 5 | Tue 12 Nov | -2.0% | 0.0% | -1.1% | -0.9% | -1.3% | 0.21 | 14.6 | Mixed / ranging | -0.7 pts | -50 / -151 | 100% | -174 | -1531 |  |
| 6 | Wed 13 Nov | -2.0% | 0.0% | -1.4% | -2.7% | -3.1% | 0.09 | 15.4 | HIGH STRESS | +1.1 pts | -116 / -84 | 100% | -170 | -1701 |  |
| 7 | Thu 14 Nov | -2.0% | 0.0% | -0.1% | +0.5% | +0.8% | 0.55 | 14.8 | Broad bearish | -2.8 pts | +30 / -234 | 100% | -170 | -1871 |  |
| 8 | Mon 18 Nov | -2.0% | 0.0% | -0.3% | -0.2% | -0.6% | 0.36 | 15.2 | Broad bearish | -1.4 pts | -24 / -179 | 100% | -166 | -2037 |  |
| 9 | Tue 19 Nov | -2.0% | 0.0% | +0.3% | +0.9% | +0.9% | 0.67 | 15.7 | Broad bearish | -2.9 pts | +35 / -238 | 100% | -162 | -2199 |  |
| 10 | Thu 21 Nov | -2.0% | 0.0% | -0.7% | -0.4% | -0.6% | 0.24 | 16.0 | Broad bearish | -1.4 pts | -22 / -181 | 100% | -158 | -2357 |  |
| 11 | Fri 22 Nov | -2.0% | 0.0% | +2.4% | +1.1% | +1.0% | 0.71 | 16.1 | HIGH STRESS | -3.0 pts | +37 / -239 | 100% | -154 | -2512 |  |
| 12 | Mon 25 Nov | -2.0% | 0.0% | +1.3% | +1.5% | +2.1% | 0.75 | 15.3 | Broad bearish | -4.1 pts | +80 / -281 | 100% | -151 | -2662 |  |
| 13 | Tue 26 Nov | -2.0% | 0.0% | -0.1% | 0.0% | +0.6% | 0.59 | 15.3 | Broad bearish | -2.7 pts | +23 / -228 | 100% | -151 | -2813 |  |
| 14 | Wed 27 Nov | -2.0% | 0.0% | +0.3% | +0.5% | +1.0% | 0.72 | 14.6 | Broad bearish | -3.1 pts | +39 / -242 | 100% | -147 | -2960 |  |
| 15 | Thu 28 Nov | -2.0% | 0.0% | -1.5% | 0.0% | +0.1% | 0.54 | 15.2 | Mixed / ranging | -2.2 pts | +5 / -208 | 100% | -143 | -3102 |  |
| 16 | Fri 29 Nov | -2.0% | 0.0% | +0.9% | +0.3% | +0.8% | 0.65 | 14.4 | Mixed / ranging | -2.8 pts | +30 / -231 | 100% | -139 | -3241 |  |
| 17 | Mon 02 Dec | -2.1% | 0.0% | +0.6% | +1.0% | +0.7% | 0.66 | 14.7 | Mixed / ranging | -2.7 pts | +26 / -232 | 100% | -139 | -3380 |  |
| 18 | Tue 03 Dec | -2.0% | 0.0% | +0.7% | +0.9% | +0.9% | 0.74 | 14.4 | Mixed / ranging | -3.0 pts | +36 / -239 | 100% | -135 | -3516 |  |
| 19 | Wed 04 Dec | -2.0% | 0.0% | 0.0% | +0.9% | +0.8% | 0.59 | 14.4 | Mixed / ranging | -2.8 pts | +29 / -231 | 100% | -131 | -3647 |  |
| 20 | Thu 05 Dec | -2.0% | 0.0% | +1.0% | +0.4% | +0.5% | 0.52 | 14.5 | Broad bullish | -2.5 pts | +18 / -218 | 100% | -127 | -3774 |  |
| 21 | Fri 06 Dec | -2.0% | 0.0% | -0.1% | +0.4% | +0.5% | 0.60 | 14.1 | Broad bullish | -2.6 pts | +21 / -225 | 100% | -127 | -3902 |  |
| 22 | Mon 09 Dec | +2.0% | +4.1% | -0.2% | +0.4% | +0.4% | 0.54 | 14.1 | Broad bullish | +1.6 pts | +14 / +182 | 100% | +120 | -3782 |  |
| 23 | Tue 10 Dec | +2.0% | 0.0% | 0.0% | +0.3% | +0.3% | 0.50 | 13.8 | Broad bullish | +1.7 pts | +9 / +189 | 0% | +106 | -3676 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 06 Nov 2024 at the open 25.90; sold Tue 10 Dec 2024 at the open 16.47 (lower-circuit lock: sold at the first free open). Gross -36.41%, costs -35 bp, net -3676 bp.
- Over the same hold: NIFTY +1.4%, Midcap +3.8%, Smallcap +3.7%; VIX -12.5%; breadth averaged 0.52; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3782 bp, Midcap -4023 bp, Smallcap -4012 bp.
- Split: market part +1.41% = beta 0.38 x Smallcap 250 +3.71%; stock part -37.82% -> **mostly the stock itself**.
- The stock's own strongest day: session 23 (+189 bp beyond its market); weakest: session 1 (-848 bp).

_Pick day Tue 05 Nov 2024 [Mixed / ranging]: NIFTY +0.9%, Smallcap +0.5%, breadth 0.66, VIX 16.1 (+11% in 5 days) -> ENS rank 2 TRU (moves with Smallcap 250, beta 0.38) -> bought Wed 06 Nov 2024 open, sold Tue 10 Dec 2024 open: gross -36.41%, net -3676 bp -> during the hold NIFTY +1.4%, Smallcap +3.7%, 2 high-stress day(s) -> market part +1.41%, stock part -37.82%: mostly the stock itself._

## ENS-20260318-1 - AQYLON - net -3523 bp (gross -34.88%) - SEVERE LOSER

- ENS rank 1 (score 1.000) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.11, correlation 0.23; NIFTY beta 1.11, Smallcap beta 0.22)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 17 Mar 2026: NIFTY +0.7%, Midcap +1.0%, Smallcap +0.6%; NIFTY minus Smallcap +0.2 pts (20-day -1.4 pts); breadth 0.63 (1,487 up / 889 down of 2,399; 10-day 0.40); VIX 19.8 (day -8.4%, 5-day +4.7%, 95th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 95th percentile of 250 sessions.
- Pick day: Wed 18 Mar 2026: NIFTY +0.8%, Midcap +1.9%, Smallcap +1.8%; NIFTY minus Smallcap -0.9 pts (20-day -1.7 pts); breadth 0.85 (2,024 up / 361 down of 2,403; 10-day 0.47); VIX 18.7 (day -5.4%, 5-day -11.1%, 93rd percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 93rd percentile of 250 sessions.
- The stock: day before -5.0%, pick day -5.0% (-5.8 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 21 sessions, mature) | S10 breakdown CONFIRMED (7d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.001, pred_mae_q20 -0.143, pred_mae_q50 -0.056, pred_mae_q80 -0.020, pred_mfe_q20 0.002, pred_mfe_q50 0.089, pred_mfe_q80 0.170, prob_big 0.597, prob_deep 0.463, prob_trap 0.532, prob_win 0.354

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 18 Mar | -5.0% | 0.0% | +0.8% | +1.9% | +1.8% | 0.85 | 18.7 | HIGH STRESS | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts | -93 / +93 | 100% | -18 | -18 | buy open |
| 2 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +54 / -549 | 100% | -495 | -512 |  |
| 3 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -288 / -202 | 100% | -466 | -978 |  |
| 4 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +197 / -696 | 100% | -451 | -1429 |  |
| 5 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +191 / -682 | 100% | -422 | -1852 |  |
| 6 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -231 / -268 | 100% | -408 | -2259 |  |
| 7 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -237 / -251 | 100% | -378 | -2638 |  |
| 8 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +173 / -672 | 100% | -368 | -3006 |  |
| 9 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +16 / -515 | 100% | -349 | -3355 |  |
| 10 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +124 / -623 | 100% | -332 | -3687 |  |
| 11 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +75 / -574 | 100% | -316 | -4003 |  |
| 12 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +419 / +0 | 100% | +252 | -3751 |  |
| 13 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -41 / +433 | 0% | +228 | -3523 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 19 Mar 2026 at the open 68.70; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -34.88%, costs -35 bp, net -3523 bp.
- Over the same hold: NIFTY +3.1%, Midcap +2.4%, Smallcap +3.8%; VIX +5.2%; breadth averaged 0.53; 13 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3794 bp, Midcap -3731 bp, Smallcap -3867 bp.
- Split: market part +3.40% = beta 1.11 x NIFTY 50 +3.07%; stock part -38.27% -> **mostly the stock itself**.
- The stock's own strongest day: session 13 (+433 bp beyond its market); weakest: session 4 (-696 bp).

_Pick day Wed 18 Mar 2026 [HIGH STRESS]: NIFTY +0.8%, Smallcap +1.8%, breadth 0.85, VIX 18.7 (-11% in 5 days) -> ENS rank 1 AQYLON (moves with NIFTY 50, beta 1.11) -> bought Thu 19 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -34.88%, net -3523 bp -> during the hold NIFTY +3.1%, Smallcap +3.8%, 13 high-stress day(s) -> market part +3.40%, stock part -38.27%: mostly the stock itself._

## ENS-20220117-1 - TTML - net -3411 bp (gross -33.76%) - SEVERE LOSER

- ENS rank 1 (score 0.999) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.63, correlation 0.18; NIFTY beta 0.29, Smallcap beta 0.63)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 14 Jan 2022: NIFTY 0.0%, Midcap 0.0%, Smallcap +0.7%; NIFTY minus Smallcap -0.7 pts (20-day -2.1 pts); breadth 0.60 (989 up / 650 down of 1,666; 10-day 0.57); VIX 16.6 (day -0.9%, 5-day -5.9%, 42nd percentile); environment: Broad bullish.
- Pick day: Mon 17 Jan 2022: NIFTY +0.3%, Midcap +0.3%, Smallcap +0.5%; NIFTY minus Smallcap -0.2 pts (20-day -3.8 pts); breadth 0.62 (1,018 up / 629 down of 1,682; 10-day 0.55); VIX 16.8 (day +1.3%, 5-day -5.1%, 46th percentile); environment: Broad bullish.
- The stock: day before -5.0%, pick day -5.0% (-5.4 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S01 Strong bullish continuation (MEDIUM, 40 sessions, mature) | S04 breakout CONFIRMED (12d) | risk: repeated large gaps
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.001, pred_mae_q20 -0.117, pred_mae_q50 -0.057, pred_mae_q80 -0.020, pred_mfe_q20 0.023, pred_mfe_q50 0.074, pred_mfe_q80 0.143, prob_big 0.634, prob_deep 0.379, prob_trap 0.134, prob_win 0.530

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 17 Jan | -5.0% | 0.0% | +0.3% | +0.3% | +0.5% | 0.62 | 16.8 | Broad bullish | -5.4 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 18 Jan | -5.0% | 0.0% | -1.1% | -1.9% | -2.0% | 0.19 | 17.8 | Broad bullish | -2.9 pts | -153 / +153 | 100% | -18 | -18 | buy open |
| 2 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts | +14 / -513 | 100% | -499 | -516 |  |
| 3 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -7 / -492 | 100% | -474 | -990 |  |
| 4 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -118 / -380 | 100% | -450 | -1440 |  |
| 5 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -290 / -208 | 100% | -427 | -1867 |  |
| 6 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +67 / -566 | 100% | -407 | -2274 |  |
| 7 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -29 / -468 | 100% | -385 | -2659 |  |
| 8 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +33 / -532 | 100% | -367 | -3027 |  |
| 9 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +60 / -560 | 100% | -349 | -3376 |  |
| 10 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +47 / -546 | 100% | -332 | -3708 |  |
| 11 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +51 / +446 | 0% | +296 | -3411 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 18 Jan 2022 at the open 224.65; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -33.76%, costs -35 bp, net -3411 bp.
- Over the same hold: NIFTY -3.4%, Midcap -4.4%, Smallcap -5.2%; VIX +19.1%; breadth averaged 0.45; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3032 bp, Midcap -2934 bp, Smallcap -2857 bp.
- Split: market part -3.26% = beta 0.63 x Smallcap 250 -5.20%; stock part -30.50% -> **mostly the stock itself**.
- The stock's own strongest day: session 11 (+446 bp beyond its market); weakest: session 6 (-566 bp).

_Pick day Mon 17 Jan 2022 [Broad bullish]: NIFTY +0.3%, Smallcap +0.5%, breadth 0.62, VIX 16.8 (-5% in 5 days) -> ENS rank 1 TTML (moves with Smallcap 250, beta 0.63) -> bought Tue 18 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -33.76%, net -3411 bp -> during the hold NIFTY -3.4%, Smallcap -5.2%, 1 high-stress day(s) -> market part -3.26%, stock part -30.50%: mostly the stock itself._

## ENS-20260319-1 - AQYLON - net -3184 bp (gross -31.49%) - SEVERE LOSER

- ENS rank 1 (score 0.998) | the other engine ranked it 6 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.16, correlation 0.25; NIFTY beta 1.16, Smallcap beta 0.30)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 18 Mar 2026: NIFTY +0.8%, Midcap +1.9%, Smallcap +1.8%; NIFTY minus Smallcap -0.9 pts (20-day -1.7 pts); breadth 0.85 (2,024 up / 361 down of 2,403; 10-day 0.47); VIX 18.7 (day -5.4%, 5-day -11.1%, 93rd percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 93rd percentile of 250 sessions.
- Pick day: Thu 19 Mar 2026: NIFTY -3.3% (3.6 sd fall), Midcap -3.1% (2.7 sd fall), Smallcap -2.6% (2.1 sd fall); NIFTY minus Smallcap -0.6 pts (20-day -2.1 pts); breadth 0.09 (224 up / 2,155 down of 2,397; 10-day 0.41); VIX 22.8 (day +21.8%, 5-day +5.9%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; NIFTY -3.6 sd day.
- The stock: day before -5.0%, pick day -5.0% (-1.7 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 22 sessions, mature) | S10 breakdown CONFIRMED (8d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick; W6 Smallcap fell 1.5% or more on the pick day

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.000, pred_mae_q20 -0.158, pred_mae_q50 -0.060, pred_mae_q80 -0.021, pred_mfe_q20 0.004, pred_mfe_q50 0.090, pred_mfe_q80 0.174, prob_big 0.626, prob_deep 0.418, prob_trap 0.601, prob_win 0.350

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 19 Mar | -5.0% | 0.0% | -3.3% | -3.1% | -2.6% | 0.09 | 22.8 | HIGH STRESS | -1.7 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts | +2 / -2 | 100% | -18 | -18 | buy open |
| 2 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -301 / -189 | 100% | -490 | -508 |  |
| 3 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +205 / -704 | 100% | -475 | -982 |  |
| 4 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +199 / -690 | 100% | -444 | -1426 |  |
| 5 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -241 / -258 | 100% | -429 | -1855 |  |
| 6 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -247 / -241 | 100% | -398 | -2253 |  |
| 7 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +180 / -679 | 100% | -387 | -2641 |  |
| 8 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +17 / -515 | 100% | -368 | -3008 |  |
| 9 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +130 / -628 | 100% | -349 | -3357 |  |
| 10 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +78 / -577 | 100% | -332 | -3690 |  |
| 11 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +437 / -18 | 100% | +265 | -3425 |  |
| 12 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -43 / +435 | 0% | +241 | -3184 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 20 Mar 2026 at the open 65.30; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -31.49%, costs -35 bp, net -3184 bp.
- Over the same hold: NIFTY +3.5%, Midcap +3.3%, Smallcap +4.2%; VIX -13.6%; breadth averaged 0.57; 12 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3494 bp, Midcap -3476 bp, Smallcap -3567 bp.
- Split: market part +4.00% = beta 1.16 x NIFTY 50 +3.46%; stock part -35.48% -> **mostly the stock itself**.
- The stock's own strongest day: session 12 (+435 bp beyond its market); weakest: session 3 (-704 bp).

_Pick day Thu 19 Mar 2026 [HIGH STRESS]: NIFTY -3.3%, Smallcap -2.6%, breadth 0.09, VIX 22.8 (+6% in 5 days) -> ENS rank 1 AQYLON (moves with NIFTY 50, beta 1.16) -> bought Fri 20 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -31.49%, net -3184 bp -> during the hold NIFTY +3.5%, Smallcap +4.2%, 12 high-stress day(s) -> market part +4.00%, stock part -35.48%: mostly the stock itself._

## ENS-20220118-1 - TTML - net -3064 bp (gross -30.29%) - SEVERE LOSER

- ENS rank 1 (score 0.997) | the other engine ranked it 5 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.69, correlation 0.20; NIFTY beta 0.33, Smallcap beta 0.69)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 17 Jan 2022: NIFTY +0.3%, Midcap +0.3%, Smallcap +0.5%; NIFTY minus Smallcap -0.2 pts (20-day -3.8 pts); breadth 0.62 (1,018 up / 629 down of 1,682; 10-day 0.55); VIX 16.8 (day +1.3%, 5-day -5.1%, 46th percentile); environment: Broad bullish.
- Pick day: Tue 18 Jan 2022: NIFTY -1.1%, Midcap -1.9%, Smallcap -2.0%; NIFTY minus Smallcap +1.0 pts (20-day -2.3 pts); breadth 0.19 (311 up / 1,341 down of 1,670; 10-day 0.52); VIX 17.8 (day +6.0%, 5-day +0.1%, 58th percentile); environment: Broad bullish.
- The stock: day before -5.0%, pick day -5.0% (-2.9 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S01 Strong bullish continuation (MEDIUM, 41 sessions, mature) | S04 breakout CONFIRMED (13d) | risk: repeated large gaps
- Warning signs that fired before entry: W6 Smallcap fell 1.5% or more on the pick day

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.000, pred_mae_q20 -0.107, pred_mae_q50 -0.049, pred_mae_q80 -0.013, pred_mfe_q20 0.032, pred_mfe_q50 0.100, pred_mfe_q80 0.184, prob_big 0.709, prob_deep 0.307, prob_trap 0.158, prob_win 0.466

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 18 Jan | -5.0% | 0.0% | -1.1% | -1.9% | -2.0% | 0.19 | 17.8 | Broad bullish | -2.9 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts | +28 / -28 | 100% | -18 | -18 | buy open |
| 2 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -8 / -491 | 100% | -499 | -516 |  |
| 3 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -129 / -369 | 100% | -473 | -990 |  |
| 4 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -319 / -179 | 100% | -450 | -1439 |  |
| 5 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +73 / -573 | 100% | -429 | -1868 |  |
| 6 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -32 / -465 | 100% | -405 | -2273 |  |
| 7 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +37 / -536 | 100% | -387 | -2660 |  |
| 8 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +66 / -566 | 100% | -368 | -3028 |  |
| 9 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +52 / -551 | 100% | -349 | -3377 |  |
| 10 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +56 / +441 | 0% | +313 | -3064 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 19 Jan 2022 at the open 213.45; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -30.29%, costs -35 bp, net -3064 bp.
- Over the same hold: NIFTY -2.3%, Midcap -2.1%, Smallcap -2.7%; VIX +12.4%; breadth averaged 0.48; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2795 bp, Midcap -2820 bp, Smallcap -2762 bp.
- Split: market part -1.84% = beta 0.69 x Smallcap 250 -2.66%; stock part -28.45% -> **mostly the stock itself**.
- The stock's own strongest day: session 10 (+441 bp beyond its market); weakest: session 5 (-573 bp).

_Pick day Tue 18 Jan 2022 [Broad bullish]: NIFTY -1.1%, Smallcap -2.0%, breadth 0.19, VIX 17.8 (0% in 5 days) -> ENS rank 1 TTML (moves with Smallcap 250, beta 0.69) -> bought Wed 19 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -30.29%, net -3064 bp -> during the hold NIFTY -2.3%, Smallcap -2.7%, 1 high-stress day(s) -> market part -1.84%, stock part -28.45%: mostly the stock itself._

## ENS-20251201-2 - KAYNES - net -2944 bp (gross -29.09%) - SEVERE LOSER

- ENS rank 2 (score 0.997) | the other engine ranked it 3 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 1.09, correlation 0.34; NIFTY beta 1.25, Smallcap beta 0.97)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 28 Nov 2025: NIFTY 0.0%, Midcap -0.1%, Smallcap -0.2%; NIFTY minus Smallcap +0.2 pts (20-day +5.2 pts); breadth 0.45 (1,027 up / 1,264 down of 2,333; 10-day 0.43); VIX 11.6 (day -1.4%, 5-day -14.7%, 20th percentile); environment: Narrow bullish.
- Pick day: Mon 01 Dec 2025: NIFTY -0.1%, Midcap -0.1%, Smallcap +0.2%; NIFTY minus Smallcap -0.3 pts (20-day +4.9 pts); breadth 0.41 (951 up / 1,360 down of 2,338; 10-day 0.41); VIX 11.6 (day +0.1%, 5-day -12.2%, 21st percentile); environment: Narrow bullish.
- The stock: day before -1.5%, pick day -2.4% (-2.3 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): S08 Bearish continuation (HIGH, 14 sessions, mature) | S10 breakdown NEW (2d) | risk: stretched far below EMA20
- Warning signs that fired before entry: W3 narrow bullish at the pick; W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.001, pred_mae_q20 -0.054, pred_mae_q50 -0.029, pred_mae_q80 -0.007, pred_mfe_q20 0.021, pred_mfe_q50 0.049, pred_mfe_q80 0.081, prob_big 0.422, prob_deep 0.054, prob_trap 0.002, prob_win 0.539

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 01 Dec | -2.4% | -2.7% | -0.1% | -0.1% | +0.2% | 0.41 | 11.6 | Narrow bullish | -2.3 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 02 Dec | +0.9% | +0.7% | -0.5% | -0.2% | -0.4% | 0.29 | 11.2 | Narrow bullish | +1.1 pts | -24 / +97 | 100% | +56 | +56 | buy open |
| 2 | Wed 03 Dec | -1.9% | -2.1% | -0.2% | -0.9% | -0.4% | 0.29 | 11.2 | Narrow bullish | -1.0 pts | -97 / -91 | 100% | -189 | -133 |  |
| 3 | Thu 04 Dec | -6.2% | -6.2% | +0.2% | 0.0% | -0.2% | 0.42 | 10.8 | Narrow bullish | -6.2 pts | -5 / -615 | 100% | -613 | -746 |  |
| 4 | Fri 05 Dec | -12.5% | -10.5% | +0.6% | +0.4% | -0.5% | 0.40 | 10.3 | Narrow bullish | -12.9 pts | +43 / -1297 | 100% | -1163 | -1909 |  |
| 5 | Mon 08 Dec | -12.6% | -13.7% | -0.9% | -1.7% | -2.3% | 0.12 | 11.1 | HIGH STRESS | -10.9 pts | -185 / -1070 | 0% | -1035 | -2944 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 02 Dec 2025 at the open 5369.00; sold Mon 08 Dec 2025 at the close 3807.00. Gross -29.09%, costs -35 bp, net -2944 bp.
- Over the same hold: NIFTY -0.5%, Midcap -2.4%, Smallcap -3.8%; VIX -4.3%; breadth averaged 0.30; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2860 bp, Midcap -2665 bp, Smallcap -2525 bp.
- Split: market part -2.66% = beta 1.09 x Midcap 150 -2.44%; stock part -26.43% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+97 bp beyond its market); weakest: session 4 (-1297 bp).

_Pick day Mon 01 Dec 2025 [Narrow bullish]: NIFTY -0.1%, Smallcap +0.2%, breadth 0.41, VIX 11.6 (-12% in 5 days) -> ENS rank 2 KAYNES (moves with Midcap 150, beta 1.09) -> bought Tue 02 Dec 2025 open, sold Mon 08 Dec 2025 close: gross -29.09%, net -2944 bp -> during the hold NIFTY -0.5%, Smallcap -3.8%, 1 high-stress day(s) -> market part -2.66%, stock part -26.43%: mostly the stock itself._

## ENS-20220719-3 - TANLA - net -2895 bp (gross -28.60%) - SEVERE LOSER

- ENS rank 3 (score 0.994) | the other engine ranked it 6 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.56, correlation 0.68; NIFTY beta 1.58, Smallcap beta 1.56)

**1. The market before entry** (known at the pick day's close)

- Day before: Mon 18 Jul 2022: NIFTY +1.4%, Midcap +1.4%, Smallcap +1.5%; NIFTY minus Smallcap 0.0 pts (20-day -5.1 pts); breadth 0.78 (1,316 up / 382 down of 1,742; 10-day 0.55); VIX 17.2 (day -2.5%, 5-day -6.6%, 36th percentile); environment: Broad bullish.
- Pick day: Tue 19 Jul 2022: NIFTY +0.4%, Midcap +0.7%, Smallcap +0.8%; NIFTY minus Smallcap -0.5 pts (20-day -4.3 pts); breadth 0.64 (1,083 up / 622 down of 1,738; 10-day 0.57); VIX 17.2 (day +0.2%, 5-day -7.3%, 37th percentile); environment: Broad bullish.
- The stock: day before +5.9%, pick day +0.1% (-0.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): UNKNOWN - evidence conflicts (16 sessions) | failed breakdown (bear trap) (3d)
- Warning signs that fired before entry: W8 high-beta pick: beta to its home index 1.5 or more

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.004, pred_mae_q20 -0.090, pred_mae_q50 -0.034, pred_mae_q80 -0.016, pred_mfe_q20 0.016, pred_mfe_q50 0.046, pred_mfe_q80 0.111, prob_big 0.504, prob_deep 0.330, prob_trap 0.001, prob_win 0.494

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Tue 19 Jul | +0.1% | +0.3% | +0.4% | +0.7% | +0.8% | 0.64 | 17.2 | Broad bullish | -0.8 pts |  | 0% | +0 | +0 |  |
| 1 | Wed 20 Jul | +4.3% | +2.3% | +1.1% | +0.1% | +0.6% | 0.59 | 16.8 | Broad bullish | +3.7 pts | -48 / +282 | 100% | +216 | +216 | buy open |
| 2 | Thu 21 Jul | -1.4% | -1.7% | +0.5% | +1.3% | +0.8% | 0.63 | 16.9 | Broad bullish | -2.2 pts | +124 / -269 | 100% | -148 | +68 |  |
| 3 | Fri 22 Jul | -4.6% | -4.5% | +0.7% | +0.2% | +0.3% | 0.53 | 16.6 | Broad bullish | -4.9 pts | +43 / -501 | 100% | -462 | -393 |  |
| 4 | Mon 25 Jul | -3.2% | -4.3% | -0.5% | -0.1% | -0.4% | 0.39 | 17.7 | Broad bullish | -2.8 pts | -64 / -257 | 100% | -310 | -703 |  |
| 5 | Tue 26 Jul | -20.0% | -16.0% | -0.9% | -1.1% | -1.0% | 0.24 | 18.2 | Broad bullish | -19.0 pts | -160 / -1840 | 100% | -1863 | -2566 |  |
| 6 | Wed 27 Jul | -19.9% | -16.4% | +1.0% | +0.9% | 0.0% | 0.56 | 18.1 | Broad bullish | -19.9 pts | -22 / -397 | 0% | -330 | -2895 | sell time |

**4. Verdict** (observed after entry)

- Bought Wed 20 Jul 2022 at the open 980.45; sold Wed 27 Jul 2022 at the open 700.00 (lower-circuit lock: sold at the first free open). Gross -28.60%, costs -35 bp, net -2895 bp.
- Over the same hold: NIFTY -0.5%, Midcap -0.5%, Smallcap -0.8%; VIX +5.6%; breadth averaged 0.49; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2808 bp, Midcap -2810 bp, Smallcap -2778 bp.
- Split: market part -1.29% = beta 1.56 x Smallcap 250 -0.82%; stock part -27.32% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+282 bp beyond its market); weakest: session 5 (-1840 bp).

_Pick day Tue 19 Jul 2022 [Broad bullish]: NIFTY +0.4%, Smallcap +0.8%, breadth 0.64, VIX 17.2 (-7% in 5 days) -> ENS rank 3 TANLA (moves with Smallcap 250, beta 1.56) -> bought Wed 20 Jul 2022 open, sold Wed 27 Jul 2022 open: gross -28.60%, net -2895 bp -> during the hold NIFTY -0.5%, Smallcap -0.8% -> market part -1.29%, stock part -27.32%: mostly the stock itself._

## ENS-20250731-2 - KITEX - net -2831 bp (gross -27.96%) - SEVERE LOSER

- ENS rank 2 (score 0.999) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.18, correlation 0.46; NIFTY beta 1.51, Smallcap beta 1.18)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 30 Jul 2025: NIFTY +0.1%, Midcap +0.2%, Smallcap -0.1%; NIFTY minus Smallcap +0.2 pts (20-day -0.1 pts); breadth 0.51 (1,121 up / 1,078 down of 2,230; 10-day 0.40); VIX 11.2 (day -2.8%, 5-day +6.6%, 2nd percentile); environment: Broad bearish.
- Pick day: Thu 31 Jul 2025: NIFTY -0.3%, Midcap -0.8%, Smallcap -0.9%; NIFTY minus Smallcap +0.6 pts (20-day +0.9 pts); breadth 0.30 (652 up / 1,557 down of 2,234; 10-day 0.39); VIX 11.5 (day +2.9%, 5-day +7.6%, 5th percentile); environment: Broad bearish.
- The stock: day before -0.4%, pick day -4.9% (-4.0 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 8 sessions, mature) | S10 breakdown NEW today
- Warning signs that fired before entry: W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge -0.004, pred_mae_q20 -0.107, pred_mae_q50 -0.037, pred_mae_q80 -0.013, pred_mfe_q20 0.029, pred_mfe_q50 0.077, pred_mfe_q80 0.139, prob_big 0.703, prob_deep 0.277, prob_trap 0.086, prob_win 0.503

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 31 Jul | -4.9% | +0.1% | -0.3% | -0.8% | -0.9% | 0.30 | 11.5 | Broad bearish | -4.0 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 01 Aug | -5.0% | -2.8% | -0.8% | -1.3% | -1.6% | 0.21 | 12.0 | Broad bearish | -3.4 pts | -192 / -86 | 100% | -295 | -295 | buy open |
| 2 | Mon 04 Aug | -2.7% | -0.4% | +0.6% | +1.1% | +1.0% | 0.62 | 12.0 | Broad bearish | -3.6 pts | +115 / -381 | 100% | -258 | -553 |  |
| 3 | Tue 05 Aug | -5.0% | 0.0% | -0.3% | -0.2% | -0.3% | 0.36 | 11.7 | Broad bearish | -4.7 pts | -37 / -463 | 100% | -473 | -1027 |  |
| 4 | Wed 06 Aug | -5.0% | -1.2% | -0.3% | -0.9% | -1.2% | 0.23 | 12.0 | Broad bearish | -3.8 pts | -142 / -359 | 100% | -450 | -1476 |  |
| 5 | Thu 07 Aug | -5.0% | 0.0% | +0.1% | +0.3% | -0.1% | 0.44 | 11.7 | Broad bearish | -4.9 pts | -12 / -488 | 100% | -427 | -1904 |  |
| 6 | Fri 08 Aug | -5.0% | 0.0% | -0.9% | -1.4% | -1.3% | 0.29 | 12.0 | Broad bearish | -3.7 pts | -148 / -352 | 100% | -406 | -2310 |  |
| 7 | Mon 11 Aug | -5.0% | 0.0% | +0.9% | +0.7% | +0.5% | 0.55 | 12.2 | Broad bearish | -5.5 pts | +53 / -553 | 100% | -385 | -2695 |  |
| 8 | Tue 12 Aug | +5.0% | +6.7% | -0.4% | -0.2% | 0.0% | 0.47 | 12.2 | Broad bearish | +5.0 pts | +21 / -182 | 0% | -135 | -2831 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 01 Aug 2025 at the open 222.10; sold Tue 12 Aug 2025 at the open 160.01 (lower-circuit lock: sold at the first free open). Gross -27.96%, costs -35 bp, net -2831 bp.
- Over the same hold: NIFTY -0.7%, Midcap -1.7%, Smallcap -2.9%; VIX +5.9%; breadth averaged 0.40; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2726 bp, Midcap -2624 bp, Smallcap -2505 bp.
- Split: market part -3.41% = beta 1.18 x Smallcap 250 -2.90%; stock part -24.54% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (-86 bp beyond its market); weakest: session 7 (-553 bp).

_Pick day Thu 31 Jul 2025 [Broad bearish]: NIFTY -0.3%, Smallcap -0.9%, breadth 0.30, VIX 11.5 (+8% in 5 days) -> ENS rank 2 KITEX (moves with Smallcap 250, beta 1.18) -> bought Fri 01 Aug 2025 open, sold Tue 12 Aug 2025 open: gross -27.96%, net -2831 bp -> during the hold NIFTY -0.7%, Smallcap -2.9% -> market part -3.41%, stock part -24.54%: mostly the stock itself._

## ENS-20260320-1 - AQYLON - net -2830 bp (gross -27.95%) - SEVERE LOSER

- ENS rank 1 (score 0.999) | the other engine ranked it 3 | size: no list (no AMFI class) | moves most with NIFTY 50 (beta 1.13, correlation 0.24; NIFTY beta 1.13, Smallcap beta 0.29)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 19 Mar 2026: NIFTY -3.3% (3.6 sd fall), Midcap -3.1% (2.7 sd fall), Smallcap -2.6% (2.1 sd fall); NIFTY minus Smallcap -0.6 pts (20-day -2.1 pts); breadth 0.09 (224 up / 2,155 down of 2,397; 10-day 0.41); VIX 22.8 (day +21.8%, 5-day +5.9%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions; NIFTY -3.6 sd day.
- Pick day: Fri 20 Mar 2026: NIFTY +0.5%, Midcap +0.6%, Smallcap +0.3%; NIFTY minus Smallcap +0.2 pts (20-day -1.7 pts); breadth 0.59 (1,409 up / 963 down of 2,402; 10-day 0.43); VIX 22.8 (day 0.0%, 5-day +0.7%, 100th percentile); environment: HIGH STRESS (direction: Broad bearish) - VIX at its 100th percentile of 250 sessions.
- The stock: day before -5.0%, pick day -4.9% (-5.4 pts vs NIFTY 50)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 23 sessions, mature) | S10 breakdown CONFIRMED (9d) | risk: stretched far below EMA20 | volatility extreme
- Warning signs that fired before entry: W1 high stress at the pick; W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.001, pred_mae_q20 -0.154, pred_mae_q50 -0.058, pred_mae_q80 -0.020, pred_mfe_q20 0.004, pred_mfe_q50 0.089, pred_mfe_q80 0.184, prob_big 0.645, prob_deep 0.370, prob_trap 0.483, prob_win 0.377

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 20 Mar | -4.9% | 0.0% | +0.5% | +0.6% | +0.3% | 0.59 | 22.8 | HIGH STRESS | -5.4 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 23 Mar | -4.9% | 0.0% | -2.6% | -3.9% | -3.8% | 0.05 | 26.7 | HIGH STRESS | -2.3 pts | -155 / +155 | 100% | -18 | -18 | buy open |
| 2 | Tue 24 Mar | -5.0% | -0.2% | +1.8% | +2.5% | +2.4% | 0.82 | 24.7 | HIGH STRESS | -6.8 pts | +201 / -701 | 100% | -499 | -517 |  |
| 3 | Wed 25 Mar | -4.9% | 0.0% | +1.7% | +2.3% | +2.5% | 0.81 | 24.6 | HIGH STRESS | -6.6 pts | +195 / -687 | 100% | -467 | -984 |  |
| 4 | Fri 27 Mar | -5.0% | 0.0% | -2.1% | -2.2% | -1.9% | 0.11 | 26.8 | HIGH STRESS | -2.9 pts | -237 / -262 | 100% | -451 | -1435 |  |
| 5 | Mon 30 Mar | -4.9% | 0.0% | -2.1% | -2.6% | -2.5% | 0.13 | 27.9 | HIGH STRESS | -2.7 pts | -243 / -245 | 100% | -419 | -1853 |  |
| 6 | Wed 01 Apr | -5.0% | 0.0% | +1.6% | +2.3% | +3.2% | 0.94 | 25.0 | HIGH STRESS | -6.5 pts | +177 / -676 | 100% | -407 | -2261 |  |
| 7 | Thu 02 Apr | -5.0% | 0.0% | +0.1% | -0.3% | -0.2% | 0.61 | 25.5 | HIGH STRESS | -5.1 pts | +17 / -515 | 100% | -386 | -2647 |  |
| 8 | Mon 06 Apr | -5.0% | 0.0% | +1.1% | +1.4% | +1.1% | 0.80 | 25.5 | HIGH STRESS | -6.1 pts | +127 / -626 | 100% | -367 | -3014 |  |
| 9 | Tue 07 Apr | -5.0% | 0.0% | +0.7% | +0.1% | +0.1% | 0.62 | 24.7 | HIGH STRESS | -5.7 pts | +77 / -576 | 100% | -349 | -3364 |  |
| 10 | Wed 08 Apr | +4.2% | +9.7% | +3.8% | +4.0% | +3.9% | 0.93 | 19.7 | HIGH STRESS | +0.4 pts | +428 / -10 | 100% | +279 | -3085 |  |
| 11 | Thu 09 Apr | +5.0% | +1.0% | -0.9% | +0.3% | +0.1% | 0.44 | 20.4 | HIGH STRESS | +5.9 pts | -42 / +434 | 0% | +255 | -2830 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 23 Mar 2026 at the open 62.10; sold Thu 09 Apr 2026 at the open 44.74 (lower-circuit lock: sold at the first free open). Gross -27.95%, costs -35 bp, net -2830 bp.
- Over the same hold: NIFTY +4.8%, Midcap +4.6%, Smallcap +5.8%; VIX -13.6%; breadth averaged 0.57; 11 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3271 bp, Midcap -3252 bp, Smallcap -3376 bp.
- Split: market part +5.39% = beta 1.13 x NIFTY 50 +4.75%; stock part -33.34% -> **mostly the stock itself**.
- The stock's own strongest day: session 11 (+434 bp beyond its market); weakest: session 2 (-701 bp).

_Pick day Fri 20 Mar 2026 [HIGH STRESS]: NIFTY +0.5%, Smallcap +0.3%, breadth 0.59, VIX 22.8 (+1% in 5 days) -> ENS rank 1 AQYLON (moves with NIFTY 50, beta 1.13) -> bought Mon 23 Mar 2026 open, sold Thu 09 Apr 2026 open: gross -27.95%, net -2830 bp -> during the hold NIFTY +4.8%, Smallcap +5.8%, 11 high-stress day(s) -> market part +5.39%, stock part -33.34%: mostly the stock itself._

## ENS-20230120-1 - KIRIINDUS - net -2732 bp (gross -26.97%) - SEVERE LOSER

- ENS rank 1 (score 0.998) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 0.27, correlation 0.14; NIFTY beta 0.22, Smallcap beta 0.26)

**1. The market before entry** (known at the pick day's close)

- Day before: Thu 19 Jan 2023: NIFTY -0.3%, Midcap -0.1%, Smallcap -0.3%; NIFTY minus Smallcap 0.0 pts (20-day -0.4 pts); breadth 0.39 (679 up / 1,072 down of 1,804; 10-day 0.45); VIX 14.0 (day -2.9%, 5-day -8.6%, 7th percentile); environment: Broad bearish.
- Pick day: Fri 20 Jan 2023: NIFTY -0.4%, Midcap -0.7%, Smallcap -0.6%; NIFTY minus Smallcap +0.1 pts (20-day -3.0 pts); breadth 0.35 (616 up / 1,143 down of 1,808; 10-day 0.45); VIX 13.8 (day -1.2%, 5-day -4.6%, 6th percentile); environment: Broad bearish.
- The stock: day before -2.8%, pick day -7.7% (-6.9 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): S09 Emerging bearish trend (HIGH, 14 sessions, mature) | S10 breakdown CONFIRMED (4d) | risk: stretched far below EMA20; large down candle in the last 5 sessions
- Warning signs that fired before entry: W2 broad bearish at the pick

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.009, pred_mae_q20 -0.063, pred_mae_q50 -0.031, pred_mae_q80 -0.012, pred_mfe_q20 0.029, pred_mfe_q50 0.054, pred_mfe_q80 0.099, prob_big 0.584, prob_deep 0.113, prob_trap 0.002, prob_win 0.584

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Fri 20 Jan | -7.7% | -7.8% | -0.4% | -0.7% | -0.6% | 0.35 | 13.8 | Broad bearish | -6.9 pts |  | 0% | +0 | +0 |  |
| 1 | Mon 23 Jan | -1.2% | -1.2% | +0.5% | +0.2% | -0.1% | 0.44 | 13.6 | Broad bearish | -1.4 pts | +1 / -122 | 100% | -139 | -139 | buy open |
| 2 | Tue 24 Jan | -2.4% | -0.9% | 0.0% | -0.3% | -0.4% | 0.38 | 13.7 | Broad bearish | -2.0 pts | -9 / -228 | 100% | -235 | -374 |  |
| 3 | Wed 25 Jan | -8.7% | -8.5% | -1.2% | -1.3% | -0.9% | 0.20 | 14.7 | Broad bearish | -7.5 pts | -34 / -838 | 100% | -841 | -1214 |  |
| 4 | Fri 27 Jan | -15.7% | -15.7% | -1.6% | -1.2% | -1.8% | 0.15 | 17.3 | Broad bearish | -14.5 pts | -34 / -1537 | 100% | -1382 | -2597 |  |
| 5 | Mon 30 Jan | -1.6% | -2.1% | +0.3% | -0.2% | -0.2% | 0.41 | 17.7 | HIGH STRESS | -1.4 pts | -4 / -154 | 0% | -135 | -2732 | sell time |

**4. Verdict** (observed after entry)

- Bought Mon 23 Jan 2023 at the open 383.05; sold Mon 30 Jan 2023 at the close 279.75. Gross -26.97%, costs -35 bp, net -2732 bp.
- Over the same hold: NIFTY -2.6%, Midcap -2.9%, Smallcap -3.8%; VIX +28.4%; breadth averaged 0.32; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2438 bp, Midcap -2404 bp, Smallcap -2321 bp.
- Split: market part -0.80% = beta 0.27 x Midcap 150 -2.93%; stock part -26.17% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (-122 bp beyond its market); weakest: session 4 (-1537 bp).

_Pick day Fri 20 Jan 2023 [Broad bearish]: NIFTY -0.4%, Smallcap -0.6%, breadth 0.35, VIX 13.8 (-5% in 5 days) -> ENS rank 1 KIRIINDUS (moves with Midcap 150, beta 0.27) -> bought Mon 23 Jan 2023 open, sold Mon 30 Jan 2023 close: gross -26.97%, net -2732 bp -> during the hold NIFTY -2.6%, Smallcap -3.8%, 1 high-stress day(s) -> market part -0.80%, stock part -26.17%: mostly the stock itself._

## ENS-20210802-2 - INDOAMIN - net -2725 bp (gross -26.90%) - SEVERE LOSER

- ENS rank 2 (score 0.980) | the other engine ranked it 2 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 1.57, correlation 0.40; NIFTY beta 1.60, Smallcap beta 1.57)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 30 Jul 2021: NIFTY -0.1%, Midcap +0.9%, Smallcap +0.5%; NIFTY minus Smallcap -0.6 pts (20-day -6.9 pts); breadth 0.52 (807 up / 738 down of 1,578; 10-day 0.47); VIX 12.8 (day -1.2%, 5-day +8.8%, 5th percentile); environment: Narrow bullish.
- Pick day: Mon 02 Aug 2021: NIFTY +0.8%, Midcap +1.3%, Smallcap +0.8%; NIFTY minus Smallcap 0.0 pts (20-day -6.3 pts); breadth 0.68 (1,056 up / 501 down of 1,595; 10-day 0.48); VIX 12.8 (day +0.1%, 5-day +2.9%, 6th percentile); environment: Narrow bullish.
- The stock: day before +5.0%, pick day -5.0% (-5.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): UNKNOWN - evidence conflicts (6 sessions) | risk: S05 extremely overextended; repeated large gaps
- Warning signs that fired before entry: W3 narrow bullish at the pick; W8 high-beta pick: beta to its home index 1.5 or more

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 02 Aug | -5.0% | 0.0% | +0.8% | +1.3% | +0.8% | 0.68 | 12.8 | Narrow bullish | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 03 Aug | -5.0% | 0.0% | +1.5% | +0.2% | -0.2% | 0.51 | 13.8 | Narrow bullish | -4.7 pts | -115 / +115 | 100% | -18 | -18 | buy open |
| 2 | Wed 04 Aug | -5.0% | 0.0% | +0.8% | -1.0% | -1.1% | 0.26 | 13.2 | Broad bullish | -3.9 pts | -175 / -326 | 100% | -501 | -518 |  |
| 3 | Thu 05 Aug | -5.0% | 0.0% | +0.2% | 0.0% | -0.5% | 0.32 | 12.9 | Narrow bullish | -4.4 pts | -85 / -414 | 100% | -474 | -992 |  |
| 4 | Fri 06 Aug | -5.0% | 0.0% | -0.3% | 0.0% | +0.1% | 0.55 | 12.6 | Narrow bullish | -5.1 pts | +21 / -520 | 100% | -450 | -1442 |  |
| 5 | Mon 09 Aug | -5.0% | 0.0% | +0.1% | -0.7% | -1.0% | 0.32 | 12.6 | Narrow bullish | -3.9 pts | -164 / -333 | 100% | -427 | -1869 |  |
| 6 | Tue 10 Aug | -5.0% | 0.0% | +0.1% | -1.1% | -2.6% | 0.14 | 12.7 | HIGH STRESS | -2.4 pts | -406 / -96 | 100% | -409 | -2278 |  |
| 7 | Wed 11 Aug | -5.0% | 0.0% | 0.0% | -0.4% | -0.5% | 0.33 | 12.7 | Narrow bullish | -4.4 pts | -84 / -413 | 100% | -385 | -2663 |  |
| 8 | Thu 12 Aug | +3.2% | +8.6% | +0.5% | +1.0% | +2.3% | 0.83 | 12.4 | HIGH STRESS | +0.9 pts | +357 / -39 | 100% | +234 | -2429 |  |
| 9 | Fri 13 Aug | -1.4% | +3.7% | +1.0% | -0.1% | -0.1% | 0.46 | 13.0 | Narrow bullish | -1.4 pts | -11 / -134 | 100% | -110 | -2538 |  |
| 10 | Mon 16 Aug | -5.0% | -2.8% | +0.2% | -0.3% | -0.9% | 0.31 | 13.5 | Narrow bullish | -4.1 pts | +20 / -246 | 0% | -186 | -2725 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 03 Aug 2021 at the open 168.80; sold Mon 16 Aug 2021 at the open 123.40 (lower-circuit lock: sold at the first free open). Gross -26.90%, costs -35 bp, net -2725 bp.
- Over the same hold: NIFTY +3.6%, Midcap -2.2%, Smallcap -4.1%; VIX +1.4%; breadth averaged 0.40; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -3045 bp, Midcap -2465 bp, Smallcap -2281 bp.
- Split: market part -6.40% = beta 1.57 x Smallcap 250 -4.08%; stock part -20.50% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+115 bp beyond its market); weakest: session 4 (-520 bp).

_Pick day Mon 02 Aug 2021 [Narrow bullish]: NIFTY +0.8%, Smallcap +0.8%, breadth 0.68, VIX 12.8 (+3% in 5 days) -> ENS rank 2 INDOAMIN (moves with Smallcap 250, beta 1.57) -> bought Tue 03 Aug 2021 open, sold Mon 16 Aug 2021 open: gross -26.90%, net -2725 bp -> during the hold NIFTY +3.6%, Smallcap -4.1%, 2 high-stress day(s) -> market part -6.40%, stock part -20.50%: mostly the stock itself._

## ENS-20220119-1 - TTML - net -2698 bp (gross -26.63%) - SEVERE LOSER

- ENS rank 1 (score 1.000) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.66, correlation 0.19; NIFTY beta 0.38, Smallcap beta 0.66)

**1. The market before entry** (known at the pick day's close)

- Day before: Tue 18 Jan 2022: NIFTY -1.1%, Midcap -1.9%, Smallcap -2.0%; NIFTY minus Smallcap +1.0 pts (20-day -2.3 pts); breadth 0.19 (311 up / 1,341 down of 1,670; 10-day 0.52); VIX 17.8 (day +6.0%, 5-day +0.1%, 58th percentile); environment: Broad bullish.
- Pick day: Wed 19 Jan 2022: NIFTY -1.0%, Midcap -0.2%, Smallcap +0.2%; NIFTY minus Smallcap -1.2 pts (20-day -3.0 pts); breadth 0.44 (721 up / 927 down of 1,669; 10-day 0.51); VIX 17.8 (day +0.2%, 5-day +3.7%, 58th percentile); environment: Broad bullish.
- The stock: day before -5.0%, pick day -5.0% (-5.2 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): S01 Strong bullish continuation (MEDIUM, 42 sessions, mature) | risk: repeated large gaps
- Warning signs that fired before entry: none

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.002, pred_mae_q20 -0.103, pred_mae_q50 -0.048, pred_mae_q80 -0.008, pred_mfe_q20 0.032, pred_mfe_q50 0.107, pred_mfe_q80 0.193, prob_big 0.716, prob_deep 0.321, prob_trap 0.150, prob_win 0.509

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Wed 19 Jan | -5.0% | 0.0% | -1.0% | -0.2% | +0.2% | 0.44 | 17.8 | Broad bullish | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Thu 20 Jan | -5.0% | 0.0% | -1.0% | -0.2% | -0.1% | 0.48 | 17.8 | Broad bullish | -4.9 pts | -9 / +9 | 100% | -18 | -18 | buy open |
| 2 | Fri 21 Jan | -5.0% | 0.0% | -0.8% | -2.1% | -1.9% | 0.18 | 18.9 | Narrow bullish | -3.1 pts | -124 / -374 | 100% | -498 | -516 |  |
| 3 | Mon 24 Jan | -5.0% | 0.0% | -2.7% | -3.7% | -4.6% | 0.05 | 22.8 | HIGH STRESS | -0.4 pts | -306 / -192 | 100% | -473 | -989 |  |
| 4 | Tue 25 Jan | -5.0% | 0.0% | +0.8% | +0.9% | +1.1% | 0.68 | 21.4 | Broad bearish | -6.1 pts | +70 / -570 | 100% | -451 | -1440 |  |
| 5 | Thu 27 Jan | -5.0% | 0.0% | -1.0% | -1.1% | -0.5% | 0.40 | 21.1 | Broad bearish | -4.5 pts | -31 / -467 | 100% | -427 | -1867 |  |
| 6 | Fri 28 Jan | -5.0% | 0.0% | 0.0% | +1.3% | +0.5% | 0.61 | 20.7 | Broad bearish | -5.5 pts | +35 / -534 | 100% | -407 | -2273 |  |
| 7 | Mon 31 Jan | -5.0% | 0.0% | +1.4% | +1.5% | +1.0% | 0.58 | 21.9 | Mixed / ranging | -6.0 pts | +64 / -563 | 100% | -387 | -2660 |  |
| 8 | Tue 01 Feb | -5.0% | 0.0% | +1.4% | +1.0% | +0.7% | 0.57 | 20.0 | Narrow bullish | -5.7 pts | +50 / -549 | 100% | -367 | -3028 |  |
| 9 | Wed 02 Feb | +5.0% | 0.0% | +1.2% | +1.1% | +1.7% | 0.77 | 18.6 | Narrow bullish | +3.3 pts | +54 / +443 | 0% | +330 | -2698 | sell time |

**4. Verdict** (observed after entry)

- Bought Thu 20 Jan 2022 at the open 202.80; sold Wed 02 Feb 2022 at the open 148.80 (lower-circuit lock: sold at the first free open). Gross -26.63%, costs -35 bp, net -2698 bp.
- Over the same hold: NIFTY -1.2%, Midcap -2.0%, Smallcap -3.1%; VIX +12.1%; breadth averaged 0.48; 1 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2543 bp, Midcap -2462 bp, Smallcap -2355 bp.
- Split: market part -2.04% = beta 0.66 x Smallcap 250 -3.07%; stock part -24.59% -> **mostly the stock itself**.
- The stock's own strongest day: session 9 (+443 bp beyond its market); weakest: session 4 (-570 bp).

_Pick day Wed 19 Jan 2022 [Broad bullish]: NIFTY -1.0%, Smallcap +0.2%, breadth 0.44, VIX 17.8 (+4% in 5 days) -> ENS rank 1 TTML (moves with Smallcap 250, beta 0.66) -> bought Thu 20 Jan 2022 open, sold Wed 02 Feb 2022 open: gross -26.63%, net -2698 bp -> during the hold NIFTY -1.2%, Smallcap -3.1%, 1 high-stress day(s) -> market part -2.04%, stock part -24.59%: mostly the stock itself._

## ENS-20210802-1 - VEEDOL - net -2697 bp (gross -26.62%) - SEVERE LOSER

- ENS rank 1 (score 0.989) | the other engine ranked it 4 | size: no list (no AMFI class) | moves most with Smallcap 250 (beta 0.43, correlation 0.11; NIFTY beta 0.42, Smallcap beta 0.43)

**1. The market before entry** (known at the pick day's close)

- Day before: Fri 30 Jul 2021: NIFTY -0.1%, Midcap +0.9%, Smallcap +0.5%; NIFTY minus Smallcap -0.6 pts (20-day -6.9 pts); breadth 0.52 (807 up / 738 down of 1,578; 10-day 0.47); VIX 12.8 (day -1.2%, 5-day +8.8%, 5th percentile); environment: Narrow bullish.
- Pick day: Mon 02 Aug 2021: NIFTY +0.8%, Midcap +1.3%, Smallcap +0.8%; NIFTY minus Smallcap 0.0 pts (20-day -6.3 pts); breadth 0.68 (1,056 up / 501 down of 1,595; 10-day 0.48); VIX 12.8 (day +0.1%, 5-day +2.9%, 6th percentile); environment: Narrow bullish.
- The stock: day before -5.0%, pick day -5.0% (-5.8 pts vs Smallcap 250)
- Its state (tl_state, known at the pick day's close): UNKNOWN - evidence conflicts (7 sessions) | risk: price up, volume flow down (candidate) | volatility extreme
- Warning signs that fired before entry: W3 narrow bullish at the pick

**2. What the model expected** - no forecasts recorded for this pick

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Mon 02 Aug | -5.0% | 0.0% | +0.8% | +1.3% | +0.8% | 0.68 | 12.8 | Narrow bullish | -5.8 pts |  | 0% | +0 | +0 |  |
| 1 | Tue 03 Aug | +0.6% | +0.8% | +1.5% | +0.2% | -0.2% | 0.51 | 13.8 | Narrow bullish | +0.9 pts | -32 / +113 | 100% | +64 | +64 | buy open |
| 2 | Wed 04 Aug | -3.0% | -3.8% | +0.8% | -1.0% | -1.1% | 0.26 | 13.2 | Broad bullish | -1.9 pts | -48 / -252 | 100% | -302 | -238 |  |
| 3 | Thu 05 Aug | -5.0% | -4.8% | +0.2% | 0.0% | -0.5% | 0.32 | 12.9 | Narrow bullish | -4.5 pts | -23 / -476 | 100% | -489 | -727 |  |
| 4 | Fri 06 Aug | -5.0% | 0.0% | -0.3% | 0.0% | +0.1% | 0.55 | 12.6 | Narrow bullish | -5.1 pts | +6 / -506 | 100% | -464 | -1192 |  |
| 5 | Mon 09 Aug | -5.0% | -0.9% | +0.1% | -0.7% | -1.0% | 0.32 | 12.6 | Narrow bullish | -4.0 pts | -45 / -455 | 100% | -441 | -1633 |  |
| 6 | Tue 10 Aug | -5.0% | 0.0% | +0.1% | -1.1% | -2.6% | 0.14 | 12.7 | HIGH STRESS | -2.4 pts | -112 / -388 | 100% | -419 | -2052 |  |
| 7 | Wed 11 Aug | -5.0% | 0.0% | 0.0% | -0.4% | -0.5% | 0.33 | 12.7 | Narrow bullish | -4.5 pts | -23 / -477 | 100% | -398 | -2450 |  |
| 8 | Thu 12 Aug | -0.2% | +3.0% | +0.5% | +1.0% | +2.3% | 0.83 | 12.4 | HIGH STRESS | -2.4 pts | +19 / -323 | 0% | -247 | -2697 | sell time |

**4. Verdict** (observed after entry)

- Bought Tue 03 Aug 2021 at the open 2950.50; sold Thu 12 Aug 2021 at the open 2165.00 (lower-circuit lock: sold at the first free open). Gross -26.62%, costs -35 bp, net -2697 bp.
- Over the same hold: NIFTY +2.2%, Midcap -2.9%, Smallcap -5.9%; VIX -0.8%; breadth averaged 0.41; 2 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2883 bp, Midcap -2369 bp, Smallcap -2077 bp.
- Split: market part -2.53% = beta 0.43 x Smallcap 250 -5.85%; stock part -24.09% -> **mostly the stock itself**.
- The stock's own strongest day: session 1 (+113 bp beyond its market); weakest: session 4 (-506 bp).

_Pick day Mon 02 Aug 2021 [Narrow bullish]: NIFTY +0.8%, Smallcap +0.8%, breadth 0.68, VIX 12.8 (+3% in 5 days) -> ENS rank 1 VEEDOL (moves with Smallcap 250, beta 0.43) -> bought Tue 03 Aug 2021 open, sold Thu 12 Aug 2021 open: gross -26.62%, net -2697 bp -> during the hold NIFTY +2.2%, Smallcap -5.9%, 2 high-stress day(s) -> market part -2.53%, stock part -24.09%: mostly the stock itself._

## ENS-20230202-1 - ADANIPOWER - net -2639 bp (gross -26.04%) - SEVERE LOSER

- ENS rank 1 (score 1.000) | the other engine ranked it 1 | size: no list (no AMFI class) | moves most with Midcap 150 (beta 1.21, correlation 0.40; NIFTY beta 1.14, Smallcap beta 1.09)

**1. The market before entry** (known at the pick day's close)

- Day before: Wed 01 Feb 2023: NIFTY -0.3%, Midcap -0.9%, Smallcap -1.1%; NIFTY minus Smallcap +0.9 pts (20-day +0.9 pts); breadth 0.27 (491 up / 1,306 down of 1,818; 10-day 0.39); VIX 16.8 (day -0.6%, 5-day +22.8%, 27th percentile); environment: Broad bearish.
- Pick day: Thu 02 Feb 2023: NIFTY 0.0%, Midcap +0.2%, Smallcap +0.4%; NIFTY minus Smallcap -0.5 pts (20-day +0.6 pts); breadth 0.47 (832 up / 957 down of 1,820; 10-day 0.38); VIX 15.7 (day -6.3%, 5-day +7.3%, 22nd percentile); environment: Broad bearish.
- The stock: day before -4.9%, pick day -5.1% (-5.2 pts vs Midcap 150)
- Its state (tl_state, known at the pick day's close): UNKNOWN - evidence conflicts (12 sessions) | S10 breakdown CONFIRMED (4d) | risk: stretched far below EMA20; repeated large gaps
- Warning signs that fired before entry: W2 broad bearish at the pick; W4 weak breadth: 10-day A/D below 0.40

**2. What the model expected** (pick_meta's forecasts, made at the pick)

- pred_edge 0.005, pred_mae_q20 -0.127, pred_mae_q50 -0.053, pred_mae_q80 -0.010, pred_mfe_q20 0.022, pred_mfe_q50 0.086, pred_mfe_q80 0.150, prob_big 0.684, prob_deep 0.390, prob_trap 0.150, prob_win 0.489

**3. Day by day: the stock next to its market** (session 0 = the pick day; later rows were observed after entry)

| s | date | stock day | open > close | NIFTY | Midcap | Smallcap | breadth | VIX | environment | stock - home | held: market / stock bp | pos | day P&L bp | total bp | trades |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0 | Thu 02 Feb | -5.1% | 0.0% | 0.0% | +0.2% | +0.4% | 0.47 | 15.7 | Broad bearish | -5.2 pts |  | 0% | +0 | +0 |  |
| 1 | Fri 03 Feb | -5.0% | 0.0% | +1.4% | -0.1% | -0.4% | 0.36 | 14.4 | Broad bearish | -4.8 pts | -46 / +46 | 100% | -18 | -18 | buy open |
| 2 | Mon 06 Feb | -5.1% | 0.0% | -0.5% | +0.9% | +0.3% | 0.54 | 14.7 | Broad bearish | -5.9 pts | +103 / -611 | 100% | -508 | -525 |  |
| 3 | Tue 07 Feb | -4.9% | 0.0% | -0.2% | 0.0% | -0.4% | 0.41 | 14.1 | Broad bearish | -4.9 pts | -1 / -492 | 100% | -469 | -994 |  |
| 4 | Wed 08 Feb | +5.1% | +5.1% | +0.8% | +0.8% | +0.8% | 0.65 | 13.6 | Broad bearish | +4.2 pts | +102 / +403 | 100% | +456 | -538 |  |
| 5 | Thu 09 Feb | -5.1% | 0.0% | +0.1% | +0.1% | -0.3% | 0.48 | 13.0 | Broad bearish | -5.2 pts | +10 / -519 | 100% | -482 | -1020 |  |
| 6 | Fri 10 Feb | -4.9% | 0.0% | -0.2% | +0.2% | +0.5% | 0.51 | 12.8 | Broad bearish | -5.2 pts | +30 / -522 | 100% | -443 | -1463 |  |
| 7 | Mon 13 Feb | -5.0% | 0.0% | -0.5% | -1.3% | -1.2% | 0.26 | 13.7 | Broad bearish | -3.7 pts | -158 / -345 | 100% | -430 | -1892 |  |
| 8 | Tue 14 Feb | -5.0% | 0.0% | +0.9% | -0.4% | -0.5% | 0.33 | 13.4 | Broad bearish | -4.5 pts | -52 / -445 | 100% | -404 | -2296 |  |
| 9 | Wed 15 Feb | -5.1% | 0.0% | +0.5% | +0.5% | +0.4% | 0.56 | 12.9 | Broad bearish | -5.5 pts | +58 / -564 | 100% | -391 | -2687 |  |
| 10 | Thu 16 Feb | +5.0% | +4.0% | +0.1% | +0.8% | +0.8% | 0.59 | 12.9 | Broad bearish | +4.2 pts | +49 / +40 | 0% | +48 | -2639 | sell time |

**4. Verdict** (observed after entry)

- Bought Fri 03 Feb 2023 at the open 38.40; sold Thu 16 Feb 2023 at the open 28.40 (lower-circuit lock: sold at the first free open). Gross -26.04%, costs -35 bp, net -2639 bp.
- Over the same hold: NIFTY +2.1%, Midcap +0.8%, Smallcap -0.8%; VIX -18.2%; breadth averaged 0.47; 0 high-stress session(s).
- Against each index (gross minus the index): NIFTY -2815 bp, Midcap -2681 bp, Smallcap -2525 bp.
- Split: market part +0.93% = beta 1.21 x Midcap 150 +0.77%; stock part -26.98% -> **mostly the stock itself**.
- The stock's own strongest day: session 4 (+403 bp beyond its market); weakest: session 2 (-611 bp).

_Pick day Thu 02 Feb 2023 [Broad bearish]: NIFTY 0.0%, Smallcap +0.4%, breadth 0.47, VIX 15.7 (+7% in 5 days) -> ENS rank 1 ADANIPOWER (moves with Midcap 150, beta 1.21) -> bought Fri 03 Feb 2023 open, sold Thu 16 Feb 2023 open: gross -26.04%, net -2639 bp -> during the hold NIFTY +2.1%, Smallcap -0.8% -> market part +0.93%, stock part -26.98%: mostly the stock itself._

