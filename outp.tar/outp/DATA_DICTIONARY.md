# Data dictionary - tradelab export TLX_20261025_001

Units: fraction = 0.012 means +1.2%; bp = basis points (100 bp = 1%); pts = difference of two returns, as a fraction. 'known' says WHEN a value is known:

- **id**: identifies the row
- **pick**: known at the pick day's close - a rule may use it
- **day**: known at that row's own close
- **after**: known only afterwards - explains, never a rule input
- **record**: pick_meta's recorded value (reconciliation)
- **info**: summary statistic

## trades

| column | known | unit | meaning |
|---|---|---|---|
| trade_id | id | text | ENGINE-YYYYMMDD-RANK (the signal day) |
| engine | id | text | D or ENS |
| signal_day | id | date | the pick day = session 0; the model ranks at its close |
| symbol | id | text | NSE symbol |
| rank | pick | 1..10 | the engine's rank that day (1 = best raw score) |
| traded | pick | bool | rank <= 3 (the paper plan's trades) |
| score | pick | number | the engine's raw score |
| other_rank | pick | 1..10 | the other engine's rank for the same stock that day (blank = not in its top 10) |
| both_engines | pick | bool | traded by both engines (both ranks <= 3) |
| repeat_of | pick | text | the same engine's earlier traded pick of this stock still inside its 5-session hold |
| repeat | pick | bool | repeat_of is not blank |
| fold | pick | number | pick_meta's walk-forward fold |
| pred_mfe_q20 | pick | number | pick_meta's forecast for this pick, made at the pick |
| pred_mfe_q50 | pick | number | pick_meta's forecast for this pick, made at the pick |
| pred_mfe_q80 | pick | number | pick_meta's forecast for this pick, made at the pick |
| pred_mae_q20 | pick | number | pick_meta's forecast for this pick, made at the pick |
| pred_mae_q50 | pick | number | pick_meta's forecast for this pick, made at the pick |
| pred_mae_q80 | pick | number | pick_meta's forecast for this pick, made at the pick |
| pred_edge | pick | number | pick_meta's forecast for this pick, made at the pick |
| prob_win | pick | number | pick_meta's forecast for this pick, made at the pick |
| prob_big | pick | number | pick_meta's forecast for this pick, made at the pick |
| prob_deep | pick | number | pick_meta's forecast for this pick, made at the pick |
| prob_trap | pick | number | pick_meta's forecast for this pick, made at the pick |
| s_atr14 | pick | fraction | ATR14 / close at the pick (pick_meta) |
| meta_rank | pick | number | pick_meta's rank |
| status | after | text | ok (finished) / pending (data ends) / stuck (locked for 20 sessions) |
| note | after | text | simulation note |
| signal_close | pick | price | close of session 0 |
| entry_day | after | date | session 1 (bought at its open) |
| entry | after | price | session 1 open = the entry price |
| entry_gap | after | fraction | entry / signal_close - 1 (the overnight gap into the trade) |
| exit_day | after | date-time | when the position was sold |
| exit_price | after | price | the sale price |
| exit_kind | after | text | close (session 5's close) or locked_open (the first free open after a lower-circuit lock) |
| locked_exit | after | bool | the exit was delayed by a lower-circuit lock |
| sessions_held | after | number | session of the sale |
| gross_bp | after | bp | exit / entry - 1, before costs |
| net_bp | after | bp | gross - 35 bp round trip |
| win | after | 0/1 | 1 when net > 0 |
| mfe | after | fraction | best high of sessions 1-5 / entry - 1 (pick_meta's definition) |
| mae | after | fraction | worst low of sessions 1-5 / entry - 1 |
| mfe_session | after | 1..5 | the session (1-5) of the best high / worst low |
| mae_session | after | 1..5 | the session (1-5) of the best high / worst low |
| mfe_held | after | fraction | the same while actually held (a locked exit holds longer) |
| mae_held | after | fraction | the same while actually held (a locked exit holds longer) |
| best_close_session | after | 1..5 | the session (1-5) of the best / worst close |
| worst_close_session | after | 1..5 | the session (1-5) of the best / worst close |
| open6_status | after | text | status if sold at session 6's open instead |
| open6_net_bp | after | bp | net if sold at session 6's open instead (honest exits) |
| hold10_status | after | text | status if held to session 10's close |
| hold10_net_bp | after | bp | net if held to session 10's close |
| close_ret_s1 | after | fraction | close of session k / entry - 1 |
| close_ret_s2 | after | fraction | close of session k / entry - 1 |
| close_ret_s3 | after | fraction | close of session k / entry - 1 |
| close_ret_s4 | after | fraction | close of session k / entry - 1 |
| close_ret_s5 | after | fraction | close of session k / entry - 1 |
| open_ret_s2 | after | fraction | open of session k / entry - 1 |
| open_ret_s3 | after | fraction | open of session k / entry - 1 |
| open_ret_s4 | after | fraction | open of session k / entry - 1 |
| open_ret_s5 | after | fraction | open of session k / entry - 1 |
| open_ret_s6 | after | fraction | open of session k / entry - 1 |
| touch_up3_session | after | 1..5 | first session (1-5) whose high reached +3 / +5 / +10% from entry (blank = never) |
| touch_up5_session | after | 1..5 | first session (1-5) whose high reached +3 / +5 / +10% from entry (blank = never) |
| touch_up10_session | after | 1..5 | first session (1-5) whose high reached +3 / +5 / +10% from entry (blank = never) |
| touch_dn3_session | after | 1..5 | first session (1-5) whose low reached -3 / -5 / -8% from entry (blank = never) |
| touch_dn5_session | after | 1..5 | first session (1-5) whose low reached -3 / -5 / -8% from entry (blank = never) |
| touch_dn8_session | after | 1..5 | first session (1-5) whose low reached -3 / -5 / -8% from entry (blank = never) |
| up5_and_dn5_same_session | after | bool | one session touched both +5% and -5% |
| status_recorded | record | text | pick_meta's recorded status |
| net_recorded_bp | record | bp | pick_meta's recorded net |
| mfe_recorded | record | fraction | pick_meta's recorded MFE / MAE |
| mae_recorded | record | fraction | pick_meta's recorded MFE / MAE |
| matches_record | record | bool | status and net reproduce pick_meta's record (the safety stop) |
| mfe_mae_match_record | record | bool | MFE / MAE reproduce the record |
| settled_since_record | record | bool | recorded pending, finished now |
| pre_prev_date | pick | date | the session before the pick day |
| pre_nifty_ret | pick | fraction | index day return on the pick day |
| pre_mid_ret | pick | fraction | index day return on the pick day |
| pre_small_ret | pick | fraction | index day return on the pick day |
| pre_nifty_ret5 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_mid_ret5 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_small_ret5 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_nifty_ret20 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_mid_ret20 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_small_ret20 | pick | fraction | index return over the 5 / 20 sessions to the pick day |
| pre_nifty_vs_ma50 | pick | fraction | index / its 50-session average - 1 on the pick day |
| pre_mid_vs_ma50 | pick | fraction | index / its 50-session average - 1 on the pick day |
| pre_small_vs_ma50 | pick | fraction | index / its 50-session average - 1 on the pick day |
| pre_nifty_minus_mid | pick | pts | NIFTY minus Midcap / Smallcap on the pick day |
| pre_nifty_minus_small | pick | pts | NIFTY minus Midcap / Smallcap on the pick day |
| pre_nifty_minus_mid_20 | pick | pts | NIFTY minus Midcap / Smallcap over the 20 sessions to the pick day |
| pre_nifty_minus_small_20 | pick | pts | NIFTY minus Midcap / Smallcap over the 20 sessions to the pick day |
| pre_ad_ratio | pick | 0..1 | breadth on the pick day: advancers / (advancers + decliners) |
| pre_ad_ratio_10 | pick | 0..1 | breadth, 10-session average, on the pick day |
| pre_ad_n | pick | count | stocks in the breadth count on the pick day |
| pre_vix | pick | level | VIX close on the pick day |
| pre_vix_chg_pct | pick | fraction | VIX day change on the pick day |
| pre_vix_chg5_pct | pick | fraction | VIX 5-session change to the pick day |
| pre_vix_pct250 | pick | 0..1 | VIX percentile within the last 250 sessions on the pick day |
| pre_env_direction | pick | code | environment direction on the pick day |
| pre_env_code | pick | 0..3 | 0 broad_bullish, 1 narrow_bullish, 2 mixed, 3 broad_bearish |
| pre_high_stress | pick | 0/1 | high-stress flag on the pick day (1 / 0 / blank = unknown) |
| pre_stress_reason | pick | text | which stress conditions fired on the pick day |
| pre_environment | pick | code | five-label view on the pick day (high_stress overrides the direction) |
| pre_missing | pick | text | core market inputs missing on the pick day |
| pre_prev_nifty_ret | pick | fraction | index day return on the session before the pick day |
| pre_prev_mid_ret | pick | fraction | index day return on the session before the pick day |
| pre_prev_small_ret | pick | fraction | index day return on the session before the pick day |
| pre_prev_ad_ratio | pick | 0..1 | breadth on the session before the pick day |
| pre_prev_vix_chg_pct | pick | fraction | VIX change on the session before the pick day |
| pre_prev_environment | pick | code | five-label environment the session before the pick day |
| pre_prev_high_stress | pick | 0/1 | high-stress flag the session before the pick day |
| pre_size_class | pick | text | large / mid / small from the AMFI list in force on the pick day; 'not in list' (the list does not name the stock) / 'no list' (no list in force: before the first, or the half-year's list is missing - an older list is never carried on) |
| pre_size_class_num | pick | 1..3 | 1 large, 2 mid, 3 small (blank when no AMFI class) |
| pre_amfi_rank | pick | rank | the stock's rank in that AMFI list (by average market cap) |
| pre_amfi_list | pick | text | the AMFI list in force on the pick day; '(via ISIN ...)' when the stock was found by its company's ISIN because that list used an older symbol (a rename) |
| pre_exposure_days | pick | count | valid daily returns in the 120-session sensitivity window |
| pre_beta_nifty | pick | number | beta of the stock's daily returns on the index's, 120 sessions to the pick day |
| pre_corr_nifty | pick | -1..1 | correlation of those daily returns with the index's |
| pre_beta_mid | pick | number | beta of the stock's daily returns on the index's, 120 sessions to the pick day |
| pre_corr_mid | pick | -1..1 | correlation of those daily returns with the index's |
| pre_beta_small | pick | number | beta of the stock's daily returns on the index's, 120 sessions to the pick day |
| pre_corr_small | pick | -1..1 | correlation of those daily returns with the index's |
| pre_home_index | pick | code | nifty / mid / small: the index the stock correlates with most |
| pre_beta_home | pick | number | beta on the home index |
| pre_corr_home | pick | -1..1 | correlation with the home index |
| pre_home_index_name | pick | text | NIFTY 50 / Midcap 150 / Smallcap 250 |
| pre_home_index_num | pick | 1..3 | 1 NIFTY 50, 2 Midcap 150, 3 Smallcap 250 |
| pre_stock_ret | pick | fraction | the stock's own return on the pick day |
| pre_prev_stock_ret | pick | fraction | the stock's return on its session before the pick day |
| pre_stock_minus_home | pick | pts | the stock's pick-day return minus its home index's |
| pre_context_complete | pick | 0/1 | 1 when every core pre-entry market value is present (indices, VIX, breadth, labels) |
| post_entry_nifty_gap | after | fraction | index gap / open-to-close on the entry day (session 1) |
| post_entry_nifty_intraday | after | fraction | index gap / open-to-close on the entry day (session 1) |
| post_entry_mid_gap | after | fraction | index gap / open-to-close on the entry day (session 1) |
| post_entry_mid_intraday | after | fraction | index gap / open-to-close on the entry day (session 1) |
| post_entry_small_gap | after | fraction | index gap / open-to-close on the entry day (session 1) |
| post_entry_small_intraday | after | fraction | index gap / open-to-close on the entry day (session 1) |
| post_entry_ad_ratio | after | 0..1 | breadth on the entry day |
| post_entry_vix_chg_pct | after | fraction | VIX change on the entry day |
| post_entry_environment | after | code | five-label environment on the entry day (at its close) |
| post_entry_high_stress | after | 0/1 | high-stress flag on the entry day |
| post_hold_start | after | text | index open (the indices' opens are usable) or previous close |
| post_hold_nifty_ret | after | fraction | index return over exactly the hold: the entry day's open to the exit (close or open) |
| post_hold_mid_ret | after | fraction | index return over exactly the hold: the entry day's open to the exit (close or open) |
| post_hold_small_ret | after | fraction | index return over exactly the hold: the entry day's open to the exit (close or open) |
| post_hold_home_ret | after | fraction | the home index over the hold |
| post_hold_vix_chg_pct | after | fraction | VIX change from the close before the entry to the exit |
| post_hold_ad_ratio_avg | after | 0..1 | average breadth over the held sessions |
| post_hold_stress_days | after | count | held sessions flagged high stress |
| post_gross_ret | after | fraction | the trade's gross return (exit / entry - 1) |
| post_mkt_part_bp | after | bp | market part = pre_beta_home x post_hold_home_ret |
| post_stock_part_bp | after | bp | stock part = gross - market part (what the stock did beyond its market) |
| post_cost_bp | after | bp | costs charged (negative) |
| post_driver | after | code | market (|market| >= 2 x |stock|) / stock (the reverse) / both (same sign) / opposite / flat (everything under 0.5%) |
| post_excess_vs_nifty_bp | after | bp | gross - the index over the same hold |
| post_excess_vs_mid_bp | after | bp | gross - the index over the same hold |
| post_excess_vs_small_bp | after | bp | gross - the index over the same hold |
| post_excess_vs_home_bp | after | bp | gross - the home index over the same hold |
| pre_state | pick | code | primary state at the pick day's close: S01 strong bullish continuation, S02 emerging bullish, S03 bullish consolidation, S06 bullish reversal attempt, S07 neutral range, S08 bearish continuation, S09 emerging bearish, S12 unstable / disorderly, UNKNOWN (evidence conflicts), INSUFFICIENT_DATA (< 60 sessions); blank when the stock has no bar on the signal day |
| pre_state_name | pick | text | the state in words |
| pre_state_num | pick | code | the state as a number (1, 2, 3, 6, 7, 8, 9, 12 = S01..S12; 0 UNKNOWN; -1 INSUFFICIENT_DATA) |
| pre_state_bullish | pick | 0/1 | 1 when the state is S01-S03 / S08-S09 |
| pre_state_bearish | pick | 0/1 | 1 when the state is S01-S03 / S08-S09 |
| pre_state_confidence | pick | text | HIGH / MEDIUM / LOW / UNKNOWN: evidence agreement, conflicts, persistence and data completeness - not a probability |
| pre_state_conf_num | pick | 0..3 | 3 HIGH, 2 MEDIUM, 1 LOW, 0 UNKNOWN |
| pre_state_phase | pick | text | EARLY (the first 5 sessions) / MATURE / DETERIORATING (a change pending, support under 50% or 2+ conflicting signs) |
| pre_state_phase_num | pick | 1..3 | 1 early, 2 mature, 3 deteriorating |
| pre_state_age | pick | sessions | sessions in the state, counted from the session the change began |
| pre_state_prev | pick | code | the state before the current one |
| pre_state_raw | pick | code | that session's own reading before confirmation (a change needs 2 sessions in a row) |
| pre_state_pending | pick | code | the new reading when a change is pending (blank when none) |
| pre_state_support | pick | 0..1 | share of the state's supporting conditions that hold (of those that can be evaluated) |
| pre_state_conflicts | pick | count | how many of the state's conflicting conditions hold |
| pre_state_event | pick | code | the event shown at the pick (last 10 sessions): BREAKOUT / FAILED_BREAKOUT / BREAKDOWN / FAILED_BREAKDOWN with NEW / CONFIRMED / STALLED / FAILED; blank = none |
| pre_state_event_num | pick | code | 0 none; 1 / 2 / 3 breakout new / confirmed / stalled; 4 failed breakout; 5 / 6 / 7 breakdown new / confirmed / stalled; 8 failed breakdown |
| pre_state_event_age | pick | sessions | sessions since that event began |
| pre_state_breakout_recent | pick | 0/1 | 1 when that event is the one shown (S04 / S11 / S10) |
| pre_state_failed_breakout | pick | 0/1 | 1 when that event is the one shown (S04 / S11 / S10) |
| pre_state_breakdown_recent | pick | 0/1 | 1 when that event is the one shown (S04 / S11 / S10) |
| pre_state_overextended | pick | 0..2 | S05 overextension: 0 no, 1 overextended, 2 extreme (a risk flag, not a sell signal) |
| pre_state_risks | pick | text | risk flags / notes, comma-separated codes (STATE_RULES.md) |
| pre_state_notes | pick | text | risk flags / notes, comma-separated codes (STATE_RULES.md) |
| pre_state_vol_regime | pick | text | the stock's volatility: COMPRESSED / NORMAL / ELEVATED / EXTREME |
| pre_state_vol_elevated | pick | 0/1 | 1 when that volatility is ELEVATED or EXTREME |
| pre_state_big_down | pick | 0/1 | 1 after a 2+ ATR down candle in the last 5 sessions |
| pre_state_bear_div | pick | 0/1 | 1 for a bearish RSI divergence candidate on confirmed swings |
| pre_state_ext20_atr | pick | ATR | close minus EMA20 / EMA50, in ATR (14, Wilder) |
| pre_state_ext50_atr | pick | ATR | close minus EMA20 / EMA50, in ATR (14, Wilder) |
| pre_state_ema20_slope_atr | pick | ATR | EMA20's change over 5 sessions / EMA50's over 10, in ATR |
| pre_state_ema50_slope_atr | pick | ATR | EMA20's change over 5 sessions / EMA50's over 10, in ATR |
| pre_state_eff20 | pick | -1..1 | 20-session efficiency: net move / sum of the absolute daily moves |
| pre_state_rsi14 | pick | 0..100 | RSI 14 (Wilder) |
| pre_state_macd_hist_atr | pick | ATR | MACD (12, 26, 9) histogram in ATR |
| pre_state_r20 | pick | fraction | the stock's 20 / 60-session return |
| pre_state_r60 | pick | fraction | the stock's 20 / 60-session return |
| pre_state_vol_ratio | pick | ratio | 10-session / 60-session realised volatility |
| pre_state_atr_rank | pick | 0..1 | ATR% percentile within its last 250 sessions (today included) |
| pre_state_rvol | pick | ratio | the day's volume / the median of the previous 50 sessions |
| pre_state_flow20 | pick | -1..1 | signed volume share over 20 sessions: OBV change / volume (a candidate, never proof of accumulation) |
| pre_state_cons_range_atr | pick | ATR | high-low range of the last 15 sessions, in ATR (consolidation width) |
| pre_state_pos20 | pick | ratio | close within the previous 20 sessions' high-low range (above 1 = above it) |
| mkt_net_bp | after | bp | buy everything: the plan's average net on every panel stock that signal day |
| mkt_n | after | count | stocks in that average |
| excess_bp | after | bp | net_bp - mkt_net_bp |
| outcome | after | code | winner (net > 0) / loser (-500 < net <= 0) / severe_loser (net <= -500 bp); finished trades only |
| story | after | text | the trade as a one-line chain: market before -> pick -> trade -> market during -> split |

## trade_days

| column | known | unit | meaning |
|---|---|---|---|
| trade_id | id | text | the trade |
| engine | id | text | D or ENS |
| rank | id | 1..10 | rank |
| traded | id | bool | rank <= 3 |
| symbol | id | text | NSE symbol |
| signal_day | id | date | the pick day |
| session | id | number | 0 = pick day, 1 = entry day, 2, 3, ... (beyond 5 only while a lock delays the exit) |
| date | id | date | the session's date |
| in_window | id | bool | session 1-5 |
| is_entry_day | id | bool | session 1 |
| is_exit_day | after | bool | the session the position was sold |
| after_exit | after | bool | after the sale (shows what the stock did next, no position) |
| held_at_close | day | bool | a position was held at this close |
| open | day | price | the stock's official daily price |
| high | day | price | the stock's official daily price |
| low | day | price | the stock's official daily price |
| close | day | price | the stock's official daily price |
| volume | day | shares | the stock's daily volume |
| entry | after | price | the trade's entry price (session 1 open) |
| ret_open_vs_entry | day | fraction | this session's price / entry - 1 |
| ret_high_vs_entry | day | fraction | this session's price / entry - 1 |
| ret_low_vs_entry | day | fraction | this session's price / entry - 1 |
| ret_close_vs_entry | day | fraction | this session's price / entry - 1 |
| mfe_sofar | day | fraction | best high / worst low since the entry / entry - 1 |
| mae_sofar | day | fraction | best high / worst low since the entry / entry - 1 |
| day_ret | day | fraction | the stock's close / previous close - 1 |
| gap | day | fraction | the stock's open / previous close - 1 |
| range_pct | day | fraction | (high - low) / previous close |
| clv | day | 0..1 | close location in the day's range |
| vol_ratio20 | day | ratio | volume / median volume of the previous 20 sessions |
| atr_ratio | day | ratio | today's range / ATR14 of the previous session |
| nifty_day_ret | day | fraction | NIFTY 50 day return |
| rel_nifty_day | day | pts | day_ret - nifty_day_ret |
| day_pnl_bp | day | bp | change in the trade's P&L marked at this close (half the 35 bp at the buy, half at the sale) |
| cum_pnl_bp | day | bp | the trade's P&L so far, marked at this close; ends at net_bp |
| pos | day | 0..1 | fraction of the target held at the close |
| avg_entry | day | price | average entry price of what is held |
| buys | day | text | fills that session: leg@price |
| sells | day | text | fills that session: leg@price |
| mid_day_ret | day | fraction | Midcap 150 / Smallcap 250 day return |
| small_day_ret | day | fraction | Midcap 150 / Smallcap 250 day return |
| nifty_minus_small_day | day | pts | NIFTY's day return minus Smallcap's |
| vix_close | day | level | India VIX close |
| vix_chg_pct | day | fraction | VIX change |
| ad_ratio | day | 0..1 | breadth that session: advancers / (advancers + decliners) |
| environment | day | code | five-label environment that session (at its close) |
| high_stress | day | 0/1 | high-stress flag that session |
| home_index | pick | code | the trade's home index (from the pick day) |
| home_day_ret | day | fraction | the home index's day return |
| rel_home_day | day | pts | day_ret - home_day_ret |
| held_ret | day | fraction | the stock's move over the part of the day the position was held (entry day: open to close; later: previous close to the close, or to the open when sold at an open) |
| home_held_ret | day | fraction | the home index over the same part of the day |
| mkt_part_day_bp | day | bp | beta_home x home_held_ret |
| stock_part_day_bp | day | bp | held_ret - the market part |
| market_line | day | text | NIFTY / Midcap / Smallcap / VIX that session in words |

## daily_book

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS |
| date | id | date | session |
| positions_at_close | day | count | traded picks held at the close |
| new | day | count | entries that session |
| exits | day | count | exits that session |
| day_pnl_bp_sum | day | bp | sum of the held trades' day P&L |
| day_pnl_bp_mean | day | bp | average day P&L of the held trades |
| book_day_ret_slot | day | fraction | the book's day return with 1/15 of capital a slot (a proxy) |
| book_cum_ret_slot | day | fraction | running sum of book_day_ret_slot |

## trade_day_features

| column | known | unit | meaning |
|---|---|---|---|
| trade_id | id | text | the trade |
| symbol | id | text | NSE symbol |
| session | id | number | session number |
| date | id | date | the session's date |
| D_ema20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ema50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ema100 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_rsi7 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_rsi14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_macd | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_macd_signal | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_macd_hist | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_cmf20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_adx14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_pdi14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_mdi14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_inside_day | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_prev_inside_day | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_cpr_pivot | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_cpr_bc | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_cpr_tc | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_support1 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_resistance1 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_support2 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_resistance2 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_nr_length | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_nr_day | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_weekly_vpoc | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_sma5 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_sma20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_daily_trend | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_weekly_trend | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_monthly_trend | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_rsi7_gt_rsi14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ema_stack_20_50_100 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ema20_angle_deg | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_atr14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_atr30 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_atr_ratio_14_30 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_cpr_width_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_oli | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_range_to_atr14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_sma50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_sma200 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_obv | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_obv_slope | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_cpr_vs_yday_code | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_structure_trend_code | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dow | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_bb_pctB_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_bb_bw_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_vol_yz_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_vol_yz_50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_donch_pos_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_donch_pos_50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_breakout_high_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_breakout_low_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_breakout_high_50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_breakout_low_50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_days_since_boh_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_days_since_bol_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dollar_vol | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dvol_z20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dvol_z50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dvol_z252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_vol_surge_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_vol_surge_50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_atr_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_range_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_gap_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_rsi14_z252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_atr_pct_z252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_vol_z252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ema20_angle_z252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_rsi14_obv_x | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_rsi7_obv_x | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ret_5d_roll_std | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_close_roll_slope_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_close_roll_slope_50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| Comb_RSIslopePos__ADX_15_25 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| Comb_GapUp__CPR_Tmr_Above | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| Comb_GapDown__CPR_Tmr_Below | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| Comb_ATRlow__EMA20pos | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| Comb_ATRhigh__EMA20neg | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_body_ratio | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_wick_skew | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_hh_run | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_hl_run | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_lh_run | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ll_run | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_nr_expand | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_compress_state | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dist_from_20h | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dist_from_20l | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dist_from_52wh | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_midpoint_slope | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_slope_stability | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| W_ret_4w | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| W_ret_13w | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| W_close_pos | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| W_vol_vs_4w | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_3 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_6 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_12 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_13 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_16 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_19 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_23 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_26 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_29 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_33 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_35 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_38 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_40 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_41 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_WQ_44 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_slope_stability_rmean50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_slope_stability_rstd10 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_slope_stability_rstd20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_body_ratio_rmean50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_body_ratio_rmean20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_close_roll_slope_20_rstd20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_close_roll_slope_20_rstd10 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_macd_hist_rstd10 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_mdi14_diff1 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_mdi14_diff5 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_mdi14_rrank10 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_mdi14_rrank20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_donch_pos_50_rmean50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_donch_pos_50_lag5 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_donch_pos_20_rmean50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_donch_pos_20_lag5 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_cmf20_rmean50 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| DOW_0 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| DOW_1 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| DOW_2 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| DOW_3 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| DOW_4 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| DOW_5 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| DOW_6 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_dist_from_52wl | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_pos_in_52w_range | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_drawdown_252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_intraday_ret_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_overnight_share | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_amihud_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_amihud_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_realvol_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_realvol_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_realvol_ratio_20_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ret_skew_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_ret_kurt_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_downside_dev_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_upside_vol_ratio | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_days_since_5pct_up | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_n_5pct_up_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| D_n_5pct_up_252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_range_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_range_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_atr_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_atr_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_rsi14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_rsi14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_adx14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_adx14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_dist_from_52wh | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_dist_from_52wh | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_dist_from_52wl | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_dist_from_52wl | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_pos_in_52w_range | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_pos_in_52w_range | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_drawdown_252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_drawdown_252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_dvol_z20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_dvol_z20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_dvol_z252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_dvol_z252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_realvol_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_realvol_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_realvol_ratio_20_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_realvol_ratio_20_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_amihud_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_amihud_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_gap_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_gap_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_intraday_ret_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_intraday_ret_pct | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_ret_skew_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_ret_skew_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_downside_dev_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_downside_dev_60 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_bb_pctB_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_bb_pctB_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_donch_pos_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_donch_pos_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_rank_D_ema20_angle_deg | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_z_D_ema20_angle_deg | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_universe_size | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| MKT_D_realvol_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| MKT_D_rsi14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| MKT_D_adx14 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| MKT_D_dist_from_52wh | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| MKT_D_drawdown_252 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| X_relvol_20 | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYBANK_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYBANK_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTY500_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTY500_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYMIDCAP150_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYMIDCAP150_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYSMLCAP250_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYSMLCAP250_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| INDIAVIX_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| INDIAVIX_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYAUTO_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYAUTO_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYFMCG_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYFMCG_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYIT_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYIT_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYMETAL_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYMETAL_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYPHARMA_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYPHARMA_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYREALTY_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYREALTY_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYENERGY_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYENERGY_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYPSUBANK_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYPSUBANK_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYFINSERVICE_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYFINSERVICE_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYMEDIA_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYMEDIA_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYCONSUMPTION_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYCONSUMPTION_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYINFRA_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| NIFTYINFRA_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| USDINR_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| USDINR_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| CRUDEOIL_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| CRUDEOIL_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| GOLD_stale | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |
| GOLD_ret_1d | day | number | a panel feature (panel_oc) at that session's close, after the label firewall |

## market_days

| column | known | unit | meaning |
|---|---|---|---|
| date | id | date | the session (NIFTY 50 calendar, IST); every value is as of its 15:30 close |
| weekday | id | text | Mon..Fri |
| nifty_close | day | index points | index close |
| nifty_ret | day | fraction | index day return: close / previous session's close - 1 |
| nifty_gap | day | fraction | index open / previous close - 1 (blank when the cache's index open is unusable) |
| nifty_intraday | day | fraction | index close / open - 1 (the open-to-close move) |
| nifty_ret5 | day | fraction | index return over the last 5 / 20 sessions (to this close) |
| nifty_ret20 | day | fraction | index return over the last 5 / 20 sessions (to this close) |
| nifty_vs_ma50 | day | fraction | close / its 50-session average - 1 |
| nifty_up50 | day | 0/1 | 1 when the index closed at or above its 50-session average (the environment's 'up') |
| nifty_ret_z | day | sd | day return / standard deviation of the previous 60 day returns (2.5 or more = abnormal) |
| mid_close | day | index points | index close |
| mid_ret | day | fraction | index day return: close / previous session's close - 1 |
| mid_gap | day | fraction | index open / previous close - 1 (blank when the cache's index open is unusable) |
| mid_intraday | day | fraction | index close / open - 1 (the open-to-close move) |
| mid_ret5 | day | fraction | index return over the last 5 / 20 sessions (to this close) |
| mid_ret20 | day | fraction | index return over the last 5 / 20 sessions (to this close) |
| mid_vs_ma50 | day | fraction | close / its 50-session average - 1 |
| mid_up50 | day | 0/1 | 1 when the index closed at or above its 50-session average (the environment's 'up') |
| mid_ret_z | day | sd | day return / standard deviation of the previous 60 day returns (2.5 or more = abnormal) |
| small_close | day | index points | index close |
| small_ret | day | fraction | index day return: close / previous session's close - 1 |
| small_gap | day | fraction | index open / previous close - 1 (blank when the cache's index open is unusable) |
| small_intraday | day | fraction | index close / open - 1 (the open-to-close move) |
| small_ret5 | day | fraction | index return over the last 5 / 20 sessions (to this close) |
| small_ret20 | day | fraction | index return over the last 5 / 20 sessions (to this close) |
| small_vs_ma50 | day | fraction | close / its 50-session average - 1 |
| small_up50 | day | 0/1 | 1 when the index closed at or above its 50-session average (the environment's 'up') |
| small_ret_z | day | sd | day return / standard deviation of the previous 60 day returns (2.5 or more = abnormal) |
| vix | day | level | India VIX close |
| vix_chg_pct | day | fraction | VIX close / previous close - 1 |
| vix_chg5_pct | day | fraction | VIX close / its close 5 sessions earlier - 1 |
| vix_pct250 | day | 0..1 | share of the last 250 VIX closes (today included) at or below today's |
| nifty_minus_mid | day | pts | NIFTY's day return minus Midcap's / Smallcap's (> 0 = NIFTY ahead) |
| nifty_minus_mid_20 | day | pts | NIFTY's 20-session return minus Midcap's / Smallcap's |
| nifty_minus_small | day | pts | NIFTY's day return minus Midcap's / Smallcap's (> 0 = NIFTY ahead) |
| nifty_minus_small_20 | day | pts | NIFTY's 20-session return minus Midcap's / Smallcap's |
| adv | day | count | cached stocks that closed above their previous close |
| dec | day | count | cached stocks that closed below their previous close |
| unch | day | count | cached stocks unchanged |
| ad_n | day | count | cached stocks with a bar that session and the one before (the breadth sample; not every NSE stock; stocks delisted before the cache was built are missing) |
| ad_ratio | day | 0..1 | adv / (adv + dec): the breadth (unchanged left out) |
| ad_ratio_10 | day | 0..1 | 10-session average of ad_ratio (the environment's breadth) |
| env_direction | day | code | broad_bullish / narrow_bullish / broad_bearish / mixed (declared rules in tl_context.py; blank when an input is missing) |
| env_code | day | 0..3 | env_direction as 0 broad_bullish, 1 narrow_bullish, 2 mixed, 3 broad_bearish |
| high_stress | day | 0/1 | 1 = VIX at its 90th percentile or above, or VIX +25% in 5 sessions, or a NIFTY / Smallcap move of 2.5 sd or more; 0 = none of these; blank = unknown (no condition fired and an input is missing) |
| stress_reason | day | text | which stress conditions fired |
| environment | day | code | the five-label view: high_stress when the flag is on, else env_direction |
| env_text | day | text | the environment in words |
| missing | day | text | core inputs missing that session (nifty / mid / small / vix / breadth) - never filled |
| summary | day | text | the day in one plain-English line |

## context_breakdown

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS (or the strategy) |
| dimension | id | text | what the trades are grouped by |
| timing | id | text | before = known at the pick (could choose trades); after = known only afterwards (explains) |
| bucket | id | text | the group |
| trades | info | count | trades in the group |
| share | info | 0..1 | share of the engine's trades |
| days | info | count | signal days in the group |
| net_bp_mean | info | bp | average of that column in the group |
| net_bp_lo | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| net_bp_hi | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| excess_bp_mean | info | bp | average of that column in the group |
| excess_bp_lo | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| excess_bp_hi | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| post_mkt_part_bp_mean | info | bp | average of that column in the group |
| post_mkt_part_bp_lo | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| post_mkt_part_bp_hi | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| post_stock_part_bp_mean | info | bp | average of that column in the group |
| post_stock_part_bp_lo | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| post_stock_part_bp_hi | info | bp | 95% block-bootstrap interval of that average (blocks of 10 signal days, 2,000 resamples, seed 7) |
| win_rate | info | 0..1 | share of trades with net > 0 |
| severe_rate | info | 0..1 | share of trades with net <= -500 bp |

## outcome_groups

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS |
| group | id | code | winner / loser / severe_loser |
| trades | info | count | trades in the group |
| share | info | 0..1 | share of the engine's trades |
| mean_net_bp | info | bp | mean net |
| net_lo | info | bp | its 95% interval |
| net_hi | info | bp | its 95% interval |
| sum_net_bp | info | bp | total net (bp of one slot, summed) |
| median_mae | info | fraction | median worst low vs entry, sessions 1-5 |
| mean_mkt_part_bp | info | bp | mean market part / stock part |
| mean_stock_part_bp | info | bp | mean market part / stock part |
| share_driven_by_market | info | 0..1 | share whose driver is 'market' |

## outcome_profiles

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS |
| field | id | text | the pre-entry column |
| meaning | id | text | in words |
| kind | id | text | mean (median) or share of the group |
| format | id | text | how to read the numbers: pct (fraction), ratio, level, num, share |
| winner_mean | info | number | the group's mean / median (or share) |
| winner_median | info | number | the group's mean / median (or share) |
| loser_mean | info | number | the group's mean / median (or share) |
| loser_median | info | number | the group's mean / median (or share) |
| severe_loser_mean | info | number | the group's mean / median (or share) |
| severe_loser_median | info | number | the group's mean / median (or share) |
| severe_minus_winner_in_sd | info | sd | (severe losers - winners) / pooled sd |

## warning_signs

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS |
| warning | id | text | declared sign id |
| words | id | text | the sign in words |
| rule | id | text | column operator threshold |
| trades | info | count | counts (known = trades with the value present) |
| known | info | count | counts (known = trades with the value present) |
| unknown | info | count | trades whose input for this sign is blank (never flagged, left out of the comparison) |
| flagged | info | count | counts (known = trades with the value present) |
| flagged_share | info | 0..1 | shares: flagged / all; severe caught / all severe; winners flagged / all winners; severe rate among flagged / among all |
| flag_days | info | count | counts (known = trades with the value present) |
| severe_caught | info | count | counts (known = trades with the value present) |
| severe_total | info | count | counts (known = trades with the value present) |
| severe_recall | info | 0..1 | shares: flagged / all; severe caught / all severe; winners flagged / all winners; severe rate among flagged / among all |
| winners_flagged | info | count | counts (known = trades with the value present) |
| winners_total | info | count | counts (known = trades with the value present) |
| winner_cost | info | 0..1 | shares: flagged / all; severe caught / all severe; winners flagged / all winners; severe rate among flagged / among all |
| losers_flagged | info | count | counts (known = trades with the value present) |
| severe_rate_flagged | info | 0..1 | shares: flagged / all; severe caught / all severe; winners flagged / all winners; severe rate among flagged / among all |
| severe_rate_all | info | 0..1 | shares: flagged / all; severe caught / all severe; winners flagged / all winners; severe rate among flagged / among all |
| lift | info | ratio | severe rate among flagged / severe rate among all |
| mean_net_flagged_bp | info | bp | mean net of flagged / unflagged trades |
| mean_net_unflagged_bp | info | bp | mean net of flagged / unflagged trades |
| diff_bp | info | bp | flagged minus KNOWN unflagged mean net (blank inputs left out) and its 95% interval |
| diff_lo | info | bp | flagged minus KNOWN unflagged mean net (blank inputs left out) and its 95% interval |
| diff_hi | info | bp | flagged minus KNOWN unflagged mean net (blank inputs left out) and its 95% interval |
| diff_p | info | 0..1 | one-sided bootstrap p: share of resamples where flagged - unflagged >= 0 |
| losses_avoided_bp | info | bp | skipping the flagged trades: losses avoided, wins given up, net change (bp of one slot, summed) |
| wins_forgone_bp | info | bp | skipping the flagged trades: losses avoided, wins given up, net change (bp of one slot, summed) |
| pnl_change_if_skipped_bp | info | bp | skipping the flagged trades: losses avoided, wins given up, net change (bp of one slot, summed) |
| book_return | info | fraction | the money view's total return with all trades / without the flagged ones (compounded, cash-limited; not stage E) |
| book_return_if_skipped | info | fraction | the money view's total return with all trades / without the flagged ones (compounded, cash-limited; not stage E) |
| book_max_dd | info | fraction | the money view's worst drawdown (from the starting capital) with all trades / without the flagged ones / the change |
| book_max_dd_if_skipped | info | fraction | the money view's worst drawdown (from the starting capital) with all trades / without the flagged ones / the change |
| book_dd_change | info | fraction | the money view's worst drawdown (from the starting capital) with all trades / without the flagged ones / the change |

## walk_forward

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS |
| warning | id | text | sign id (ANY = every qualified sign) |
| test_year | id | year | the year judged |
| train_years | id | text | the years it was chosen on |
| train_trades | info | count | training trades used / left out because they exited inside the test year (purge) / with a blank input |
| train_purged | info | count | training trades used / left out because they exited inside the test year (purge) / with a blank input |
| train_unknown | info | count | training trades used / left out because they exited inside the test year (purge) / with a blank input |
| train_flagged | info | count | flagged trades / days in the training years |
| train_flag_days | info | count | flagged trades / days in the training years |
| train_diff_bp | info | bp | training flagged minus unflagged mean net, 95% interval |
| train_diff_lo | info | bp | training flagged minus unflagged mean net, 95% interval |
| train_diff_hi | info | bp | training flagged minus unflagged mean net, 95% interval |
| train_p | info | 0..1 | the training one-sided bootstrap p (10,000 resamples) and the Bonferroni threshold 0.05 / 8 it had to meet |
| p_needed | info | 0..1 | the training one-sided bootstrap p (10,000 resamples) and the Bonferroni threshold 0.05 / 8 it had to meet |
| qualified | info | bool | the declared qualification rule passed on the training years |
| test_trades | info | count | test-year counts |
| test_flagged | info | count | test-year counts |
| test_unknown | info | count | test-year trades with a blank input (kept: a blank never skips) |
| test_severe_avoided | info | count | test-year counts |
| test_winners_forgone | info | count | test-year counts |
| test_pnl_change_bp | info | bp | net change from skipping the flagged test-year trades |
| test_return | info | fraction | the test year's money-view return (fresh capital) with all trades / without the flagged ones / the change |
| test_return_if_skipped | info | fraction | the test year's money-view return (fresh capital) with all trades / without the flagged ones / the change |
| test_return_change | info | fraction | the test year's money-view return (fresh capital) with all trades / without the flagged ones / the change |
| test_book_max_dd | info | fraction | the test year's worst money-view drawdown with / without them |
| test_book_max_dd_if_skipped | info | fraction | the test year's worst money-view drawdown with / without them |
| test_dd_improved | info | bool | the drawdown got smaller |

## walk_forward_verdicts

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS |
| warning | id | text | sign id |
| test_years | info | count | counts over the test years |
| qualified_years | info | count | counts over the test years |
| return_change | info | fraction | money-view return change summed over the qualified test years |
| pnl_change_bp | info | bp | net change over the qualified test years |
| severe_avoided | info | count | counts over the test years |
| winners_forgone | info | count | counts over the test years |
| dd_improved_years | info | count | counts over the test years |
| verdict | info | text | CANDIDATE for a stage E replay / NOT SUPPORTED / NEVER QUALIFIED (declared rule in tl_research.py) |

## book_by_environment

| column | known | unit | meaning |
|---|---|---|---|
| group | id | text | the engine (export) or the account (backtest) |
| environment | id | code | the environment known at the PREVIOUS session's close (what was known that morning) |
| days | info | count | sessions in that environment |
| share_of_days | info | 0..1 | their share |
| mean_day_bp | info | bp | mean day return of the account / book (bp of capital) |
| lo | info | bp | 95% block-bootstrap interval of mean_day_bp |
| hi | info | bp | 95% block-bootstrap interval of mean_day_bp |
| total_return | info | fraction | those days' returns added (book) or compounded (account) |
| max_drawdown_inside | info | fraction | worst drawdown with only that environment's days chained together |
| worst_day_bp | info | bp | worst / best day |
| best_day_bp | info | bp | worst / best day |
| avg_positions | info | count | positions held at the close: average / most at once (simultaneous exposure) |
| max_positions | info | count | positions held at the close: average / most at once (simultaneous exposure) |
| avg_exposure | info | 0..1 | invested / equity: average / highest |
| max_exposure | info | 0..1 | invested / equity: average / highest |

## state_book

| column | known | unit | meaning |
|---|---|---|---|
| engine | id | text | D or ENS |
| grouping | id | text | state x phase / state / phase / confidence / event / S05 / stock volatility |
| cell | id | text | the group (e.g. 'S01 / EARLY') |
| trades | info | count | traded picks / signal days in the cell |
| share | info | 0..1 | share of the engine's traded picks |
| days | info | count | traded picks / signal days in the cell |
| net_bp_mean | info | bp | mean net per trade and its 95% interval (block bootstrap over signal days) |
| net_bp_lo | info | bp | mean net per trade and its 95% interval (block bootstrap over signal days) |
| net_bp_hi | info | bp | mean net per trade and its 95% interval (block bootstrap over signal days) |
| diff_vs_rest_bp | info | bp | the cell minus the engine's other picks whose value is known, 95% interval |
| diff_lo | info | bp | the cell minus the engine's other picks whose value is known, 95% interval |
| diff_hi | info | bp | the cell minus the engine's other picks whose value is known, 95% interval |
| diff_p_two_sided | info | 0..1 | two-sided bootstrap p of that difference (not corrected for the many cells) |
| win_rate | info | 0..1 | share with net > 0 / net <= -500 bp |
| severe_rate | info | 0..1 | share with net > 0 / net <= -500 bp |
