# Research: why D / ENS trades win or lose in different markets

tl_research v1.3 (tradelab v1.3.1), 2026-10-25T03:55:22; export TLX_20261025_001; declaration ee11568ce928dcf7 (research-declaration-2 (2026-10-24)). Traded picks only (ranks 1-3, finished): D 4,964, ENS 4,964.

**Question:** can the market conditions behind the worst losses be seen BEFORE entry, and would avoiding them cut drawdown without destroying the edge? This report observes only: nothing is filtered, the plan is unchanged, and every threshold below was declared on 24 Oct 2026 before any real run (research-declaration-2 after a review: purged training, known inputs only, Bonferroni, money view).

**What the numbers are:** trade nets are pick_meta's recorded plan nets (flat 35 bp round trip). Returns and drawdowns are tradelab's money view of the plan (compounded, cash-limited) - NOT stage E's execution backtest (EXEC_20260930_001, the -47.64% baseline). Lower-circuit exits follow stage E's own rule.

## Verdict first

- **D**: walk-forward (each year judged by signs chosen on earlier years only): no warning sign survives out of sample; all qualified signs together: money-view return change +0.00% (summed over qualified years), worst drawdown improved in 0 of 0 qualified year(s).
- **ENS**: walk-forward (each year judged by signs chosen on earlier years only): no warning sign survives out of sample; all qualified signs together: money-view return change +0.00% (summed over qualified years), worst drawdown improved in 0 of 0 qualified year(s).
- **D** by the phase of the stock's state at the pick (descriptive, section 6): early +139.3 [+71.6, +208.8] bp (1,144 trades); mature +108.4 [+31.8, +184.0] bp (1,890 trades); deteriorating +44.8 [-32.1, +121.0] bp (613 trades).
- **ENS** by the phase of the stock's state at the pick (descriptive, section 6): early +132.2 [+66.4, +201.6] bp (1,218 trades); mature +112.7 [+33.4, +190.1] bp (1,822 trades); deteriorating +89.0 [+7.8, +169.2] bp (606 trades).
- A CANDIDATE is not a rule: next comes a replay in stage E's execution simulator (the -47.64% baseline; the -25% target can only be judged there), then a declared forward paper test (month-6 checkpoint).

## 1. Winners, losers and severe losers

Severe loser = net <= -500 bp after costs. Market / stock part: beta to the home index x that index over the same hold, and the rest.

| engine | group | trades | share | mean net bp | sum net bp | median MAE | market part bp | stock part bp | driven by market |
|---|---|---|---|---|---|---|---|---|---|
| D | winner | 2,504 | 50.4% | +712.4 [+661.5, +765.0] | +1,783,788 | -2.03% | +135.6 | +611.7 | 15% |
| D | loser | 1,550 | 31.2% | -209.6 [-221.2, -198.5] | -324,804 | -4.24% | -18.4 | -156.1 | 14% |
| D | severe_loser | 910 | 18.3% | -1014.2 [-1091.1, -943.8] | -922,897 | -10.82% | -299.4 | -679.8 | 18% |
| ENS | winner | 2,552 | 51.4% | +700.1 [+648.3, +755.0] | +1,786,771 | -1.95% | +146.1 | +589.0 | 15% |
| ENS | loser | 1,528 | 30.8% | -219.9 [-228.4, -211.3] | -336,060 | -4.37% | -28.9 | -156.1 | 13% |
| ENS | severe_loser | 884 | 17.8% | -1010.1 [-1085.3, -939.9] | -892,936 | -10.69% | -308.7 | -666.4 | 18% |

## 2. What the market looked like before entry, by outcome

Means (shares for categories) of pre-entry values. 'sd gap' = (severe losers - winners) / pooled sd: about 0.2 is small, 0.5 medium. Descriptive - many fields are compared.

#### D

| field | winners | losers | severe losers | sd gap |
|---|---|---|---|---|
| breadth, 10-day A/D | 0.48 | 0.49 | 0.47 | -0.12 |
| breadth on the pick day | 0.48 | 0.49 | 0.47 | -0.04 |
| VIX | 17.6 | 16.3 | 17.8 | +0.02 |
| VIX 5-day change | +0.55% | -0.45% | +2.87% | +0.16 |
| VIX percentile | 0.47 | 0.43 | 0.51 | +0.11 |
| NIFTY minus Smallcap, 20 days | -0.68% | -1.43% | -0.75% | -0.02 |
| NIFTY minus Midcap, 20 days | -0.68% | -1.11% | -0.72% | -0.02 |
| Smallcap pick-day move | +0.06% | +0.16% | 0.00% | -0.04 |
| Smallcap move the day before | +0.05% | +0.20% | -0.02% | -0.06 |
| Smallcap 5 days | +0.32% | +0.88% | +0.04% | -0.08 |
| NIFTY vs its 50-day average | +0.96% | +1.72% | +0.27% | -0.14 |
| Smallcap vs its 50-day average | +1.77% | +3.29% | +0.93% | -0.12 |
| beta to the home index | 1.10 | 1.00 | 1.17 | +0.16 |
| correlation with the home index | 0.41 | 0.38 | 0.40 | -0.08 |
| the stock's pick-day move | -1.54% | -0.95% | -1.57% | -0.01 |
| environment = broad_bearish | 14.2% | 11.1% | 19.3% | |
| environment = broad_bullish | 29.8% | 37.1% | 23.8% | |
| environment = high_stress | 16.2% | 10.3% | 16.4% | |
| environment = mixed | 12.5% | 13.0% | 15.6% | |
| environment = narrow_bullish | 27.3% | 28.5% | 24.8% | |
| high stress = no | 83.8% | 89.7% | 83.6% | |
| high stress = yes | 16.2% | 10.3% | 16.4% | |
| size class (AMFI) = no list | 100.0% | 100.0% | 100.0% | |
| home index = Midcap 150 | 19.2% | 21.0% | 19.5% | |
| home index = NIFTY 50 | 8.0% | 13.1% | 4.6% | |
| home index = Smallcap 250 | 72.8% | 65.9% | 75.9% | |

#### ENS

| field | winners | losers | severe losers | sd gap |
|---|---|---|---|---|
| breadth, 10-day A/D | 0.48 | 0.49 | 0.47 | -0.12 |
| breadth on the pick day | 0.48 | 0.49 | 0.47 | -0.06 |
| VIX | 17.8 | 16.3 | 17.3 | -0.06 |
| VIX 5-day change | +0.54% | -0.21% | +2.53% | +0.13 |
| VIX percentile | 0.48 | 0.43 | 0.49 | +0.04 |
| NIFTY minus Smallcap, 20 days | -0.69% | -1.39% | -0.81% | -0.03 |
| NIFTY minus Midcap, 20 days | -0.70% | -1.06% | -0.75% | -0.02 |
| Smallcap pick-day move | +0.08% | +0.16% | -0.03% | -0.08 |
| Smallcap move the day before | +0.05% | +0.19% | -0.01% | -0.05 |
| Smallcap 5 days | +0.32% | +0.87% | +0.05% | -0.08 |
| NIFTY vs its 50-day average | +1.01% | +1.73% | +0.12% | -0.19 |
| Smallcap vs its 50-day average | +1.83% | +3.24% | +0.89% | -0.14 |
| beta to the home index | 1.11 | 1.03 | 1.19 | +0.19 |
| correlation with the home index | 0.41 | 0.39 | 0.41 | +0.01 |
| the stock's pick-day move | -1.82% | -1.29% | -2.02% | -0.05 |
| environment = broad_bearish | 14.1% | 10.8% | 20.1% | |
| environment = broad_bullish | 29.9% | 36.5% | 24.8% | |
| environment = high_stress | 16.2% | 10.3% | 16.2% | |
| environment = mixed | 12.0% | 13.8% | 16.0% | |
| environment = narrow_bullish | 27.8% | 28.6% | 23.0% | |
| high stress = no | 83.8% | 89.7% | 83.8% | |
| high stress = yes | 16.2% | 10.3% | 16.2% | |
| size class (AMFI) = no list | 100.0% | 100.0% | 100.0% | |
| home index = (blank) | 0.0% | 0.1% | 0.0% | |
| home index = Midcap 150 | 20.1% | 21.9% | 16.9% | |
| home index = NIFTY 50 | 7.4% | 10.7% | 4.9% | |
| home index = Smallcap 250 | 72.5% | 67.3% | 78.3% | |

## 3. Warning signs on ALL trades (in-sample: the same history)

Each sign is a yes/no condition known before entry. 'catches' = severe losers it flags; 'costs' = winners it flags too. 'difference' = mean net of flagged minus KNOWN unflagged trades (blank inputs left out of both; 'unknown' counts them) with its 95% interval and one-sided p. 'skip' = what skipping the flagged trades would have done: P&L in bp (one slot each, summed) and the money view's worst drawdown with and without them. A sign that also flags many winners destroys the edge it protects.

#### D

| sign | flags (unknown) | catches severe | costs winners | severe rate flagged / all | difference bp (p) | P&L if skipped bp | money view: worst drawdown -> if skipped |
|---|---|---|---|---|---|---|---|
| W1 high stress at the pick | 714 (14.4%; 0) | 149/910 (16%) | 405/2504 (16%) | 20.9% / 18.3% | +90.7 [-125.1, +307.1] (p 0.7975) | -132,524 | -45.77% -> -34.79% |
| W2 broad bearish at the pick | 1,025 (20.6%; 0) | 256/910 (28%) | 541/2504 (22%) | 25.0% / 18.3% | -25.4 [-195.1, +141.1] (p 0.3875) | -90,066 | -45.77% -> -27.87% |
| W3 narrow bullish at the pick | 1,524 (30.7%; 0) | 251/910 (28%) | 786/2504 (31%) | 16.5% / 18.3% | +36.1 [-55.9, +128.7] (p 0.7820) | -202,667 | -45.77% -> -45.06% |
| W4 weak breadth: 10-day A/D below 0.40 | 525 (10.6%; 0) | 135/910 (15%) | 305/2504 (12%) | 25.7% / 18.3% | +51.9 [-220.8, +309.6] (p 0.6750) | -81,048 | -45.77% -> -32.84% |
| W5 VIX up 15% or more in 5 days | 381 (7.7%; 0) | 95/910 (10%) | 206/2504 (8%) | 24.9% / 18.3% | -55.9 [-326.1, +208.0] (p 0.3680) | -21,471 | -45.77% -> -32.69% |
| W6 Smallcap fell 1.5% or more on the pick day | 450 (9.1%; 0) | 102/910 (11%) | 251/2504 (10%) | 22.7% / 18.3% | +31.8 [-133.3, +195.0] (p 0.6760) | -61,610 | -45.77% -> -29.81% |
| W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days | 756 (15.2%; 0) | 155/910 (17%) | 420/2504 (17%) | 20.5% / 18.3% | +127.0 [-39.5, +313.9] (p 0.9205) | -163,012 | -45.77% -> -48.16% |
| W8 high-beta pick: beta to its home index 1.5 or more | 885 (17.8%; 0) | 200/910 (22%) | 438/2504 (17%) | 22.6% / 18.3% | -61.7 [-187.5, +53.8] (p 0.1595) | -50,678 | -45.77% -> -22.39% |

#### ENS

| sign | flags (unknown) | catches severe | costs winners | severe rate flagged / all | difference bp (p) | P&L if skipped bp | money view: worst drawdown -> if skipped |
|---|---|---|---|---|---|---|---|
| W1 high stress at the pick | 714 (14.4%; 0) | 143/884 (16%) | 414/2552 (16%) | 20.0% / 17.8% | +126.9 [-82.3, +334.6] (p 0.8845) | -157,772 | -39.10% -> -36.00% |
| W2 broad bearish at the pick | 1,025 (20.6%; 0) | 260/884 (29%) | 549/2552 (22%) | 25.4% / 17.8% | -4.7 [-166.9, +165.9] (p 0.4810) | -111,342 | -39.10% -> -28.23% |
| W3 narrow bullish at the pick | 1,524 (30.7%; 0) | 226/884 (26%) | 809/2552 (32%) | 14.8% / 17.8% | +48.2 [-43.0, +138.6] (p 0.8380) | -222,154 | -39.10% -> -39.04% |
| W4 weak breadth: 10-day A/D below 0.40 | 525 (10.6%; 0) | 127/884 (14%) | 310/2552 (12%) | 24.2% / 17.8% | +59.2 [-177.3, +297.6] (p 0.7115) | -86,794 | -39.10% -> -33.58% |
| W5 VIX up 15% or more in 5 days | 381 (7.7%; 0) | 87/884 (10%) | 207/2552 (8%) | 22.8% / 17.8% | -12.4 [-251.0, +223.9] (p 0.4925) | -38,464 | -39.10% -> -34.26% |
| W6 Smallcap fell 1.5% or more on the pick day | 450 (9.1%; 0) | 101/884 (11%) | 255/2552 (10%) | 22.4% / 17.8% | +12.3 [-129.1, +151.6] (p 0.5885) | -55,586 | -39.10% -> -31.78% |
| W7 NIFTY ahead of Smallcap by 3 pts or more over 20 days | 756 (15.2%; 0) | 136/884 (15%) | 426/2552 (17%) | 18.0% / 17.8% | +184.0 [+7.5, +380.3] (p 0.9790) | -202,857 | -39.10% -> -39.43% |
| W8 high-beta pick: beta to its home index 1.5 or more | 917 (18.5%; 1) | 211/884 (24%) | 457/2552 (18%) | 23.0% / 17.8% | -31.8 [-141.0, +79.6] (p 0.3130) | -79,259 | -39.10% -> -27.84% |

## 4. Out of sample, in time order (walk-forward)

For each year: a test year is qualified only on trades whose actual exit (incl. lower-circuit delays) came before 1 Jan of that year; a sign QUALIFIES on the purged training trades: >= 30 flagged trades on >= 20 signal days, and the one-sided bootstrap p-value of (flagged - unflagged mean net) < 0 at most 0.05 / 8 = 0.00625 (Bonferroni over the 8 signs; 10,000 circular-block resamples over signal days). A qualified sign is then judged on that year alone in the money view (fresh capital): the year's return and worst drawdown with and without its flagged trades. Verdict rule: qualified in at least 2 test years; over those years skipping its flagged trades did not lower the money view's return (summed) and improved the year's worst drawdown in at least half of them -> a CANDIDATE for a stage E replay (the execution simulator), then a declared forward paper test; otherwise NOT SUPPORTED or NEVER QUALIFIED. Nothing is ever applied automatically.

| engine | sign | qualified years | return change (money view) | P&L change bp | severe avoided | winners forgone | drawdown improved | verdict |
|---|---|---|---|---|---|---|---|---|
| D | W1 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W2 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W3 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W4 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W5 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W6 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W7 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | W8 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| D | ANY | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W1 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W2 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W3 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W4 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W5 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W6 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W7 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | W8 | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
| ENS | ANY | 0/6 | +0.00% | +0 | 0 | 0 | 0/0 | NEVER QUALIFIED |
Purged from training (exited inside the test year): D 90 trade-folds, ENS 91 trade-folds.

## 5. The plan's money view by market environment

the plan's own fills through tradelab's money layer: Rs 10 lakh, 1/15 of the previous close's equity a new position, integer shares, 25% minimum order, flat 35 bp, compounded and cash-limited; a skipped trade's money stays in cash; each test year starts from fresh capital. Not stage E's simulator. the money view by environment: each day labelled with the environment known at the previous close. Mean day return in bp with a 95% block-bootstrap interval; worst drawdown inside = that environment's days chained together; positions = trades held at the close; exposure = invested / equity.

| engine | environment (previous close) | days | mean day bp | total | worst drawdown inside | worst day bp | avg / max positions |
|---|---|---|---|---|---|---|---|
| D | broad_bullish | 513 (31%) | +25.80 [+12.68, +38.71] | +255.02% | -14.14% | -592 | 12.0 / 14 |
| D | narrow_bullish | 450 (27%) | +23.18 [+9.80, +36.41] | +166.45% | -16.41% | -500 | 12.1 / 14 |
| D | mixed | 221 (13%) | +16.63 [-3.10, +37.76] | +39.00% | -16.61% | -602 | 12.0 / 15 |
| D | broad_bearish | 237 (14%) | -2.93 [-34.80, +25.88] | -12.77% | -33.00% | -685 | 12.0 / 15 |
| D | high_stress | 238 (14%) | +29.34 [-17.34, +72.46] | +83.17% | -42.75% | -1061 | 12.2 / 15 |
| ENS | broad_bullish | 513 (31%) | +28.58 [+15.77, +41.37] | +311.33% | -14.15% | -655 | 12.0 / 15 |
| ENS | narrow_bullish | 450 (27%) | +26.33 [+11.69, +40.38] | +208.17% | -15.61% | -589 | 12.0 / 14 |
| ENS | mixed | 221 (13%) | +10.93 [-11.69, +33.05] | +22.01% | -21.11% | -599 | 12.0 / 15 |
| ENS | broad_bearish | 237 (14%) | -6.85 [-40.60, +24.59] | -20.70% | -34.74% | -628 | 12.1 / 15 |
| ENS | high_stress | 238 (14%) | +33.77 [-8.17, +79.56] | +103.31% | -35.89% | -885 | 12.2 / 16 |

**The book's worst drawdown and the environments during it**

- D: -45.77% from 2020-01-24 to 2020-03-24; environments (previous close) on those days: high_stress 50%, mixed 38%, narrow_bullish 7%, broad_bullish 5%
- ENS: -39.10% from 2020-02-20 to 2020-03-24; environments (previous close) on those days: high_stress 86%, mixed 14%

## How much to trust this

- Same 2020-2026 history the engines were built and studied on: sections 1-3 and 5 describe it. Section 4 is the honest test - each year judged only by signs chosen on earlier years - but it is still the same history; the forward paper ledger is the only untouched evidence.
- 8 signs are tested per engine and year: qualification uses a Bonferroni p-value (0.05 / 8), so luck alone qualifies a sign in about 5% of engine-years at most; the descriptive 95% intervals in section 3 are not corrected.
- Breadth counts the stocks in your cache (survivors), not NSE's official advance/decline. Size class is AMFI's list in force on the pick day, blank where no list was given.
- Returns and drawdowns are tradelab's money view (compounded, cash-limited, flat 35 bp), not stage E's execution simulator; a CANDIDATE has to be replayed there before it can speak to the -25% target.


## 6. Stock states at the pick (descriptive; research-declaration-3)

the traded picks (ranks 1-3, finished) grouped by the stock state known at the pick day's close (tl_state v1, research defaults declared 2026-10-25): primary state; state x phase (EARLY = the first 5 sessions of the state, MATURE, DETERIORATING = a change pending, or support under 50%, or 2+ conflicting signs); phase over all states; confidence; the event of the last 10 sessions; S05 overextension; the stock's volatility. mean net bp per trade with its 95% circular-block bootstrap interval over signal days (blocks of 10, 2,000 resamples, seed 7); the difference against the engine's other traded picks whose value is known, with its 95% interval and a two-sided p. about 50 cells per engine: at 95% about 2 or 3 of them will look different by luck alone. **DESCRIPTIVE ONLY. No rule is chosen from these tables. A state-based rule needs its own declaration, the purged walk-forward (chosen on earlier years only), a stage E replay and the forward paper test.**

### D

**state x phase**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| S01 / EARLY | 187 | 4% | +189.5 [+67.5, +322.9] | +86.6 [-81.7, +254.6] | 0.315 | 49% | 17.1% |
| S01 / MATURE | 431 | 9% | +40.7 [-76.2, +154.2] | -75.6 [-200.8, +50.4] | 0.236 | 45% | 16.9% |
| S01 / DETERIORATING | 166 | 3% | +33.4 [-107.3, +167.6] | -77.5 [-225.8, +62.3] | 0.290 | 51% | 24.7% |
| S02 / EARLY | 109 | 2% | -11.0 [-188.3, +197.6] | -122.1 [-326.9, +86.8] | 0.232 | 38% | 21.1% |
| S02 / MATURE | 225 | 5% | +136.2 [+53.3, +221.2] | +30.7 [-87.0, +145.9] | 0.616 | 56% | 14.7% |
| S02 / DETERIORATING | 64 | 1% | +65.1 [-64.2, +211.6] | -43.1 [-238.8, +149.2] | 0.631 | 45% | 14.1% |
| S03 / EARLY | 152 | 3% | +75.5 [+0.5, +157.9] | -33.3 [-155.2, +95.6] | 0.597 | 43% | 10.5% |
| S03 / MATURE | 178 | 4% | +127.5 [-12.7, +323.3] | +21.2 [-122.2, +204.1] | 0.832 | 47% | 6.7% |
| S03 / DETERIORATING | 88 | 2% | +150.6 [+15.8, +278.3] | +44.3 [-123.5, +210.3] | 0.640 | 53% | 18.2% |
| S06 / EARLY | 6 | 0% | +701.0 | +594.6 [+114.4, +1576.9] * | 0.000 | 100% | 0.0% |
| S06 / MATURE | 37 | 1% | +247.2 [-49.5, +488.1] | +141.3 [-334.0, +533.9] | 0.507 | 54% | 18.9% |
| S06 / DETERIORATING | 111 | 2% | +9.0 [-191.3, +189.7] | -101.4 [-299.0, +91.4] | 0.297 | 47% | 17.1% |
| S07 / EARLY | 83 | 2% | +101.3 [+2.0, +212.1] | -6.2 [-144.7, +136.5] | 0.922 | 48% | 7.2% |
| S07 / MATURE | 67 | 1% | +58.5 [-92.7, +208.8] | -49.8 [-227.9, +129.3] | 0.586 | 46% | 13.4% |
| S07 / DETERIORATING | 74 | 1% | -10.8 [-106.7, +79.5] | -120.6 [-260.3, +13.4] | 0.079 | 42% | 14.9% |
| S08 / EARLY | 120 | 2% | +192.0 [-96.2, +502.3] | +87.6 [-182.8, +381.8] | 0.549 | 52% | 24.2% |
| S08 / MATURE | 356 | 7% | +223.3 [+79.3, +375.8] | +128.5 [-23.1, +292.7] | 0.092 | 54% | 19.9% |
| S08 / DETERIORATING | 42 | 1% | +161.3 [-106.8, +454.1] | +54.6 [-247.8, +371.2] | 0.809 | 48% | 16.7% |
| S09 / EARLY | 485 | 10% | +157.6 [+53.7, +257.6] | +58.0 [-54.1, +166.2] | 0.297 | 55% | 20.8% |
| S09 / MATURE | 596 | 12% | +69.4 [-87.5, +223.7] | -45.4 [-186.2, +98.3] | 0.564 | 52% | 23.3% |
| S09 / DETERIORATING | 68 | 1% | -36.8 [-188.1, +117.1] | -146.9 [-366.6, +107.4] | 0.213 | 46% | 27.9% |
| S12 / EARLY | 2 | 0% | +757.3 | +650.3 | n/a | 100% | 0.0% |

**state**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 784 | 16% | +74.7 [-14.9, +157.4] | -39.6 [-140.4, +68.8] | 0.464 | 47% | 18.6% |
| S02 | 398 | 8% | +84.4 [-7.9, +178.7] | -25.6 [-131.1, +82.9] | 0.610 | 49% | 16.3% |
| S03 | 418 | 8% | +113.4 [+27.2, +224.9] | +6.0 [-94.6, +132.8] | 0.946 | 47% | 10.5% |
| S06 | 154 | 3% | +93.2 [-102.1, +271.3] | -15.2 [-212.4, +169.6] | 0.879 | 51% | 16.9% |
| S07 | 224 | 5% | +51.5 [-25.2, +129.6] | -59.2 [-156.4, +41.4] | 0.244 | 46% | 11.6% |
| S08 | 518 | 10% | +211.0 [+65.2, +368.9] | +115.0 [-29.4, +266.3] | 0.132 | 53% | 20.7% |
| S09 | 1,149 | 23% | +100.4 [-10.7, +206.9] | -9.9 [-119.8, +94.1] | 0.856 | 53% | 22.5% |
| S12 | 2 | 0% | +757.3 | +649.6 | n/a | 100% | 0.0% |
| UNKNOWN | 1,317 | 27% | +109.7 [+39.3, +179.7] | +2.4 [-72.4, +77.6] | 0.989 | 51% | 18.0% |

**phase, all states**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 1,144 | 23% | +139.3 [+71.6, +208.8] | +46.5 [-22.2, +115.3] | 0.183 | 50% | 18.1% |
| MATURE | 1,890 | 38% | +108.4 [+31.8, +184.0] | +2.1 [-69.1, +72.9] | 0.898 | 51% | 18.2% |
| DETERIORATING | 613 | 12% | +44.8 [-32.1, +121.0] | -75.3 [-161.7, +5.0] | 0.079 | 48% | 19.9% |

**confidence**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| UNKNOWN | 1,317 | 27% | +109.7 [+39.3, +179.7] | +2.4 [-72.4, +77.6] | 0.989 | 51% | 18.0% |
| HIGH | 1,729 | 35% | +101.7 [+20.3, +178.1] | -9.7 [-86.1, +61.6] | 0.808 | 51% | 19.4% |
| MEDIUM | 1,305 | 26% | +144.3 [+75.2, +220.7] | +49.3 [-28.6, +133.8] | 0.213 | 50% | 16.5% |
| LOW | 613 | 12% | +44.8 [-32.1, +121.0] | -72.2 [-152.6, +9.6] | 0.076 | 48% | 19.9% |

**event, last 10 sessions**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| none | 1,061 | 21% | +81.4 [+22.4, +142.9] | -33.8 [-111.8, +43.8] | 0.406 | 46% | 12.3% |
| BREAKOUT:NEW | 510 | 10% | +61.0 [-19.5, +148.5] | -52.4 [-154.0, +50.6] | 0.329 | 46% | 21.2% |
| BREAKOUT:CONFIRMED | 723 | 15% | +140.6 [+67.7, +216.5] | +38.1 [-56.5, +133.8] | 0.466 | 53% | 16.0% |
| BREAKOUT:STALLED | 47 | 1% | +57.9 [-139.9, +294.4] | -50.6 [-228.3, +124.4] | 0.564 | 45% | 10.6% |
| FAILED_BREAKOUT:FAILED | 522 | 11% | +113.9 [+20.1, +209.2] | +6.6 [-99.8, +115.2] | 0.892 | 52% | 15.5% |
| BREAKDOWN:NEW | 1,233 | 25% | +162.2 [+61.3, +262.7] | +72.1 [-26.6, +164.3] | 0.139 | 55% | 20.8% |
| BREAKDOWN:CONFIRMED | 653 | 13% | +25.9 [-124.0, +173.0] | -94.5 [-227.3, +43.0] | 0.165 | 49% | 26.6% |
| BREAKDOWN:STALLED | 11 | 0% | +63.9 | -44.2 [-841.6, +855.1] | 0.890 | 36% | 36.4% |
| FAILED_BREAKDOWN:FAILED | 204 | 4% | +181.9 [-20.3, +395.8] | +77.1 [-112.4, +281.4] | 0.468 | 50% | 16.7% |

**S05 overextension**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| no | 4,669 | 94% | +111.7 [+59.4, +166.4] | +62.2 [-62.3, +190.8] | 0.315 | 51% | 18.2% |
| overextended | 231 | 5% | +93.1 [-37.6, +223.9] | -15.7 [-161.9, +122.4] | 0.815 | 53% | 22.1% |
| extreme | 64 | 1% | -107.7 [-246.3, -13.3] | -218.5 [-436.2, -54.1] * | 0.015 | 12% | 15.6% |

**stock volatility**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 631 | 13% | +73.7 [+16.6, +129.2] | -39.3 [-123.6, +49.0] | 0.350 | 46% | 9.8% |
| NORMAL | 2,556 | 51% | +96.3 [+43.7, +149.4] | -24.1 [-110.5, +64.2] | 0.613 | 50% | 17.4% |
| ELEVATED | 999 | 20% | +126.8 [+37.1, +229.6] | +23.5 [-66.2, +122.7] | 0.656 | 50% | 21.4% |
| EXTREME | 778 | 16% | +150.2 [-24.7, +304.3] | +50.0 [-108.7, +205.4] | 0.524 | 56% | 24.4% |

(*) = the difference's 95% interval excludes zero (not corrected for the many cells).

### ENS

**state x phase**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| S01 / EARLY | 166 | 3% | +191.7 [+30.7, +349.7] | +80.0 [-89.4, +244.9] | 0.351 | 57% | 16.3% |
| S01 / MATURE | 358 | 7% | +141.0 [+25.9, +254.4] | +28.6 [-99.9, +163.9] | 0.673 | 53% | 17.0% |
| S01 / DETERIORATING | 185 | 4% | -46.5 [-185.0, +73.2] | -170.4 [-318.8, -34.4] * | 0.017 | 49% | 25.4% |
| S02 / EARLY | 75 | 2% | -72.3 [-170.7, +28.5] | -191.5 [-328.3, -50.2] * | 0.011 | 35% | 22.7% |
| S02 / MATURE | 172 | 3% | +28.8 [-84.7, +149.1] | -90.7 [-224.2, +47.0] | 0.182 | 48% | 18.0% |
| S02 / DETERIORATING | 58 | 1% | +70.3 [-137.0, +321.8] | -45.7 [-313.5, +278.7] | 0.720 | 47% | 20.7% |
| S03 / EARLY | 205 | 4% | +56.2 [-24.4, +135.3] | -62.6 [-172.6, +54.4] | 0.296 | 51% | 12.7% |
| S03 / MATURE | 318 | 6% | +55.7 [-19.8, +133.0] | -65.2 [-162.9, +34.6] | 0.194 | 47% | 7.9% |
| S03 / DETERIORATING | 109 | 2% | +182.8 [+2.1, +378.8] | +69.6 [-91.5, +234.4] | 0.412 | 51% | 17.4% |
| S06 / EARLY | 6 | 0% | +116.1 | +0.9 [-437.3, +508.7] | 0.932 | 50% | 16.7% |
| S06 / MATURE | 21 | 0% | +200.8 [-97.2, +502.0] | +86.1 [-490.2, +536.6] | 0.813 | 38% | 19.0% |
| S06 / DETERIORATING | 101 | 2% | +179.6 [-92.2, +510.0] | +66.2 [-166.8, +296.7] | 0.588 | 52% | 18.8% |
| S07 / EARLY | 76 | 2% | +11.3 [-84.6, +102.1] | -106.2 [-226.9, +18.8] | 0.091 | 38% | 6.6% |
| S07 / MATURE | 63 | 1% | +133.0 [-43.7, +302.3] | +18.1 [-178.0, +227.0] | 0.858 | 56% | 12.7% |
| S07 / DETERIORATING | 44 | 1% | +152.4 [-1.2, +339.4] | +37.6 [-152.2, +222.1] | 0.679 | 52% | 9.1% |
| S08 / EARLY | 115 | 2% | +162.9 [-74.6, +404.5] | +49.2 [-206.3, +339.2] | 0.751 | 51% | 25.2% |
| S08 / MATURE | 397 | 8% | +247.2 [+92.7, +407.6] | +148.1 [-9.7, +306.1] | 0.058 | 54% | 18.9% |
| S08 / DETERIORATING | 39 | 1% | +211.3 [-64.7, +532.2] | +97.1 [-150.9, +358.8] | 0.450 | 49% | 15.4% |
| S09 / EARLY | 572 | 12% | +176.9 [+60.7, +283.7] | +73.1 [-33.7, +178.7] | 0.180 | 58% | 17.1% |
| S09 / MATURE | 493 | 10% | +43.4 [-141.2, +214.3] | -83.1 [-250.6, +97.0] | 0.346 | 52% | 22.7% |
| S09 / DETERIORATING | 70 | 1% | +78.0 [-80.9, +248.1] | -37.9 [-279.2, +242.9] | 0.783 | 50% | 22.9% |
| S12 / EARLY | 3 | 0% | +535.8 | +420.9 [-34.7, +978.6] | 0.143 | 100% | 0.0% |

**state**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| S01 | 709 | 14% | +104.0 [+6.0, +196.9] | -9.8 [-111.9, +92.5] | 0.837 | 52% | 19.0% |
| S02 | 305 | 6% | +11.8 [-87.9, +109.2] | -107.1 [-212.5, +6.3] | 0.064 | 45% | 19.7% |
| S03 | 632 | 13% | +77.8 [+18.2, +141.9] | -39.6 [-123.1, +42.0] | 0.345 | 49% | 11.1% |
| S06 | 128 | 3% | +180.1 [-33.5, +429.5] | +69.5 [-122.2, +268.1] | 0.508 | 50% | 18.8% |
| S07 | 183 | 4% | +87.1 [-12.9, +195.1] | -26.2 [-136.0, +91.3] | 0.634 | 48% | 9.3% |
| S08 | 551 | 11% | +227.1 [+81.7, +382.9] | +129.0 [-12.0, +287.6] | 0.073 | 53% | 20.0% |
| S09 | 1,135 | 23% | +112.8 [+3.2, +230.7] | +0.6 [-103.8, +112.9] | 0.955 | 55% | 19.9% |
| S12 | 3 | 0% | +535.8 | +423.7 [-32.1, +972.1] | 0.116 | 100% | 0.0% |
| UNKNOWN | 1,318 | 27% | +104.4 [+32.3, +174.6] | -10.9 [-83.5, +65.7] | 0.737 | 50% | 18.4% |

**phase, all states**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| EARLY | 1,218 | 25% | +132.2 [+66.4, +201.6] | +25.4 [-46.7, +99.2] | 0.483 | 53% | 16.7% |
| MATURE | 1,822 | 37% | +112.7 [+33.4, +190.1] | -5.2 [-76.3, +65.8] | 0.926 | 51% | 17.3% |
| DETERIORATING | 606 | 12% | +89.0 [+7.8, +169.2] | -31.4 [-126.4, +56.0] | 0.480 | 50% | 20.3% |

**confidence**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| UNKNOWN | 1,318 | 27% | +104.4 [+32.3, +174.6] | -10.9 [-83.5, +65.7] | 0.737 | 50% | 18.4% |
| HIGH | 1,672 | 34% | +94.7 [+13.9, +167.7] | -26.6 [-100.1, +46.1] | 0.468 | 51% | 18.5% |
| MEDIUM | 1,368 | 28% | +152.0 [+82.4, +226.0] | +54.7 [-22.0, +132.5] | 0.161 | 53% | 15.3% |
| LOW | 606 | 12% | +89.0 [+7.8, +169.2] | -26.6 [-110.7, +54.1] | 0.496 | 50% | 20.3% |

**event, last 10 sessions**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| none | 1,292 | 26% | +102.1 [+45.1, +159.8] | -13.9 [-97.4, +63.8] | 0.721 | 47% | 12.2% |
| BREAKOUT:NEW | 328 | 7% | +111.9 [-0.6, +241.3] | -0.5 [-127.4, +129.0] | 1.000 | 51% | 20.4% |
| BREAKOUT:CONFIRMED | 625 | 13% | +123.6 [+47.0, +204.7] | +12.9 [-81.9, +108.4] | 0.798 | 52% | 18.4% |
| BREAKOUT:STALLED | 44 | 1% | +128.7 [-55.1, +304.0] | +16.4 [-193.4, +230.9] | 0.889 | 55% | 9.1% |
| FAILED_BREAKOUT:FAILED | 558 | 11% | +49.3 [-20.2, +122.9] | -71.1 [-158.1, +12.3] | 0.106 | 50% | 17.2% |
| BREAKDOWN:NEW | 1,349 | 27% | +151.1 [+51.5, +249.5] | +53.2 [-38.4, +146.6] | 0.233 | 56% | 20.8% |
| BREAKDOWN:CONFIRMED | 539 | 11% | +68.3 [-117.4, +237.1] | -49.4 [-204.7, +109.4] | 0.556 | 50% | 23.6% |
| BREAKDOWN:STALLED | 30 | 1% | +176.4 [-113.9, +483.7] | +64.4 [-274.4, +418.6] | 0.691 | 47% | 10.0% |
| FAILED_BREAKDOWN:FAILED | 199 | 4% | +165.2 [-36.0, +409.7] | +55.0 [-140.8, +270.2] | 0.628 | 56% | 17.6% |

**S05 overextension**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| no | 4,811 | 97% | +114.9 [+62.4, +167.9] | +80.7 [-102.8, +289.9] | 0.395 | 51% | 17.5% |
| overextended | 140 | 3% | +94.1 [-86.7, +271.6] | -18.8 [-210.3, +152.9] | 0.797 | 53% | 25.7% |
| extreme | 13 | 0% | -611.9 | -726.1 [-1754.3, +56.6] | 0.069 | 8% | 30.8% |

**stock volatility**

| cell | trades | share | net bp per trade [95%] | vs the rest [95%] | p | win | severe |
|---|---|---|---|---|---|---|---|
| COMPRESSED | 789 | 16% | +110.4 [+49.0, +170.2] | -2.3 [-90.5, +87.9] | 0.973 | 51% | 9.9% |
| NORMAL | 2,456 | 49% | +82.1 [+21.9, +139.2] | -59.8 [-142.3, +22.1] | 0.165 | 49% | 18.2% |
| ELEVATED | 944 | 19% | +156.6 [+66.6, +254.9] | +54.6 [-35.4, +152.3] | 0.271 | 52% | 19.5% |
| EXTREME | 775 | 16% | +156.3 [+7.3, +309.2] | +52.0 [-96.3, +200.3] | 0.494 | 57% | 22.7% |

(*) = the difference's 95% interval excludes zero (not corrected for the many cells).

## Files

- outcome_groups.csv, outcome_profiles.csv, warning_signs.csv, walk_forward.csv (+ walk_forward_verdicts.csv), book_by_environment.csv, state_book.csv (v1.3), severe_losers.md / .html
