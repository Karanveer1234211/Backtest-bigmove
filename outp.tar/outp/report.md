# tradelab export - PM_20261017_001

tl_export v1.3 (tradelab v1.3.1), 2026-10-25T03:55:23. Picks: 33,100 (engines ['D', 'ENS'], ranks [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).

## Headline (the plan: buy the session-1 open, sell the session-5 close, honest exits, 35 bp)

- D ranks 1-3: 4,964 finished trades, mean net +108.0 [+57.8, +160.0] bp over 1,655 signal days; excess over buy-everything +123.6 [+91.7, +157.7] bp
- ENS ranks 1-3: 4,964 finished trades, mean net +112.4 [+59.8, +164.5] bp over 1,655 signal days; excess over buy-everything +128.0 [+93.2, +163.2] bp

Intervals: 95% circular block bootstrap over signal days (blocks of 10, 2,000 resamples, seed 7). Same history the engines were built and studied on - a description, not new evidence.

## Reconciliation (safety stop)

- OK - D 16,544 of 16,550 (99.96%), mean net +76.06 bp vs recorded +76.06 (diff +0.0005); MFE/MAE agree on 99.96%; ENS 16,543 of 16,550 (99.96%), mean net +82.11 bp vs recorded +82.11 (diff +0.0000); MFE/MAE agree on 99.96%

## Status of every pick

- ok: 33,098
- stuck: 2

## Mean net by rank (finished trades, bp)

| engine | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| D | +113.4 | +121.9 | +88.7 | +101.5 | +55.4 | +74.7 | +62.3 | +30.5 | +56.9 | +55.4 |
| ENS | +129.8 | +127.8 | +79.6 | +76.3 | +99.2 | +81.4 | +60.6 | +76.7 | +59.9 | +29.9 |

## Files

- trade_day_features.parquet
- trades.parquet
- trades.csv
- trade_days.parquet
- trade_days.csv
- daily_book.parquet
- daily_book.csv
- market_days.parquet
- market_days.csv
- market_diary.md
- context_breakdown.csv
- cards/cards_sample.md
- cards/cards_sample.html
- research/outcome_groups.csv
- research/outcome_profiles.csv
- research/warning_signs.csv
- research/walk_forward.csv
- research/walk_forward_verdicts.csv
- research/book_by_environment.csv
- research/state_book.csv
- research/research_report.md
- research/severe_losers.md
- research/severe_losers.html
- research/research_summary.json
- DATA_DICTIONARY.md
- data_dictionary.csv

## Column notes

- Returns (ret_*, mfe, mae, close_ret_sK, open_ret_sK) are fractions of the entry price (session-1 open). P&L columns ending _bp are basis points of the trade's size, after costs.
- mfe / mae: best high / worst low of sessions 1-5 vs entry (pick_meta's definition; mfe_session / mae_session = the session it happened). mfe_held / mae_held: the same while actually held (a locked exit holds longer). touch_* = first session (1-5) whose high / low reached the level; blank = never.
- open6_net_bp: sold at the 6th session's open instead; hold10_net_bp: held to the 10th close (both with honest exits). These are alternatives on the same history, not tested rules.
- trade_days: day_pnl_bp is the change in the trade's marked-to-close P&L that session (half of the 35 bp is charged at the buy, half at the sale); cum_pnl_bp ends at net_bp. Rows after the exit (after_exit) show what the stock did next with no position.
- daily_book: positions are the traded ranks 1-3; 1/15 of capital a slot, additive - a proxy, not the execution simulator.
- Features are panel values at each session's close (the firewall removed labels, forward-looking names and raw price / volume levels). Never use label_* or outcome columns as model inputs.

## Market context (v1.1)

- Indices found: NIFTY 50, Midcap 150, Smallcap 250, India VIX. Missing: none.
- Breadth: saved copy built 2026-10-24T22:07:05; advancers / (advancers + decliners) over 2495 cached stocks, median 1502.0 a session. Not NSE's official count: the cache's coverage, and stocks delisted before the cache was built are missing.
- Size class: BLANK - no AMFI lists given (it is never filled from today's list or a proxy). Put AMFI's half-yearly PDFs in %CACHE_DAILY_ROOT%\sectors\amfi\ and re-run.

### Environment labels (declared 24 Oct 2026, before any real run)

- index_up: close >= its 50-session average
- breadth: 10-session average of advancers / (advancers + decliners), all cached stocks
- breadth_strong: >= 0.5
- broad_bullish: NIFTY, Midcap, Smallcap up and breadth strong
- narrow_bullish: NIFTY up, and Midcap or Smallcap down or breadth weak
- broad_bearish: NIFTY, Midcap, Smallcap down and breadth weak
- mixed: anything else
- high_stress: VIX at or above the 90th percentile of its last 250 sessions, or VIX +25% in 5 sessions, or NIFTY / Smallcap day move >= 2.5 sd (of the previous 60 days)
- size: AMFI half-yearly lists only, each used from the 1st of the second month after its half-year ends (1 Feb / 1 Aug: an ASSUMED, conservative availability - AMFI's publication dates are not recorded; actual dates in amfi_published.csv are used instead, from the next day) until the next half-year's list is due (a missing list leaves the size blank; never carried forward)
- sensitivity: beta and correlation of daily returns, 120 sessions to the pick day (>= 60 returns)

### Where the P&L came from (ranks 1-3, the plan)

Market part = beta to the home index x that index over exactly the same hold; stock part = the rest. Intervals: 95% block bootstrap over signal days.

- **D** (4,964 trades; complete pre-entry context on 100.0%): gross +143.0 [+92.8, +195.0] bp = market part +7.8 [-34.9, +45.8] + stock part **+135.2 [+102.2, +171.3]** bp. vs NIFTY +129.2 [+88.1, +171.0], vs Smallcap +124.8 [+90.7, +160.3], vs home +127.1 [+93.0, +163.7] bp. High stress at the pick: 14.4% of trades.
  - environment at the pick: broad_bullish 31%, narrow_bullish 27%, high_stress 14%, broad_bearish 14%, mixed 13%
  - driver: stock 51%, opposite 16%, market 15%, both 15%, flat 3%
  - size (AMFI): no list 100%
  - home index: Smallcap 250 71%, Midcap 150 20%, NIFTY 50 9%
- **ENS** (4,964 trades; complete pre-entry context on 100.0%): gross +147.4 [+94.8, +199.5] bp = market part +11.2 [-31.2, +49.2] + stock part **+136.1 [+98.7, +174.2]** bp. vs NIFTY +133.8 [+90.3, +175.7], vs Smallcap +129.4 [+92.9, +166.6], vs home +131.9 [+95.0, +169.3] bp. High stress at the pick: 14.4% of trades.
  - environment at the pick: broad_bullish 31%, narrow_bullish 27%, high_stress 14%, broad_bearish 14%, mixed 13%
  - driver: stock 51%, opposite 17%, both 15%, market 15%, flat 2%, (blank) 0%
  - size (AMFI): no list 100%
  - home index: Smallcap 250 72%, Midcap 150 20%, NIFTY 50 8%, (blank) 0%

### The chain: the market before entry -> the trade -> the market during it

Each table groups the traded picks (means in bp, 95% intervals; win = share with net > 0; severe = share with net <= -500 bp). 'Known BEFORE entry' tables could in principle choose trades - but these are the same 2020-2026 years the engines were built on and many tables are shown, so a difference is a hypothesis (research\research_report.md tests the declared warning signs out of sample). 'Observed AFTER entry' tables explain outcomes and can never select. Nothing here filters trades.

#### engine D

**environment at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,539 | 31% | +91.1 [+27.4, +150.9] | +101.0 [+53.5, +146.3] | +22.6 [-13.4, +56.9] | +103.6 [+55.5, +150.0] | 49% | 14.1% |
| narrow_bullish | 1,350 | 27% | +118.1 [+53.6, +181.3] | +117.0 [+68.8, +164.9] | +30.3 [-11.4, +69.8] | +122.8 [+75.9, +170.0] | 51% | 16.7% |
| mixed | 657 | 13% | +69.6 [-38.8, +173.9] | +136.7 [+64.2, +209.9] | -52.9 [-133.6, +15.9] | +157.5 [+81.8, +229.8] | 48% | 21.6% |
| broad_bearish | 704 | 14% | +82.7 [-69.9, +231.9] | +121.1 [+27.8, +218.8] | -9.3 [-107.4, +83.0] | +127.1 [+29.0, +223.5] | 51% | 25.0% |
| high_stress | 714 | 14% | +185.6 [-33.5, +403.0] | +175.4 [+73.9, +290.6] | +6.1 [-223.2, +185.5] | +214.5 [+99.8, +351.2] | 57% | 20.9% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,250 | 86% | +95.0 [+52.4, +142.5] | +114.9 [+83.8, +150.7] | +8.1 [-21.1, +37.9] | +121.9 [+90.5, +156.0] | 49% | 17.9% |
| yes | 714 | 14% | +185.6 [-33.5, +403.0] | +175.4 [+73.9, +290.6] | +6.1 [-223.2, +185.5] | +214.5 [+99.8, +351.2] | 57% | 20.9% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,629 | 33% | +82.0 [+21.0, +143.5] | +98.8 [+53.9, +145.7] | +15.0 [-20.1, +48.7] | +102.0 [+56.5, +149.5] | 48% | 14.9% |
| narrow_bullish | 1,524 | 31% | +133.0 [+73.4, +197.3] | +119.6 [+76.9, +164.8] | +45.7 [+1.2, +90.5] | +122.2 [+83.2, +165.3] | 52% | 16.5% |
| mixed | 786 | 16% | +139.6 [+36.5, +243.4] | +161.8 [+85.2, +246.7] | -3.1 [-77.2, +63.6] | +177.7 [+94.4, +266.1] | 50% | 20.5% |
| broad_bearish | 1,025 | 21% | +87.9 [-70.5, +243.6] | +139.8 [+61.2, +221.4] | -51.9 [-214.2, +75.4] | +174.7 [+85.2, +271.7] | 53% | 25.0% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < 0.40 | 525 | 11% | +154.4 [-147.3, +388.2] | +216.1 [+85.0, +337.2] | -90.3 [-392.3, +131.8] | +279.6 [+160.8, +413.2] | 58% | 25.7% |
| 0.40 - 0.50 | 2,372 | 48% | +99.0 [+38.8, +160.8] | +112.6 [+72.2, +154.1] | +14.4 [-28.4, +57.4] | +119.6 [+79.8, +160.1] | 50% | 19.3% |
| 0.50 - 0.60 | 1,878 | 38% | +93.9 [+39.2, +148.1] | +104.8 [+65.0, +144.9] | +20.2 [-15.5, +56.1] | +108.7 [+68.2, +148.3] | 49% | 15.0% |
| >= 0.60 | 189 | 4% | +232.1 [+84.8, +394.6] | +192.2 [+70.6, +321.2] | +73.5 [+1.0, +151.1] | +193.5 [+64.9, +334.2] | 56% | 18.5% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -10% | 651 | 13% | +193.3 [+54.0, +347.5] | +162.6 [+54.1, +279.4] | +56.6 [-0.5, +113.4] | +171.7 [+56.5, +296.6] | 52% | 15.8% |
| -10% .. 0% | 1,977 | 40% | +88.0 [+32.2, +140.8] | +114.0 [+73.1, +154.5] | +3.2 [-32.6, +38.0] | +119.8 [+77.1, +163.4] | 49% | 16.9% |
| 0% .. +10% | 1,566 | 32% | +119.2 [+51.3, +193.1] | +124.5 [+71.7, +183.7] | +28.7 [-12.3, +66.2] | +125.5 [+71.3, +186.7] | 51% | 19.0% |
| +10% .. +25% | 626 | 13% | +115.9 [-0.5, +232.7] | +119.4 [+52.2, +188.9] | +19.7 [-75.2, +103.8] | +131.3 [+68.0, +195.9] | 52% | 20.3% |
| >= +25% | 144 | 3% | -159.6 [-798.0, +386.9] | +89.1 [-142.8, +278.0] | -429.6 [-1163.4, +201.8] | +304.9 [+115.0, +565.7] | 49% | 33.3% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,446 | 29% | +54.4 [-8.3, +118.2] | +79.4 [+36.2, +125.7] | +8.4 [-32.1, +47.9] | +81.1 [+37.5, +126.8] | 46% | 17.8% |
| -3 .. 0 pts | 1,640 | 33% | +126.1 [+61.0, +188.9] | +138.6 [+93.0, +185.7] | +14.4 [-29.7, +57.0] | +146.8 [+102.9, +193.5] | 52% | 15.8% |
| 0 .. +3 pts | 1,122 | 23% | +78.0 [-53.3, +199.3] | +120.8 [+56.3, +189.2] | -40.6 [-177.4, +66.1] | +153.5 [+88.8, +225.8] | 50% | 21.3% |
| >= +3 pts (NIFTY ahead: narrow) | 756 | 15% | +215.6 [+56.6, +391.2] | +180.0 [+78.5, +294.5] | +64.2 [-21.7, +150.4] | +186.5 [+78.3, +310.2] | 56% | 20.5% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no list | 4,964 | 100% | +108.0 [+57.8, +160.0] | +123.6 [+91.7, +157.7] | +7.8 [-34.9, +45.8] | +135.2 [+102.2, +171.3] | 50% | 18.3% |

**home index** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| NIFTY 50 | 446 | 9% | +128.6 [-8.8, +265.2] | +133.8 [+3.9, +271.1] | +17.0 [-11.4, +44.6] | +146.6 [+12.0, +280.2] | 45% | 9.4% |
| Midcap 150 | 983 | 20% | +48.6 [-22.2, +121.2] | +41.9 [-21.3, +100.6] | +24.0 [-18.4, +63.4] | +59.6 [-7.4, +123.4] | 49% | 18.0% |
| Smallcap 250 | 3,535 | 71% | +121.9 [+66.0, +178.7] | +145.1 [+110.4, +179.6] | +2.1 [-44.7, +48.7] | +154.8 [+117.4, +192.7] | 52% | 19.5% |

**environment on the entry day** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,536 | 31% | +114.6 [+53.3, +172.7] | +94.5 [+45.0, +143.4] | +50.2 [+18.3, +80.5] | +99.4 [+51.1, +148.4] | 50% | 13.3% |
| narrow_bullish | 1,350 | 27% | +117.8 [+59.1, +174.9] | +120.9 [+71.3, +167.4] | +29.7 [-8.9, +67.5] | +123.1 [+76.1, +168.3] | 50% | 17.2% |
| mixed | 657 | 13% | +108.0 [+4.7, +208.1] | +147.0 [+75.1, +222.4] | -20.4 [-82.8, +38.7] | +163.3 [+92.2, +232.6] | 48% | 18.3% |
| broad_bearish | 707 | 14% | +59.5 [-104.3, +209.3] | +125.7 [+26.6, +228.4] | -33.1 [-128.3, +52.1] | +127.6 [+29.2, +228.5] | 50% | 27.2% |
| high_stress | 714 | 14% | +123.3 [-98.9, +347.2] | +167.9 [+61.3, +286.9] | -58.6 [-296.1, +121.6] | +216.9 [+103.2, +353.1] | 53% | 22.7% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3% | 664 | 13% | -574.3 [-706.3, -463.3] | -25.8 [-102.7, +46.9] | -617.4 [-800.8, -482.8] | +78.1 [-7.0, +178.8] | 21% | 53.3% |
| -3% .. -1% | 779 | 16% | -101.4 [-167.6, -36.1] | +124.1 [+60.4, +187.0] | -192.3 [-210.7, -173.8] | +125.9 [+66.1, +191.3] | 34% | 23.9% |
| -1% .. +1% | 1,494 | 30% | +115.9 [+68.0, +163.7] | +143.4 [+96.1, +191.8] | +5.3 [-1.9, +12.5] | +145.6 [+98.3, +194.3] | 51% | 13.3% |
| +1% .. +3% | 1,341 | 27% | +276.1 [+216.8, +337.4] | +116.3 [+59.9, +175.0] | +189.1 [+174.0, +205.3] | +122.0 [+68.9, +176.2] | 60% | 9.3% |
| >= +3% | 686 | 14% | +660.5 [+528.4, +803.3] | +239.1 [+127.2, +351.1] | +491.1 [+440.8, +546.9] | +204.3 [+84.7, +326.6] | 77% | 6.7% |

**what drove the trade** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| market | 744 | 15% | -108.2 [-230.6, +4.7] | -26.1 [-64.1, +9.0] | -89.3 [-227.4, +31.0] | +16.1 [-4.8, +42.2] | 49% | 22.4% |
| stock | 2,539 | 51% | +242.5 [+180.9, +305.9] | +240.0 [+182.8, +295.8] | +30.2 [+16.6, +43.7] | +247.3 [+189.7, +305.6] | 57% | 21.3% |
| both | 722 | 15% | +70.2 [-42.5, +179.2] | +64.3 [+0.1, +128.6] | +41.4 [-14.5, +94.5] | +63.9 [+5.7, +121.2] | 57% | 26.0% |
| opposite | 794 | 16% | -56.1 [-77.4, -38.2] | -29.4 [-78.4, +19.7] | -2.4 [-94.8, +72.3] | -18.7 [-89.3, +58.9] | 33% | 1.8% |
| flat | 165 | 3% | -32.3 [-36.1, -28.8] | +4.3 [-27.2, +41.6] | +2.3 [-0.2, +5.6] | +0.4 [-4.1, +4.0] | 3% | 0.0% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| S01 | 784 | 16% | +74.7 [-14.9, +157.4] | +90.1 [+11.2, +169.5] | +25.6 [-12.7, +63.8] | +84.1 [+5.1, +162.1] | 47% | 18.6% |
| S02 | 398 | 8% | +84.4 [-7.9, +178.7] | +79.3 [-2.8, +163.9] | +26.0 [-15.7, +64.7] | +93.4 [+12.5, +183.4] | 49% | 16.3% |
| S03 | 418 | 8% | +113.4 [+27.2, +224.9] | +93.5 [+8.1, +206.5] | +30.4 [-5.7, +62.7] | +118.1 [+39.2, +222.5] | 47% | 10.5% |
| S06 | 154 | 3% | +93.2 [-102.1, +271.3] | +49.0 [-90.6, +187.5] | +99.0 [-1.2, +191.2] | +29.2 [-122.8, +178.7] | 51% | 16.9% |
| S07 | 224 | 5% | +51.5 [-25.2, +129.6] | +84.3 [+7.1, +167.3] | -14.9 [-63.6, +33.2] | +101.4 [+29.7, +181.4] | 46% | 11.6% |
| S08 | 518 | 10% | +211.0 [+65.2, +368.9] | +238.6 [+138.5, +354.9] | -13.7 [-132.1, +79.9] | +259.7 [+150.8, +388.5] | 53% | 20.7% |
| S09 | 1,149 | 23% | +100.4 [-10.7, +206.9] | +131.4 [+55.1, +201.8] | -17.3 [-118.9, +67.9] | +152.7 [+72.2, +232.6] | 53% | 22.5% |
| S12 | 2 | 0% | +757.3 | +737.2 | -39.2 | +831.6 | 100% | 0.0% |
| UNKNOWN | 1,317 | 27% | +109.7 [+39.3, +179.7] | +129.1 [+77.7, +185.3] | +8.1 [-32.3, +45.7] | +136.6 [+83.4, +193.7] | 51% | 18.0% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| EARLY | 1,144 | 23% | +139.3 [+71.6, +208.8] | +146.2 [+85.9, +203.7] | +16.8 [-34.8, +65.5] | +157.4 [+95.8, +220.0] | 50% | 18.1% |
| MATURE | 1,890 | 38% | +108.4 [+31.8, +184.0] | +134.0 [+82.5, +186.2] | -4.2 [-64.6, +46.9] | +147.6 [+94.1, +200.1] | 51% | 18.2% |
| DETERIORATING | 613 | 12% | +44.8 [-32.1, +121.0] | +37.8 [-23.1, +101.5] | +27.3 [-27.9, +79.3] | +52.5 [-13.0, +120.5] | 48% | 19.9% |
| (blank) | 1,317 | 27% | +109.7 [+39.3, +179.7] | +129.1 [+77.7, +185.3] | +8.1 [-32.3, +45.7] | +136.6 [+83.4, +193.7] | 51% | 18.0% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| HIGH | 1,729 | 35% | +101.7 [+20.3, +178.1] | +128.0 [+75.3, +181.8] | -8.9 [-80.9, +48.4] | +145.6 [+95.0, +200.8] | 51% | 19.4% |
| MEDIUM | 1,305 | 26% | +144.3 [+75.2, +220.7] | +152.6 [+91.2, +215.6] | +20.5 [-18.1, +57.5] | +158.9 [+93.9, +222.9] | 50% | 16.5% |
| LOW | 613 | 12% | +44.8 [-32.1, +121.0] | +37.8 [-23.1, +101.5] | +27.3 [-27.9, +79.3] | +52.5 [-13.0, +120.5] | 48% | 19.9% |
| UNKNOWN | 1,317 | 27% | +109.7 [+39.3, +179.7] | +129.1 [+77.7, +185.3] | +8.1 [-32.3, +45.7] | +136.6 [+83.4, +193.7] | 51% | 18.0% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 510 | 10% | +61.0 [-19.5, +148.5] | +77.5 [-1.6, +159.1] | +4.0 [-30.2, +38.8] | +92.0 [+11.0, +180.4] | 46% | 21.2% |
| BREAKOUT:CONFIRMED | 723 | 15% | +140.6 [+67.7, +216.5] | +157.3 [+88.8, +230.5] | +17.7 [-22.8, +58.0] | +157.9 [+88.7, +232.2] | 53% | 16.0% |
| BREAKOUT:STALLED | 47 | 1% | +57.9 [-139.9, +294.4] | +122.1 [-70.8, +351.9] | -14.6 [-59.2, +27.5] | +107.5 [-66.7, +324.8] | 45% | 10.6% |
| FAILED_BREAKOUT:FAILED | 522 | 11% | +113.9 [+20.1, +209.2] | +105.2 [+18.1, +189.2] | +41.6 [-2.2, +82.1] | +107.3 [+20.1, +189.9] | 52% | 15.5% |
| BREAKDOWN:NEW | 1,233 | 25% | +162.2 [+61.3, +262.7] | +191.9 [+135.0, +247.8] | -11.7 [-118.7, +78.1] | +208.9 [+149.7, +272.1] | 55% | 20.8% |
| BREAKDOWN:CONFIRMED | 653 | 13% | +25.9 [-124.0, +173.0] | +80.9 [-32.5, +190.8] | -38.8 [-126.3, +35.1] | +99.7 [-22.9, +221.1] | 49% | 26.6% |
| BREAKDOWN:STALLED | 11 | 0% | +63.9 | +97.7 | -109.2 | +208.1 | 36% | 36.4% |
| FAILED_BREAKDOWN:FAILED | 204 | 4% | +181.9 [-20.3, +395.8] | +166.0 [-5.1, +351.4] | +52.5 [-25.8, +129.2] | +164.4 [-12.0, +352.6] | 50% | 16.7% |
| (blank) | 1,061 | 21% | +81.4 [+22.4, +142.9] | +71.1 [+16.2, +127.5] | +31.1 [+0.9, +62.0] | +85.3 [+31.7, +140.8] | 46% | 12.3% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,669 | 94% | +111.7 [+59.4, +166.4] | +124.7 [+91.6, +160.8] | +9.0 [-35.7, +48.4] | +137.7 [+103.3, +175.6] | 51% | 18.2% |
| overextended | 231 | 5% | +93.1 [-37.6, +223.9] | +135.7 [+7.3, +274.8] | -8.0 [-79.3, +55.3] | +136.0 [+7.1, +277.0] | 53% | 22.1% |
| extreme | 64 | 1% | -107.7 [-246.3, -13.3] | +0.5 [-158.2, +122.3] | -21.7 [-52.4, +0.1] | -51.1 [-165.4, +27.8] | 12% | 15.6% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| COMPRESSED | 631 | 13% | +73.7 [+16.6, +129.2] | +62.8 [+5.7, +121.2] | +39.3 [+3.1, +75.4] | +69.4 [+13.9, +126.6] | 46% | 9.8% |
| NORMAL | 2,556 | 51% | +96.3 [+43.7, +149.4] | +110.4 [+69.5, +152.3] | +13.2 [-18.3, +44.9] | +118.1 [+79.1, +159.3] | 50% | 17.4% |
| ELEVATED | 999 | 20% | +126.8 [+37.1, +229.6] | +153.1 [+84.9, +229.7] | +1.2 [-56.9, +56.5] | +160.5 [+86.4, +243.2] | 50% | 21.4% |
| EXTREME | 778 | 16% | +150.2 [-24.7, +304.3] | +178.4 [+78.8, +280.5] | -27.1 [-188.9, +102.0] | +212.3 [+103.5, +325.8] | 56% | 24.4% |

#### engine ENS

**environment at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,539 | 31% | +87.2 [+24.6, +145.6] | +97.1 [+50.2, +143.4] | +15.7 [-18.8, +47.5] | +106.6 [+61.6, +150.4] | 50% | 14.2% |
| narrow_bullish | 1,350 | 27% | +132.4 [+68.6, +193.7] | +131.3 [+83.6, +177.6] | +36.4 [-5.4, +75.6] | +131.0 [+85.5, +175.9] | 53% | 15.0% |
| mixed | 657 | 13% | +28.1 [-85.2, +135.7] | +95.3 [+22.1, +163.5] | -45.2 [-126.3, +26.4] | +108.3 [+37.5, +175.6] | 46% | 21.5% |
| broad_bearish | 704 | 14% | +97.4 [-80.2, +270.5] | +135.8 [+11.3, +257.4] | -3.4 [-101.1, +90.8] | +135.8 [+8.5, +257.1] | 51% | 25.3% |
| high_stress | 714 | 14% | +221.0 [+21.3, +437.6] | +210.7 [+98.2, +340.5] | +20.6 [-206.0, +197.0] | +235.7 [+90.4, +400.8] | 58% | 20.0% |

**high stress at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,250 | 86% | +94.1 [+47.2, +140.7] | +114.1 [+80.0, +149.3] | +9.7 [-19.3, +39.1] | +119.4 [+85.7, +154.0] | 50% | 17.4% |
| yes | 714 | 14% | +221.0 [+21.3, +437.6] | +210.7 [+98.2, +340.5] | +20.6 [-206.0, +197.0] | +235.7 [+90.4, +400.8] | 58% | 20.0% |

**direction at the pick (stress ignored)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,629 | 33% | +84.3 [+25.1, +142.8] | +101.1 [+55.3, +146.5] | +8.7 [-24.3, +40.8] | +110.7 [+69.2, +154.9] | 49% | 14.6% |
| narrow_bullish | 1,524 | 31% | +145.8 [+81.1, +210.4] | +132.4 [+85.5, +177.7] | +50.8 [+7.7, +96.5] | +130.0 [+87.4, +170.5] | 53% | 14.8% |
| mixed | 786 | 16% | +110.7 [-9.8, +241.2] | +132.8 [+46.4, +236.0] | +7.2 [-72.8, +76.2] | +138.5 [+49.8, +247.8] | 49% | 20.4% |
| broad_bearish | 1,025 | 21% | +108.6 [-59.1, +262.2] | +160.6 [+51.9, +261.7] | -40.4 [-199.6, +83.7] | +184.0 [+56.9, +307.7] | 54% | 25.4% |

**breadth at the pick (10-day A/D)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < 0.40 | 525 | 11% | +165.3 [-70.5, +370.6] | +227.1 [+111.0, +346.6] | -85.9 [-387.1, +133.9] | +286.3 [+130.7, +455.7] | 59% | 24.2% |
| 0.40 - 0.50 | 2,372 | 48% | +111.5 [+46.6, +173.5] | +125.2 [+82.2, +167.1] | +22.6 [-20.0, +67.2] | +123.9 [+80.4, +165.0] | 51% | 18.3% |
| 0.50 - 0.60 | 1,878 | 38% | +79.9 [+24.5, +137.3] | +90.7 [+46.6, +136.2] | +18.1 [-17.3, +53.1] | +96.8 [+52.0, +140.5] | 49% | 15.8% |
| >= 0.60 | 189 | 4% | +298.6 [+139.1, +495.6] | +258.7 [+122.1, +427.3] | +69.8 [+7.5, +132.0] | +263.8 [+131.3, +426.7] | 58% | 13.2% |

**VIX 5-day change at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -10% | 651 | 13% | +157.7 [+30.8, +320.8] | +127.0 [+27.4, +245.8] | +65.5 [+4.1, +128.0] | +127.5 [+28.7, +252.5] | 51% | 17.7% |
| -10% .. 0% | 1,977 | 40% | +87.1 [+33.5, +139.3] | +113.0 [+76.1, +151.1] | +6.7 [-28.6, +41.2] | +115.5 [+77.4, +154.9] | 50% | 16.4% |
| 0% .. +10% | 1,566 | 32% | +134.9 [+63.4, +205.9] | +140.3 [+86.5, +196.5] | +27.6 [-12.0, +62.4] | +142.3 [+87.4, +198.0] | 52% | 18.1% |
| +10% .. +25% | 626 | 13% | +144.2 [+46.3, +235.9] | +147.7 [+81.9, +209.8] | +23.9 [-74.0, +110.1] | +155.3 [+82.0, +231.7] | 55% | 18.5% |
| >= +25% | 144 | 3% | -130.0 [-612.1, +291.4] | +118.7 [-68.7, +293.3] | -404.3 [-1127.9, +217.1] | +309.2 [+12.3, +730.1] | 49% | 31.2% |

**NIFTY minus Smallcap, 20 days, at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3 pts (small caps ahead) | 1,446 | 29% | +51.8 [-13.3, +115.9] | +76.7 [+27.4, +130.0] | +4.6 [-36.2, +43.4] | +82.2 [+35.1, +131.1] | 47% | 16.9% |
| -3 .. 0 pts | 1,640 | 33% | +89.5 [+17.4, +152.3] | +102.0 [+59.8, +142.2] | +22.8 [-23.5, +67.3] | +101.6 [+57.3, +142.3] | 52% | 17.3% |
| 0 .. +3 pts | 1,122 | 23% | +118.8 [-12.3, +244.9] | +161.6 [+77.1, +242.6] | -35.8 [-171.5, +69.9] | +189.8 [+94.1, +284.1] | 53% | 19.6% |
| >= +3 pts (NIFTY ahead: narrow) | 756 | 15% | +268.3 [+103.3, +447.7] | +232.7 [+127.3, +352.6] | +68.6 [-18.7, +159.3] | +234.8 [+127.3, +360.4] | 56% | 18.0% |

**size class (AMFI)** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no list | 4,964 | 100% | +112.4 [+59.8, +164.5] | +128.0 [+93.2, +163.2] | +11.2 [-31.2, +49.2] | +136.1 [+98.7, +174.2] | 51% | 17.8% |

**home index** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| NIFTY 50 | 396 | 8% | +56.5 [-120.5, +202.3] | +62.4 [-104.0, +208.1] | +9.0 [-17.6, +33.6] | +82.5 [-90.1, +225.8] | 48% | 10.9% |
| Midcap 150 | 997 | 20% | +84.0 [+9.7, +157.0] | +98.8 [+33.4, +161.6] | +11.5 [-40.3, +53.3] | +107.5 [+32.1, +178.6] | 52% | 14.9% |
| Smallcap 250 | 3,570 | 72% | +126.5 [+71.4, +181.7] | +143.4 [+105.8, +181.4] | +11.4 [-32.9, +53.1] | +150.1 [+110.4, +191.2] | 52% | 19.4% |
| (blank) | 1 | 0% | -35.0 | +267.0 | n/a | n/a | 0% | 0.0% |

**environment on the entry day** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| broad_bullish | 1,536 | 31% | +118.6 [+55.5, +175.1] | +98.5 [+50.2, +144.5] | +42.9 [+11.9, +70.8] | +110.8 [+64.7, +156.5] | 51% | 13.1% |
| narrow_bullish | 1,350 | 27% | +128.5 [+67.4, +185.9] | +131.6 [+83.1, +180.8] | +36.2 [-2.9, +74.3] | +127.3 [+80.8, +173.7] | 52% | 15.1% |
| mixed | 657 | 13% | +79.4 [-20.8, +179.5] | +118.4 [+46.9, +188.5] | -13.0 [-80.5, +49.4] | +127.4 [+58.3, +195.4] | 50% | 19.2% |
| broad_bearish | 707 | 14% | +68.2 [-114.4, +237.7] | +134.4 [+2.8, +258.4] | -30.0 [-125.6, +53.4] | +133.2 [-1.4, +255.5] | 50% | 27.6% |
| high_stress | 714 | 14% | +142.5 [-53.1, +364.3] | +187.1 [+75.0, +320.4] | -40.9 [-275.4, +140.5] | +218.4 [+67.5, +390.4] | 53% | 22.1% |

**Smallcap over the hold** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| < -3% | 667 | 13% | -572.3 [-680.0, -465.7] | -24.4 [-113.5, +68.1] | -614.5 [-791.7, -482.1] | +77.2 [-40.0, +221.6] | 22% | 51.1% |
| -3% .. -1% | 781 | 16% | -151.0 [-215.1, -92.0] | +73.5 [+8.8, +134.9] | -190.7 [-205.8, -175.9] | +74.5 [+9.8, +135.2] | 33% | 28.3% |
| -1% .. +1% | 1,487 | 30% | +98.5 [+48.0, +149.8] | +125.2 [+74.8, +173.9] | +5.9 [-1.1, +13.3] | +127.6 [+78.5, +177.0] | 49% | 12.3% |
| +1% .. +3% | 1,344 | 27% | +343.8 [+284.7, +409.1] | +184.1 [+124.7, +250.0] | +198.1 [+184.1, +212.8] | +180.6 [+124.0, +243.1] | 65% | 7.3% |
| >= +3% | 685 | 14% | +655.4 [+510.1, +795.2] | +234.5 [+117.8, +341.5] | +495.4 [+437.0, +559.8] | +195.1 [+74.8, +303.0] | 79% | 6.0% |

**what drove the trade** - observed AFTER entry: explains, cannot select

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| market | 738 | 15% | -76.6 [-172.1, +11.5] | -14.7 [-46.5, +13.2] | -53.2 [-155.8, +40.1] | +11.6 [-5.2, +30.9] | 51% | 21.7% |
| stock | 2,544 | 51% | +225.4 [+158.6, +299.2] | +233.5 [+173.8, +297.5] | +25.0 [+10.2, +39.4] | +235.4 [+174.3, +302.0] | 57% | 21.1% |
| both | 752 | 15% | +122.6 [+29.9, +212.3] | +93.1 [+41.2, +145.4] | +64.7 [+20.5, +109.5] | +92.8 [+45.4, +140.0] | 59% | 22.7% |
| opposite | 820 | 17% | -57.7 [-82.6, -34.8] | -17.0 [-78.4, +46.1] | -21.4 [-147.6, +77.0] | -1.3 [-91.0, +105.1] | 35% | 2.1% |
| flat | 109 | 2% | -35.9 [-39.8, -32.2] | -37.2 [-64.5, -8.3] | +3.4 [+0.7, +6.1] | -4.3 [-7.7, -0.8] | 6% | 0.0% |
| (blank) | 1 | 0% | -35.0 | +267.0 | n/a | n/a | 0% | 0.0% |

**stock state at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| S01 | 709 | 14% | +104.0 [+6.0, +196.9] | +127.7 [+32.1, +217.1] | +10.4 [-23.7, +43.3] | +128.6 [+34.7, +217.5] | 52% | 19.0% |
| S02 | 305 | 6% | +11.8 [-87.9, +109.2] | +1.6 [-92.0, +96.4] | +35.5 [-8.2, +77.4] | +11.4 [-89.2, +105.4] | 45% | 19.7% |
| S03 | 632 | 13% | +77.8 [+18.2, +141.9] | +86.3 [+29.5, +149.3] | +11.0 [-19.7, +37.2] | +101.7 [+46.2, +161.8] | 49% | 11.1% |
| S06 | 128 | 3% | +180.1 [-33.5, +429.5] | +163.0 [-16.1, +391.7] | +59.9 [-16.7, +139.6] | +155.2 [-22.2, +379.7] | 50% | 18.8% |
| S07 | 183 | 4% | +87.1 [-12.9, +195.1] | +81.8 [+7.9, +165.7] | +44.8 [-17.3, +95.3] | +77.3 [+8.7, +155.9] | 48% | 9.3% |
| S08 | 551 | 11% | +227.1 [+81.7, +382.9] | +231.4 [+124.8, +345.1] | +6.5 [-105.5, +99.3] | +255.6 [+141.0, +381.0] | 53% | 20.0% |
| S09 | 1,135 | 23% | +112.8 [+3.2, +230.7] | +153.9 [+69.3, +239.6] | -17.7 [-125.1, +71.4] | +165.5 [+73.7, +255.3] | 55% | 19.9% |
| S12 | 3 | 0% | +535.8 | +479.3 | -42.6 | +613.4 | 100% | 0.0% |
| UNKNOWN | 1,318 | 27% | +104.4 [+32.3, +174.6] | +114.1 [+58.8, +171.5] | +23.9 [-14.3, +59.2] | +115.6 [+60.4, +173.8] | 50% | 18.4% |

**state phase at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| EARLY | 1,218 | 25% | +132.2 [+66.4, +201.6] | +140.9 [+85.7, +199.3] | +21.1 [-25.1, +62.2] | +146.1 [+90.0, +206.3] | 53% | 16.7% |
| MATURE | 1,822 | 37% | +112.7 [+33.4, +190.1] | +142.9 [+92.5, +197.0] | -9.0 [-89.0, +52.0] | +156.7 [+98.8, +218.8] | 51% | 17.3% |
| DETERIORATING | 606 | 12% | +89.0 [+7.8, +169.2] | +87.4 [+13.2, +158.1] | +25.0 [-17.8, +66.8] | +99.1 [+23.6, +167.6] | 50% | 20.3% |
| (blank) | 1,318 | 27% | +104.4 [+32.3, +174.6] | +114.1 [+58.8, +171.5] | +23.9 [-14.3, +59.2] | +115.6 [+60.4, +173.8] | 50% | 18.4% |

**state confidence at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| HIGH | 1,672 | 34% | +94.7 [+13.9, +167.7] | +130.7 [+76.6, +184.3] | -17.2 [-92.5, +47.1] | +146.9 [+85.7, +210.6] | 51% | 18.5% |
| MEDIUM | 1,368 | 28% | +152.0 [+82.4, +226.0] | +156.1 [+98.6, +217.1] | +27.8 [-8.9, +63.5] | +159.1 [+103.5, +221.1] | 53% | 15.3% |
| LOW | 606 | 12% | +89.0 [+7.8, +169.2] | +87.4 [+13.2, +158.1] | +25.0 [-17.8, +66.8] | +99.1 [+23.6, +167.6] | 50% | 20.3% |
| UNKNOWN | 1,318 | 27% | +104.4 [+32.3, +174.6] | +114.1 [+58.8, +171.5] | +23.9 [-14.3, +59.2] | +115.6 [+60.4, +173.8] | 50% | 18.4% |

**event in the last 10 sessions** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| BREAKOUT:NEW | 328 | 7% | +111.9 [-0.6, +241.3] | +146.6 [+38.9, +268.7] | +2.6 [-40.0, +45.9] | +144.3 [+36.2, +271.0] | 51% | 20.4% |
| BREAKOUT:CONFIRMED | 625 | 13% | +123.6 [+47.0, +204.7] | +130.4 [+52.4, +207.6] | +21.8 [-13.9, +57.1] | +136.8 [+59.7, +215.4] | 52% | 18.4% |
| BREAKOUT:STALLED | 44 | 1% | +128.7 [-55.1, +304.0] | +121.1 [-88.3, +301.6] | +76.5 [-11.7, +171.1] | +87.1 [-105.3, +271.0] | 55% | 9.1% |
| FAILED_BREAKOUT:FAILED | 558 | 11% | +49.3 [-20.2, +122.9] | +61.7 [+5.0, +123.3] | +25.0 [-12.7, +61.8] | +59.3 [+4.2, +119.4] | 50% | 17.2% |
| BREAKDOWN:NEW | 1,349 | 27% | +151.1 [+51.5, +249.5] | +186.9 [+125.7, +245.7] | -12.2 [-115.9, +77.8] | +198.3 [+128.8, +272.4] | 56% | 20.8% |
| BREAKDOWN:CONFIRMED | 539 | 11% | +68.3 [-117.4, +237.1] | +116.3 [-37.3, +240.1] | -24.7 [-123.8, +65.9] | +128.0 [-35.7, +266.9] | 50% | 23.6% |
| BREAKDOWN:STALLED | 30 | 1% | +176.4 [-113.9, +483.7] | +66.5 [-132.5, +268.5] | +131.3 [+29.3, +226.0] | +80.1 [-140.5, +325.1] | 47% | 10.0% |
| FAILED_BREAKDOWN:FAILED | 199 | 4% | +165.2 [-36.0, +409.7] | +142.3 [-18.0, +346.3] | +47.5 [-36.8, +131.0] | +152.7 [-8.8, +349.1] | 56% | 17.6% |
| (blank) | 1,292 | 26% | +102.1 [+45.1, +159.8] | +93.6 [+41.7, +146.7] | +31.3 [+6.2, +57.0] | +105.9 [+54.8, +156.6] | 47% | 12.2% |

**S05 overextension at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| no | 4,811 | 97% | +114.9 [+62.4, +167.9] | +130.6 [+95.7, +166.0] | +10.9 [-33.0, +49.7] | +139.0 [+102.1, +177.8] | 51% | 17.5% |
| overextended | 140 | 3% | +94.1 [-86.7, +271.6] | +104.5 [-62.9, +283.3] | +28.3 [-23.3, +78.5] | +100.8 [-60.9, +275.4] | 53% | 25.7% |
| extreme | 13 | 0% | -611.9 | -578.2 | -54.5 | -522.4 | 8% | 30.8% |

**stock volatility at the pick** - known BEFORE entry

| bucket | trades | share | net bp | excess bp | market part bp | stock part bp | win | severe |
|---|---|---|---|---|---|---|---|---|
| COMPRESSED | 789 | 16% | +110.4 [+49.0, +170.2] | +92.0 [+37.9, +149.9] | +41.1 [+8.1, +74.0] | +104.3 [+51.2, +159.2] | 51% | 9.9% |
| NORMAL | 2,456 | 49% | +82.1 [+21.9, +139.2] | +99.2 [+55.4, +142.7] | +14.8 [-15.7, +43.9] | +102.4 [+58.2, +145.8] | 49% | 18.2% |
| ELEVATED | 944 | 19% | +156.6 [+66.6, +254.9] | +179.5 [+107.9, +259.0] | +13.8 [-37.4, +61.9] | +177.8 [+103.9, +265.9] | 52% | 19.5% |
| EXTREME | 775 | 16% | +156.3 [+7.3, +309.2] | +193.2 [+99.2, +292.2] | -33.6 [-204.6, +103.5] | +224.9 [+105.5, +356.5] | 57% | 22.7% |

### Research (research\research_report.md)

- D W1: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W2: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W3: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W4: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W5: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W6: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W7: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D W8: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- D ANY: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W1: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W2: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W3: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W4: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W5: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W6: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W7: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS W8: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)
- ENS ANY: NEVER QUALIFIED (qualified 0/6 test years; money-view return change +0.00%; P&L change +0 bp; drawdown improved in 0)

### Files

- trades: pre_* (known at the pick day's close: the market the day before and that day, environment, high stress, breadth, VIX, divergence, AMFI size, beta / correlation to the three indices) and post_* (observed after the entry: entry-day moves, the hold, market part / stock part, driver); outcome; story.
- trade_days: Midcap / Smallcap / VIX / breadth / environment that session; held_ret split into mkt_part_day_bp and stock_part_day_bp.
- market_days + market_diary.md: every session; context_breakdown.csv: the tables above; cards\cards_sample.html: readable trades (python tl_cards.py --export <this folder> --worst 20 ...); research\: winners vs losers, warning signs, walk-forward, the book by environment.
- DATA_DICTIONARY.md: every column, its unit and when it is known.
