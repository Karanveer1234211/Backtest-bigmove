# BigMove Pine v3 — AUTO HISTORICAL REGISTRY

**What changed:** No manually entered CSV case key. A single universal Pine v6 strategy automatically selects the proper historical picks when you change NSE tickers on the **1D** chart.

## Start here — preferred workflow

1. Open **`scripts/BigMove_AUTO_All_Tickers_P0_P6_v3.pine`** and paste the contents into TradingView → Pine Editor. Save and **Add to chart**. (The code has been source-audited, not compiler-verified.)
2. Open any NSE ticker in `registry/ticker_index.csv` — e.g. `NSE:NIITLTD`. Keep 1D timeframe. **Do not change any case key**; the registry responds automatically to chart symbol changes.
3. In Settings → Inputs choose **Setup family** `P0` ... `P6` or `All`, **Engine** `D` / `ENS` / `All`, and **Rank** `1` / `2` / `3` / `All`. Defaults are `All / All / All`.
4. Replay from before a journal selection. Orange `PICK` labels are original evening selections. Aqua `TRIGGER + ORDER` labels mean a new setup signal qualified for a simulated entry next open. `TRIGGER / BLOCKED` means the case's rule qualified, but an existing/pending position prevented a separate simulated trade.
5. The table reports `AUTO MATCHED N` cases mapped to the current stock, `Historical picks seen` on the *loaded chart*, `Triggered cases`, `No trigger (expired)`, and blocked orders. It replaces `WRONG SYMBOL`/manual keys. Some chart histories start after the historical pick; in that case `picks seen < matched`.
6. For apples-to-apples strategy runs, **filter to one setup + one engine** before opening Strategy Tester. Even then the same ticker can have overlapping 5-session holdings, so the per-chart strategy is an *execution illustration*, not a complete portfolio or an independent trade simulator of every opportunity.
7. Results must count `NO TRIGGER` cases as skipped opportunities. **Do not treat a trigger or a blocked trade as an original journal profit.** Original exits can be shown via an OFF-by-default checkbox for audit but are hindsight information.

### The NIITLTD example from your screenshot

Open **`NSE:NIITLTD` / 1D** and choose `P0 / All / All`:

| Original selection | Engine/rank | Setup | Journal entry date | Journal exit date |
|---|---|---|---|---|
| 2022-01-24 | D3 | P0 | 2022-01-25 | 2022-02-01 |
| 2026-03-25 | ENS3 | P0 | 2026-03-27 | 2026-04-06 |

There is **no key to paste**. The existing P0 hypothesis requires a *same-day 20-session low breakdown and reclaim plus strong close and volume* and therefore can correctly produce **NO TRIGGER** for 2026-03-25. This update changes the **case selection interface only**, not the trigger definition. The previously proposed two-session P0B has **not** been silently added.

## Files

- `scripts/BigMove_AUTO_All_Tickers_P0_P6_v3.pine`: **universal auto-load strategy**, all 1,583 P0–P6 setup memberships, 467 NSE tickers; best single-script daily workflow.
- `scripts/BigMove_AUTO_All_9930_Top3_Picks_Overlay_v3.pine`: **full journal pick overlay indicator**. All 9,930 original top-3 selections over 1,064 symbols, including 8,482 not in any P0–P6 setup. This indicator does not generate new simulated orders.
- `ticker_scripts/BigMove_<TICKER>_AUTO_v3.pine`: 467 compact ticker-specific alternatives when a universal script takes too long to compile or run. Load the corresponding ticker-specific script once per stock; no per-trade key.
- `registry/ticker_index.csv`: ticker lookup with P0..P6 case counts and exact corresponding file path.
- `registry/all_eligible_setup_cases_blind.csv`: all 1,583 cases with **no net-return/outcome columns**, useful to plan blind replay.
- `qa/verification.json` and `qa/TEST_REPORT.md`: provenance, exhaustive mapping checks, known limitations.
- `rebuild/build_registry.py`: optional local generator. Reads existing **source mapping CSVs**, not live TradingView or production. It writes only this research folder; Python standard library only. Edit the BASE/SOURCE constants if moving folders.

## Controls and execution

- All chart signals are evaluated on **confirmed daily closes**. A qualifying signal is ordered for next daily open; default 10-session watchlist excludes triggers that would fill beyond T+10.
- The original 7 trigger rules, P0–P6, and optional shorter family TTLs are preserved from v2. No strategy outcome is presumed successful.
- Default Pine commission 0.175% per side, approximating 35 bp total. Actual brokerage, NSE taxes, price impact and lower-circuit exit delays are not fully simulated. Strategy Tester can differ from the frozen model's honest-exit backtest.
- The stop and R-multiple target use user-configurable research assumptions; those do **not** replace the original engine's five-session close exit.
- Price histories may be split-adjusted; some old tickers are renamed and will need separate alias audits. `HEG` previously mapped to `HEGAM`.
- Pine cannot dynamically access the local xlsx/CSV. The selected-date keys are **embedded at generation time** in this script. A newer journal requires re-generating the script. This is a static registry that auto-selects *among its embedded records*, not a live journal connector.
- The single TradingView strategy portfolio **cannot simultaneously represent independent D and ENS trades** in the same ticker or concurrent repeat picks. Read each trigger label and process independent cases externally in a research tracker. Simulated strategy totals are NOT a substitute for the full-history, multi-symbol portfolio comparison.

## Source fidelity / preserved files

- Original `TRADE_JOURNAL 2.xlsx` untouched.
- All top-3 selection identities checked against `Picks` raw extraction (33,100 selections), plus exact reconciliation with prior 9,930 mapped records.
- `What worked` supplies hypotheses; journal `Picks` and original selection-day market labels supply mapping, **never future profit classification**.
- All research outputs in this dedicated `BigMove_Auto_Registry_20261028` directory. No frozen models or production files changed.

**Compilation and tests:** Produced with deterministic Python-based source verification; no TradingView Pine compiler is exposed by the connected TradingView integration. If you see a compile error, send the exact error and line number for a targeted repair before using its performance report.
