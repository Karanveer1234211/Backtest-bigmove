#!/usr/bin/env python3
"""Read-only BigMove Pine registry generator. Uses Python stdlib only.

Expects the prior full-history mapping CSVs. NEVER modifies source or production.
"""
import csv, json, hashlib, re, collections, pathlib, sys, textwrap, zipfile

BASE=pathlib.Path('/mnt/data/BigMove_Auto_Registry_20261028')
SOURCE=pathlib.Path('/mnt/data/BigMove_Full_History_Setup_Map_2026-10-28/data')
MEM=SOURCE/'TOP3_ALL_category_memberships.csv'
TOP=SOURCE/'TOP3_all_9930_mapped.csv'

def get_rows(path):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def ndate(value):
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2}', value),value
    return value.replace('-','')

def dateval(date):
    return f'{date[:4]}-{date[4:6]}-{date[6:]}'

def quote(s):
    assert all(c not in s for c in ['"','\\','\r'])
    return '"'+s.replace('\n','\\n')+'"'

def collect_data(rows):
    by=collections.defaultdict(list)
    for r in rows:
        symbol=r['tradingview_symbol_suggestion']
        assert symbol.startswith('NSE:') and re.fullmatch(r'NSE:[A-Z0-9_&.-]+',symbol),symbol
        sid=r['setup_id']; assert sid in [f'P{x}' for x in range(7)]
        eng=r['engine']; assert eng in ['D','ENS']
        rank=int(r['rank']); assert rank in (1,2,3)
        age=int(r['stock_event_age_at_pick_sessions'] or 0)
        date=ndate(r['selection_date']); entry=ndate(r['journal_buy_date']); exit=ndate(r['journal_exit_date'])
        assert len(date)==8 and 0<=age<100
        record=f'{sid},{date},{eng}{rank},{age},{entry},{exit}'
        by[symbol[4:]].append(record)
    for ticker in by:
        by[ticker].sort(key=lambda x: (x.split(',')[1], x.split(',')[0],x.split(',')[2]))
    return dict(sorted(by.items()))

members=get_rows(MEM); top=get_rows(TOP)
assert len(members)==1583 and len(top)==9930
assert len({r['pine_case_key'] for r in members})==len(members)
assert len({r['trade_id'] for r in top})==9930
assert {r['trade_id'] for r in members} <= {r['trade_id'] for r in top}
by=collect_data(members)
assert len(by)==467
assert sum(map(len,by.values()))==1583

# Packs are independent complete ticker rows, safely below a few KB per literal.
# Format: TICKER|P1,YYYYMMDD,D1,age,BUYDATE,EXITDATE;P2,...\nTICKER|...
lines=[ticker+'|'+ ';'.join(cases) for ticker,cases in by.items()]
packs=[];cur=[];cur_sz=0
for line in lines:
    assert len(line)<5000
    if cur and cur_sz + len(line)+1 >6500:
        packs.append('\n'.join(cur));cur=[];cur_sz=0
    cur.append(line);cur_sz += len(line)+1
if cur: packs.append('\n'.join(cur))
assert sum(p.count('\n')+1 for p in packs)==len(by)

# Reuse same trigger hypotheses as prior v2. Do not modify rules because user wants registry, not new signals.
HEAD='''//@version=6
// BigMove 2026-10-28. RESEARCH ONLY. Pick-time classifications from 2020-2026 journal.
// AUTO REGISTRY: switches NSE ticker without manual CSV key. Full P0-P6 eligible history.
// Historical outcomes NOT embedded. A setup TRIGGER is a NEW hypothesis, not journal P/L.
// One chart has one strategy position: all case signals counted, entries can be blocked by overlap.
strategy("BigMove | Auto Registry P0-P6 | v3", overlay = true,
     initial_capital = 1000000, currency = currency.INR,
     commission_type = strategy.commission.percent, commission_value = 0.175,
     pyramiding = 0, calc_on_every_tick = false, process_orders_on_close = false,
     max_labels_count = 500, max_bars_back = 500)

string familyFilter = input.string("All", "Setup family", options = ["All", "P0", "P1", "P2", "P3", "P4", "P5", "P6"], group = "1. Auto case filters")
string engineFilter = input.string("All", "Engine", options = ["All", "D", "ENS"], group = "1. Auto case filters")
string rankFilter = input.string("All", "Rank", options = ["All", "1", "2", "3"], group = "1. Auto case filters")
int watchDays = input.int(10, "Selection validity (trading sessions)", minval = 2, maxval = 10, group = "2. Setup rules")
bool fullTTL = input.bool(true, "Use all ten sessions (off = family TTL)", group = "2. Setup rules")
int holdDays = input.int(5, "Max holding sessions", minval = 1, maxval = 20, group = "3. Trade simulator")
string timeExit = input.string("CLOSE_5", "Exit fill", options = ["CLOSE_5", "OPEN_6"], group = "3. Trade simulator")
float riskPct = input.float(1.0, "Risk (% equity)", minval = 0.1, maxval = 5.0, step = 0.1, group = "3. Trade simulator")
float maxAlloc = input.float(6.67, "Max allocation (% equity)", minval = 0.1, maxval = 100.0, group = "3. Trade simulator")
bool useStop = input.bool(true, "Initial stop", group = "3. Trade simulator")
bool useTarget = input.bool(true, "R-multiple profit target", group = "3. Trade simulator")
bool showPickLabels = input.bool(true, "Labels: selection day", group = "4. Chart")
bool showTriggerLabels = input.bool(true, "Labels: independently qualified triggers", group = "4. Chart")
bool showNoTriggers = input.bool(false, "Labels: expired without trigger", group = "4. Chart")
bool showOldEntries = input.bool(false, "Markers: original journal buy dates", group = "4. Chart")
bool showOldExits = input.bool(false, "Markers: original journal exits (hindsight!)", group = "4. Chart")

// Every encoded row is: TICKER|SETUP,SELECTION,ENGINERANK,EVENT_AGE,OLD_BUY,OLD_EXIT;...
// The source ticker grouping is done OFFLINE. Only the current chart's cases are parsed.
var array<int> aPick = array.new_int()
var array<int> aSetup = array.new_int()
var array<string> aRank = array.new_string()
var array<int> aAge = array.new_int()
var array<int> aOldBuy = array.new_int()
var array<int> aOldExit = array.new_int()
var array<int> aStatus = array.new_int()       // 0 future; 1 armed; 2 triggered; 3 expired; 4 invalid
var array<int> aPickBar = array.new_int()
var array<float> aATR = array.new_float()
var array<float> aBaseHi = array.new_float()
var array<float> aBaseLo = array.new_float()
var array<float> aEventLo = array.new_float()
var array<float> aEventHi = array.new_float()
var array<bool> aCompressed = array.new_bool()
var array<bool> aTight = array.new_bool()

f_load(string pack) =>
    for tickerLine in str.split(pack, "\\n")
        array<string> fields = str.split(tickerLine, "|")
        if array.size(fields) == 2 and array.get(fields, 0) == syminfo.ticker
            for rec in str.split(array.get(fields, 1), ";")
                array<string> c = str.split(rec, ",")
                if array.size(c) == 6
                    string setup = array.get(c, 0)
                    string er = array.get(c, 2)
                    string eng = str.substring(er, 0, str.length(er) - 1)
                    string rn = str.substring(er, str.length(er) - 1, str.length(er))
                    bool included = (familyFilter == "All" or familyFilter == setup) and (engineFilter == "All" or engineFilter == eng) and (rankFilter == "All" or rankFilter == rn)
                    if included
                        array.push(aPick, int(str.tonumber(array.get(c, 1))))
                        array.push(aSetup, int(str.tonumber(str.substring(setup, 1, 2))))
                        array.push(aRank, er)
                        array.push(aAge, int(str.tonumber(array.get(c, 3))))
                        array.push(aOldBuy, int(str.tonumber(array.get(c, 4))))
                        array.push(aOldExit, int(str.tonumber(array.get(c, 5))))
                        array.push(aStatus, 0)
                        array.push(aPickBar, -1)
                        array.push(aATR, na)
                        array.push(aBaseHi, na)
                        array.push(aBaseLo, na)
                        array.push(aEventLo, na)
                        array.push(aEventHi, na)
                        array.push(aCompressed, false)
                        array.push(aTight, false)

'''

TAIL='''
// Computed on EVERY bar, before looping over cases, to avoid conditional-history inconsistencies.
float atr = ta.atr(14)
float atr5 = ta.atr(5)
float atr20 = ta.atr(20)
float vol20 = ta.sma(volume, 20)
float vol5 = ta.sma(volume, 5)
float ema20 = ta.ema(close, 20)
float ema50 = ta.ema(close, 50)
float priorLow20 = ta.lowest(low[1], 20)
float priorHigh20 = ta.highest(high[1], 20)
float baseHi7 = ta.highest(high, 7)
float baseLo7 = ta.lowest(low, 7)
float baseHi10 = ta.highest(high, 10)
float baseLo10 = ta.lowest(low, 10)
float low3 = ta.lowest(low, 3)
float fall3 = close[3] > 0 ? close / close[3] - 1.0 : na
float priceLocation = (close - low) / math.max(high - low, syminfo.mintick)
int today = year * 10000 + month * 100 + dayofmonth
bool ready = timeframe.isdaily and syminfo.prefix == "NSE"
var int nPick = 0
var int nTrigger = 0
var int nExpired = 0
var int nBlocked = 0
var float activeStop = na
var float activeTarget = na
var float activeR = na
var int fillBar = na
var bool orderPending = false
var int lastOrderBar = na
bool orderedThisBar = false
bool markedOldBuy = false
bool markedOldExit = false
bool inAnyWindow = false
float currentLevel = na
int n = array.size(aPick)
if ready and n > 0 and barstate.isconfirmed
    for i = 0 to n - 1
        int pickD = array.get(aPick, i)
        int family = array.get(aSetup, i)
        string er = array.get(aRank, i)
        int phase = array.get(aStatus, i)
        bool oldBuy = today == array.get(aOldBuy, i)
        bool oldExit = today == array.get(aOldExit, i)
        markedOldBuy := markedOldBuy or oldBuy
        markedOldExit := markedOldExit or oldExit
        if phase == 0 and today == pickD
            array.set(aStatus, i, 1)
            array.set(aPickBar, i, bar_index)
            array.set(aATR, i, atr)
            array.set(aBaseHi, i, family == 5 ? baseHi7 : baseHi10)
            array.set(aBaseLo, i, family == 5 ? baseLo7 : baseLo10)
            int age = array.get(aAge, i)
            // Selection-day event's pre-event 20d level. age is a known pick-time field.
            array.set(aEventLo, i, priorLow20[age])
            array.set(aEventHi, i, priorHigh20[age])
            array.set(aCompressed, i, atr20 > 0 and atr5 / atr20 <= 0.75 and close > ema50)
            float baseR7 = baseHi7 - baseLo7
            array.set(aTight, i, close > ema50 and (baseR7 <= 0.04 * close or baseR7 <= 1.50 * atr) and vol5 <= 0.80 * vol20)
            nPick += 1
            phase := 1
            if showPickLabels
                label.new(bar_index, high + (i % 4) * 0.15 * atr, "PICK P" + str.tostring(family) + " " + er, style = label.style_label_down, color = color.orange, textcolor = color.black, size = size.tiny)
        if phase == 1
            int sincePick = bar_index - array.get(aPickBar, i)
            int ttl = family == 0 ? 3 : family == 1 ? 2 : family == 2 ? 3 : family == 3 ? 5 : family == 4 or family == 5 ? 7 : 5
            int maxTrigger = fullTTL ? watchDays - 1 : math.min(watchDays - 1, ttl)
            if sincePick > maxTrigger
                array.set(aStatus, i, 3)
                nExpired += 1
                if showNoTriggers
                    label.new(bar_index, low, "NO TRIGGER P" + str.tostring(family) + " " + er, style = label.style_label_up, color = color.new(color.gray, 45), textcolor = color.white, size = size.tiny)
            else
                inAnyWindow := true
                float selATR = array.get(aATR, i)
                float hiBase = array.get(aBaseHi, i)
                float loBase = array.get(aBaseLo, i)
                float brokenLevel = array.get(aEventLo, i)
                float breakoutLevel = array.get(aEventHi, i)
                float proposedStop = na
                bool signal = false
                float rr = family == 0 ? 1.5 : family == 1 ? 2.0 : family == 2 ? 2.0 : family == 3 ? 2.0 : family == 4 ? 2.5 : family == 5 ? 2.0 : 1.75
                float riskMult = family == 0 ? 0.50 : family == 6 ? 0.60 : family == 5 ? 0.75 : 1.0
                if family == 0 and sincePick >= 1
                    signal := low < priorLow20 and close > priorLow20 and priceLocation >= 0.65 and volume >= 1.5 * vol20
                    proposedStop := low - 0.50 * atr
                else if family == 1
                    signal := low <= priorLow20 and volume >= 1.5 * vol20 and priceLocation >= 0.70
                    proposedStop := low - 0.50 * atr
                else if family == 2 and sincePick >= 1
                    signal := (low <= brokenLevel or close[1] < brokenLevel) and close > brokenLevel and close > open and priceLocation >= 0.60 and volume >= 1.2 * vol20
                    proposedStop := math.min(low, low3) - 0.25 * atr
                else if family == 3 and sincePick >= 1
                    bool approached = low <= breakoutLevel + 0.50 * selATR and high >= breakoutLevel - 0.50 * selATR
                    signal := approached and close > breakoutLevel and close > ema20 and priceLocation >= 0.60 and volume >= 1.1 * vol20
                    proposedStop := math.min(low - 0.10 * atr, breakoutLevel - 0.75 * selATR)
                else if family == 4 and sincePick >= 1
                    signal := array.get(aCompressed, i) and close > hiBase + 0.10 * selATR and volume >= 1.3 * vol20
                    proposedStop := math.min(loBase - 0.1 * atr, close - 1.50 * atr)
                else if family == 5 and sincePick >= 1
                    signal := array.get(aTight, i) and close > hiBase + 0.10 * selATR and volume >= 1.3 * vol20
                    proposedStop := math.min(loBase - 0.1 * atr, close - 1.50 * atr)
                else if family == 6
                    signal := fall3 <= -0.06 and low <= priorLow20 and volume >= 1.5 * vol20 and priceLocation >= 0.60
                    proposedStop := low - 0.50 * atr
                if family == 2
                    currentLevel := brokenLevel
                else if family == 3
                    currentLevel := breakoutLevel
                else if family == 4 or family == 5
                    currentLevel := hiBase
                if signal and not na(proposedStop) and proposedStop < close and close > 0
                    array.set(aStatus, i, 2)
                    nTrigger += 1
                    string caseId = "P" + str.tostring(family) + "|" + er + "|" + str.tostring(pickD)
                    bool canOrder = not orderedThisBar and not orderPending and strategy.position_size == 0
                    if showTriggerLabels
                        label.new(bar_index, low - (i % 4) * 0.15 * atr, (canOrder ? "TRIGGER + ORDER " : "TRIGGER / BLOCKED ") + caseId, style = label.style_label_up, color = canOrder ? color.aqua : color.new(color.teal, 55), textcolor = color.black, size = size.tiny)
                    if canOrder
                        float riskPerShare = close - proposedStop
                        float byRisk = strategy.equity * (riskPct / 100.0) * riskMult / riskPerShare
                        float byCash = strategy.equity * (maxAlloc / 100.0) / close
                        float qty = math.floor(math.min(byRisk, byCash))
                        if qty >= 1
                            activeStop := proposedStop
                            activeR := rr
                            activeTarget := close + rr * riskPerShare
                            strategy.entry("AUTO", strategy.long, qty = qty, comment = caseId)
                            if useStop or useTarget
                                strategy.exit("AUTO SL/TP", from_entry = "AUTO", stop = useStop ? activeStop : na, limit = useTarget ? activeTarget : na)
                            orderedThisBar := true
                            orderPending := true
                            lastOrderBar := bar_index
                            alert("BigMove AUTO " + caseId + " " + syminfo.ticker, alert.freq_once_per_bar_close)
                    if not canOrder
                        nBlocked += 1

// Market entry normally fills next daily OPEN; the signal itself is recorded at close.
if strategy.position_size > 0 and strategy.position_size[1] == 0
    fillBar := bar_index
    orderPending := false
    if not na(activeStop) and not na(activeR)
        activeTarget := strategy.position_avg_price + activeR * (strategy.position_avg_price - activeStop)
if strategy.position_size > 0
    if useStop or useTarget
        strategy.exit("AUTO SL/TP", from_entry = "AUTO", stop = useStop ? activeStop : na, limit = useTarget ? activeTarget : na)
    int barsHeld = na(fillBar) ? 0 : bar_index - fillBar + 1
    if barsHeld >= holdDays and barstate.isconfirmed
        strategy.close("AUTO", comment = timeExit, immediately = timeExit == "CLOSE_5")
// A gap through both entry and stop can open+close within one simulated bar.
// Clear pending status even if end-of-bar position size is already zero.
if orderPending and not na(lastOrderBar) and bar_index > lastOrderBar and strategy.position_size == 0
    orderPending := false
if strategy.position_size == 0 and strategy.position_size[1] > 0
    fillBar := na
    activeStop := na
    activeTarget := na
    activeR := na

bgcolor(inAnyWindow ? color.new(color.yellow, 92) : na, title = "Eligible watchlist windows")
plotshape(showOldEntries and markedOldBuy, title = "Journal original buy", style = shape.circle, location = location.belowbar, color = color.orange, size = size.tiny, text = "OLD BUY")
plotshape(showOldExits and markedOldExit, title = "Journal original exit (future-known marker)", style = shape.circle, location = location.abovebar, color = color.purple, size = size.tiny, text = "OLD SELL")
plot(strategy.position_size > 0 ? activeStop : na, "Stop", color = color.red, style = plot.style_linebr)
plot(strategy.position_size > 0 ? activeTarget : na, "Target", color = color.green, style = plot.style_linebr)
plot(inAnyWindow ? currentLevel : na, "Frozen base or event level", color = color.blue, style = plot.style_linebr)

var table status = table.new(position.top_right, 2, 8, border_width = 1)
if barstate.islast
    table.cell(status, 0, 0, "AUTO JOURNAL REGISTRY", text_color = color.white, bgcolor = color.new(color.blue, 30))
    table.cell(status, 1, 0, syminfo.ticker, text_color = color.white, bgcolor = color.new(color.blue, 30))
    table.cell(status, 0, 1, "Mapping / data")
    table.cell(status, 1, 1, not ready ? "REQUIRES NSE 1D" : n == 0 ? "NO MATCHING CASES" : "AUTO MATCHED " + str.tostring(n), bgcolor = not ready or n == 0 ? color.new(color.red, 45) : color.new(color.green, 70))
    table.cell(status, 0, 2, "Setup / engine / rank")
    table.cell(status, 1, 2, familyFilter + " / " + engineFilter + " / " + rankFilter)
    table.cell(status, 0, 3, "Historical picks seen")
    table.cell(status, 1, 3, str.tostring(nPick) + " of " + str.tostring(n))
    table.cell(status, 0, 4, "Triggered cases")
    table.cell(status, 1, 4, str.tostring(nTrigger))
    table.cell(status, 0, 5, "No trigger (expired)")
    table.cell(status, 1, 5, str.tostring(nExpired))
    table.cell(status, 0, 6, "Orders blocked by overlap")
    table.cell(status, 1, 6, str.tostring(nBlocked))
    table.cell(status, 0, 7, "Strategy positions")
    table.cell(status, 1, 7, str.tostring(strategy.closedtrades) + " closed | " + str.tostring(strategy.opentrades) + " open")
// CAUTION: Strategy Tester cannot represent every overlapping independent candidate.
// Use ALL TRIGGER labels to audit each case; no-trigger candidates count in opportunity denominator.
// Not TradingView compiler-verified. Chart replay can display fewer bars than full journal.
'''

def pack_calls(packs):
    return 'if barstate.isfirst\n'+''.join('    f_load('+quote(pack)+')\n' for pack in packs)+'\n'

universal=HEAD+pack_calls(packs)+TAIL
(ROOT:=BASE/'scripts').mkdir(parents=True,exist_ok=True)
file=ROOT/'BigMove_AUTO_All_Tickers_P0_P6_v3.pine'
file.write_text(universal,encoding='utf-8')

# One compact ticker-specific auto-loading strategy for each of the 467 eligible tickers.
# Small scripts are easier to paste into TradingView and may compile faster than universal.
for ticker, recs in by.items():
    tpack=ticker+'|'+ ';'.join(recs)
    safe=re.sub(r'[^A-Z0-9_-]','_',ticker)
    customHead=HEAD.replace("BigMove | Auto Registry P0-P6 | v3", "BigMove | "+ticker+" AUTO | v3")
    (BASE/'ticker_scripts'/f'BigMove_{safe}_AUTO_v3.pine').write_text(customHead+pack_calls([tpack])+TAIL,encoding='utf-8')

# Full 9,930 picks CSV gives an overlay for 1,064 symbols including those without a category.
# Encode at most two strings per journal trade: day, engine/rank, bitmask eligibility.
allby=collections.defaultdict(list)
member_cases=collections.defaultdict(int)
for r in members: member_cases[r['trade_id']]|=1<<int(r['setup_id'][1])
for r in top:
    t=r['tradingview_symbol_suggestion'][4:]
    record=f"{ndate(r['selection_date'])},{r['engine']}{r['rank']},{member_cases[r['trade_id']]}"
    allby[t].append(record)
assert len(allby)==1064
assert sum(map(len,allby.values()))==9930

# Build full-selection date-overlay, not a simulator. Symbol switch auto works everywhere.
selectionLines=[t+'|'+ ';'.join(rows) for t,rows in sorted(allby.items())]
sPacks=[];cur=[];size=0
for line in selectionLines:
    if cur and size+len(line)+1>6500:
        sPacks.append('\n'.join(cur));cur=[];size=0
    cur.append(line);size+=len(line)+1
if cur:sPacks.append('\n'.join(cur))
OHEAD='''//@version=6
// BigMove history: ALL 9,930 top-3 selections, 2020-01 through 2026-09.
// Uses journal selection-day dates, engines, ranks, 7-setup membership bitmask.
// No outcomes embedded, no new profit assumptions; plotting only.
indicator("BigMove | Full Top3 Journal | Auto Overlay v3", overlay = true, max_labels_count = 500)
string filterFamily = input.string("All", "Show family", options = ["All", "P0", "P1", "P2", "P3", "P4", "P5", "P6", "Unmatched"], group = "Selection filters")
string filterEngine = input.string("All", "Engine", options = ["All", "D", "ENS"], group = "Selection filters")
bool showLabels = input.bool(true, "Show PICK label", group = "Display")
var array<int> pDates = array.new_int()
var array<string> pRanks = array.new_string()
var array<int> pMasks = array.new_int()
f_load(string chunk) =>
    for tickerLine in str.split(chunk, "\\n")
        array<string> v = str.split(tickerLine, "|")
        if array.size(v) == 2 and array.get(v, 0) == syminfo.ticker
            for record in str.split(array.get(v, 1), ";")
                array<string> r = str.split(record, ",")
                if array.size(r) == 3
                    string er = array.get(r, 1)
                    bool keepEngine = filterEngine == "All" or (filterEngine == "D" and str.substring(er, 0, 1) == "D") or (filterEngine == "ENS" and str.substring(er, 0, 3) == "ENS")
                    int mask = int(str.tonumber(array.get(r, 2)))
                    int req = filterFamily == "P0" ? 1 : filterFamily == "P1" ? 2 : filterFamily == "P2" ? 4 : filterFamily == "P3" ? 8 : filterFamily == "P4" ? 16 : filterFamily == "P5" ? 32 : filterFamily == "P6" ? 64 : 0
                    bool keepFamily = filterFamily == "All" or (filterFamily == "Unmatched" and mask == 0) or (req > 0 and int(math.floor(mask / req)) % 2 == 1)
                    if keepEngine and keepFamily
                        array.push(pDates, int(str.tonumber(array.get(r, 0))))
                        array.push(pRanks, er)
                        array.push(pMasks, mask)
'''
OTAIL='''
float plotATR = ta.atr(14)
int today = year * 10000 + month * 100 + dayofmonth
var int seen = 0
bool marker = false
if timeframe.isdaily and syminfo.prefix == "NSE" and barstate.isconfirmed and array.size(pDates) > 0
    for i = 0 to array.size(pDates) - 1
        if today == array.get(pDates, i)
            seen += 1
            marker := true
            int mask = array.get(pMasks, i)
            string labelText = array.get(pRanks, i) + (mask == 0 ? " OTHER" : " ELIGIBLE")
            if showLabels
                label.new(bar_index, high + (i % 3) * 0.2 * plotATR, labelText, color = mask == 0 ? color.new(color.gray, 40) : color.orange, textcolor = color.black, style = label.style_label_down, size = size.tiny)
plotshape(marker, title = "Top3 selection", location = location.abovebar, style = shape.flag, color = color.yellow, size = size.tiny, text = "TOP3")
var table t = table.new(position.top_right, 2, 4)
if barstate.islast
    table.cell(t,0,0,"JOURNAL AUTO OVERLAY")
    table.cell(t,1,0,syminfo.ticker)
    table.cell(t,0,1,"Mapped picks in journal")
    table.cell(t,1,1,str.tostring(array.size(pDates)))
    table.cell(t,0,2,"Picks on loaded chart")
    table.cell(t,1,2,str.tostring(seen))
    table.cell(t,0,3,"Status")
    table.cell(t,1,3,not timeframe.isdaily ? "USE 1D" : array.size(pDates) == 0 ? "NO SELECTIONS" : "AUTO MATCHED")
'''
overlay=OHEAD+pack_calls(sPacks)+OTAIL
(ROOT/'BigMove_AUTO_All_9930_Top3_Picks_Overlay_v3.pine').write_text(overlay,encoding='utf-8')

# Lean lookup and index, never contains future outcome data.
idx=[]
for ticker,cases in by.items():
    cnt=collections.Counter(x.split(',')[0] for x in cases)
    idx.append(dict(ticker=ticker,tradingview_symbol='NSE:'+ticker,setup_case_count=len(cases),**{f'P{x}':cnt.get(f'P{x}',0) for x in range(7)},file=f'ticker_scripts/BigMove_{re.sub(r"[^A-Z0-9_-]","_",ticker)}_AUTO_v3.pine'))
with (BASE/'registry'/'ticker_index.csv').open('w',newline='',encoding='utf-8') as f:
    fields=['ticker','tradingview_symbol','setup_case_count']+[f'P{x}' for x in range(7)]+['file']
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(idx)
with (BASE/'registry'/'all_eligible_setup_cases_blind.csv').open('w',newline='',encoding='utf-8') as f:
    flds=['setup_id','selection_date','engine','rank','journal_symbol','tradingview_symbol_suggestion','primary_stock_state_at_pick','stock_event_at_pick','market_environment_at_pick','market_breadth_10day_at_pick','vix_5day_change_at_pick_pct','journal_buy_date','journal_exit_date']
    w=csv.DictWriter(f,fieldnames=flds);w.writeheader();w.writerows([{k:r[k] for k in flds} for r in members])

# Verify every serialized record recovers exact original field set, no omissions or duplication.
def parse(packs):
    out=collections.defaultdict(list)
    for p in packs:
        for line in p.split('\n'):
            t,records=line.split('|',1)
            out[t].extend(records.split(';'))
    return dict(out)
assert parse(packs)==by
assert sum(len(x.split(';')) for p in sPacks for x in [line.split('|',1)[1] for line in p.split('\n')])==9930
check=collections.Counter(r['setup_id'] for r in members)
summary=dict(source_membership_sha256=hashlib.sha256(MEM.read_bytes()).hexdigest(),source_top3_sha256=hashlib.sha256(TOP.read_bytes()).hexdigest(),
             eligible_cases=len(members),eligible_unique_trades=len({r['trade_id'] for r in members}),eligible_tickers=len(by),
             top3_trades=len(top),top3_tickers=len(allby),setup_counts=dict(sorted(check.items())),
             overlapping_case_count=sum(len(v) for v in by.values())-len({r['trade_id'] for r in members}),
             total_packs=len(packs),overlay_packs=len(sPacks),max_ticker_cases=max(map(len,by.values())),
             most_relevant_niitltd_cases=by.get('NIITLTD',[]),
             universal_pine_bytes=file.stat().st_size,overlay_pine_bytes=(ROOT/'BigMove_AUTO_All_9930_Top3_Picks_Overlay_v3.pine').stat().st_size,
             derived_only_no_production_modification=True,compile_status='NOT_COMPILED_IN_TRADINGVIEW')
(BASE/'qa'/'verification.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')

# Library zip built after verifying all file references and source hashes.
print(json.dumps(summary,indent=2))
