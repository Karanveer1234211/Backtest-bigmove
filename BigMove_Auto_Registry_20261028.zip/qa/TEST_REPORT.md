# BigMove auto-registry QA — 2026-10-28

## Checks completed

- All **33,100** original raw `Picks` sheet selection rows re-read from the separately extracted journal CSV (date, engine, rank, symbol).
- All **9,930** journal ranks 1–3 match the prior full-history mapped source by **date × engine × rank × original symbol**, with **zero missing/extra keys**.
- All **1,583** P0–P6 memberships are serialized into the auto-registry exactly once, over **467 chart symbols**. This is **1,448 distinct original selections**: 135 duplicate memberships reflect legitimate overlapping setup labels.
- The full-history overlay embeds **all 9,930 top-3 selections** over **1,064 symbols**, including **8,482 category-unmatched original top-3 trades**.
- Source membership and complete top-3 CSV hashes recorded in `verification.json`.
- The `NSE:NIITLTD` test registry contains exactly two P0 selections: 2022-01-24 D3 and 2026-03-25 ENS3.
- Filtering uses chart `syminfo.ticker` rather than a manually entered `pine_case_key`. Setup family, engine and rank remain independently configurable through TradingView Inputs.
- New strategy uses original P0–P6 trigger hypothesis rules, reads only selection-date-state data and confirmed OHLCV bars, and maintains a status separately for each mapped case.
- Every *trigger* is recorded as an independent case even where the single net position prevents a separate Strategy Tester trade; a blocked case cannot count as a simulated fill.
- Late (T+10) signal fills that would occur at T+11 are excluded from the 10-session window.
- No user uploads, frozen models, declarations, production scripts or source CSVs modified.

## Not verified

**Pine Script was not compiled or executed inside TradingView**. The connected TradingView tools offer price/history lookup but no Pine Editor compile/install action. TradingView strategy order simulation, gap stops, circuit restrictions and intraday same-bar SL/TP ordering require your replay checks. Treat outcomes as unvalidated until that verification is performed.

Historical ticker renames other than the previously researched `HEG`→`HEGAM` alias may prevent chart matches. Unavailable history or splits may also change the behavior relative to original journal.
