@echo off
rem run_watch.bat - tradelab v1.3: tonight's watchlist page - market context, every stock's state, pick_meta's
rem numbers and the Soul cards on one page. Double-click after Run Now and run_pick_meta.bat, before 09:00.
rem Reads production READ ONLY (paper ledger, pick_meta cards, paper watchlist, cache); writes only under
rem TRADELAB_OUT\watch. Extra arguments pass through, e.g.  run_watch.bat --date 2026-10-23 --force
call "%~dp0env_tradelab.bat"
if errorlevel 1 goto :failed
python tl_watch.py --root "%CACHE_DAILY_ROOT%" %*
if errorlevel 1 goto :failed
for /f "delims=" %%F in ('dir /b /o-d "%TRADELAB_OUT%\watch\WATCH_*.html" 2^>nul') do (
    start "" "%TRADELAB_OUT%\watch\%%F"
    goto :opened
)
:opened
echo RESULT: OK
pause
goto :eof
:failed
echo RESULT: FAILED - read the lines above
pause
exit /b 1
