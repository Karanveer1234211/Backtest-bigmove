# pathlab coverage audit (pl_coverage v1.0)

Counts only: nothing after T0 is read. Effective n = what a group's rows are worth in independent observations, from the date-block bootstrap of the move over the five sessions up to T0 (known at T0).

- Eligible rows: equities 1,457,693, ETFs 17,297; cash-like rows removed 1,391; under 60 sessions of bars 0.
- ETFs: 61 by NSE's ETF list C:\QuantData\pathlab\ref\eq_etfseclist.csv (355 names, 61 of them in the panel) plus the name rule (BEES / ETF / IETF endings: ETFs the cache holds under an older name) (full list: etf_list.csv).
- Survivorship: 0 of 1,436 stocks stop trading before the last window ends (delisted, suspended, or renamed on NSE - a symbol change shows as one name stopping and another starting; kept, listed in stocks.csv); 439 list after 2019. Stocks delisted before the cache was built are absent and cannot be counted from this data.

## Market dates per regime (equities)

| window | Broad bullish | Narrow bullish | Mixed | Broad bearish | High stress |
|---|---|---|---|---|---|
| train 2020-2022 | 262 | 211 | 100 | 69 | 106 |
| train 2020-2023 | 362 | 260 | 128 | 123 | 121 |
| train 2020-2024 | 431 | 324 | 156 | 147 | 185 |
| validate 2023 | 100 | 49 | 28 | 54 | 15 |
| validate 2024 | 69 | 64 | 28 | 24 | 64 |
| validate 2025 | 57 | 90 | 12 | 69 | 21 |
| validate 2023-2025 | 226 | 203 | 68 | 147 | 100 |
| development 2020-2025 | 488 | 414 | 168 | 216 | 206 |
| final 2026 | 31 | 36 | 51 | 19 | 37 |
| all 2020-2026 | 519 | 450 | 219 | 235 | 243 |
| year 2020 | 93 | 67 | 27 | 13 | 52 |
| year 2021 | 96 | 85 | 42 | 13 | 12 |
| year 2022 | 73 | 59 | 31 | 43 | 42 |
| year 2023 | 100 | 49 | 28 | 54 | 15 |
| year 2024 | 69 | 64 | 28 | 24 | 64 |
| year 2025 | 57 | 90 | 12 | 69 | 21 |
| year 2026 | 31 | 36 | 51 | 19 | 37 |

## State x regime cells meeting candidate minimums (of 45, equities)

| window | 50 dates, 250 rows, 8 stretches | 100 dates, 500 rows, 10 stretches | 200 dates, 1,000 rows |
|---|---|---|---|
| train 2020-2022 | 40 | 28 | 15 |
| train 2020-2023 | 40 | 40 | 16 |
| train 2020-2024 | 41 | 40 | 16 |
| validate 2023 | 16 | 8 | 0 |
| validate 2024 | 24 | 0 | 0 |
| validate 2025 | 24 | 0 | 0 |
| validate 2023-2025 | 40 | 30 | 16 |
| development 2020-2025 | 41 | 40 | 31 |
| final 2026 | 8 | 0 | 0 |
| all 2020-2026 | 41 | 41 | 40 |
| year 2020 | 20 | 0 | 0 |
| year 2021 | 16 | 0 | 0 |
| year 2022 | 16 | 0 | 0 |
| year 2023 | 16 | 8 | 0 |
| year 2024 | 24 | 0 | 0 |
| year 2025 | 24 | 0 | 0 |
| year 2026 | 8 | 0 | 0 |

## train 2020-2022: dates / rows / effective n per cell (equities)

| state | Broad bullish | Narrow bullish | Mixed | Broad bearish | High stress |
|---|---|---|---|---|---|
| S01 Strong bull | 262 / 19,827 / 1,897 | 211 / 16,272 / 500 | 100 / 3,925 / 132 | 69 / 1,678 / 87 | 92 / 2,899 / 121 |
| S02 Emerging bull | 262 / 37,113 / 1,163 | 211 / 17,707 / 495 | 100 / 6,465 / 131 | 69 / 3,237 / 89 | 100 / 4,407 / 54 |
| S03 Bull consolidation | 262 / 15,776 / 1,653 | 211 / 18,586 / 419 | 95 / 5,107 / 117 | 69 / 2,086 / 84 | 103 / 3,610 / 87 |
| S06 Reversal attempt | 255 / 16,635 / 181 | 205 / 7,053 / 169 | 99 / 5,135 / 57 | 69 / 4,243 / 49 | 101 / 3,798 / 21 |
| S07 Neutral range | 262 / 28,662 / 729 | 211 / 26,753 / 325 | 100 / 13,491 / 107 | 69 / 8,769 / 71 | 106 / 9,339 / 57 |
| S08 Bear continuation | 238 / 3,311 / 119 | 197 / 4,361 / 255 | 99 / 3,905 / 100 | 69 / 4,185 / 46 | 105 / 7,462 / 22 |
| S09 Emerging bear | 262 / 10,973 / 373 | 211 / 24,318 / 282 | 100 / 14,571 / 92 | 69 / 14,968 / 58 | 106 / 22,244 / 45 |
| S12 Unstable | 12 / 12 / 7 | 20 / 23 / 8 | 20 / 22 / 7 | 24 / 42 / 9 | 60 / 158 / 10 |
| UNKNOWN Unknown | 262 / 45,785 / 1,241 | 211 / 37,073 / 618 | 100 / 16,697 / 168 | 69 / 11,365 / 82 | 106 / 15,355 / 70 |

## validate 2023-2025: dates / rows / effective n per cell (equities)

| state | Broad bullish | Narrow bullish | Mixed | Broad bearish | High stress |
|---|---|---|---|---|---|
| S01 Strong bull | 226 / 20,995 / 1,364 | 203 / 17,973 / 615 | 68 / 3,806 / 166 | 147 / 3,933 / 288 | 99 / 8,648 / 161 |
| S02 Emerging bull | 226 / 39,302 / 753 | 203 / 25,536 / 445 | 68 / 5,324 / 108 | 147 / 7,936 / 166 | 100 / 10,404 / 269 |
| S03 Bull consolidation | 226 / 20,074 / 869 | 203 / 20,242 / 935 | 68 / 4,909 / 199 | 147 / 6,274 / 223 | 98 / 7,553 / 130 |
| S06 Reversal attempt | 226 / 25,049 / 163 | 203 / 11,995 / 320 | 68 / 4,743 / 30 | 147 / 7,620 / 108 | 100 / 5,667 / 121 |
| S07 Neutral range | 226 / 39,216 / 249 | 203 / 34,452 / 451 | 68 / 14,360 / 86 | 147 / 23,269 / 221 | 100 / 19,601 / 104 |
| S08 Bear continuation | 226 / 5,755 / 87 | 203 / 10,474 / 93 | 68 / 5,526 / 83 | 147 / 18,677 / 121 | 100 / 5,275 / 94 |
| S09 Emerging bear | 226 / 16,800 / 281 | 203 / 37,179 / 220 | 68 / 12,034 / 109 | 147 / 43,696 / 203 | 100 / 21,749 / 104 |
| S12 Unstable | 68 / 130 / 24 | 69 / 113 / 47 | 24 / 31 / 13 | 74 / 161 / 65 | 70 / 231 / 32 |
| UNKNOWN Unknown | 226 / 57,448 / 649 | 203 / 50,280 / 616 | 68 / 17,628 / 127 | 147 / 31,492 / 197 | 100 / 23,852 / 131 |

## final 2026: dates / rows / effective n per cell (equities)

| state | Broad bullish | Narrow bullish | Mixed | Broad bearish | High stress |
|---|---|---|---|---|---|
| S01 Strong bull | 31 / 2,014 / 290 | 36 / 2,809 / 338 | 51 / 2,848 / 581 | 19 / 438 / 73 | 37 / 853 / 146 |
| S02 Emerging bull | 31 / 5,670 / 265 | 36 / 5,513 / 170 | 51 / 7,826 / 121 | 19 / 1,505 / 38 | 37 / 3,052 / 56 |
| S03 Bull consolidation | 31 / 2,604 / 86 | 36 / 3,800 / 228 | 51 / 3,259 / 443 | 19 / 486 / 41 | 37 / 1,066 / 35 |
| S06 Reversal attempt | 31 / 4,671 / 219 | 36 / 2,711 / 163 | 51 / 7,816 / 21 | 19 / 2,140 / 27 | 37 / 4,158 / 18 |
| S07 Neutral range | 31 / 6,567 / 65 | 36 / 7,840 / 200 | 51 / 9,709 / 83 | 19 / 3,123 / 29 | 37 / 4,978 / 25 |
| S08 Bear continuation | 31 / 1,302 / 63 | 36 / 1,558 / 134 | 51 / 2,758 / 34 | 19 / 2,297 / 18 | 37 / 5,936 / 18 |
| S09 Emerging bear | 31 / 3,817 / 28 | 36 / 6,908 / 149 | 51 / 9,664 / 155 | 19 / 4,648 / 17 | 37 / 9,841 / 27 |
| S12 Unstable | 11 / 28 / 6 | 21 / 28 / 8 | 26 / 77 / 23 | 8 / 20 / 3 | 30 / 117 / 29 |
| UNKNOWN Unknown | 31 / 7,862 / 156 | 36 / 9,389 / 391 | 51 / 12,763 / 112 | 19 / 5,047 / 22 | 37 / 9,362 / 30 |

## all 2020-2026: dates / rows / effective n per cell (equities)

| state | Broad bullish | Narrow bullish | Mixed | Broad bearish | High stress |
|---|---|---|---|---|---|
| S01 Strong bull | 519 / 42,836 / 3,292 | 450 / 37,054 / 1,397 | 219 / 10,579 / 515 | 235 / 6,049 / 304 | 228 / 12,400 / 246 |
| S02 Emerging bull | 519 / 82,085 / 2,272 | 450 / 48,756 / 1,098 | 219 / 19,615 / 378 | 235 / 12,678 / 246 | 237 / 17,863 / 385 |
| S03 Bull consolidation | 519 / 38,454 / 2,131 | 450 / 42,628 / 1,473 | 214 / 13,275 / 478 | 235 / 8,846 / 329 | 238 / 12,229 / 276 |
| S06 Reversal attempt | 512 / 46,355 / 436 | 444 / 21,759 / 639 | 218 / 17,694 / 61 | 235 / 14,003 / 152 | 238 / 13,623 / 73 |
| S07 Neutral range | 519 / 74,445 / 653 | 450 / 69,045 / 1,012 | 219 / 37,560 / 263 | 235 / 35,161 / 295 | 243 / 33,918 / 216 |
| S08 Bear continuation | 495 / 10,368 / 230 | 436 / 16,393 / 224 | 218 / 12,189 / 177 | 235 / 25,159 / 180 | 242 / 18,673 / 71 |
| S09 Emerging bear | 519 / 31,590 / 502 | 450 / 68,405 / 564 | 219 / 36,269 / 262 | 235 / 63,312 / 263 | 243 / 53,834 / 143 |
| S12 Unstable | 91 / 170 / 30 | 110 / 164 / 74 | 70 / 130 / 45 | 106 / 223 / 102 | 160 / 506 / 55 |
| UNKNOWN Unknown | 519 / 111,095 / 1,592 | 450 / 96,742 / 1,547 | 219 / 47,088 / 416 | 235 / 47,904 / 278 | 243 / 48,569 / 254 |

Full tables: coverage_groups.csv (every window x universe x group), regime_days.csv, cells_meeting_minimums.csv, stocks.csv, etf_list.csv.
