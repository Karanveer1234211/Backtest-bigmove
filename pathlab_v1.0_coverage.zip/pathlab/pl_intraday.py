"""
pl_intraday.py - pathlab v1.0: one stock's 3-minute bars as dense session x 125 arrays.

The usable-session test is tradelab's (tl_data.IntradayStore._judge), applied to every session at once:
  at least 80% of the 125 bars, a 09:15 bar, every price present, and the first open / the highest high / the
  lowest low within 0.5% of the daily bar. Bars are read the way tradelab reads them (IST stamps, bar k starts at
  09:15 + 3k, off-grid stamps dropped, a repeated stamp keeps its last row). tests/test_pathlab.py checks this
  reader against tradelab's own on the same files, session by session.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd

NB = 125
BAR_MIN = 3
SESSION_START_MIN = 9 * 60 + 15
USABLE_SHARE = 0.80
PRICE_TOL = 0.005
IST = "Asia/Kolkata"

REASONS = ("ok", "under 80% of bars", "no 09:15 bar", "missing prices", "no daily bar that day",
           "first open off the daily bar by > 0.5%", "first high off the daily bar by > 0.5%",
           "first low off the daily bar by > 0.5%")


class Dense:
    """days (datetime64[D]) x 125 bars: O, H, L, C, V (NaN where a bar is missing), present, usable, reason code."""

    def __init__(self, days, O, H, L, C, V, present, usable, reason):
        self.days, self.O, self.H, self.L, self.C, self.V = days, O, H, L, C, V
        self.present, self.usable, self.reason = present, usable, reason
        self.pos = {d: i for i, d in enumerate(days.tolist())}

    def __len__(self) -> int:
        return len(self.days)

    def reasons(self) -> Dict[str, int]:
        u, c = np.unique(self.reason, return_counts=True)
        return {REASONS[int(k)]: int(v) for k, v in zip(u, c)}


def empty() -> Dense:
    z = np.zeros((0, NB))
    return Dense(np.array([], dtype="datetime64[D]"), z, z, z, z, z, z.astype(bool), np.zeros(0, bool),
                 np.zeros(0, np.int8))


def read_dense(path: Path, ddates: np.ndarray, do: np.ndarray, dh: np.ndarray, dl: np.ndarray,
               d_from: Optional[np.datetime64] = None, d_to: Optional[np.datetime64] = None) -> Dense:
    """ddates / do / dh / dl: the stock's daily bars (tradelab DailySeries) for the price check."""
    try:
        df = pd.read_parquet(path, columns=["timestamp", "open", "high", "low", "close", "volume"])
    except Exception:  # noqa: BLE001 - an unreadable file is an absent file (counted by the caller)
        return empty()
    if df.empty:
        return empty()
    ts = pd.to_datetime(df["timestamp"])
    if getattr(ts.dt, "tz", None) is not None:
        ts = ts.dt.tz_convert(IST).dt.tz_localize(None)
    t = ts.to_numpy(dtype="datetime64[ns]")
    dayv = t.astype("datetime64[D]")
    keep = np.ones(len(t), bool)
    if d_from is not None:
        keep &= dayv >= np.datetime64(d_from, "D")
    if d_to is not None:
        keep &= dayv <= np.datetime64(d_to, "D")
    mins = (t - dayv.astype("datetime64[ns]")).astype("timedelta64[s]").astype(np.int64) / 60.0 - SESSION_START_MIN
    slot = mins / BAR_MIN
    keep &= (slot >= -1e-9) & (slot <= NB - 1 + 1e-9) & (np.abs(slot - np.round(slot)) < 1e-6)
    if not keep.any():
        return empty()
    cols = {k: pd.to_numeric(df[k], errors="coerce").to_numpy(float)[keep] for k in ("open", "high", "low", "close", "volume")}
    dd = dayv[keep]
    sl = np.round(slot[keep]).astype(np.int64)
    udays, di = np.unique(dd, return_inverse=True)
    key = di.astype(np.int64) * NB + sl
    order = np.argsort(key, kind="stable")
    ks = key[order]
    lastmask = np.r_[ks[1:] != ks[:-1], True]           # a repeated (day, bar) keeps its last row (tradelab)
    sel = order[lastmask]
    nd = len(udays)
    O = np.full(nd * NB, np.nan)
    H, L, C, V = O.copy(), O.copy(), O.copy(), O.copy()
    present = np.zeros(nd * NB, bool)
    k = key[sel]
    O[k], H[k], L[k], C[k] = cols["open"][sel], cols["high"][sel], cols["low"][sel], cols["close"][sel]
    V[k] = np.nan_to_num(cols["volume"][sel])
    present[k] = True
    O, H, L, C, V, present = (x.reshape(nd, NB) for x in (O, H, L, C, V, present))
    # the usable-session test, in tradelab's order
    reason = np.zeros(nd, np.int8)
    cnt = present.sum(axis=1)
    r1 = cnt < USABLE_SHARE * NB
    r2 = ~r1 & ~present[:, 0]
    bad = np.zeros(nd, bool)
    for X in (O, H, L, C):
        bad |= (present & ~np.isfinite(X)).any(axis=1)
    r3 = ~r1 & ~r2 & bad
    reason[r1], reason[r2], reason[r3] = 1, 2, 3
    pending = reason == 0
    j = np.searchsorted(ddates, udays)
    has = j < len(ddates)
    has[has] = ddates[j[has]] == udays[has]
    r4 = pending & ~has
    reason[r4] = 4
    pending &= has
    jj = np.where(has, j, 0)
    with np.errstate(invalid="ignore", divide="ignore"):
        hmax = np.where(present, H, -np.inf).max(axis=1)
        lmin = np.where(present, L, np.inf).min(axis=1)
        for code, got, ref in ((5, O[:, 0], do[jj]), (6, hmax, dh[jj]), (7, lmin, dl[jj])):
            okp = np.isfinite(ref) & (ref > 0) & (np.abs(got / np.where(ref > 0, ref, 1.0) - 1) <= PRICE_TOL)
            fail = pending & ~okp
            reason[fail] = code
            pending &= ~fail
    usable = reason == 0
    return Dense(udays, O, H, L, C, V, present, usable, reason)
