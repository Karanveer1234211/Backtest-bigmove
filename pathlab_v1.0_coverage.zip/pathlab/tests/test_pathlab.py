"""
tests/test_pathlab.py - pathlab v1.0's tests. Run from the pathlab folder after env_pathlab.bat:

    python tests\\test_pathlab.py            all tests (about 10-15 minutes)
    python tests\\test_pathlab.py quick      the fast ones only (about 2 minutes)

Every test builds its own synthetic world in a temporary folder; nothing touches the cache, tradelab, bigmove_deploy
or PATHLAB_OUT. Ends with "ALL n TESTS PASSED" or lists the failures (exit code 1). It also writes
fingerprint.json beside itself: key results rounded to 1e-9, so two library sets can be compared file to file.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PL = HERE.parent
for p in (str(PL), str(HERE)):
    if p not in sys.path:
        sys.path.insert(0, p)
for k in ("TRADELAB_OUT", "PATHLAB_OUT"):          # never read Karan's real saved breadth or outputs in a test
    os.environ.pop(k, None)

import pl_world as W                                # noqa: E402  (finds tradelab and its stand-in modules)
import tl_world as TW                               # noqa: E402
import pl_common as PC                              # noqa: E402
import pl_paths as PP                               # noqa: E402

RESULTS = []
FINGER = {}
TMP = Path(tempfile.mkdtemp(prefix="pathlab_tests_"))
CACHE_WORLD = None


def test(fn):
    RESULTS.append(fn)
    return fn


def decl_for_tests(**fam) -> Path:
    """The shipped declaration with the test world's inputs and lighter compute settings (same code paths)."""
    D = json.loads((PL / "PATHLAB_DECLARATION.json").read_text(encoding="utf-8"))
    D["inputs"]["picks_run"] = "PM_TEST_001"
    D["inputs"]["tlx_export"] = "TLX_TEST_001"
    D["families"].update({"stability_refits": 6, "n_init": 2, "k_max": 8, "stability_sample": 60000})
    D["families"].update(fam)
    D["atlas"].update({"boot_B": 300, "mi_permutations": 40})
    p = TMP / f"decl_{hashlib.sha256(json.dumps(D, sort_keys=True).encode()).hexdigest()[:8]}.json"
    p.write_text(json.dumps(D, indent=2), encoding="utf-8")
    return p


def load_decl(p: Path) -> dict:
    return json.loads(Path(p).read_text(encoding="utf-8"))


def cache_world():
    global CACHE_WORLD
    if CACHE_WORLD is None:
        root = TMP / "w1"
        CACHE_WORLD = W.make_cache_world(root)
    return CACHE_WORLD


def cli(*args, out: Path, expect: int = 0, decl: Path = None, root: Path = None) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    mods = str(Path(root) / "_mods") if root else ""
    env["PYTHONPATH"] = os.pathsep.join([x for x in (mods, str(PL), str(W.TRADELAB_DIR)) if x])
    cmd = [sys.executable, str(PL / "pathlab.py")] + list(args) + ["--out", str(out), "--allow-unfrozen"]
    if decl:
        cmd += ["--declaration", str(decl)]
    if root and args and args[0] in ("audit", "run", "build", "coverage"):
        cmd += ["--root", str(root), "--tlx", str(W.tlx_dir(root)), "--stage-e-any"]
    r = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=str(PL))
    if r.returncode != expect:
        raise AssertionError(f"pathlab {' '.join(args)} exited {r.returncode}, expected {expect}\n--- stdout\n"
                             f"{r.stdout[-3000:]}\n--- stderr\n{r.stderr[-3000:]}")
    return r


def world_build(out: Path, decl: Path, **kw):
    """Build in-process (for tests that look inside)."""
    import pl_build as PB
    w = cache_world()
    TW.use_mods(w["root"])
    D = load_decl(decl)
    world = PB.World(w["root"], D, stage_e_any=True, log=PC.Log(quiet=True))
    cdir = PB.build(world, out, "test", W.tlx_dir(w["root"]), PC.Log(quiet=True), **kw)
    return world, cdir


def sha_dir(d: Path, pattern="*.parquet") -> dict:
    return {p.name: PC.sha256_file(p) for p in sorted(Path(d).glob(pattern))}


# ======================================================================
# hand arithmetic
# ======================================================================
@test
def t01_daily_hand():
    D = load_decl(decl_for_tests())

    def run(rows):
        O, H, L, C = (np.array([[r[k] for r in rows]]) for k in range(4))
        return {k: v[0] for k, v in PP.daily_measures(np.array([100.0]), np.array([2.0]), O, H, L, C, D).items()}
    m = run([(101, 103, 99.5, 102), (102, 102.5, 97.5, 98), (98, 99, 95.5, 96), (96.5, 101, 96, 100.5), (100.5, 104.5, 100, 104)])
    exp = {"vd00": 0.5, "vd01": 1.5, "vd02": -0.25, "vd03": 1.0, "vd06": -1.0, "vd08": -2.25, "vd15": 2.0, "gap_p": 0.01,
           "mfe_a": 2.25, "mfe_s": 5, "mae_a": -2.25, "mae_s": 3, "mfeo_p": 104.5 / 101 - 1, "maeo_p": 95.5 / 101 - 1,
           "r5o_p": 104 / 101 - 1, "tu_a05": 1, "tu_a1": 1, "tu_a2": 5, "tu_a3": 0, "td_a05": 2, "td_a1": 2, "td_a2": 3,
           "td_a3": 0, "tu_p3": 1, "tu_p5": 0, "td_p3": 3, "td_p5": 0, "ord_a1_1": 1, "ord_a2_1": 2, "ord_a1_2": 1,
           "ord_a2_2": 2, "ord_a3_3": 0, "ord_p3_3": 1, "up_first_a1": 1, "rec_d2_endup": 1, "cont_up": 1, "rev_up": 0,
           "sign_code": 25, "n_up": 3, "best_close_s": 5, "worst_close_s": 3, "vol45_12": 9.5 / 8.5, "stg1": 1, "stg2": 2,
           "stg3": 2, "stg4": 1, "stg5": 1, "sq_dsr": 0, "sq_brc": 0, "clv1": 2.5 / 3.5, "co_p1": 102 / 101 - 1}
    bad = {k: (m[k], v) for k, v in exp.items() if not np.isclose(m[k], v)}
    assert not bad, bad
    for k in ("rec_d1_endup", "rec_d1_backc0", "rec_d1_toup1", "rec_p5_endup", "cont_dn", "rev_dn"):
        assert np.isnan(m[k]), (k, m[k])
    m = run([(99, 100.5, 97, 97.5), (97.5, 100.2, 97.2, 100.1), (100, 103, 99, 102.5), (102, 102.6, 101, 101.5),
             (101.5, 102, 100.5, 101)])
    assert (m["ord_a1_1"], m["up_first_a1"], m["rec_d1_endup"], m["rec_d1_backc0"], m["rec_d1_toup1"]) == (2, 0, 1, 1, 1), m
    flat = [(100, 101, 99, 100)] * 4
    assert run([(100, 103, 97, 100)] + flat)["ord_a1_1"] == 3                 # same session, open settles nothing: tie
    assert run([(102.5, 103, 97, 100)] + flat)["ord_a1_1"] == 1               # gap through +1: up first
    g = run([(97.5, 103, 97, 100)] + flat)
    assert (g["ord_a1_1"], g["rec_d1_backc0"], g["rec_d1_toup1"]) == (2, 1, 1), g
    q = run([(100, 100, 100, 100), (100, 100.2, 99.9, 100.1), (100.1, 100.3, 100, 100.2), (100, 100.1, 99.8, 100),
             (100, 100.1, 99.9, 100.05)])
    assert [q[f"stg{j}"] for j in range(1, 6)] == [3] * 5 and q["n_locked"] == 1
    ce = run([(100, 100.5, 99.6, 100.2), (100.2, 100.6, 99.9, 100.3), (100.3, 104, 100, 103.5), (103.5, 104, 103, 103.6),
              (103.6, 104, 103, 103.8)])
    assert ce["sq_ce"] == 1, [ce[f"stg{j}"] for j in range(1, 6)]


def _hand_session(knots, n=125):
    x = np.arange(n + 1)
    path = np.interp(x, [k for k, _ in knots], [v for _, v in knots])
    O, C = path[:-1], path[1:]
    return O, np.maximum(O, C), np.minimum(O, C), C


@test
def t02_intraday_hand():
    D = load_decl(decl_for_tests())
    sess = [[(0, 100.5), (20, 102.2), (30, 103), (80, 97.5), (125, 99)]] + \
           [[(0, 99 + 0.1 * j), (60, 100), (125, 99.5 + 0.1 * j)] for j in range(1, 5)]
    sess2 = [[(0, 100), (20, 97.5), (60, 100.5), (125, 100.2)]] + [[(0, 100), (60, 100.4), (125, 100.1)]] * 4
    out = {}
    for name, S in (("A", sess), ("B", sess2)):
        bars = [_hand_session(k) for k in S]
        O3, H3, L3, C3 = (np.array([b[i] for b in bars]) for i in range(4))
        V3 = np.ones_like(O3)
        pres = np.ones_like(O3, bool)
        dclose = C3[:, -1]
        T = PP.session_table(O3, H3, L3, C3, V3, pres, dclose, D)
        dr = np.arange(5)[None, :]
        prevC = np.r_[100.0, dclose[:4]][None, :]
        m = PP.intraday_measures(np.array([100.0]), np.array([2.0]), dr, np.zeros((1, 5)), np.ones((1, 5)), prevC, T,
                                 (O3, H3, L3, C3), D)
        out[name] = {k: v[0] for k, v in m.items()}
        dm = PP.daily_measures(np.array([100.0]), np.array([2.0]), O3[:, 0][None], H3.max(1)[None], L3.min(1)[None],
                               dclose[None], D)
        out[name + "_daily"] = {k: v[0] for k, v in dm.items()}
    a, ad = out["A"], out["A_daily"]
    assert ad["ord_a1_1"] == 3, "daily resolution: both +-1 ATR in session 1 is a tie"
    assert (a["itu_a1"], a["itd_a1"], a["iord_a1_1"], a["iup_first_a1"]) == (17, 75, 1, 1), \
        (a["itu_a1"], a["itd_a1"], a["iord_a1_1"], a["iup_first_a1"])
    assert (a["imfe_bar"], a["imae_bar"], a["thi1"], a["tlo1"], a["hif1"]) == (29, 79, 87.0, 237.0, 1.0), \
        (a["imfe_bar"], a["imae_bar"], a["thi1"], a["tlo1"], a["hif1"])
    p = lambda k: np.interp(k, [0, 20, 30, 80, 125], [100.5, 102.2, 103, 97.5, 99])
    assert np.isclose(a["m30_a"], (p(10) - 100.5) / 2) and a["drive"] == 1
    assert a["rej_up"] == 0 and a["rej_dn"] == 0
    assert (a["mstg1"], a["astg1"]) == (4, 2), (a["mstg1"], a["astg1"])
    assert np.isclose(a["lh_a1"], (99 - p(105)) / 2)
    assert np.isclose(a["vi00"], 0.25) and np.isclose(a["vi01"], (p(5) - 100) / 2) and np.isclose(a["vi08"], -0.5)
    tp = (np.maximum(p(np.arange(125)), p(np.arange(1, 126))) + np.minimum(p(np.arange(125)), p(np.arange(1, 126))) +
          p(np.arange(1, 126))) / 3
    assert np.isclose(a["vwp_a1"], (99 - tp.mean()) / 2)
    b = out["B"]
    assert (b["itd_a1"], b["iord_a1_1"], b["irec_d1_backc0"], b["irec_d1_toup1"]) == (15, 2, 1.0, 0.0), \
        (b["itd_a1"], b["iord_a1_1"], b["irec_d1_backc0"], b["irec_d1_toup1"])


# ======================================================================
# the 3-minute reader against tradelab's
# ======================================================================
@test
def t03_reader_parity():
    import pl_intraday as PI
    w = cache_world()
    TW.use_mods(w["root"])
    import tl_data as TD
    prod = TD.Production(stage_e_any=True)
    mkt = TD.Market(w["root"], prod)
    store = mkt.intraday
    n_sess = n_bad = 0
    for s in w["three"]:
        ds = mkt.series(s)
        dn = PI.read_dense(Path(store.path(s)), ds.dates, ds.o, ds.h, ds.l)
        ref = store.sessions(s, dn.days, ds)
        assert np.array_equal(np.array(sorted(ref), dtype="datetime64[D]"), dn.days), s
        for i, d in enumerate(dn.days):
            r = ref[d]
            assert bool(r.usable) == bool(dn.usable[i]), (s, d, r.reason, PI.REASONS[dn.reason[i]])
            if not r.usable:
                assert r.reason == PI.REASONS[dn.reason[i]], (s, d, r.reason, PI.REASONS[dn.reason[i]])
                n_bad += 1
            sl = r.slot
            assert np.array_equal(np.flatnonzero(dn.present[i]), sl), (s, d)
            for a_, b_ in ((r.o, dn.O[i, sl]), (r.h, dn.H[i, sl]), (r.l, dn.L[i, sl]), (r.c, dn.C[i, sl])):
                assert np.array_equal(a_, b_, equal_nan=True), (s, d)
            n_sess += 1
    planted = sum(len(v) for v in w["bad_sessions"].values())
    assert n_bad == planted, (n_bad, planted)
    FINGER["reader_sessions"] = n_sess


# ======================================================================
# the build on the cache world
# ======================================================================
@test
def t04_build_cases():
    out = TMP / "out_build"
    world, cdir = world_build(out, decl_for_tests())
    B = PC.read_json(cdir / "BUILD_DONE.json")
    assert B["integrity"]["status"] == "passed" and B["integrity"]["match_share"] == 1.0, B["integrity"]
    rd = lambda s: pd.read_parquet(cdir / "rows" / f"{s}.parquet")
    cf = rd("CASHFUND")
    assert cf["cash_like"].all() and not cf["eligible"].any(), "the money-market fund must be out"
    late = rd("LATESYM")
    P = pd.read_parquet(cache_world()["root"] / "panel_oc" / "panel.parquet")
    lp = P[P["symbol"] == "LATESYM"]
    ld = pd.read_parquet(cache_world()["root"] / "LATESYM_daily.parquet")
    pos = np.searchsorted(PC.to_day(ld["timestamp"]), PC.to_day(lp["timestamp"]))
    want = int((pos + 1 < 60).sum())                    # panel rows with fewer than 60 sessions of bars
    assert int(late["insuff"].sum()) == want and int(late["hist"].min()) == int(pos.min()) + 1, \
        (int(late["insuff"].sum()), want, int(late["hist"].min()))
    susp = rd("SUSPSYM")
    miss = [np.datetime64(d) for d in w_spec("SUSPSYM")["missing"]]
    inc = susp.loc[susp["complete"] == 0, "t0"].to_numpy().astype("datetime64[D]")
    assert len(inc) == 5 and (inc < miss[0]).all(), inc
    gone = rd("GONESYM")
    assert (gone.sort_values("t0")["complete"].to_numpy()[-5:] == 0).all() and int((gone["complete"] == 0).sum()) == 5
    sp = rd("SPLITSYM")
    sd = pd.read_parquet(cache_world()["root"] / "SPLITSYM_daily.parquet")
    kpos = int(np.searchsorted(PC.to_day(sd["timestamp"]), np.datetime64(w_spec("SPLITSYM")["split_day"])))
    i = sp["hist"].to_numpy() - 1                       # the T0 position in the stock's bars
    want_pre = (i - kpos >= 0) & (i - kpos <= 59)       # the split inside the 60 sessions up to T0
    want_win = (i >= kpos - 5) & (i <= kpos - 1)        # the split inside the five sessions after T0
    assert np.array_equal(sp["ca_pre"].to_numpy() == 1, want_pre) and np.array_equal(sp["ca_win"].to_numpy() == 1, want_win)
    assert int(sp["ca"].sum()) == int((want_pre | want_win).sum()) > 0
    lk = rd("LOCKSYM")
    assert int((lk["n_locked"] > 0).sum()) >= 50 and int(lk["lock_up"].sum()) > 0 and int(lk["lock_dn"].sum()) > 0
    h = rd("HANDSYM")
    r = h[h["t0"] == pd.Timestamp(W.HAND_T0)].iloc[0]
    A0 = r["atr0"]
    assert r["c0"] == 100.0 and r["pk_D"] == 1 and r["complete"] == 1
    O = [W.HAND[j][0] for j in range(1, 6)]
    H = [W.HAND[j][1] for j in range(1, 6)]
    L = [W.HAND[j][2] for j in range(1, 6)]
    C = [W.HAND[j][3] for j in range(1, 6)]
    exp = {"vd00": (O[0] - 100) / A0, "vd15": (C[4] - 100) / A0, "mfe_a": (max(H) - 100) / A0, "mae_a": (min(L) - 100) / A0,
           "mfeo_p": max(H) / O[0] - 1, "maeo_p": min(L) / O[0] - 1, "r5_p": C[4] / 100 - 1, "co_p3": C[2] / O[0] - 1}
    for kk, v in exp.items():
        assert np.isclose(r[kk], v, rtol=1e-6), (kk, r[kk], v)
    first = lambda arr, lvl, up: next((j + 1 for j, x in enumerate(arr) if (x >= lvl if up else x <= lvl)), 0)
    assert int(r["tu_a1"]) == first(H, 100 + A0, True) and int(r["td_a1"]) == first(L, 100 - A0, False)
    assert int(r["iok"]) == 1, "HANDSYM's window has usable 3-minute bars"
    st = PC.read_json(cdir / "done" / "GONESYM.json")["stats"]
    assert st["ca_source"] == "fallback"
    N = pd.read_parquet(cdir / "null" / "STK00.parquet")
    Rr = rd("STK00")
    e = Rr[(Rr["eligible"] == 1) & (Rr["complete"] == 1) & (Rr["ca"] == 0)]
    assert len(N) == len(e), (len(N), len(e))
    FINGER["build_rows"] = int(B["rows"])
    FINGER["build_hash_STK00"] = content_hash(cdir / "rows" / "STK00.parquet")
    FINGER["build_hash_null_STK00"] = content_hash(cdir / "null" / "STK00.parquet")
    FINGER["build_hash_inull_STK00"] = content_hash(cdir / "inull" / "STK00.parquet")


def content_hash(p: Path) -> str:
    """A hash of a table's values (column names, dtypes kind, numbers rounded to 1e-12): independent of the
    library versions that wrote the file."""
    df = pd.read_parquet(p)
    h = hashlib.sha256()
    for c in sorted(df.columns):
        v = df[c]
        if v.dtype.kind == "f":
            arr = np.round(v.to_numpy(np.float64), 12)
            h.update(c.encode() + np.nan_to_num(arr, nan=-9.87e99).tobytes())
        elif v.dtype.kind in "iub":
            h.update(c.encode() + v.to_numpy(np.int64).tobytes())
        elif v.dtype.kind == "M":
            h.update(c.encode() + v.to_numpy("datetime64[ns]").astype(np.int64).tobytes())
        else:
            h.update(c.encode() + "|".join(v.astype(str).tolist()).encode())
    return h.hexdigest()[:16]


def w_spec(s):
    return cache_world()["spec"][s]


@test
def t05_point_in_time():
    """Scramble every bar after T0: every value known at T0 must not move (states, ATR, liquidity, filters)."""
    import pl_build as PB
    w = cache_world()
    TW.use_mods(w["root"])
    D = load_decl(decl_for_tests())
    world = PB.World(w["root"], D, stage_e_any=True, log=PC.Log(quiet=True))
    M = world.market_info(TMP / "pit_out")
    U = world.universe()
    cols = ["state0", "phase0", "conf0", "overext0", "event0", "volreg0", "age0", "atr0", "atrp0", "c0", "liq", "v50", "rv20",
            "med_range60", "cash_like", "insuff", "eligible", "reg0", "hist", "ca_pre"]
    rng = np.random.default_rng(5)
    checked = 0
    for s in ("STK01", "STK05", "HANDSYM"):
        days = U[s]
        world.market.load([s])
        base, _, _, _ = PB.build_symbol(world, M, s, days, np.ones(len(days), bool), np.zeros(len(days), np.int8),
                                        np.zeros(len(days), np.int8))
        ds = world.market.daily[s]
        for t0 in rng.choice(days[100:-10], size=4, replace=False):
            i = ds.idx(t0)
            sav = [x.copy() for x in (ds.o, ds.h, ds.l, ds.c, ds.v)]
            k = len(ds.c) - i - 1
            f = np.exp(rng.normal(0, 0.05, k))
            ds.c[i + 1:] = ds.c[i + 1:] * f
            ds.o[i + 1:] = ds.o[i + 1:] * f[::-1]
            ds.h[i + 1:] = np.maximum(ds.o[i + 1:], ds.c[i + 1:]) * 1.01
            ds.l[i + 1:] = np.minimum(ds.o[i + 1:], ds.c[i + 1:]) * 0.99
            ds.v[i + 1:] = ds.v[i + 1:] * 3
            sel = days == t0
            got, _, _, _ = PB.build_symbol(world, M, s, days[sel], np.ones(1, bool), np.zeros(1, np.int8), np.zeros(1, np.int8))
            want = base[base["t0"] == pd.Timestamp(t0)]
            for c in cols:
                a_, b_ = got[c].to_numpy(), want[c].to_numpy()
                assert np.array_equal(a_, b_, equal_nan=True) if a_.dtype.kind == "f" else np.array_equal(a_, b_), (s, t0, c, a_, b_)
            assert not np.allclose(got["r5_a"].to_numpy(float), want["r5_a"].to_numpy(float)), "the scramble must change the path"
            ds.o, ds.h, ds.l, ds.c, ds.v = sav
            checked += 1
    assert checked == 12


@test
def t06_resume_identical():
    d = decl_for_tests()
    out1, out2 = TMP / "res_clean", TMP / "res_stop"
    _, c1 = world_build(out1, d)
    try:
        world_build(out2, d, stop_after=7)
        raise AssertionError("the test stop did not fire")
    except KeyboardInterrupt:
        pass
    n_done = len(list((Path(out2) / "cache").glob("*/done/*.json")))
    assert n_done == 7, n_done
    _, c2 = world_build(out2, d)
    for sub in ("rows", "null", "inull"):
        a_, b_ = sha_dir(c1 / sub), sha_dir(c2 / sub)
        assert a_ == b_, f"{sub}: resumed build differs from the clean one"
    assert c1.name == c2.name


@test
def t07_lock_and_amend():
    w = cache_world()
    out = TMP / "lock_out"
    d1 = decl_for_tests()
    cli("build", out=out, decl=d1, root=w["root"], expect=0)
    D = load_decl(d1)
    D["thresholds_atr"] = [0.5, 1.0, 2.0, 3.0, 4.0]
    d2 = TMP / "decl_changed.json"
    d2.write_text(json.dumps(D, indent=2), encoding="utf-8")
    r = cli("build", out=out, decl=d2, root=w["root"], expect=3)
    assert "changed" in r.stdout, r.stdout[-500:]
    cli("build", "--amend", "test: a threshold added", out=out, decl=d2, root=w["root"], expect=0)
    am = PC.amendments(out)
    assert len(am) == 1 and am[0]["reason"] == "test: a threshold added", am
    r = cli("status", out=out, decl=d2, expect=0)
    assert "amended" in r.stdout


@test
def t08_integrity_stops():
    w = W.make_cache_world(TMP / "w_bad", seed=4, n_regular=8, n_3m=3)
    W.corrupt_tlx(w["root"], 0.02)
    out = TMP / "bad_out"
    r = cli("build", out=out, decl=decl_for_tests(), root=w["root"], expect=3)
    assert "integrity check failed" in r.stdout, r.stdout[-800:]
    assert list((out / "cache").glob("*/integrity_mismatches.csv"))


@test
def t09_bat_file():
    raw = (PL / "env_pathlab.bat").read_bytes()
    assert b"\r\n" in raw and raw.count(b"\n") == raw.count(b"\r\n"), "env_pathlab.bat must have CRLF line endings"
    txt = raw.decode("ascii")
    import re
    labels = re.findall(r"^:(\w+)", txt, flags=re.M)
    assert len(labels) == len(set(labels)), labels
    for tgt in re.findall(r"goto :(\w+)", txt):
        assert tgt == "eof" or tgt in labels, tgt


# ======================================================================
# families and atlas on worlds with known answers
# ======================================================================
def rows_run(kind: str, n_stocks: int = 60):
    import pl_families as PF
    import pl_atlas as PA
    D = load_decl(decl_for_tests())
    cd = TMP / f"rw_{kind}"
    W.make_rows_world(cd, kind, decl=D, n_stocks=n_stocks)
    run = TMP / f"rw_{kind}_run"
    run.mkdir(exist_ok=True)
    PF.run_families(cd, run, D, PC.Log(quiet=True), kinds=("daily",))
    PA.run_atlas(cd, run, D, PC.Log(quiet=True))
    L = pd.read_parquet(run / "atlas" / "labels.parquet")
    L["state"] = [PA.group_label(int(g))[1] for g in L["group"]]
    L["regime"] = [PA.group_label(int(g))[2] for g in L["group"]]
    L["gkind"] = [PA.group_label(int(g))[0] for g in L["group"]]
    fam = json.loads((run / "families" / "daily" / "families.json").read_text())
    mi = json.loads((run / "atlas" / "daily" / "mutual_information.json").read_text())
    return cd, run, L, fam, mi


def template_map(cd: Path, run: Path) -> dict:
    """True template -> the family most of its paths landed in."""
    R = pd.concat([pd.read_parquet(p, columns=["sym", "t0", "fam_true"]) for p in sorted((cd / "rows").glob("*.parquet"))])
    A = pd.read_parquet(run / "families" / "daily" / "assign.parquet")
    J = R.merge(A, on=["sym", "t0"])
    J = J[J["fam"] >= 0]
    out = {}
    for t, g in J.groupby("fam_true"):
        vc = g["fam"].value_counts(normalize=True)
        out[int(t)] = (int(vc.index[0]), float(vc.iloc[0]))
    return out


@test
def t10_planted():
    cd, run, L, fam, mi = rows_run("planted")
    assert fam["status"] == "families found" and fam["k"] == 6, (fam["status"], fam["k"])
    tm = template_map(cd, run)
    assert all(p >= 0.9 for _, p in tm.values()), tm                        # each template lands in one family
    assert len({f for f, _ in tm.values()}) == 6, tm
    names = {t: fam["families"][f]["name"] for t, (f, _) in tm.items()}
    keys = list(W.TEMPLATES)
    assert names[keys.index("up")].startswith("Immediate expansion"), names
    assert names[keys.index("down")].startswith("Persistent decline"), names
    assert names[keys.index("dip_rec")].startswith("Initial decline then recovery"), names
    assert names[keys.index("rally_rev")].startswith("Early rally then reversal"), names
    assert names[keys.index("quiet")].startswith("Quiet consolidation"), names
    fid = lambda t: f"fam:F{tm[keys.index(t)][0] + 1:02d}"
    cells = L[L["gkind"] == "cell"]

    def labs(m, base, mask):
        x = cells[(cells["measure"] == m) & (cells["baseline"] == base) & mask]
        return int((x["label"] == "verified").sum()), len(x), x
    for t, sign in (("up", 1), ("down", -1)):
        nv, n, x = labs(fid(t), "same regime, all states", cells["state"] == "S01")
        assert nv >= 4 and (np.sign(x["diff_conf"]) == sign).all(), (t, nv, n)
    for t, sign in (("rally_rev", 1), ("quiet", -1)):
        nv, n, x = labs(fid(t), "same state, all regimes", cells["regime"] == "high_stress")
        assert nv >= 7 and (np.sign(x["diff_conf"]) == sign).all(), (t, nv, n)
    # nothing verified where nothing was planted (dip_rec / late_up have no planted effect beyond the mirror of others)
    for t in ("dip_rec", "late_up"):
        x = cells[(cells["measure"] == fid(t)) & (cells["baseline"] != "everything")]
        assert int((x["label"] == "verified").sum()) <= 2, (t, x[x["label"] == "verified"][["state", "regime", "baseline"]])
    for p in ("discovery", "confirmation"):
        assert mi[p]["state"]["z"] > 5 and mi[p]["regime"]["z"] > 5, mi[p]
    FINGER["planted_labels"] = L["label"].value_counts().sort_index().to_dict()
    FINGER["planted_assign"] = PC.sha256_file(run / "families" / "daily" / "assign.parquet")[:16]
    st = pd.read_parquet(run / "atlas" / "daily" / "stats.parquet")
    FINGER["planted_stats"] = [round(float(v), 9) for v in st["value"].fillna(-999).to_numpy()[:2000:37]]


@test
def t11_nolift():
    cd, run, L, fam, mi = rows_run("nolift")
    assert fam["status"] == "families found", fam["status"]
    cells = L[(L["gkind"] != "all") & (L["baseline"] != "random walk")]
    nv = int((cells["label"] == "verified").sum())
    assert nv <= 2, f"{nv} verified where nothing was planted"
    for p in ("discovery", "confirmation"):
        assert abs(mi[p]["state"]["z"]) < 3.5 and abs(mi[p]["regime"]["z"]) < 3.5, mi[p]
    vs = L[L["baseline"] == "random walk"]
    fam_rows = vs[vs["measure"].str.startswith("fam:")]
    assert (fam_rows["label"] == "verified").all(), "planted families must differ from the random walk"


@test
def t12_absent():
    cd, run, L, fam, mi = rows_run("absent")
    assert fam["status"] in ("regions only", "no stable structure"), fam["status"]
    cells = L[(L["gkind"] != "all") & (L["baseline"] != "random walk")]
    assert int((cells["label"] == "verified").sum()) <= 2
    vs = L[(L["baseline"] == "random walk") & L["measure"].str.startswith("fam:")]
    assert int((vs["label"] == "verified").sum()) <= 1, vs[["measure", "label", "diff_disc", "diff_conf"]]
    for p in ("discovery", "confirmation"):
        assert abs(mi[p]["state"]["z"]) < 3.5 and abs(mi[p]["regime"]["z"]) < 3.5, mi[p]
    FINGER["absent_status"] = fam["status"]


@test
def t13_end_to_end_cli():
    w = cache_world()
    out = TMP / "e2e_out"
    d = decl_for_tests()
    r = cli("audit", out=out, decl=d, root=w["root"], expect=0)
    assert "All essential inputs" in (sorted((out / "runs").glob("PL_*"))[-1] / "audit" / "audit.md").read_text()
    r = cli("run", out=out, decl=d, root=w["root"], expect=0)
    run = sorted((out / "runs").glob("PL_*"))[-1]
    for f in ("ATLAS.md", "ATLAS.html", "summary.json", "outputs.sha256", "atlas/labels.csv", "atlas/daily/stats.csv",
              "atlas/intraday/stats.csv", "families/daily/families.json", "audit/audit.md", "log.txt"):
        assert (run / f).exists(), f
    html = (run / "ATLAS.html").read_text(encoding="utf-8")
    assert "<svg" in html and "Verdict first" in html
    S = json.loads((run / "summary.json").read_text())
    assert S["integrity"]["status"] == "passed"
    # a second 'run --resume' finishes at once and changes nothing
    before = PC.sha256_file(run / "atlas" / "labels.parquet")
    cli("run", "--resume", run.name, out=out, decl=d, root=w["root"], expect=0)
    assert PC.sha256_file(run / "atlas" / "labels.parquet") == before
    r = cli("status", out=out, decl=d, expect=0)
    assert run.name in r.stdout
    FINGER["e2e_families"] = S["families"]
    FINGER["e2e_labels"] = S["labels"]


@test
def t14_guards():
    w = cache_world()
    r = cli("build", out=w["root"] / "inside", decl=decl_for_tests(), root=w["root"], expect=2)
    assert "never writes there" in r.stdout
    r3 = subprocess.run([sys.executable, str(PL / "pathlab.py"), "run", "--root", str(w["root"]), "--out", str(TMP / "frz"),
                         "--declaration", str(decl_for_tests()), "--tlx", str(W.tlx_dir(w["root"])), "--stage-e-any"],
                        capture_output=True, text=True, cwd=str(PL),
                        env={**os.environ, "PYTHONPATH": os.pathsep.join([str(w["root"] / "_mods"), str(PL), str(W.TRADELAB_DIR)])})
    assert r3.returncode == 2 and "not available in this build" in r3.stdout, r3.stdout[-500:]
    env_out = TMP / "noroot"
    r2 = subprocess.run([sys.executable, str(PL / "pathlab.py"), "audit", "--out", str(env_out)], capture_output=True,
                        text=True, cwd=str(PL))
    assert r2.returncode == 2 and "--root is required" in r2.stdout


@test
def t15_coverage():
    """The coverage audit: runs from the command line, finds the ETF and the cash-like fund, and reads nothing
    after T0 (every bar after a date scrambled -> every row up to that date unchanged)."""
    import pl_build as PB
    import pl_coverage as PV
    w = cache_world()
    out = TMP / "cov_out"
    cli("coverage", out=out, decl=decl_for_tests(), root=w["root"], expect=0)
    cdir = sorted((out / "coverage").glob("COV_*"))[-1]
    for f in ("coverage.md", "coverage_groups.csv", "regime_days.csv", "cells_meeting_minimums.csv", "stocks.csv",
              "etf_list.csv", "outputs.sha256"):
        assert (cdir / f).exists(), f
    E = pd.read_csv(cdir / "etf_list.csv")
    assert list(E["symbol"]) == ["GOLDBEES"], list(E["symbol"])
    S = pd.read_csv(cdir / "stocks.csv").set_index("symbol")
    assert bool(S.loc["GONESYM", "stopped_inside_cache"]) and bool(S.loc["LATESYM", "listed_after_2019"])
    C = pd.read_csv(cdir / "coverage_groups.csv")
    allg = C[(C["universe"] == "equities") & (C["window"] == "all 2020-2026") & (C["kind"] == "all")].iloc[0]
    assert allg["rows"] > 0 and allg["n_eff"] < allg["rows"], allg.to_dict()
    # outcome-blind: scramble every bar after 2024-01-01 for every stock -> rows with T0 before it are identical
    TW.use_mods(w["root"])
    D = load_decl(decl_for_tests())
    world = PB.World(w["root"], D, stage_e_any=True, log=PC.Log(quiet=True))
    M = world.market_info(TMP / "cov_pit")
    U = world.universe()
    some = ["STK02", "STK03", "SPLITSYM", "GOLDBEES"]
    R1, _ = PV.coverage_rows(world, M, U, {"GOLDBEES"}, D, only=some)
    world.market.load(some)
    rng = np.random.default_rng(9)
    for s_ in some:
        ds = world.market.daily[s_]
        k = int(np.searchsorted(ds.dates, np.datetime64("2024-01-01")))
        f = np.exp(rng.normal(0, 0.05, len(ds.c) - k))
        ds.c[k:] *= f
        ds.o[k:] *= f
        ds.h[k:] = np.maximum(ds.o[k:], ds.c[k:]) * 1.02
        ds.l[k:] = np.minimum(ds.o[k:], ds.c[k:]) * 0.98
    world.market.load = lambda syms: None                   # keep the scrambled series in memory
    R2, _ = PV.coverage_rows(world, M, U, {"GOLDBEES"}, D, only=some)
    a_ = R1[R1["t0"] < pd.Timestamp("2024-01-01")].reset_index(drop=True)
    b_ = R2[R2["t0"] < pd.Timestamp("2024-01-01")].reset_index(drop=True)
    pd.testing.assert_frame_equal(a_, b_)
    assert not R1[R1["t0"] > pd.Timestamp("2024-03-01")]["prior5"].equals(R2[R2["t0"] > pd.Timestamp("2024-03-01")]["prior5"])
    # the ETF list: NSE's list joins the name rule, corrections apply last, a malformed file stops loudly
    eb = TMP / "etf_base"
    (eb / "ref").mkdir(parents=True, exist_ok=True)
    syms = list(U)
    assert {"STK05", "STK06", "GOLDBEES"} <= set(syms)
    got, src = PV.etf_symbols(w["root"], eb, syms)
    assert got == {"GOLDBEES"} and "INCOMPLETE" in src, (got, src)
    (eb / "ref" / "eq_etfseclist.csv").write_text(" Symbol ,Underlying\nstk05 ,Gold\nNOTINPANEL,Nifty 50\n", encoding="utf-8")
    got, src = PV.etf_symbols(w["root"], eb, syms)
    assert got == {"GOLDBEES", "STK05"} and "plus the name rule" in src and "1 of them" in src, (got, src)
    (eb / "ref" / "etf_corrections.csv").write_text("Symbol,IS_ETF\nstk06,1\nGOLDBEES,0\nNOSUCH,1\n,\n", encoding="utf-8")
    got, src = PV.etf_symbols(w["root"], eb, syms)
    assert got == {"STK05", "STK06"} and "2 corrections" in src and "NOSUCH" in src, (got, src)
    for bad_text in ("name,flag\nSTK06,1\n", "symbol,is_etf\nSTK06,yes\n"):
        (eb / "ref" / "etf_corrections.csv").write_text(bad_text, encoding="utf-8")
        try:
            PV.etf_symbols(w["root"], eb, syms)
        except PC.PLError:
            continue
        raise AssertionError(f"a bad corrections file was accepted: {bad_text!r}")


QUICK = {"t01_daily_hand", "t02_intraday_hand", "t03_reader_parity", "t04_build_cases", "t09_bat_file", "t14_guards",
         "t15_coverage"}


def main(argv) -> int:
    quick = "quick" in argv
    only = [a for a in argv if a.startswith("t")]
    t0 = time.time()
    print(f"pathlab tests ({PC.VERSION}) - numpy {np.__version__}, pandas {pd.__version__}, python {sys.version.split()[0]}"
          f"\n  temporary folder {TMP}", flush=True)
    fails = []
    ran = 0
    for fn in RESULTS:
        if quick and fn.__name__ not in QUICK:
            continue
        if only and fn.__name__ not in only:
            continue
        ts = time.time()
        try:
            fn()
            print(f"  PASS {fn.__name__} ({time.time() - ts:.0f} s)", flush=True)
        except Exception as e:  # noqa: BLE001
            fails.append(fn.__name__)
            print(f"  FAIL {fn.__name__}: {type(e).__name__}: {str(e)[:1500]}", flush=True)
            traceback.print_exc()
        ran += 1
    FINGER["versions"] = {"numpy": np.__version__, "pandas": pd.__version__}
    (HERE / "fingerprint.json").write_text(json.dumps(FINGER, indent=1, default=str), encoding="utf-8")
    print(f"{'ALL %d TESTS PASSED' % ran if not fails else 'FAILED: ' + ', '.join(fails)} ({time.time() - t0:.0f} s)")
    if not fails:
        shutil.rmtree(TMP, ignore_errors=True)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
