"""
pl_build.py - pathlab v1.0: the audit stage and the build stage.

audit  reads everything Phase 1 needs, prints what exists and what is missing, and stops when something essential
       is missing. Nothing about any path is computed.
build  one pass over every stock: tl_state's states (bars up to each close only), the regime of every session
       (tl_context), and for every T0 row (the eligible universe plus every BigMove pick) the five-day path from
       daily bars, the 3-minute detail where all needed sessions are usable, and the random-walk ("null") version of
       the same row. One file per stock under PATHLAB_OUT\\cache\\<build fingerprint>\\, so a stopped build resumes
       where it stopped; a stock is rebuilt only when one of its input files changed. The picks' paths are then
       checked against tradelab's export (TLX): 99.5% must match or the build stops.
"""
from __future__ import annotations

import gc
import json
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import pl_common as PC
import pl_intraday as PI
import pl_paths as PP

BUILD_VERSION = "pl_build v1.0"
PHASE_CODE = {"": 0, "EARLY": 1, "MATURE": 2, "DETERIORATING": 3}
CONF_CODE = {"UNKNOWN": 0, "LOW": 1, "MEDIUM": 2, "HIGH": 3}
VOLREG_CODE = {"": 0, "COMPRESSED": 1, "NORMAL": 2, "ELEVATED": 3, "EXTREME": 4}
F64_COLS = {"c0", "atr0", "mfeo_p", "maeo_p", "co_p1", "co_p2", "co_p3", "co_p4", "co_p5", "r5o_p", "r5_p", "liq"}
MISSING_STATE = -2


# ======================================================================
# the shared inputs
# ======================================================================
class World:
    """Production data read through tradelab: calendar, daily bars, regimes, universe, picks."""

    def __init__(self, root: Path, decl: dict, stage_e_any: bool = False, tradelab_any: bool = False, log=print):
        self.root = Path(root)
        self.D = decl
        self.log = log
        self.TC, self.TD, self.TS, self.TX = PC.tradelab(tradelab_any)
        self.prod = self.TD.Production(stage_e_any)
        self.market = self.TD.Market(self.root, self.prod)
        self.cal = self.market.cal
        sp = decl["span"]
        self.t0_first, self.t0_last = PC.day(sp["t0_first"]), PC.day(sp["t0_last"])
        self.n_win = int(decl["window"]["sessions"])
        p_last = int(np.searchsorted(self.cal, self.t0_last, side="right")) - 1
        if p_last < 0 or p_last + self.n_win >= len(self.cal):
            raise PC.PLError(f"the NIFTY 50 calendar ({self.cal[0] if len(self.cal) else '-'} to "
                             f"{self.cal[-1] if len(self.cal) else '-'}) does not reach {self.n_win} sessions past "
                             f"{self.t0_last}")
        self.last_window_day = self.cal[p_last + self.n_win]
        self.ctx_meta: dict = {}

    # ---------------- market regime of every session ----------------
    def market_info(self, out_base: Path, breadth_rebuild: bool = False) -> pd.DataFrame:
        TX = self.TX
        ib = TX.IndexBook(self.market)
        core = [k for k in ("nifty", "mid", "small", "vix") if k in ib.missing]
        if core:
            raise PC.PLError(f"index files missing from the cache: {', '.join(TX.SPEC[k][0] for k in core)} - the "
                             f"regime labels need NIFTY 50, Midcap 150, Smallcap 250 and India VIX")
        breadth, meta, src = None, {}, ""
        bases = []
        if os.environ.get("TRADELAB_OUT"):
            bases.append(("tradelab's saved copy", Path(os.environ["TRADELAB_OUT"])))
        bases.append(("pathlab's saved copy", Path(out_base)))
        need = str(self.last_window_day)
        if not breadth_rebuild:
            for nm, b in bases:
                got = TX.load_breadth(b)
                if got is None:
                    continue
                last = str(got[1].get("calendar_last"))
                if last < need:
                    self.log(f"   breadth: {nm} ends {last}, before the last window day {need} - not used")
                    continue
                bd = PC.to_day(got[0]["date"])
                p0 = max(0, int(np.searchsorted(self.cal, self.t0_first)) - 80)
                p1 = int(np.searchsorted(self.cal, self.last_window_day)) + 1
                miss = np.setdiff1d(self.cal[p0:p1], bd)
                if len(miss):
                    self.log(f"   breadth: {nm} lacks {len(miss):,} sessions of this calendar (e.g. {miss[0]}) - not used")
                    continue
                breadth, meta, src = got[0], got[1], f"{nm} ({b}), built {got[1].get('built')}"
                break
        if breadth is None:
            syms = TX.cache_stock_symbols(self.market)
            self.log(f"   breadth: counting advancers / decliners over {len(syms):,} cached stocks (once; saved to "
                     f"{Path(out_base) / 'context'}) ...")
            breadth, meta = TX.ad_breadth(self.market, ib.cal, syms, log=self.log)
            import datetime as _dt
            meta.update({"version": TX.CTX_VERSION, "built": _dt.datetime.now().isoformat(timespec="seconds"),
                         "calendar_last": str(ib.cal[-1]), "built_by": PC.VERSION})
            TX.save_breadth(Path(out_base), breadth, meta)
            src = f"counted now, saved to {Path(out_base) / 'context'}"
        self.log(f"   breadth: {src}")
        F = TX.market_frame(ib, breadth)
        env = F["environment"].astype(str).to_numpy()
        code = np.array([PC.REGIME_CODES.get(e, -1) for e in env], dtype=np.int8)
        M = pd.DataFrame({"date": pd.DatetimeIndex(self.cal.astype("datetime64[ns]")), "env": code,
                          "env_direction": F["env_direction"].astype(str).to_numpy(),
                          "high_stress": F["high_stress"].to_numpy(float),
                          "nifty_close": F["nifty_close"].to_numpy(float), "mid_close": F["mid_close"].to_numpy(float),
                          "small_close": F["small_close"].to_numpy(float), "ad_ratio_10": F["ad_ratio_10"].to_numpy(float)})
        self.ctx_meta = {"breadth_source": src, "breadth_meta": {k: v for k, v in meta.items() if k != "unreadable_sample"},
                         "ctx_version": TX.CTX_VERSION, "definitions": TX.DEFINITIONS}
        return M

    # ---------------- the eligible universe (panel rows) ----------------
    def universe(self) -> Dict[str, np.ndarray]:
        import pyarrow.parquet as pq
        name = self.D["inputs"]["panel"]
        p = self.root / name / "panel.parquet"
        if not p.exists():
            raise PC.PLError(f"{p} not found (the eligible universe)")
        pf = pq.ParquetFile(p)
        names = list(pf.schema_arrow.names)
        tcol = "timestamp" if "timestamp" in names else ("date" if "date" in names else None)
        if tcol is None or "symbol" not in names:
            raise PC.PLError(f"{p.name} has no timestamp/date or symbol column")
        parts_s, parts_d = [], []
        for rb in pf.iter_batches(batch_size=500_000, columns=[tcol, "symbol"]):
            b = rb.to_pandas()
            d = PC.to_day(b[tcol])
            m = (d >= self.t0_first) & (d <= self.t0_last)
            parts_d.append(d[m])
            parts_s.append(b["symbol"].astype(str).to_numpy()[m])
        if not parts_d:
            return {}
        d = np.concatenate(parts_d)
        s = np.concatenate(parts_s)
        U = pd.DataFrame({"symbol": s, "day": d}).drop_duplicates()
        out = {}
        for sym, g in U.groupby("symbol", sort=True):
            out[str(sym)] = np.sort(g["day"].to_numpy().astype("datetime64[D]"))
        return out

    # ---------------- the BigMove picks ----------------
    def picks(self) -> Tuple[pd.DataFrame, dict]:
        I = self.D["inputs"]
        T, info = self.TD.load_picks(self.root, I["picks_run"], I["picks_engines"], I["picks_ranks"],
                                     self.t0_first, self.t0_last)
        P = pd.DataFrame({"engine": T["engine"].astype(str).to_numpy(), "symbol": T["symbol"].astype(str).to_numpy(),
                          "day": PC.to_day(T["signal_day"]), "rank": T["rank"].astype(int).to_numpy()})
        return P, info


# ======================================================================
# corporate-action suspects
# ======================================================================
def ca_suspects(world: World, sym: str) -> Tuple[Optional[np.ndarray], str, Optional[List[int]]]:
    """Days the cache's own detector marked as split-shaped discontinuities (<SYMBOL>_daily.ok.json). Returns
    (days or None when unusable, how, signature of the file)."""
    DQ = getattr(world.prod, "DQ", None)
    p = None
    if DQ is not None and hasattr(DQ, "_paths"):
        try:
            p = Path(DQ._paths(world.root, sym)[1])
        except Exception:  # noqa: BLE001
            p = None
    if p is None:
        p = world.root / f"{sym}_daily.ok.json"
    sig = PC.file_sig(p)
    js = PC.read_json(p) if sig else None
    if not isinstance(js, dict) or "corporate_action_suspects" not in js:
        return None, "fallback", sig
    days = []
    for h in js.get("corporate_action_suspects") or []:
        ts = h.get("timestamp") if isinstance(h, dict) else None
        if ts:
            try:
                days.append(PC.to_day([ts])[0])
            except Exception:  # noqa: BLE001
                pass
    return np.array(sorted(set(days)), dtype="datetime64[D]"), "ok.json", sig


# ======================================================================
# one stock
# ======================================================================
def _codes(arr, table, default=0) -> np.ndarray:
    return np.array([table.get(x, default) for x in arr], dtype=np.int8)


def rolling_median_at(x: np.ndarray, pos: np.ndarray, w: int) -> np.ndarray:
    """Median of x over positions pos-w+1..pos (NaN when fewer than w finite values)."""
    s = pd.Series(x).rolling(w, min_periods=w).median().to_numpy(float)
    out = np.full(len(pos), np.nan)
    ok = pos >= 0
    out[ok] = s[pos[ok]]
    return out


def build_symbol(world: World, M: pd.DataFrame, sym: str, days: np.ndarray, in_univ: np.ndarray,
                 pkD: np.ndarray, pkE: np.ndarray) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    """Rows for one stock. days: sorted T0 days (universe and picks); in_univ: panel row on that day."""
    D = world.D
    st: dict = {"t0_requested": int(len(days))}
    ds = world.market.series(sym)
    if ds is None or len(ds) < 2:
        st["no_daily_bars"] = int(len(days))
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), st
    ss = world.TS.StateSeries(sym, ds.dates, ds.o, ds.h, ds.l, ds.c, ds.v)
    cal = world.cal
    nW = world.n_win
    # T0 positions in the stock and in the calendar
    ipos = np.searchsorted(ds.dates, days)
    ok_i = ipos < len(ds.dates)
    ok_i[ok_i] = ds.dates[ipos[ok_i]] == days[ok_i]
    ppos = np.searchsorted(cal, days)
    ok_p = ppos < len(cal)
    ok_p[ok_p] = cal[ppos[ok_p]] == days[ok_p]
    keep = ok_i & ok_p
    st["no_bar_on_t0"] = int((~ok_i).sum())
    st["t0_not_a_session"] = int((ok_i & ~ok_p).sum())
    days, ipos, ppos = days[keep], ipos[keep], ppos[keep]
    in_univ, pkD, pkE = in_univ[keep], pkD[keep], pkE[keep]
    n = len(days)
    if n == 0:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), st
    # window: the next nW calendar sessions, located in the stock's bars
    wcal = ppos[:, None] + np.arange(1, nW + 1)[None, :]
    beyond = wcal >= len(cal)
    wcal_c = np.minimum(wcal, len(cal) - 1)
    wdays = cal[wcal_c]
    jpos = np.searchsorted(ds.dates, wdays)
    has = jpos < len(ds.dates)
    has[has] = ds.dates[jpos[has]] == wdays[has]
    has &= ~beyond
    jpos = np.where(has, jpos, -1)
    n_present = has.sum(axis=1)
    complete = n_present == nW
    # T0 classification (bars up to T0 only)
    A = ss.A
    C0 = ds.c[ipos]
    atr0 = A["atr"][ipos]
    atrp0 = A["atr_pct"][ipos]
    state0 = _codes(ss.state[ipos], PC.STATE_CODES, 0)
    U = D["universe"]
    insuff = (state0 == PC.STATE_CODES["INSUFFICIENT_DATA"]) | (ipos + 1 < int(U["min_history_sessions"])) | \
        ~np.isfinite(atr0) | ~(atr0 > 0)
    with np.errstate(divide="ignore", invalid="ignore"):
        drange = (ds.h - ds.l) / ds.c
    med_rng = rolling_median_at(drange, ipos, int(U["cash_like_window"]))
    cash_like = np.isfinite(med_rng) & (med_rng < float(U["cash_like_max_median_range"]))
    turn = rolling_median_at(ds.c * ds.v, ipos, int(U["turnover_window"]))
    v50 = rolling_median_at(ds.v, ipos, 50)
    with np.errstate(divide="ignore", invalid="ignore"):
        lr = np.log(ds.c[1:] / ds.c[:-1])
    lr2 = pd.Series(np.r_[np.nan, lr] ** 2).rolling(20, min_periods=20).mean().to_numpy(float)
    rv20 = np.sqrt(lr2[ipos])
    eligible = in_univ & ~cash_like & ~insuff
    # corporate-action suspects
    sus, how, _sig = ca_suspects(world, sym)
    if sus is None:
        with np.errstate(divide="ignore", invalid="ignore"):
            big = np.abs(ds.c[1:] / ds.c[:-1] - 1) >= float(D["corporate_actions"]["fallback_abs_close_move"])
        sus_pos = np.flatnonzero(np.r_[False, big])
    else:
        sp_ = np.searchsorted(ds.dates, sus)
        okk = sp_ < len(ds.dates)
        okk[okk] = ds.dates[sp_[okk]] == sus[okk]
        sus_pos = sp_[okk]
    st["ca_source"] = how
    st["ca_suspect_sessions"] = int(len(sus_pos))
    is_sus = np.zeros(len(ds.dates), bool)
    is_sus[sus_pos] = True
    cs = np.r_[0, np.cumsum(is_sus)]
    lb = int(D["corporate_actions"]["lookback_sessions"])
    ca_pre = (cs[ipos + 1] - cs[np.maximum(ipos + 1 - lb, 0)]) > 0
    ca_win = (np.where(jpos >= 0, is_sus[np.maximum(jpos, 0)], False)).any(axis=1)
    ca = ca_pre | ca_win
    # ---------------- the rows ----------------
    R: Dict[str, np.ndarray] = {
        "sym": np.full(n, sym, dtype=object), "t0": days.astype("datetime64[ns]"), "cal_pos": ppos.astype(np.int32),
        "year": days.astype("datetime64[Y]").astype(np.int64).astype(np.int16) + 1970,
        "in_univ": in_univ.astype(np.int8), "cash_like": cash_like.astype(np.int8), "insuff": insuff.astype(np.int8),
        "eligible": eligible.astype(np.int8), "hist": (ipos + 1).astype(np.int32),
        "pk_D": pkD.astype(np.int8), "pk_ENS": pkE.astype(np.int8),
        "c0": C0.astype(np.float64), "atr0": atr0.astype(np.float64), "atrp0": atrp0, "liq": turn, "v50": v50,
        "rv20": rv20, "med_range60": med_rng,
        "state0": state0, "phase0": _codes(ss.phase[ipos], PHASE_CODE), "conf0": _codes(ss.confidence[ipos], CONF_CODE),
        "overext0": ss.overext[ipos].astype(np.int8),
        "event0": np.array([world.TS.EVENT_NUM.get(f"{k}:{s}" if k else "", 0)
                            for k, s in zip(ss.ev_kind[ipos], ss.ev_status[ipos])], dtype=np.int8),
        "volreg0": _codes(ss.vol_regime[ipos], VOLREG_CODE), "age0": ss.age[ipos].astype(np.int32),
        "n_present": n_present.astype(np.int8), "complete": complete.astype(np.int8),
        "ca": ca.astype(np.int8), "ca_win": ca_win.astype(np.int8), "ca_pre": ca_pre.astype(np.int8),
    }
    env = M["env"].to_numpy()
    R["reg0"] = env[ppos].astype(np.int8)
    rg = np.where(beyond, -1, env[wcal_c]).astype(np.int8)
    for k in range(nW):
        R[f"rg{k + 1}"] = rg[:, k]
    order = np.array([PC.REGIME_CODES[r] for r in D["regime_order"]])
    rank_of = np.full(len(PC.REGIMES), 0)
    for rk, code in enumerate(order):
        rank_of[code] = rk
    r0, r5 = R["reg0"].astype(np.int64), rg[:, -1].astype(np.int64)
    known = (r0 >= 0) & (r5 >= 0)
    cls = np.full(n, -1, np.int8)
    cls[known & (r0 == r5)] = 0
    cls[known & (r0 != r5) & (rank_of[np.maximum(r5, 0)] < rank_of[np.maximum(r0, 0)])] = 1
    cls[known & (r0 != r5) & (rank_of[np.maximum(r5, 0)] > rank_of[np.maximum(r0, 0)])] = 2
    R["rg_class"] = cls
    chg = (rg != R["reg0"][:, None]) & (rg >= 0) & (R["reg0"][:, None] >= 0)
    R["rg_first_change"] = np.where(chg.any(axis=1), chg.argmax(axis=1) + 1, 0).astype(np.int8)
    for nm in ("nifty", "mid", "small"):
        cl = M[f"{nm}_close"].to_numpy(float)
        with np.errstate(divide="ignore", invalid="ignore"):
            R[f"{nm}_r5"] = np.where(beyond[:, -1], np.nan, cl[wcal_c[:, -1]] / cl[ppos] - 1)
            R[f"{nm}_r1"] = np.where(beyond[:, 0], np.nan, cl[wcal_c[:, 0]] / cl[ppos] - 1)
    # states at each window session's close (observed after T0: description only)
    stw = np.full((n, nW), MISSING_STATE, np.int8)
    for k in range(nW):
        m = jpos[:, k] >= 0
        stw[m, k] = _codes(ss.state[jpos[m, k]], PC.STATE_CODES, 0)
        R[f"st{k + 1}"] = stw[:, k]
    diff = (stw != state0[:, None]) & (stw != MISSING_STATE)
    R["st_first_change"] = np.where(diff.any(axis=1), diff.argmax(axis=1) + 1, 0).astype(np.int8)
    # ---------------- daily path measures (complete windows) ----------------
    rows = np.flatnonzero(complete)
    meas: Dict[str, np.ndarray] = {}
    if len(rows):
        jp = jpos[rows]
        O, H, L, C, V = (getattr(ds, k)[jp] for k in ("o", "h", "l", "c", "v"))
        mm = PP.daily_measures(C0[rows], atr0[rows], O, H, L, C, D, V=V, v50=v50[rows], rv20=rv20[rows])
        prevC = np.column_stack([C0[rows], C[:, :nW - 1]])
        with np.errstate(divide="ignore", invalid="ignore"):
            b35 = (np.abs(C / prevC - 1) >= float(D["corporate_actions"]["fallback_abs_close_move"])).any(axis=1)
        mm["big35"] = b35.astype(np.int8)
        for k, v in mm.items():
            full = np.full(n, np.nan) if v.dtype.kind == "f" else np.full(n, -1, dtype=v.dtype)   # -1 = no window
            full[rows] = v
            meas[k] = full
    R.update(meas)
    # ---------------- 3-minute ----------------
    st["has_3m_file"] = 0
    dense = None
    ip = _intraday_path(world, sym)
    if ip is not None and Path(ip).exists():
        st["has_3m_file"] = 1
        d_from = PC.day(D["span"]["intraday_first"])
        dense = PI.read_dense(Path(ip), ds.dates, ds.o, ds.h, ds.l, d_from - np.timedelta64(10, "D"),
                              world.last_window_day)
        st["sessions_3m"] = int(len(dense))
        st["sessions_3m_usable"] = int(dense.usable.sum())
        st["reasons_3m"] = dense.reasons()
    ims: Dict[str, np.ndarray] = {}
    T = None
    if dense is not None and len(dense):
        dclose = np.full(len(dense), np.nan)
        jd = np.searchsorted(ds.dates, dense.days)
        okd = jd < len(ds.dates)
        okd[okd] = ds.dates[jd[okd]] == dense.days[okd]
        dclose[okd] = ds.c[jd[okd]]
        T = PP.session_table(dense.O, dense.H, dense.L, dense.C, dense.V, dense.present, dclose, D)
        drow = np.searchsorted(dense.days, wdays)
        okr = drow < len(dense)
        okr[okr] = dense.days[drow[okr]] == wdays[okr]
        okr &= has
        okr[okr] = dense.usable[drow[okr]]
        dr = np.where(okr, drow, -1)
        prevC = np.full((n, nW), np.nan)
        prevC[:, 0] = C0
        for k in range(1, nW):
            m = jpos[:, k - 1] >= 0
            prevC[m, k] = ds.c[jpos[m, k - 1]]
        if (dr >= 0).any():
            ims = PP.intraday_measures(C0, atr0, dr, np.zeros((n, nW)), np.ones((n, nW)), prevC, T,
                                       (dense.O, dense.H, dense.L, dense.C), D)
            R.update(ims)
    st["rows"] = int(n)
    st["eligible"] = int(eligible.sum())
    st["complete"] = int(complete.sum())
    st["intraday_full"] = int(np.asarray(R.get("iok", np.zeros(n))).astype(bool).sum())
    rows_df = pd.DataFrame(R)
    # ---------------- the random-walk version (null) ----------------
    nseed = int(D["null"]["seed"])
    clip = D["null"]["scale_clip"]
    want = eligible & complete & ~ca
    null_df = pd.DataFrame()
    inull_df = pd.DataFrame()
    span_lo, span_hi = world.t0_first, world.last_window_day
    okd = (ds.dates >= span_lo) & (ds.dates <= span_hi)
    kk = np.arange(len(ds.dates))
    with np.errstate(invalid="ignore"):
        pool_ok = okd & (kk >= 1) & np.isfinite(ds.o) & np.isfinite(ds.h) & np.isfinite(ds.l) & np.isfinite(ds.c)
        prev_ok = np.r_[False, np.isfinite(ds.c[:-1]) & (ds.c[:-1] > 0) & np.isfinite(A["atr_pct"][:-1]) &
                        (A["atr_pct"][:-1] > 0)]
    pool_ok &= prev_ok & ~is_sus & ~np.r_[False, is_sus[:-1]]
    pool = np.flatnonzero(pool_ok)
    nrows = np.flatnonzero(want)
    st["null_pool"] = int(len(pool))
    if len(nrows) and len(pool) > 2 * nW:
        rng = np.random.default_rng(PC.sym_seed(nseed, sym))
        dn = _draw(rng, pool, jpos[nrows], nW)
        On, Hn, Ln, Cn, ok_n = _null_bars(ds.o, ds.h, ds.l, ds.c, A["atr_pct"], C0[nrows], atrp0[nrows], dn, clip)
        st["null_nonpositive_dropped"] = int((~ok_n).sum())
        nr = nrows[ok_n]
        if len(nr):
            mm = PP.daily_measures(C0[nr], atr0[nr], On[ok_n], Hn[ok_n], Ln[ok_n], Cn[ok_n], D, rv20=rv20[nr])
            NR = {"sym": np.full(len(nr), sym, dtype=object), "t0": days[nr].astype("datetime64[ns]"),
                  "cal_pos": ppos[nr].astype(np.int32)}
            NR.update(mm)
            null_df = pd.DataFrame(NR)
    # intraday null: whole donor sessions (usable ones), the same chain
    if dense is not None and len(dense) and "iok" in R:
        iwant = want & (np.asarray(R["iok"]) == 1)
        irows = np.flatnonzero(iwant)
        if len(irows):
            dpos_of = np.full(len(ds.dates), -1, np.int64)
            jd = np.searchsorted(ds.dates, dense.days)
            okd2 = jd < len(ds.dates)
            okd2[okd2] = ds.dates[jd[okd2]] == dense.days[okd2]
            dpos_of[jd[okd2]] = np.flatnonzero(okd2)
            ipool = pool[(dpos_of[pool] >= 0)]
            ipool = ipool[dense.usable[dpos_of[ipool]]]
            st["inull_pool"] = int(len(ipool))
            if len(ipool) > 2 * nW:
                rng2 = np.random.default_rng(PC.sym_seed(nseed + 1, sym))
                dn = _draw(rng2, ipool, jpos[irows], nW)
                aff_a, aff_g, prevN, ok_n = _null_affine(ds.c, A["atr_pct"], C0[irows], atrp0[irows], dn, clip,
                                                         ds.l)
                drn = dpos_of[dn]
                ir = irows[ok_n]
                if len(ir):
                    im = PP.intraday_measures(C0[ir], atr0[ir], drn[ok_n], aff_a[ok_n], aff_g[ok_n], prevN[ok_n], T,
                                              (dense.O, dense.H, dense.L, dense.C), D)
                    IR = {"sym": np.full(len(ir), sym, dtype=object), "t0": days[ir].astype("datetime64[ns]"),
                          "cal_pos": ppos[ir].astype(np.int32)}
                    IR.update(im)
                    inull_df = pd.DataFrame(IR)
    return _compact(rows_df), _compact(null_df), _compact(inull_df), st


def _intraday_path(world: World, sym: str) -> Optional[Path]:
    """The stock's 3-minute file through intraday_cache (None when there is no 3-minute store at all)."""
    if getattr(world, "_no_intraday", False):
        return None
    try:
        return Path(world.market.intraday.path(sym))
    except Exception:  # noqa: BLE001 - no intraday_cache module or no 3-minute folder: daily paths only
        world._no_intraday = True
        return None


def _draw(rng, pool: np.ndarray, window_pos: np.ndarray, nW: int) -> np.ndarray:
    """n x nW donor positions from `pool`, never one of the row's own window sessions (redrawn until clear)."""
    n = window_pos.shape[0]
    d = pool[rng.integers(0, len(pool), size=(n, nW))]
    for _ in range(100):
        clash = (d[:, :, None] == window_pos[:, None, :]).any(axis=2)
        if not clash.any():
            break
        d[clash] = pool[rng.integers(0, len(pool), size=int(clash.sum()))]
    return d


def _null_affine(c, atrp, C0, atrp0, dn, clip, l=None):
    """The price map of each donor session onto the null path: price -> a + g x price, chained from C0."""
    n, nW = dn.shape
    a = np.zeros((n, nW))
    g = np.zeros((n, nW))
    prev = np.zeros((n, nW))
    P = C0.astype(float).copy()
    ok = np.ones(n, bool)
    for j in range(nW):
        k = dn[:, j]
        s = np.clip(atrp0 / atrp[k - 1], clip[0], clip[1])
        cprev = c[k - 1]
        g[:, j] = P * s / cprev
        a[:, j] = P - g[:, j] * cprev
        prev[:, j] = P
        if l is not None:
            ok &= (a[:, j] + g[:, j] * l[k]) > 0
        P = a[:, j] + g[:, j] * c[k]
    ok &= np.isfinite(g).all(axis=1) & np.isfinite(a).all(axis=1)
    return a, g, prev, ok


def _null_bars(o, h, l, c, atrp, C0, atrp0, dn, clip):
    a, g, _prev, ok = _null_affine(c, atrp, C0, atrp0, dn, clip, l)
    On, Hn, Ln, Cn = (a + g * x[dn] for x in (o, h, l, c))
    ok &= np.isfinite(On).all(axis=1) & (Ln > 0).all(axis=1)
    return On, Hn, Ln, Cn, ok


def _compact(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = {}
    for k in df.columns:
        v = df[k]
        if v.dtype == object:
            out[k] = v.astype(str)
        elif v.dtype.kind == "f" and k not in F64_COLS:
            out[k] = v.astype(np.float32)
        else:
            out[k] = v
    return pd.DataFrame(out)


# ======================================================================
# the build stage
# ======================================================================
def build_fingerprint(world: World, M: pd.DataFrame, fp_decl: str) -> Tuple[str, dict]:
    TS = world.TS
    parts = {"build": BUILD_VERSION, "paths": PP.__doc__[:40], "declaration": fp_decl,
             "state_version": TS.STATE_VERSION, "state_cfg": TS.cfg_hash(TS.STATE_CFG),
             "ctx_version": world.TX.CTX_VERSION, "tradelab": world.TC.VERSION,
             "market": PC.sha16_text(M[["env", "nifty_close", "mid_close", "small_close"]].to_csv(index=False)),
             "code": {p: PC.sha256_file(PC.HERE / p)[:16] for p in ("pl_build.py", "pl_paths.py", "pl_intraday.py")}}
    return PC.sha16_text(PC.canon(parts)), parts


def build(world: World, out_base: Path, fp_decl: str, tlx: Optional[Path], log, max_symbols: Optional[int] = None,
          only: Optional[Sequence[str]] = None, stop_after: Optional[int] = None) -> Path:
    t0 = time.time()
    D = world.D
    log(f"[build] {PC.VERSION}: T0 {world.t0_first} to {world.t0_last}, windows to {world.last_window_day}")
    M = world.market_info(out_base)
    bfp, parts = build_fingerprint(world, M, fp_decl)
    cdir = Path(out_base) / "cache" / bfp
    for sub in ("rows", "null", "inull", "done"):
        (cdir / sub).mkdir(parents=True, exist_ok=True)
    PC.write_parquet_atomic(M, cdir / "market.parquet")
    PC.write_json_atomic({"fingerprint": bfp, "parts": parts, "ctx": world.ctx_meta}, cdir / "build_meta.json")
    log(f"   cache {cdir}")
    U = world.universe()
    log(f"   universe: {sum(len(v) for v in U.values()):,} panel rows, {len(U):,} stocks in the span")
    P, pinfo = world.picks()
    log(f"   picks: {len(P):,} ({', '.join(D['inputs']['picks_engines'])}, ranks "
        f"{min(D['inputs']['picks_ranks'])}-{max(D['inputs']['picks_ranks'])}) from {pinfo.get('file')}")
    syms = sorted(set(U) | set(P["symbol"]))
    if only:
        syms = [s for s in syms if s in set(only)]
    if max_symbols:
        syms = syms[:int(max_symbols)]
    pk = {}
    for (s, e), g in P.groupby(["symbol", "engine"]):
        pk.setdefault(s, {})[e] = dict(zip(g["day"].to_numpy().astype("datetime64[D]").tolist(), g["rank"].astype(int)))
    stats: Dict[str, dict] = {}
    done_n = skipped = 0
    batch = 40
    for b0 in range(0, len(syms), batch):
        chunk = syms[b0:b0 + batch]
        todo = []
        for s in chunk:
            dset = _t0_days(U.get(s), pk.get(s, {}))
            sig = _signature(world, s, dset, bfp)
            dj = PC.read_json(cdir / "done" / f"{_fname(s)}.json")
            if dj and dj.get("signature") == sig:
                stats[s] = dj.get("stats", {})
                skipped += 1
                continue
            todo.append((s, dset, sig))
        if todo:
            world.market.load([s for s, _, _ in todo])
        for s, dset, sig in todo:
            days, inu = dset
            pD = np.array([pk.get(s, {}).get("D", {}).get(d.item(), 0) for d in days], dtype=np.int8)
            pE = np.array([pk.get(s, {}).get("ENS", {}).get(d.item(), 0) for d in days], dtype=np.int8)
            rows, nul, inul, st = build_symbol(world, M, s, days, inu, pD, pE)
            f = _fname(s)
            for sub, df in (("rows", rows), ("null", nul), ("inull", inul)):
                p = cdir / sub / f"{f}.parquet"
                if len(df):
                    PC.write_parquet_atomic(df, p)
                elif p.exists():
                    p.unlink()
            PC.write_json_atomic({"symbol": s, "signature": sig, "stats": st}, cdir / "done" / f"{f}.json")
            stats[s] = st
            world.market.daily.pop(s, None)
            done_n += 1
            if stop_after is not None and done_n >= stop_after:
                raise KeyboardInterrupt(f"test stop after {done_n} stocks")
        if (b0 // batch) % 10 == 9 or b0 + batch >= len(syms):
            log(f"   {min(b0 + batch, len(syms)):,} of {len(syms):,} stocks ({done_n:,} built, {skipped:,} already "
                f"done, {time.time() - t0:,.0f} s)")
        gc.collect()
    summ = summarize_build(cdir, stats, syms, world, log)
    if tlx is not None:
        summ["integrity"] = integrity(world, cdir, tlx, log)
    else:
        summ["integrity"] = {"status": "not run (no --tlx)"}
        log("   integrity: NOT RUN (pass --tlx <TLX export folder>); the atlas refuses to run without it")
    summ["seconds"] = round(time.time() - t0, 1)
    summ["fingerprint"] = bfp
    PC.write_json_atomic(summ, cdir / "BUILD_DONE.json")
    log(f"[build] done in {summ['seconds']:,.0f} s: {summ['rows']:,} rows, {summ['eligible']:,} eligible")
    return cdir


def _fname(sym: str) -> str:
    """A file name for a symbol (symbols like 'M&M' or 'BAJAJ-AUTO' are kept; only path-unsafe characters change)."""
    bad = '<>:"/\\|?*'
    return "".join("_" if ch in bad else ch for ch in sym)


def _t0_days(udays: Optional[np.ndarray], pks: dict) -> Tuple[np.ndarray, np.ndarray]:
    u = udays if udays is not None else np.array([], dtype="datetime64[D]")
    extra = sorted({d for e in pks.values() for d in e})
    alld = np.unique(np.concatenate([u, np.array(extra, dtype="datetime64[D]")])) if extra else np.unique(u)
    inu = np.isin(alld, u)
    return alld, inu


def _signature(world: World, sym: str, dset, bfp: str) -> dict:
    DQ = getattr(world.prod, "DQ", None)
    try:
        pd_, po = (Path(x) for x in DQ._paths(world.root, sym)) if DQ is not None and hasattr(DQ, "_paths") else \
            (world.root / f"{sym}_daily.parquet", world.root / f"{sym}_daily.ok.json")
    except Exception:  # noqa: BLE001
        pd_, po = world.root / f"{sym}_daily.parquet", world.root / f"{sym}_daily.ok.json"
    ip = _intraday_path(world, sym)
    days, inu = dset
    key = PC.sha16_text(",".join(str(d) for d in days.tolist()) + "|" + "".join("1" if x else "0" for x in inu))
    return {"build": bfp, "daily": PC.file_sig(pd_), "ok_json": PC.file_sig(po),
            "intraday": PC.file_sig(ip) if ip else None, "t0": key}


def summarize_build(cdir: Path, stats: Dict[str, dict], syms: List[str], world: World, log) -> dict:
    tot = {"stocks": len(syms), "rows": 0, "eligible": 0, "complete": 0, "intraday_full": 0, "no_bar_on_t0": 0,
           "t0_not_a_session": 0, "no_daily_bars": 0, "ca_fallback_stocks": 0, "ca_suspect_sessions": 0,
           "stocks_with_3m": 0, "null_nonpositive_dropped": 0}
    reasons: Dict[str, int] = {}
    for s in syms:
        st = stats.get(s, {})
        for k in ("rows", "eligible", "complete", "intraday_full", "no_bar_on_t0", "t0_not_a_session",
                  "no_daily_bars", "ca_suspect_sessions", "null_nonpositive_dropped"):
            tot[k] += int(st.get(k, 0) or 0)
        tot["ca_fallback_stocks"] += int(st.get("ca_source") == "fallback")
        tot["stocks_with_3m"] += int(st.get("has_3m_file", 0) or 0)
        for r, v in (st.get("reasons_3m") or {}).items():
            reasons[r] = reasons.get(r, 0) + int(v)
    tot["sessions_3m_by_reason"] = reasons
    cols = ["sym", "year", "eligible", "complete", "ca", "cash_like", "insuff", "in_univ", "pk_D", "pk_ENS", "state0",
            "reg0"]
    R = load_rows(cdir, "rows", cols + ["iok"], quiet=True)
    if len(R):
        if "iok" not in R.columns:
            R["iok"] = 0
        R["iok"] = R["iok"].fillna(0).astype(int)
        el = R["eligible"] == 1
        R["eligible_complete"] = (el & (R["complete"] == 1)).astype(int)
        R["eligible_ca_suspect"] = (el & (R["ca"] == 1)).astype(int)
        R["eligible_intraday_full"] = (el & (R["iok"] == 1)).astype(int)
        R["picks_D"] = (R["pk_D"] > 0).astype(int)
        R["picks_ENS"] = (R["pk_ENS"] > 0).astype(int)
        R["rows"] = 1
        cov = R.groupby("year")[["rows", "in_univ", "cash_like", "insuff", "eligible", "eligible_complete",
                                 "eligible_ca_suspect", "eligible_intraday_full", "picks_D", "picks_ENS"]].sum()
        cov = cov.rename(columns={"in_univ": "in_universe", "insuff": "insufficient_history"}).reset_index()
        PC.write_table(cov, cdir / "coverage_by_year")
        tot["coverage_by_year"] = cov.to_dict(orient="records")
        e = R[R["eligible"] == 1]
        tot["eligible_stocks"] = int(e["sym"].nunique())
        tot["eligible_rows_by_state"] = {PC.STATE_FROM_CODE.get(int(k), str(k)): int(v)
                                         for k, v in e["state0"].value_counts().sort_index().items()}
        tot["eligible_rows_by_regime"] = {(PC.REGIMES[int(k)] if int(k) >= 0 else "blank"): int(v)
                                          for k, v in e["reg0"].value_counts().sort_index().items()}
    log(f"   rows {tot['rows']:,}; eligible {tot['eligible']:,}; complete windows {tot['complete']:,}; "
        f"all-five-sessions 3-minute {tot['intraday_full']:,}; stocks with a 3-minute file {tot['stocks_with_3m']:,}")
    if tot["ca_fallback_stocks"]:
        log(f"   corporate actions: {tot['ca_fallback_stocks']:,} stocks had no usable ok.json - the 35% move "
            f"fallback was used for them")
    return tot


def load_rows(cdir: Path, sub: str, columns: Optional[Sequence[str]] = None, quiet: bool = False,
              filt=None) -> pd.DataFrame:
    """Concatenate one cache sub-folder (rows / null / inull), reading only `columns` (missing columns are skipped)."""
    import pyarrow as pa
    import pyarrow.parquet as pq
    files = sorted((Path(cdir) / sub).glob("*.parquet"))
    tabs = []
    for f in files:
        try:
            pf = pq.ParquetFile(f)
            have = set(pf.schema_arrow.names)
            cols = [c for c in columns if c in have] if columns is not None else None
            t = pf.read(columns=cols)
        except Exception as e:  # noqa: BLE001
            raise PC.PLError(f"cannot read {f} ({type(e).__name__}: {e}) - delete it and its done/*.json to rebuild")
        if filt is not None:
            t = filt(t)
        tabs.append(t)
    if not tabs:
        return pd.DataFrame(columns=list(columns) if columns else [])
    try:
        t = pa.concat_tables(tabs, promote_options="permissive")
    except TypeError:                                   # pyarrow before 14
        t = pa.concat_tables(tabs, promote=True)
    return t.to_pandas()


# ======================================================================
# integrity: the picks' paths against tradelab's export
# ======================================================================
def integrity(world: World, cdir: Path, tlx: Path, log) -> dict:
    D = world.D
    tlx = Path(tlx)
    f = tlx / "trades.parquet"
    if not f.exists():
        raise PC.PLError(f"--tlx {tlx}: trades.parquet not found")
    rec = world.TC.read_hash_file(tlx / "outputs.sha256").get("trades.parquet")
    sha = PC.sha256_file(f)
    if rec is None or not world.TC.hash_matches(rec, sha):
        raise PC.PLStop(f"{f} does not match its outputs.sha256 (recorded {rec}, file {sha[:16]}...) - refusing")
    X = pd.read_parquet(f)
    need = ["symbol", "signal_day", "mfe", "mae"] + [f"close_ret_s{k}" for k in range(1, 6)]
    miss = [c for c in need if c not in X.columns]
    if miss:
        raise PC.PLError(f"{f} lacks {miss}")
    X = X[need].copy()
    X["t0"] = PC.to_day(X["signal_day"]).astype("datetime64[ns]")
    X = X.drop(columns=["signal_day"]).drop_duplicates(["symbol", "t0"])
    X["symbol"] = X["symbol"].astype(str)
    R = load_rows(cdir, "rows", ["sym", "t0", "complete", "pk_D", "pk_ENS", "mfeo_p", "maeo_p"] +
                  [f"co_p{k}" for k in range(1, 6)], quiet=True)
    R = R[(R["pk_D"] > 0) | (R["pk_ENS"] > 0)].rename(columns={"sym": "symbol"})
    R["t0"] = pd.to_datetime(R["t0"]).astype("datetime64[ns]")
    J = X.merge(R, on=["symbol", "t0"], how="left", indicator=True)
    found = J["_merge"] == "both"
    pairs = [("mfe", "mfeo_p"), ("mae", "maeo_p")] + [(f"close_ret_s{k}", f"co_p{k}") for k in range(1, 6)]
    comp = found & (J["complete"] == 1)
    for a, b in pairs:
        comp &= np.isfinite(J[a].astype(float)) & np.isfinite(J[b].astype(float))
    tol = float(D["integrity"]["abs_tol"])
    match = comp.copy()
    for a, b in pairs:
        match &= (np.abs(J[a].astype(float) - J[b].astype(float)) <= tol)
    n_comp, n_match = int(comp.sum()), int(match.sum())
    share = n_match / n_comp if n_comp else float("nan")
    out = {"tlx": str(tlx), "tlx_sha16": sha[:16], "tlx_picks": int(len(X)), "found_in_pathlab": int(found.sum()),
           "not_found": int((~found).sum()), "incomplete_window_here": int((found & (J["complete"] != 1)).sum()),
           "comparable": n_comp, "matching": n_match, "match_share": share,
           "required": float(D["integrity"]["min_match_share"])}
    bad = J[comp & ~match]
    if len(bad):
        bad.head(500).to_csv(cdir / "integrity_mismatches.csv", index=False)
    log(f"   integrity vs {tlx.name}: {n_match:,} of {n_comp:,} comparable picks match "
        f"({share:.4%}; {out['not_found']:,} not built here, {out['incomplete_window_here']:,} with a missing session)")
    if not (n_comp > 0 and share >= out["required"]):
        out["status"] = "FAILED"
        PC.write_json_atomic(out, cdir / "integrity.json")
        raise PC.PLStop(f"integrity check failed: {share:.4%} of {n_comp:,} comparable picks match the TLX export "
                        f"(need {out['required']:.1%}). Mismatches: {cdir / 'integrity_mismatches.csv'}. Send Claude "
                        f"that file.")
    out["status"] = "passed"
    PC.write_json_atomic(out, cdir / "integrity.json")
    return out


# ======================================================================
# the audit stage
# ======================================================================
def audit(root: Path, decl: dict, out_base: Path, run_dir: Path, tlx: Optional[Path], log, stage_e_any=False,
          tradelab_any=False) -> dict:
    t0 = time.time()
    A: dict = {"version": PC.VERSION, "root": str(root), "essential_missing": [], "warnings": []}
    log(f"[audit] {PC.VERSION} reading {root} (read only)")
    lib = {}
    for mod in ("numpy", "pandas", "pyarrow", "scipy"):
        try:
            lib[mod] = __import__(mod).__version__
        except Exception as e:  # noqa: BLE001
            lib[mod] = None
            A["essential_missing"].append(f"python package {mod} ({type(e).__name__})")
    A["libraries"] = lib
    log(f"   libraries: " + ", ".join(f"{k} {v}" for k, v in lib.items()))
    try:
        world = World(root, decl, stage_e_any, tradelab_any, log)
    except PC.PLError as e:
        A["essential_missing"].append(str(e))
        _finish_audit(A, run_dir, log, t0)
        raise
    except Exception as e:  # noqa: BLE001 - tradelab's own errors (TLError) carry the fix in their text
        A["essential_missing"].append(f"{type(e).__name__}: {e}")
        _finish_audit(A, run_dir, log, t0)
        raise PC.PLError(str(e)) from None
    A["tradelab"] = {"version": world.TC.VERSION, "folder": str(Path(world.TC.__file__).parent),
                     "stage_e": world.prod.describe(), "state_version": world.TS.STATE_VERSION,
                     "state_cfg_hash": world.TS.cfg_hash(world.TS.STATE_CFG), "ctx_version": world.TX.CTX_VERSION}
    cal = world.cal
    A["calendar"] = {"first": str(cal[0]), "last": str(cal[-1]), "sessions": int(len(cal)),
                     "t0_first": str(world.t0_first), "t0_last": str(world.t0_last),
                     "last_window_day": str(world.last_window_day)}
    log(f"   calendar (NIFTY 50): {cal[0]} to {cal[-1]}, {len(cal):,} sessions; last window ends {world.last_window_day}")
    # indices and breadth source
    idx = {}
    for k, sym, nm, kind in world.TX.INDEX_SPECS:
        ds = world.market.series(sym)
        idx[sym] = None if ds is None else {"first": str(ds.dates[0]), "last": str(ds.dates[-1]), "sessions": len(ds)}
        if ds is None:
            A["essential_missing"].append(f"index file {sym}")
    A["indices"] = idx
    log("   indices: " + ", ".join(f"{s} {'ok' if v else 'MISSING'}" for s, v in idx.items()))
    bsrc = []
    places = [("PATHLAB_OUT", Path(out_base))]
    if os.environ.get("TRADELAB_OUT"):
        places.insert(0, ("TRADELAB_OUT", Path(os.environ["TRADELAB_OUT"])))
    for nm, b in places:
        got = world.TX.load_breadth(b)
        bsrc.append({"where": nm, "folder": str(b), "usable": got is not None,
                     "built": got[1].get("built") if got else None,
                     "calendar_last": got[1].get("calendar_last") if got else None})
    A["breadth_saved"] = bsrc
    log("   breadth: " + "; ".join(f"{x['where']}: " + (f"built {x['built']} to {x['calendar_last']}" if x["usable"]
                                                          else "none usable") for x in bsrc) +
        " (none usable = the build counts it once, a few minutes)")
    # panel / universe
    try:
        U = world.universe()
        nrows = sum(len(v) for v in U.values())
        by_year: Dict[int, int] = {}
        for v in U.values():
            yy = v.astype("datetime64[Y]").astype(int) + 1970
            for y_, c_ in zip(*np.unique(yy, return_counts=True)):
                by_year[int(y_)] = by_year.get(int(y_), 0) + int(c_)
        A["universe"] = {"rows_in_span": nrows, "stocks_in_span": len(U), "rows_by_year": by_year}
        log(f"   panel_oc in the span: {nrows:,} stock-days, {len(U):,} stocks; by year " +
            ", ".join(f"{y}: {c:,}" for y, c in sorted(by_year.items())))
        miss_daily = [s for s in U if not (Path(root) / f"{s}_daily.parquet").exists()]
        A["universe"]["stocks_without_daily_file"] = len(miss_daily)
        if miss_daily:
            A["warnings"].append(f"{len(miss_daily)} panel stocks have no daily file (e.g. {miss_daily[:5]})")
    except PC.PLError as e:
        A["essential_missing"].append(str(e))
        U = {}
    # 3-minute store
    try:
        ist = world.market.intraday
        files = sorted(Path(ist.dir).glob("*_3m.parquet"))
        with3 = [s for s in U if Path(ist.path(s)).exists()]
        A["intraday"] = {"folder": str(ist.dir), "files": len(files), "universe_stocks_with_file": len(with3)}
        sample = with3[:: max(1, len(with3) // 12)][:12]
        spans, use = [], {"sessions": 0, "usable": 0}
        for s in sample:
            ds = world.market.series(s)
            if ds is None:
                continue
            dn = PI.read_dense(Path(ist.path(s)), ds.dates, ds.o, ds.h, ds.l)
            if len(dn):
                spans.append((str(dn.days[0]), str(dn.days[-1])))
                use["sessions"] += len(dn)
                use["usable"] += int(dn.usable.sum())
        A["intraday"]["sample_spans"] = spans
        A["intraday"]["sample_usable_share"] = use["usable"] / use["sessions"] if use["sessions"] else None
        log(f"   3-minute: {len(files):,} files; {len(with3):,} of {len(U):,} universe stocks have one; sample of "
            f"{len(sample)}: {use['usable']:,} of {use['sessions']:,} sessions usable; spans " +
            (f"{min(a for a, _ in spans)} to {max(b for _, b in spans)}" if spans else "-"))
        if use["sessions"] and use["usable"] < 0.5 * use["sessions"]:
            A["essential_missing"].append("3-minute sample: under half the sessions usable (layout or stamps?)")
    except Exception as e:  # noqa: BLE001
        A["intraday"] = {"error": f"{type(e).__name__}: {e}"}
        A["warnings"].append(f"3-minute store not readable ({e}); the intraday atlas would be empty")
    # corporate-action files
    ok_n = fb = sus = 0
    for s in list(U)[:: max(1, len(U) // 200)]:
        d_, how, _ = ca_suspects(world, s)
        if how == "ok.json":
            ok_n += 1
            sus += len(d_)
        else:
            fb += 1
    A["corporate_actions_sample"] = {"ok_json_usable": ok_n, "fallback": fb, "suspect_sessions": sus}
    log(f"   corporate actions (sample of {ok_n + fb} stocks): {ok_n} with a usable ok.json ({sus} suspect sessions), "
        f"{fb} would use the 35% fallback")
    # picks and the TLX export
    try:
        P, info = world.picks()
        A["picks"] = {k: info.get(k) for k in ("file", "sha256", "rows_in_file", "first_day", "last_day")}
        A["picks"]["rows_in_span"] = int(len(P))
        log(f"   picks {decl['inputs']['picks_run']}: {len(P):,} in the span ({info.get('first_day')} to "
            f"{info.get('last_day')}), hash checked")
    except Exception as e:  # noqa: BLE001
        A["essential_missing"].append(f"picks run {decl['inputs']['picks_run']}: {e}")
    if tlx is None:
        A["essential_missing"].append("--tlx <the TLX export folder> (the integrity check needs it)")
    else:
        f = Path(tlx) / "trades.parquet"
        if not f.exists():
            A["essential_missing"].append(f"{f} not found")
        else:
            rec = world.TC.read_hash_file(Path(tlx) / "outputs.sha256").get("trades.parquet")
            ok = rec is not None and world.TC.hash_matches(rec, PC.sha256_file(f))
            A["tlx"] = {"folder": str(tlx), "hash_ok": bool(ok)}
            if not ok:
                A["essential_missing"].append(f"{f} does not match its outputs.sha256")
            log(f"   TLX export {Path(tlx).name}: trades.parquet {'hash checked' if ok else 'HASH MISMATCH'}")
    amfi = Path(root) / "sectors" / "amfi"
    A["amfi_lists"] = len(list(amfi.glob("*"))) if amfi.is_dir() else 0
    if not A["amfi_lists"]:
        A["warnings"].append("no AMFI size lists: market-cap segments are replaced by liquidity tiers (declared)")
    return _finish_audit(A, run_dir, log, t0)


def _finish_audit(A: dict, run_dir: Path, log, t0) -> dict:
    A["seconds"] = round(time.time() - t0, 1)
    d = Path(run_dir) / "audit"
    d.mkdir(parents=True, exist_ok=True)
    PC.write_json_atomic(A, d / "audit.json")
    lines = [f"# pathlab audit ({PC.VERSION})", "", f"root: {A.get('root')}", ""]
    if A["essential_missing"]:
        lines += ["## ESSENTIAL INPUTS MISSING - nothing else can run", ""] + [f"- {x}" for x in A["essential_missing"]] + [""]
    else:
        lines += ["All essential inputs found.", ""]
    if A["warnings"]:
        lines += ["## Warnings", ""] + [f"- {x}" for x in A["warnings"]] + [""]
    lines += ["## Details", "", "```", json.dumps({k: v for k, v in A.items() if k not in ("essential_missing", "warnings")},
                                                indent=2, default=str), "```", ""]
    (d / "audit.md").write_text("\n".join(lines), encoding="utf-8")
    if A["essential_missing"]:
        log("   ESSENTIAL INPUTS MISSING:\n" + "\n".join(f"     - {x}" for x in A["essential_missing"]))
    for w in A["warnings"]:
        log(f"   warning: {w}")
    log(f"[audit] done in {A['seconds']:.0f} s -> {d / 'audit.md'}")
    if A["essential_missing"]:
        raise PC.PLError("audit: essential inputs missing (listed above and in audit.md)")
    return A
