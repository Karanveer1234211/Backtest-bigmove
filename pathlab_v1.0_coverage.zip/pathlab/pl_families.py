"""
pl_families.py - pathlab v1.0: discovering path families (daily and intraday separately).

  1. Vectors in ATR units (daily: the session-1 open, then high, low, close of sessions 1-5 = 16 numbers; intraday:
     9 checkpoints a session x 5 = 45), capped at +-8 ATR for the grouping only.
  2. Principal components keeping 95% of the variation, fitted on a year-balanced sample of the DISCOVERY period.
  3. k-means for k = 4..16 on that sample (pathlab's own k-means++ / Lloyd, seeded: identical across library
     versions). For each k: stability = mean adjusted Rand index over 20 refits on date-block resamples; reproduction =
     a separate fit on the confirmation period, paired by the Hungarian method, every pair's centre distance at most
     0.5 x the family's RMS spread; separation = along the line joining every group and its nearest neighbour the
     smoothed density dips to at most half the lower of the two peaks (a valley between them).
       FAMILIES      the largest k that is stable (ARI >= 0.75), reproduced and separated
       PATH REGIONS  when no k separates: the largest k that is stable and reproduced - a partition of a continuum,
                     reported as regions, never as distinct behaviours
       neither       "no stable structure": cells are described by the measures alone
  4. Frozen on the discovery period; every row of both periods is assigned to the nearest centre. A Gaussian mixture
     with the same k checks each group; groups that one method alone finds are marked.
  5. The random-walk (null) rows are assigned to the same frozen groups (and the same search is run on them at the
     chosen k); a group is "real structure" only when its share differs from the null's, with the interval to show
     it, in both periods (atlas stage).
"""
from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import pl_common as PC
import pl_build as PB
import pl_paths as PP

FAM_VERSION = "pl_families v1.0"


# ======================================================================
# numerical pieces (seeded, no scikit-learn)
# ======================================================================
def pca_fit(X: np.ndarray, var: float) -> dict:
    mu = X.mean(axis=0)
    Z = X - mu
    cov = (Z.T @ Z) / max(len(Z) - 1, 1)
    w, V = np.linalg.eigh(cov)
    order = np.argsort(w)[::-1]
    w, V = w[order], V[:, order]
    w = np.maximum(w, 0)
    share = w / w.sum() if w.sum() > 0 else w
    k = int(np.searchsorted(np.cumsum(share), var) + 1)
    k = max(1, min(k, len(w)))
    V = V[:, :k].copy()
    for j in range(k):                                   # sign convention: the largest loading is positive
        if V[np.argmax(np.abs(V[:, j])), j] < 0:
            V[:, j] *= -1
    return {"mean": mu, "comp": V, "eig": w[:k], "share": share[:k], "n": k, "total_var": float(w.sum())}


def pca_apply(P: dict, X: np.ndarray) -> np.ndarray:
    return (X - P["mean"]) @ P["comp"]


def _d2(X: np.ndarray, x2: np.ndarray, c: np.ndarray) -> np.ndarray:
    d = x2[:, None] - 2.0 * (X @ c.T) + (c * c).sum(axis=1)[None, :]
    return np.maximum(d, 0.0)


def kmeans_pp(X: np.ndarray, x2: np.ndarray, k: int, rng) -> np.ndarray:
    n = len(X)
    c = np.empty((k, X.shape[1]))
    c[0] = X[int(rng.integers(n))]
    d2 = _d2(X, x2, c[:1])[:, 0]
    for j in range(1, k):
        cs = np.cumsum(d2)
        tot = cs[-1]
        i = int(np.searchsorted(cs, rng.random() * tot, side="right")) if tot > 0 else int(rng.integers(n))
        c[j] = X[min(i, n - 1)]
        d2 = np.minimum(d2, _d2(X, x2, c[j:j + 1])[:, 0])
    return c


def lloyd(X: np.ndarray, x2: np.ndarray, c: np.ndarray, max_iter: int, tol: float = 0.0
          ) -> Tuple[np.ndarray, np.ndarray, float, int]:
    """Lloyd iterations; stops when no more than `tol` of the points change group (0 = none at all)."""
    k, dim = c.shape
    lab = None
    it = 0
    n = len(X)
    for it in range(1, max_iter + 1):
        d = _d2(X, x2, c)
        new = d.argmin(axis=1)
        if lab is not None:
            changed = int((new != lab).sum())
            if changed == 0 or changed <= tol * n:
                lab = new
                break
        lab = new
        cnt = np.bincount(lab, minlength=k).astype(np.float64)
        c2 = np.empty_like(c)
        for j in range(dim):
            c2[:, j] = np.bincount(lab, weights=X[:, j], minlength=k)
        empty = cnt == 0
        if empty.any():                                  # an empty group restarts at the farthest point
            far = np.argsort(d.min(axis=1))[::-1]
            for t, j in enumerate(np.flatnonzero(empty)):
                c2[j] = X[far[t]]
                cnt[j] = 1.0
        c = c2 / cnt[:, None]
    d = _d2(X, x2, c)
    lab = d.argmin(axis=1)
    inertia = float(d[np.arange(len(X)), lab].sum())
    return c, lab, inertia, it


def kmeans(X: np.ndarray, k: int, seed: int, n_init: int, max_iter: int, tol: float = 0.0
           ) -> Tuple[np.ndarray, np.ndarray, float]:
    x2 = (X * X).sum(axis=1)
    best = None
    for r in range(n_init):
        rng = np.random.default_rng(seed + 7919 * r)
        c0 = kmeans_pp(X, x2, k, rng)
        c, lab, inertia, _ = lloyd(X, x2, c0, max_iter, tol)
        if best is None or inertia < best[2] - 1e-9 * abs(best[2]):
            best = (c, lab, inertia)
    c, lab, inertia = best
    # canonical order: by size (largest first), ties by the first coordinate
    cnt = np.bincount(lab, minlength=k)
    order = np.lexsort((c[:, 0], -cnt))
    remap = np.empty(k, np.int64)
    remap[order] = np.arange(k)
    return c[order], remap[lab], inertia


def kde_line(p: np.ndarray, bins: int = 512) -> Tuple[np.ndarray, np.ndarray]:
    """Gaussian-kernel density of 1-D values on a grid (binned, Silverman's bandwidth)."""
    p = np.asarray(p, float)
    p = p[np.isfinite(p)]
    lo, hi = np.percentile(p, [0.5, 99.5])
    if not hi > lo:
        return np.array([lo]), np.array([1.0])
    q75, q25 = np.percentile(p, [75, 25])
    s = min(p.std(), (q75 - q25) / 1.34) if q75 > q25 else p.std()
    bw = max(0.9 * s * len(p) ** -0.2, 1e-9)
    edges = np.linspace(lo, hi, bins + 1)
    cnt, _ = np.histogram(p, bins=edges)
    step = edges[1] - edges[0]
    half = int(np.ceil(4 * bw / step))
    kern = np.exp(-0.5 * (np.arange(-half, half + 1) * step / bw) ** 2)
    dens = np.convolve(cnt.astype(float), kern / kern.sum(), mode="same")
    return (edges[:-1] + edges[1:]) / 2, dens


def valley_ratio(p: np.ndarray, boundary: float) -> float:
    """Lowest smoothed density between the highest point on each side of `boundary`, over the lower of those two
    peaks. About 1 = no valley (one cloud cut in two, or a flat top); near 0 = two separate clouds."""
    g, d = kde_line(p)
    left, right = g < boundary, g >= boundary
    if not left.any() or not right.any():
        return 1.0
    iL = int(np.argmax(np.where(left, d, -1)))
    iR = int(np.argmax(np.where(right, d, -1)))
    a, b = sorted((iL, iR))
    peak = min(d[iL], d[iR])
    return float(d[a:b + 1].min() / peak) if peak > 0 else 1.0


def separation(Z: np.ndarray, lab: np.ndarray, c: np.ndarray, max_points: int, seed: int) -> List[dict]:
    """For each group and its nearest neighbouring centre: both groups' members projected on the line joining the
    centres; the valley ratio of their smoothed density across the k-means boundary (the midpoint). Ashman's D of a
    two-component fit is reported too (for reference only: a flat-topped cloud scores D > 2 without any valley)."""
    k = len(c)
    rng = np.random.default_rng(seed)
    dist = np.sqrt(((c[:, None, :] - c[None, :, :]) ** 2).sum(axis=2))
    np.fill_diagonal(dist, np.inf)
    out = []
    for j in range(k):
        nb = int(np.argmin(dist[j]))
        idx = np.flatnonzero((lab == j) | (lab == nb))
        if len(idx) > max_points:
            idx = np.sort(rng.choice(idx, size=max_points, replace=False))
        u = (c[nb] - c[j]) / max(dist[j, nb], 1e-12)
        pj = Z[idx] @ u
        vr = valley_ratio(pj, float(((c[j] + c[nb]) / 2) @ u))
        b = bimodality(pj)
        out.append({"family": j, "neighbour": nb, "valley_ratio": vr, "ashman_d": float(b.get("ashman_d", np.nan)),
                    "n": int(len(idx))})
    return out


def assign(X: np.ndarray, c: np.ndarray, chunk: int = 200_000) -> Tuple[np.ndarray, np.ndarray]:
    lab = np.empty(len(X), np.int64)
    dist = np.empty(len(X))
    for a in range(0, len(X), chunk):
        xs = X[a:a + chunk]
        d = _d2(xs, (xs * xs).sum(axis=1), c)
        lab[a:a + chunk] = d.argmin(axis=1)
        dist[a:a + chunk] = np.sqrt(d[np.arange(len(xs)), lab[a:a + chunk]])
    return lab, dist


def gmm_full(X: np.ndarray, means: np.ndarray, lab: np.ndarray, max_iter: int, reg: float) -> Tuple[np.ndarray, float, int]:
    """EM for a full-covariance Gaussian mixture, started from the k-means solution. Returns hard labels."""
    n, d = X.shape
    k = len(means)
    w = np.bincount(lab, minlength=k) / n
    mu = means.copy()
    cov = np.empty((k, d, d))
    for j in range(k):
        Z = X[lab == j] - mu[j]
        cov[j] = (Z.T @ Z) / max(len(Z), 1) + reg * np.eye(d)
    ll_old = -np.inf
    it = 0
    logr = None
    for it in range(1, max_iter + 1):
        logp = np.empty((n, k))
        for j in range(k):
            try:
                Lc = np.linalg.cholesky(cov[j])
            except np.linalg.LinAlgError:
                cov[j] += 1e-4 * np.eye(d)
                Lc = np.linalg.cholesky(cov[j])
            Y = np.linalg.solve(Lc, (X - mu[j]).T)
            logdet = 2.0 * np.log(np.diag(Lc)).sum()
            logp[:, j] = np.log(max(w[j], 1e-300)) - 0.5 * ((Y * Y).sum(axis=0) + logdet + d * np.log(2 * np.pi))
        mx = logp.max(axis=1, keepdims=True)
        lse = mx[:, 0] + np.log(np.exp(logp - mx).sum(axis=1))
        ll = float(lse.mean())
        logr = logp - lse[:, None]
        if ll - ll_old < 1e-6 * max(1.0, abs(ll)):
            break
        ll_old = ll
        r = np.exp(logr)
        nk = r.sum(axis=0) + 1e-12
        w = nk / n
        mu = (r.T @ X) / nk[:, None]
        for j in range(k):
            Z = X - mu[j]
            cov[j] = (Z * r[:, j:j + 1]).T @ Z / nk[j] + reg * np.eye(d)
    return logr.argmax(axis=1), ll_old if np.isfinite(ll_old) else ll, it


def gmm_1d(x: np.ndarray, k: int, max_iter: int = 200) -> dict:
    """1-D Gaussian mixture (k = 1 or 2) by EM; BIC, means, sds, weights."""
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 20:
        return {"ok": False}
    if k == 1:
        m, s = x.mean(), max(x.std(), 1e-9)
        ll = float(np.sum(-0.5 * ((x - m) / s) ** 2 - np.log(s) - 0.5 * np.log(2 * np.pi)))
        return {"ok": True, "ll": ll, "bic": -2 * ll + 2 * np.log(n), "mu": [m], "sd": [s], "w": [1.0]}
    q1, q3 = np.quantile(x, [0.25, 0.75])
    mu = np.array([q1, q3])
    sd = np.array([x.std(), x.std()]) / 2 + 1e-9
    w = np.array([0.5, 0.5])
    ll_old = -np.inf
    for _ in range(max_iter):
        lp = np.log(w)[None, :] - 0.5 * ((x[:, None] - mu[None, :]) / sd[None, :]) ** 2 - np.log(sd)[None, :] - \
            0.5 * np.log(2 * np.pi)
        mx = lp.max(axis=1, keepdims=True)
        lse = mx[:, 0] + np.log(np.exp(lp - mx).sum(axis=1))
        ll = float(lse.sum())
        r = np.exp(lp - lse[:, None])
        nk = r.sum(axis=0) + 1e-12
        w = nk / n
        mu = (r * x[:, None]).sum(axis=0) / nk
        sd = np.sqrt((r * (x[:, None] - mu[None, :]) ** 2).sum(axis=0) / nk) + 1e-9
        if ll - ll_old < 1e-8 * max(1.0, abs(ll)):
            break
        ll_old = ll
    return {"ok": True, "ll": ll, "bic": -2 * ll + 5 * np.log(n), "mu": mu.tolist(), "sd": sd.tolist(),
            "w": w.tolist()}


def bimodality(x: np.ndarray) -> dict:
    """One vs two components by BIC, and Ashman's D (two clean peaks need D >= 2; heavy tails alone give BIC a
    second component with nearly the same mean, D well under 2)."""
    a, b = gmm_1d(x, 1), gmm_1d(x, 2)
    if not (a.get("ok") and b.get("ok")):
        return {"ok": False}
    mu, sd, w = np.array(b["mu"]), np.array(b["sd"]), np.array(b["w"])
    dd = float(np.sqrt(2) * abs(mu[0] - mu[1]) / np.sqrt(sd[0] ** 2 + sd[1] ** 2))
    return {"ok": True, "bic1": a["bic"], "bic2": b["bic"], "bic_prefers_2": bool(b["bic"] < a["bic"]),
            "ashman_d": dd, "min_weight": float(w.min()), "mu": b["mu"], "sd": b["sd"], "w": b["w"],
            "n": int(np.isfinite(np.asarray(x, float)).sum())}


def hungarian(cost: np.ndarray) -> np.ndarray:
    from scipy.optimize import linear_sum_assignment
    r, c = linear_sum_assignment(cost)
    out = np.empty(cost.shape[0], np.int64)
    out[r] = c
    return out


# ======================================================================
# names
# ======================================================================
def name_daily(v: np.ndarray) -> str:
    """Declared rules on a centre path (16 numbers, ATR units): see PATHLAB_DECLARATION.json naming_rules."""
    O1 = v[0]
    H = v[[1, 4, 7, 10, 13]]
    L = v[[2, 5, 8, 11, 14]]
    C = v[[3, 6, 9, 12, 15]]
    return _name(O1, H, L, C)


def name_intraday(v: np.ndarray) -> str:
    """The same rules on the intraday centre: session closes = the 'close' checkpoints, highs / lows = the extremes
    of each session's checkpoints, O1 = the 09:15 open."""
    S = v.reshape(5, 9)
    return _name(S[0, 0], S.max(axis=1), S.min(axis=1), S[:, 8])


def _name(O1, H, L, C) -> str:
    c1, c2, c5 = C[0], C[1], C[4]
    prev = np.r_[0.0, C[:-1]]
    rng = H.max() - L.min()
    if c1 >= 0.5 and np.all(C >= prev - 0.25) and c5 >= 1.5:
        nm = "Immediate expansion and continuation"
    elif c1 <= -0.5 and np.all(C <= prev + 0.25) and c5 <= -1.5:
        nm = "Persistent decline"
    elif max(c1, c2) >= 0.75 and c5 <= max(c1, c2) - 1.0:
        nm = "Early rally then reversal"
    elif min(c1, c2) <= -0.75 and c5 >= min(c1, c2) + 1.0:
        nm = "Initial decline then recovery"
    elif abs(c1) < 0.5 and abs(c2) < 0.75 and c5 >= 1.0:
        nm = "Delayed expansion up"
    elif abs(c1) < 0.5 and abs(c2) < 0.75 and c5 <= -1.0:
        nm = "Delayed decline"
    elif np.all(np.abs(C) < 0.75) and rng < 3.0:
        nm = "Quiet consolidation"
    elif rng >= 3.0 and abs(c5) < 1.0:
        nm = "Volatile oscillation"
    elif c5 >= 0.5:
        nm = "Gradual drift up"
    elif c5 <= -0.5:
        nm = "Gradual drift down"
    else:
        nm = "Flat / mixed"
    if O1 >= 0.75:
        nm += " (gap up)"
    elif O1 <= -0.75:
        nm += " (gap down)"
    return nm


def unique_names(names: List[str], centres: np.ndarray, closes_idx) -> List[str]:
    """Two families with one name get a magnitude word from their 5-day close (larger / smaller)."""
    out = list(names)
    for nm in set(names):
        idx = [i for i, x in enumerate(names) if x == nm]
        if len(idx) < 2:
            continue
        c5 = np.array([abs(centres[i][closes_idx]) for i in idx])
        order = np.argsort(-c5)
        for rank, t in enumerate(order):
            out[idx[t]] = f"{nm} - {['strongest', 'second', 'third', 'fourth', 'fifth', 'sixth'][min(rank, 5)]}"
    return out


# ======================================================================
# data
# ======================================================================
DATASETS = {
    "daily": {"cols": PP.daily_vector_names(), "need": "complete", "first_key": "t0_first",
              "disc_last": "discovery_last", "null": "null", "name": name_daily, "close_idx": 15},
    "intraday": {"cols": PP.intraday_vector_names(), "need": "iok", "first_key": "intraday_first",
                 "disc_last": "intraday_discovery_last", "null": "inull", "name": name_intraday, "close_idx": 44},
}


def periods(cal: np.ndarray, D: dict, kind: str) -> Dict[str, Tuple[np.datetime64, np.datetime64]]:
    """discovery / confirmation T0 ranges, with the declared embargo (sessions after the discovery end skipped)."""
    sp = D["span"]
    first = PC.day(sp["t0_first"]) if kind == "daily" else PC.day(sp["intraday_first"]) - np.timedelta64(10, "D")
    dlast = PC.day(sp["discovery_last"] if kind == "daily" else sp["intraday_discovery_last"])
    e = int(np.searchsorted(cal, dlast, side="right")) - 1
    emb = int(sp["embargo_sessions"])
    cfirst = cal[min(e + emb + 1, len(cal) - 1)]
    return {"discovery": (first, cal[e]), "confirmation": (cfirst, PC.day(sp["t0_last"])),
            "all": (first, PC.day(sp["t0_last"]))}


def load_vectors(cdir: Path, kind: str, D: dict) -> Tuple[pd.DataFrame, pd.DataFrame]:
    spec = DATASETS[kind]
    keys = ["sym", "t0", "cal_pos", "year", "eligible", "complete", "ca"]
    need = spec["need"]
    cols = keys + ([need] if need not in keys else []) + spec["cols"]
    R = PB.load_rows(cdir, "rows", cols)
    if len(R) == 0 or need not in R.columns:
        return pd.DataFrame(columns=cols), pd.DataFrame()
    R = R[(R[need] == 1) & (R["ca"] == 0)].reset_index(drop=True)
    N = PB.load_rows(cdir, spec["null"], ["sym", "t0", "cal_pos"] + spec["cols"])
    for df in (R, N):
        if len(df):
            df["t0"] = pd.to_datetime(df["t0"]).astype("datetime64[ns]")
    return R, N


def year_balanced(dates: np.ndarray, years: np.ndarray, n: int, seed: int) -> np.ndarray:
    """Row positions: the same number from each year (all of a year that has fewer), seeded."""
    rng = np.random.default_rng(seed)
    uy = np.unique(years)
    per = int(np.ceil(n / max(len(uy), 1)))
    out = []
    for y in uy:
        idx = np.flatnonzero(years == y)
        if len(idx) > per:
            idx = np.sort(rng.choice(idx, size=per, replace=False))
        out.append(idx)
    return np.sort(np.concatenate(out)) if out else np.zeros(0, np.int64)


def date_resample(dates: np.ndarray, B: int, block: int, seed: int) -> List[np.ndarray]:
    """For each of B resamples: row positions of the sample drawn by circular blocks of consecutive dates."""
    ud, inv = np.unique(dates, return_inverse=True)
    order = np.argsort(inv, kind="stable")
    starts = np.searchsorted(inv[order], np.arange(len(ud)))
    ends = np.r_[starts[1:], len(order)]
    I = PC.circular_block_index(len(ud), B, block, seed)
    out = []
    for b in range(B):
        parts = [order[starts[d]:ends[d]] for d in I[b]]
        out.append(np.concatenate(parts) if parts else np.zeros(0, np.int64))
    return out


# ======================================================================
# the stage
# ======================================================================
def run_families(cdir: Path, run_dir: Path, D: dict, log, kinds: Sequence[str] = ("daily", "intraday")) -> dict:
    M = pd.read_parquet(Path(cdir) / "market.parquet")
    cal = PC.to_day(M["date"])
    out = {}
    for kind in kinds:
        out[kind] = families_one(cdir, Path(run_dir) / "families" / kind, kind, D, cal, log)
    return out


def families_one(cdir: Path, fdir: Path, kind: str, D: dict, cal: np.ndarray, log) -> dict:
    t0 = time.time()
    F = D["families"]
    spec = DATASETS[kind]
    fdir.mkdir(parents=True, exist_ok=True)
    done = PC.read_json(fdir / "DONE.json")
    if done:
        log(f"[families/{kind}] already done ({fdir})")
        return done
    log(f"[families/{kind}] {FAM_VERSION}")
    R, N = load_vectors(cdir, kind, D)
    per = periods(cal, D, kind)
    if len(R) == 0:
        res = {"kind": kind, "status": "no data", "k": None}
        PC.write_json_atomic(res, fdir / "families.json")
        PC.write_json_atomic(res, fdir / "DONE.json")
        log(f"   no {kind} vectors - skipped")
        return res
    t = PC.to_day(R["t0"])
    X = R[spec["cols"]].to_numpy(np.float64)
    finite = np.isfinite(X).all(axis=1)
    cap = float(F["cap_atr"])
    Xc = np.clip(X, -cap, cap)
    inp = lambda nm: (t >= per[nm][0]) & (t <= per[nm][1]) & finite
    disc, conf = np.flatnonzero(inp("discovery")), np.flatnonzero(inp("confirmation"))
    log(f"   rows: {len(R):,} ({len(disc):,} discovery {per['discovery'][0]}..{per['discovery'][1]}, "
        f"{len(conf):,} confirmation {per['confirmation'][0]}..{per['confirmation'][1]})")
    seed = int(F["seed"])
    if len(disc) < 1000 or len(conf) < 1000:
        res = {"kind": kind, "status": "too few rows", "k": None, "rows_discovery": int(len(disc)),
               "rows_confirmation": int(len(conf))}
        PC.write_json_atomic(res, fdir / "families.json")
        PC.write_json_atomic(res, fdir / "DONE.json")
        log("   too few rows for a family search - skipped (reported)")
        return res
    yrs = R["year"].to_numpy()
    sd = disc[year_balanced(t[disc], yrs[disc], int(F["sample"]), seed)]
    sc = conf[year_balanced(t[conf], yrs[conf], int(F["sample"]), seed + 1)]
    P = pca_fit(Xc[sd], float(F["pca_variance"]))
    Zd, Zc = pca_apply(P, Xc[sd]), pca_apply(P, Xc[sc])
    ss = year_balanced(t[sd], yrs[sd], int(F.get("stability_sample", len(sd))), seed + 2)   # positions in the sample
    Zs = Zd[ss]
    log(f"   sample {len(sd):,} discovery / {len(sc):,} confirmation paths ({len(ss):,} for the stability refits); "
        f"{P['n']} components keep {P['share'].sum():.1%} of the variation")
    tol = float(F.get("lloyd_tol", 0.0))
    ni, mi = int(F["n_init"]), int(F["max_iter"])
    vmax = float(F.get("separation_valley_max", 0.5))
    # ---------------- the k scan (resumable per k) ----------------
    kdir = fdir / "k_scan"
    kdir.mkdir(exist_ok=True)
    tot_ss = float(((Zd - Zd.mean(axis=0)) ** 2).sum())
    rs = None
    scan = []
    for k in range(int(F["k_min"]), int(F["k_max"]) + 1):
        kj = kdir / f"k{k:02d}.json"
        got = PC.read_json(kj)
        if got:
            scan.append(got)
            continue
        tk = time.time()
        c, lab, inertia = kmeans(Zd, k, seed + 100 * k, ni, mi, tol)
        if rs is None:
            rs = date_resample(t[sd][ss], int(F["stability_refits"]), int(D["atlas"]["boot_block"]), seed + 5)
        base_lab, _ = assign(Zs, c)
        aris = []
        for r, idx in enumerate(rs):
            cr, _, _ = kmeans(Zs[idx], k, seed + 100 * k + 1 + r, ni, mi, tol)
            lr, _ = assign(Zs, cr)
            aris.append(PC.ari(base_lab, lr))
        cc, _labc, _ = kmeans(Zc, k, seed + 100 * k + 50, ni, mi, tol)
        dist = np.sqrt(((c[:, None, :] - cc[None, :, :]) ** 2).sum(axis=2))
        pair = hungarian(dist)
        d_pair = dist[np.arange(k), pair]
        spread = np.array([np.sqrt(((Zd[lab == j] - c[j]) ** 2).sum(axis=1).mean()) if (lab == j).any() else np.nan
                           for j in range(k)])
        ratio = d_pair / spread
        share = np.bincount(lab, minlength=k) / len(lab)
        sep = separation(Zd, lab, c, int(F.get("separation_max_points", 20000)), seed + 9)
        vals_ = np.array([x["valley_ratio"] for x in sep])
        separated = bool(np.all(vals_ <= vmax))
        rec = {"k": k, "stability_mean_ari": float(np.mean(aris)), "stability_min_ari": float(np.min(aris)),
               "aris": [float(a) for a in aris], "repro_ratio": ratio.tolist(), "repro_max_ratio": float(np.nanmax(ratio)),
               "families_reproduced": int((ratio <= float(F["repro_max_ratio"])).sum()),
               "separation_worst_valley": float(np.nanmax(vals_)), "separation": sep, "separated": separated,
               "explained": float(1 - inertia / tot_ss) if tot_ss > 0 else float("nan"),
               "smallest_share": float(share.min()), "shares": share.tolist(), "seconds": round(time.time() - tk, 1)}
        rec["stable_reproduced"] = bool(rec["stability_mean_ari"] >= float(F["stability_min_ari"]) and
                                        rec["families_reproduced"] == k)
        rec["qualifies"] = bool(rec["stable_reproduced"] and separated)
        np.save(kdir / f"k{k:02d}_centres.npy", c)
        PC.write_json_atomic(rec, kj)
        scan.append(rec)
        log(f"   k={k:2d}: stability ARI {rec['stability_mean_ari']:.3f} (min {rec['stability_min_ari']:.3f}), "
            f"reproduced {rec['families_reproduced']}/{k} (worst {rec['repro_max_ratio']:.2f}), worst valley "
            f"{rec['separation_worst_valley']:.2f}, explains {rec['explained']:.1%}, smallest {rec['smallest_share']:.2%} -> "
            f"{'FAMILIES' if rec['qualifies'] else ('regions' if rec['stable_reproduced'] else 'no')} ({rec['seconds']:.0f} s)")
    S = pd.DataFrame([{k_: v for k_, v in r.items() if k_ not in ("aris", "repro_ratio", "shares", "separation")} for r in scan])
    PC.write_table(S, fdir / "k_scan_table")
    res: dict = {"kind": kind, "version": FAM_VERSION, "periods": {k_: [str(a), str(b)] for k_, (a, b) in per.items()},
                 "rows": int(len(R)), "rows_discovery": int(len(disc)), "rows_confirmation": int(len(conf)),
                 "sample_discovery": int(len(sd)), "sample_confirmation": int(len(sc)),
                 "pca": {"components": int(P["n"]), "variance_kept": float(P["share"].sum()),
                         "share": P["share"].tolist()},
                 "scan": S.to_dict(orient="records")}
    res["multimodality_pcs"] = [dict(pc=j + 1, **bimodality(Zd[:, j])) for j in range(min(3, Zd.shape[1]))]
    qf = S[S["qualifies"]]
    qr = S[S["stable_reproduced"]]
    if len(qf):
        k, unit = int(qf["k"].max()), "family"
        log(f"   chosen k = {k}: separated FAMILIES (the largest k that is stable, reproduced and separated)")
    elif len(qr):
        k, unit = int(qr["k"].max()), "region"
        log(f"   no k gives separated families; chosen k = {k} as PATH REGIONS (the largest k that is stable and "
            f"reproduced): a partition of a continuum, not distinct behaviours")
    else:
        res.update({"status": "no stable structure", "k": None, "unit": None})
        log(f"   NO STABLE STRUCTURE: no k from {F['k_min']} to {F['k_max']} is both stable (ARI >= "
            f"{F['stability_min_ari']}) and reproduced - cells are described by the measures alone")
        PC.write_json_atomic(res, fdir / "families.json")
        PC.write_json_atomic(res, fdir / "DONE.json")
        return res
    prefix = ("F" if unit == "family" else "R") if kind == "daily" else ("I" if unit == "family" else "J")
    c = np.load(kdir / f"k{k:02d}_centres.npy")
    lab_s, _ = assign(Zd, c)
    fam = np.full(len(R), -1, np.int8)
    lab_all, _ = assign(pca_apply(P, Xc[finite]), c)
    fam[finite] = lab_all
    PC.write_parquet_atomic(pd.DataFrame({"sym": R["sym"].astype(str), "t0": R["t0"], "fam": fam}), fdir / "assign.parquet")
    null_sep = None
    if len(N):
        XN = np.clip(N[spec["cols"]].to_numpy(np.float64), -cap, cap)
        okn = np.isfinite(XN).all(axis=1)
        nfam = np.full(len(N), -1, np.int8)
        ZN = pca_apply(P, XN[okn])
        nfam[okn], _ = assign(ZN, c)
        PC.write_parquet_atomic(pd.DataFrame({"sym": N["sym"].astype(str), "t0": N["t0"], "fam": nfam}),
                                fdir / "assign_null.parquet")
        # the same search on the random-walk paths at the chosen k: how separated are its groups?
        tn = PC.to_day(N["t0"])[okn]
        dn = np.flatnonzero((tn >= per["discovery"][0]) & (tn <= per["discovery"][1]))
        if len(dn) > 1000:
            dn = dn[year_balanced(tn[dn], pd.DatetimeIndex(tn[dn].astype("datetime64[ns]")).year.to_numpy(),
                                  int(F["sample"]), seed + 3)]
            cn, ln, inn = kmeans(ZN[dn], k, seed + 100 * k + 77, ni, mi, tol)
            sn = separation(ZN[dn], ln, cn, int(F.get("separation_max_points", 20000)), seed + 9)
            null_sep = {"k": k, "separation_worst_valley": float(np.nanmax([x["valley_ratio"] for x in sn])),
                        "separated": bool(all(x["valley_ratio"] <= vmax for x in sn)),
                        "explained": float(1 - inn / float(((ZN[dn] - ZN[dn].mean(axis=0)) ** 2).sum()))}
            log(f"   random-walk paths at k = {k}: worst valley {null_sep['separation_worst_valley']:.2f}, partition "
                f"explains {null_sep['explained']:.1%} (real: {next(r for r in scan if r['k'] == k)['explained']:.1%})")
    cent = np.array([Xc[sd][lab_s == j].mean(axis=0) for j in range(k)])
    raw_med = np.array([np.median(X[sd][lab_s == j], axis=0) for j in range(k)])
    names = unique_names([spec["name"](cent[j]) for j in range(k)], cent, spec["close_idx"])
    share = np.bincount(lab_s, minlength=k) / len(lab_s)
    spread = np.array([np.sqrt(((Zd[lab_s == j] - c[j]) ** 2).sum(axis=1).mean()) for j in range(k)])
    rec = next(r for r in scan if r["k"] == k)
    g_lab, g_ll, g_it = gmm_full(Zd, c, lab_s, int(F["gmm_max_iter"]), float(F["gmm_reg"]))
    cont = np.zeros((k, k))
    np.add.at(cont, (lab_s, g_lab), 1)
    pair = hungarian(-cont)
    agree = cont[np.arange(k), pair] / np.maximum(cont.sum(axis=1), 1)
    gm_ari = PC.ari(lab_s, g_lab)
    log(f"   Gaussian mixture check: ARI {gm_ari:.3f} with k-means; groups matched by the mixture: "
        f"{int((agree >= float(F['gmm_agree_min'])).sum())}/{k}")
    ci = spec["close_idx"]
    cmask = np.zeros(len(R), bool)
    cmask[conf] = True
    subs = []
    for j in range(k):
        bd, bc = bimodality(X[sd][lab_s == j, ci]), bimodality(X[cmask & (fam == j), ci])
        two = bool(bd.get("ok") and bc.get("ok") and bd["bic_prefers_2"] and bc["bic_prefers_2"] and
                   bd["ashman_d"] >= float(F["subfamily_min_ashman_d"]) and bc["ashman_d"] >= float(F["subfamily_min_ashman_d"]) and
                   bd["min_weight"] >= float(F["subfamily_min_weight"]) and bc["min_weight"] >= float(F["subfamily_min_weight"]))
        subs.append({"family": j, "two_peaks": two, "discovery": bd, "confirmation": bc})
    fams = []
    for j in range(k):
        fams.append({"family": j, "id": f"{prefix}{j + 1:02d}", "name": names[j], "share_discovery_sample": float(share[j]),
                     "minority": bool(share[j] < float(F["minority_share"])), "spread": float(spread[j]),
                     "repro_ratio": float(rec["repro_ratio"][j]), "valley_ratio": float(rec["separation"][j]["valley_ratio"]),
                     "gmm_agreement": float(agree[j]),
                     "method": "both" if agree[j] >= float(F["gmm_agree_min"]) else "k-means only",
                     "centre_capped": cent[j].tolist(), "centre_median_raw": raw_med[j].tolist(),
                     "two_peaks_in_close5": subs[j]["two_peaks"]})
    res.update({"status": "families found" if unit == "family" else "regions only", "k": k, "unit": unit,
                "prefix": prefix, "families": fams,
                "gmm": {"ari_vs_kmeans": float(gm_ari), "iterations": int(g_it), "mean_loglik": float(g_ll)},
                "random_walk_at_k": null_sep, "subfamilies": subs, "centres_pca": c.tolist(),
                "pca_mean": P["mean"].tolist(), "pca_comp": P["comp"].tolist(), "cap": cap,
                "seconds": round(time.time() - t0, 1)})
    for f_ in fams:
        log(f"   {f_['id']} {f_['share_discovery_sample']:6.2%}  {f_['name']}"
            f"{'  [minority]' if f_['minority'] else ''}{'  [k-means only]' if f_['method'] != 'both' else ''}"
            f"{'  [two peaks in the 5-day close]' if f_['two_peaks_in_close5'] else ''}")
    PC.write_json_atomic(res, fdir / "families.json")
    PC.write_json_atomic({"kind": kind, "status": res["status"], "k": k, "unit": unit, "seconds": res["seconds"]},
                         fdir / "DONE.json")
    log(f"[families/{kind}] done in {res['seconds']:.0f} s")
    return PC.read_json(fdir / "DONE.json")


def load_result(run_dir: Path, kind: str) -> dict:
    return PC.read_json(Path(run_dir) / "families" / kind / "families.json", {}) or {}
