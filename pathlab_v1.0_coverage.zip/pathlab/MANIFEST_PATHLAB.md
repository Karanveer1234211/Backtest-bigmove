# MANIFEST - pathlab v1.0 coverage release (25 Oct 2026)

Copy the whole folder to `C:\Users\karanvsi\PyCharmMiscProject\pathlab\`. Copy every file below; there is nothing to ignore.
Not shipped: `__pycache__`, `tests\fingerprint.json` (the tests write it).

| file | sha256 (first 16) | bytes | role |
|---|---|---|---|
| `pathlab.py` | fe28a1340af3c6c1 | 11,362 | command line (audit, coverage; the other stages refused until the freeze) |
| `pl_common.py` | cb887c64ed477692 | 20,047 | shared: declaration and lock, guards, ledger, date-block bootstrap, FDR, ARI |
| `pl_build.py` | 9c1f90e7047f04e2 | 48,137 | audit stage; market regimes, universe, picks (build stage: not runnable yet) |
| `pl_coverage.py` | d99c372eb4a1e11d | 17,260 | the outcome-blind coverage audit (NEW, change 2) |
| `pl_atlas.py` | 8f703e5cf63ce20f | 56,740 | cell statistics engine (coverage uses its bootstrap engine; the atlas stage is not runnable yet) |
| `pl_families.py` | 87c921002d59424c | 31,759 | family search (imported by pl_atlas; not runnable yet) |
| `pl_paths.py` | c1c6874f69688e38 | 22,228 | five-day path measures (imported; not runnable yet) |
| `pl_intraday.py` | d1860753b834e6f9 | 5,252 | 3-minute reader with tradelab's usable-session test (imported) |
| `pl_report.py` | e75a241fe927be0d | 50,605 | report writer (not runnable yet) |
| `PATHLAB_DECLARATION.json` | 8926588f3c08b74c | 11,288 | settings (DRAFT: the nine-change revision lands with the revised code) |
| `env_pathlab.bat` | 2172cf2cb353bd3a | 1,624 | session setup (CRLF): CACHE_DAILY_ROOT, PYTHONPATH, PATHLAB_OUT, TRADELAB_OUT |
| `README_PATHLAB.md` | 50b0256bac7c4622 | 3,135 | install, commands, what to send back |
| `tests/test_pathlab.py` | 28c02a513b41dea6 | 33,084 | tests (run: python tests\test_pathlab.py quick) |
| `tests/pl_world.py` | 6e84952a236f7f4e | 23,688 | synthetic worlds for the tests |

Requires tradelab v1.3.1 unchanged at `C:\Users\karanvsi\PyCharmMiscProject\tradelab\`. Tested here on two library sets: pandas 2.3.3 / numpy 2.4.1 (yours) and pandas 3.0.5 / numpy 2.5.3: quick suite 7 of 7 on both; build outputs identical by value.
