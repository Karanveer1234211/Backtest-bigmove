# tradelab v1.2.1 — every pick, trade by trade, with the market around it; a backtester and a trade simulator

tradelab sits **next to** `bigmove_deploy` (not inside it). It reads production data read-only — the cache, pick_meta's research run, `panel_oc`, the 3-minute bars, and stage E's lower-circuit rule — and writes only under `C:\QuantData\tradelab`. Nothing in production changes. D and ENS predictions are read as recorded (hash-checked) and the plan is recomputed and must match them.

| command | what it gives you |
|---|---|
| `tl_check.py` | a 30-second preflight: what tradelab sees on your PC (now also the index files, breadth stock count and AMFI lists), and the plan reproduced on 300 random picks |
| `tl_export.py` | every pick D and ENS made (ranks 1–10, 2020–2026) with its outcomes, day by day for sessions 0–5, **the market before and during each trade**, the research report, trade cards, a data dictionary |
| `tl_backtest.py` | any strategy on the picks, compared with the plan on the same picks (95% intervals), a money view — and in v1.1 the comparison and the money **by market environment**, and a before / after split date |
| `tl_sim.py` | one trade (or a few) replayed bar by bar: a written story (now opening with the market around the trade), every bar's values, a chart (now with NIFTY / Midcap / Smallcap beside the stock) |
| `tl_context.py` (v1.1) | `check` the market inputs · `build` the daily breadth once · `diary` one plain-English line per session |
| `tl_research.py` (v1.1) | re-run the research report on an export: winners vs losers vs severe losers, warning signs, walk-forward |
| `tl_cards.py` (v1.1) | trade cards for any selection (worst 20, a symbol, a day…) and the market diary for any dates |

## Install (once)

1. Copy the `tradelab` folder to `C:\Users\karanvsi\PyCharmMiscProject\tradelab` (beside `bigmove_deploy`, not inside it). For v1.1, replace the whole v1 folder (your outputs in `C:\QuantData\tradelab` are not touched).
2. Open `cmd`:
   ```
   call C:\Users\karanvsi\PyCharmMiscProject\tradelab\env_tradelab.bat
   pip install pypdf pdfplumber openpyxl reportlab
   python tests\test_tradelab.py
   ```
   It must end with `VERIFIED (tradelab v1.2.1)` (about 9–15 minutes). The test uses synthetic data only. `pypdf` / `openpyxl` read AMFI's lists; `pdfplumber` and `reportlab` are needed by the tests.
3. AMFI size lists (once, then one new file each January and July): see **Size class** below.
4. Preflight on your real data (reads only, about 30 seconds):
   ```
   python tl_check.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001
   ```
   It must end with `CHECK OK`. Warnings (a missing index file, a refused AMFI list) do not stop it — they say which columns will stay blank. If it prints `CHECK FAILED`, send me the whole output.

`env_tradelab.bat` runs your `env_daily.bat` (sets `CACHE_DAILY_ROOT`), puts `tradelab`, then `bigmove_deploy\open_close`, then `bigmove_deploy` on `PYTHONPATH`, and sets `TRADELAB_OUT=C:\QuantData\tradelab`. Every command needs `--root %CACHE_DAILY_ROOT%` (no silent default path) and, except `tl_context.py`, `tl_cards.py` and `tl_research.py`, `--pm-run PM_20261017_001`.

## 1. Export every pick

```
python tl_export.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001
```
Options: `--engines D ENS` · `--ranks 1-10` (default; `1-3` = the traded picks) · `--from 2020-01-01 --to 2026-09-30` · `--features all|none|D_rsi14,D_atr_pct` · `--features-csv` · `--bars3 D-20240425-2,ENS-20250102-1` or `--bars3 traded` · `--no-benchmark` · v1.1: `--context full|saved|indices|none` (default `full`: indices + AMFI + breadth; `none` = exactly v1's files) · `--amfi-dir <folder>` · `--cards 5` (sample cards: best and worst 5 per engine; 0 = none).

**Safety stop.** The plan (buy the session-1 open, sell the session-5 close, a locked close sells at the first unlocked open within 20 sessions, 35 bp) is recomputed from the bars for every pick and must match pick_meta's recorded status and net to 1e-9 for at least 99.5% of each engine's picks, with the mean net within 0.01 bp. Otherwise the run writes only `STOPPED.txt` and `reconcile_mismatches.csv` — send me that CSV.

Files in `C:\QuantData\tradelab\export\TLX_YYYYMMDD_NNN\` — **start with `report.md`, then `research\research_report.md`, then `cards\cards_sample.html`.**

| file | one row per | main columns |
|---|---|---|
| `trades` | pick | identity (trade_id, engine, rank, traded, overlaps, repeat_of), forecasts (prob_*, pred_*), the plan's outcome (entry, exit, exit_kind, locked_exit, net_bp, win), path outcomes (mfe, mae and their sessions, `touch_*`, `close_ret_s1..s5`, `open_ret_s2..s6`), alternatives (`open6_net_bp`, `hold10_net_bp`), the record and `matches_record`, buy-everything that day (`mkt_net_bp`) and `excess_bp`; v1.1: every `pre_*` and `post_*` column (below), `outcome` (winner / loser / severe_loser) and `story` (the trade in one sentence) |
| `trade_days` | pick × session 0–5 (longer for a locked exit) | daily OHLCV, `ret_*_vs_entry`, `day_ret`, `gap`, `range_pct`, `clv`, `vol_ratio20`, `atr_ratio`, `rel_nifty_day`, `held_at_close`, `day_pnl_bp`, `cum_pnl_bp` (ends at net_bp), `mfe_sofar`, `mae_sofar`, `after_exit`; v1.1: Midcap / Smallcap day returns, VIX, breadth, environment and stress that session, the home index's day, `rel_home_day`, and each held day split into `mkt_part_day_bp` + `stock_part_day_bp` with a `market_line` in words |
| `trade_day_features` | pick × session 0–5 | every allowed panel feature at that session's close |
| `daily_book` | engine × session | positions open, new, exits, the book's day P&L (1/15 of capital per slot — a proxy) and its running total |
| `trade_bars_3m` | 3-minute bar (chosen trades) | OHLCV, VWAP, cumulative volume, return vs entry and vs the previous close, session high / low so far |
| v1.1 `market_days` | session | everything below for every session of the export's span, plus `summary` (the day in one sentence) and `missing` |
| v1.1 `market_diary.md` | session | one plain-English line per session, by month |
| v1.1 `context_breakdown.csv` | engine × market dimension × bucket | trades, mean net with its 95% interval, win rate, severe-loser rate, market part, stock part |
| v1.1 `research\` | — | `research_report.md` (verdict first), `outcome_groups.csv`, `outcome_profiles.csv`, `warning_signs.csv`, `walk_forward.csv`, `walk_forward_verdicts.csv`, `book_by_environment.csv`, `severe_losers.md/.html` (a card for each of the worst trades), `research_summary.json` |
| v1.1 `cards\` | — | `cards_sample.md/.html`: the best and worst trades told as a chain |
| v1.1 `DATA_DICTIONARY.md`, `data_dictionary.csv` | column | every column of every table: meaning, unit, and **when it is known** (at the pick / that day / after entry) |

## 2. The market around every trade (v1.1)

The chain for each pick: **what the market did on the session before the pick → the pick (its rank) → what the market and the stock did on the signal day → what they did during the hold.** Everything is point in time: a value for day *d* uses bars up to *d*'s close and nothing later (tested by scrambling every later bar: no earlier value changes).

**Before entry vs after entry — the column names say which.**
- `pre_*` = known at the signal-day close, before the entry (the pick day's market, the previous session's market, the stock's size class, beta, correlation, home index). A rule, filter or sizing expression may use these.
- `post_*` = observed after the entry (the entry day's gap, the market over the hold, the market / stock split of the result). For understanding only: **a rule that names a `post_*` column is refused.**

**What is measured** (definitions declared 24 Oct 2026, before any real run — fixed in `tl_context.py`, never tuned on results):

| category | values | how |
|---|---|---|
| market direction | NIFTY 50, NIFTY Midcap 150, NIFTY Smallcap 250: day return, gap, open-to-close, 5- and 20-day return, close vs its 50-day average, the day's move in standard deviations (of the previous 60 days) | the cache's `NIFTY50`, `NIFTYMIDCAP150`, `NIFTYSMLCAP250` daily files |
| divergence | NIFTY minus Midcap, NIFTY minus Smallcap, the day and 20 days (> 0 = NIFTY ahead = a narrow market) | |
| breadth | advancers / (advancers + decliners), and its 10-day average | counted over **every stock in your cache** that traded that day (unchanged stocks left out); `ad_n` = how many. Not NSE's official count: stocks delisted before the cache was built are missing (survivorship) |
| volatility | India VIX level, day change, 5-day % change, percentile within its last 250 sessions | the cache's `INDIAVIX` daily file |
| size class | large / mid / small, AMFI rank | AMFI's official half-yearly lists only (below) |
| sensitivity | beta and correlation of the stock to each of the three indices over the 120 sessions up to the pick (≥ 60 returns); home index = the one it correlates with most | |
| environment | one readable label a day | below |

**Environment labels** (an index is *up* when it closes at or above its 50-day average; breadth = the 10-day average A/D):

| label | rule |
|---|---|
| Broad bullish | NIFTY, Midcap and Smallcap all up, and breadth ≥ 0.50 |
| Narrow bullish | NIFTY up, but Midcap or Smallcap down, or breadth < 0.50 |
| Broad bearish | all three down, and breadth < 0.50 |
| Mixed / ranging | anything else |
| **High stress** | a **separate flag** that can sit on top of any of the above: VIX at or above the 90th percentile of its last 250 sessions, or VIX up 25%+ in 5 sessions, or a NIFTY or Smallcap day move of 2.5 standard deviations or more. `high_stress` = 1 / 0 / blank (unknown); `stress_reason` says which fired. The five-label `environment` = High stress when the flag is on, else the direction |

**Missing data is never filled.** A missing index file, a missing day or too little history leaves the value blank; `missing` names what was missing. The labels are blank when an input they need is blank. The stress flag is 1 if any condition fired; otherwise blank (not 0) when an input was missing.

**The split of each result.** Market part = the stock's beta to its home index × the home index's move over exactly the same hold; stock part = the rest (`post_mkt_part_bp` + `post_stock_part_bp` = gross). `post_driver` says which dominated (market, stock, both, opposite, flat). The same split is done day by day in `trade_days`. This answers "NIFTY was up 1% but my pick fell 2% — was it Smallcap?": the card shows the home index, its move, and the split.

**Size class (AMFI, point in time).** SEBI's large (ranks 1–100), mid (101–250) and small (251+) by AMFI's six-monthly average market cap list. Download the lists from AMFI's *Categorisation of Large, Mid and Small Cap Stocks* page — the **Excel (.xlsx)** files are the most reliable to read (PDF also works) — for every half-year from **Jan–Jun 2019** to **Jan–Jun 2026** (15 files), and put them, names unchanged, in
```
%CACHE_DAILY_ROOT%\sectors\amfi\
```
Each list is used from **1 Feb / 1 Aug** — the 1st of the second month after its half-year. That is an assumed, conservative availability date, not AMFI's publication date (lists were reported on 5 Jan 2021 and by 9 Jul 2025; funds realign within a month). If you know the real dates, put them in `amfi_published.csv` in the same folder (`file,published` with `YYYY-MM-DD`): that list is then used from the next day. A list stays in force **until the next half-year's list starts**. Before the first list, or for a half-year whose list is missing, the class is `no list` (blank) — an older list is never carried on; a stock the list does not name is `not in list`. A renamed stock (e.g. an old symbol in the 2023 list) is found by its company's ISIN; the class always comes from the list in force that day. Every list is checked when read (ranks 1–250 present, categories agree with the rank cut-offs, NSE symbols found) and **refused** otherwise — `tl_check` shows each file's status, warns about a missing half-year, and says how many of your cached stocks the latest list covers. Add each new list when AMFI publishes it (next: Jul–Dec 2026, early January 2027).

**Breadth** is counted once and saved under `C:\QuantData\tradelab\context\` (the export does it; `python tl_context.py build --root %CACHE_DAILY_ROOT%` refreshes it after a cache update). The backtester and simulator reuse the saved copy (`--context auto`); days after it are blank and they say so.

**The diary.** `python tl_context.py diary --root %CACHE_DAILY_ROOT% --from 2024-06-01 --to 2024-06-30` prints and saves one line per session. The format (this line is from the synthetic test world, so its numbers are not real): *"Tue 07 Mar 2023: NIFTY -0.8%, Midcap -1.0%, Smallcap -1.3%; NIFTY minus Smallcap +0.5 pts (20-day -0.8 pts); breadth 0.18 (11 up / 50 down of 61; 10-day 0.42); VIX 19.4 (day +9.4%, 5-day -1.9%, 79th percentile); environment: Broad bearish."*

## 3. Research: what goes with the worst losses (v1.1)

The question: **can we identify the market conditions associated with D/ENS's worst losses before entering those trades, and reduce drawdown without destroying the existing edge?** The export answers it with `research\research_report.md` (or re-run on an export: `python tl_research.py --export C:\QuantData\tradelab\export\TLX_...`). Everything here was declared on 24 Oct 2026, before any real run, and is logged in the ledger before the result.

- **Groups** (per engine, ranks 1–3 traded): winner (net > 0), loser (−500 < net ≤ 0), **severe loser (net ≤ −500 bp)** after the 35 bp cost. `outcome_profiles.csv` compares the three groups on every `pre_*` value (what was known before entry) and on the `post_*` values (what happened during the hold).
- **Warning signs** — each is a condition known before entry, tested on winners **and** losers: how many flagged trades, how many severe losers caught, **how many winners it would also have skipped**, the P&L change if flagged trades were skipped, the difference in mean net (flagged − unflagged) with a 95% interval, and the book's worst drawdown with and without them.

  | id | warning sign (at the signal-day close) |
  |---|---|
  | W1 | high stress |
  | W2 | broad bearish |
  | W3 | narrow bullish |
  | W4 | weak breadth: 10-day A/D below 0.40 |
  | W5 | VIX up 15% or more in 5 days |
  | W6 | Smallcap fell 1.5% or more on the pick day |
  | W7 | NIFTY ahead of Smallcap by 3 pts or more over 20 days |
  | W8 | high-beta pick: beta to its home index 1.5 or more |
  | ANY | any of the above |

- **Walk-forward (chronological, out of sample; v1.2 rules).** For each year, a sign *qualifies* only on trades that had **actually exited before 1 Jan of that year** (purged), comparing flagged vs **known** unflagged trades (a blank input is left out and never flags), with ≥ 30 flagged trades on ≥ 20 days and a one-sided bootstrap **p ≤ 0.05 / 8** (Bonferroni over the 8 signs, 10,000 resamples). Skipping it is then judged on that year alone in the **money view**: the plan's own fills, compounded and cash-limited (₹10 lakh, 1/15 of equity a position, integer shares, flat 35 bp), skipped money left in cash, fresh capital each year. A sign is a **CANDIDATE for a stage E replay** only if it qualified in at least 2 years and, over those years, skipping it did not lower the money view's return and improved the year's worst drawdown in at least half. The money view is tradelab's simulator, **not** stage E's execution backtest (the −47.64% baseline): the −25% target can only be judged in a stage E replay.
- **The book by environment** (`book_by_environment.csv`): days, total return, worst drawdown inside, average / maximum positions — each day labelled with the environment known at the previous close.

**Nothing filters trades automatically.** A CANDIDATE is a hypothesis: replay it in stage E's simulator, then a declared forward paper test. Re-running the research on an older export needs the cache: `python tl_research.py --export C:\QuantData\tradelab\export\TLX_... --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001`. The month-6 checkpoint (2027-03-31) of the paper ledger is still the judge.

## 4. Backtest a strategy

```
python tl_backtest.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --strategy strategies\scale_20_80_vwap.py
```
Options: `--compare auto` (default: the plan on the same picks and clock) or another strategy file · `--values rvol,clv,D_rsi14` · `--engines`, `--ranks`, `--from`, `--to` · `--capital 1000000` · `--no-portfolio` · `--timeline D-20240425-2,...` · `--tag "what I am trying"` · `--declare "PASS if the paired lower bound > 0"` · `--list-names` · v1.1: `--context auto|full|saved|indices|none` · `--split-date 2024-01-01` (the comparison and the money view before and from that date — write the date down before you run).

The report leads with the verdict: the strategy's mean net per pick slot, the plan's on the **same** picks, and the paired difference with its 95% interval (circular blocks of 10 signal days, 2,000 resamples, seed 7) → BETTER / WORSE / NOT SHOWN. Then fills, exits, MFE/MAE, by year / engine / rank, the money view (CAGR, worst drawdown with dates, Sharpe, exposure, skipped trades), and in v1.1: **where the strategy helps or hurts** — the paired difference by the market at the pick (`context_breakdown.csv`) and the money by environment (`money_by_environment.csv`: return, worst drawdown, worst / best day, positions and exposure by environment, strategy and comparison side by side).

**Discipline.** Every backtest is logged in `C:\QuantData\tradelab\tradelab_ledger.jsonl` *before* it runs (with your `--declare` rule) and again with its result; the report says how many backtests and distinct strategies the ledger holds. With 20 variants on the same years, one will look BETTER by luck. A strategy found here is a hypothesis until a declared rule passes on the forward paper ledger.

## 5. Simulate single trades

```
python tl_sim.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --trade D-20240425-2 --strategy strategies\scale_20_80_vwap.py --strategy strategies\plan.py
python tl_sim.py --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001 --symbol RELIANCE --signal-day 2024-04-25
```
Add `--values rvol,clv,rel_nifty_day,D_rsi14,prob_big,ad_ratio,small_prev_ret` to record any value on every bar of the timeline.

Writes, per trade and strategy: `*_story.md` (v1.1: opens with the market around the trade — the session before, the signal day, each session held — and the market / stock split; then every buy / sell with its reason), `*_timeline.csv` and `<trade>_chart.html` (v1.1: a second panel with the stock against NIFTY, Midcap and Smallcap from the signal-day close). Same engine as the backtester — identical numbers.

## 6. Trade cards and the diary (v1.1)

```
python tl_cards.py --export C:\QuantData\tradelab\export\TLX_20261024_001 --worst 20 --engine D
python tl_cards.py --export C:\QuantData\tradelab\export\TLX_20261024_001 --symbol RELIANCE
python tl_cards.py --export C:\QuantData\tradelab\export\TLX_20261024_001 --day 2024-06-04
python tl_cards.py --export C:\QuantData\tradelab\export\TLX_20261024_001 --where "pre_high_stress == 1 and outcome == 'severe_loser'"
python tl_cards.py --export C:\QuantData\tradelab\export\TLX_20261024_001 --diary 2024-06-01 2024-06-30
```
Each card (Markdown and HTML) opens with the trade in one line (rank, size class, home index and beta) and has four parts: **1. The market before entry** (the session before and the signal day, the stock's own move, the warning signs that fired), **2. What the model expected** (pick_meta's forecasts), **3. Day by day: the stock next to its market** (NIFTY, Midcap, Smallcap, breadth, VIX, environment, the stock against its home index, and each held day's market / stock part), **4. Verdict** (entry and exit, net, the split, what drove it). Other selectors: `--trade`, `--best N`, `--ranks 1-3`, `--from/--to`, `--max`, `--name`.

## Writing strategies

A strategy is a Python file with a `STRATEGY` dict (or JSON). Start from a file in `strategies\`:

| file | idea |
|---|---|
| `plan.py`, `plan_intraday.py` | the paper test's plan (daily / on the 3-minute clock) |
| `open6.py` | sell at the 6th open |
| `scale_20_80_vwap.py` | 20% at the open, 80% when a 3-minute close crosses above VWAP (sessions 1–2, 09:30–14:30) |
| `orb_add_on.py` | 50% at the open, 50% on a buy stop at the 15-minute opening-range high |
| `dip_or_fallback.py` | limit 1% under the open until 11:00, else buy at 11:00 |
| `half_target_stop.py` | half at +5%, stop at −8%, rest at the 5th close |
| `trail_after_5pct.py` | trail 4% under the highest high once MFE ≥ 5%, hold up to 10 sessions |
| `filtered_rsi_entry.py` | skip picks with P(stuck) ≥ 10%; buy only if RSI(14) at the signal close < 70 (a panel feature) |
| `weak_close_exit.py` | sell after 14:30 in sessions 2–4 if under VWAP and down 3%+ (with a plugin) |
| v1.1 `hypo_skip_smallcap_fall.py` | **a hypothesis to test, not a rule to trade**: the plan, skipping picks made on a day Smallcap fell 1.5%+ (warning sign W6); run it with `--split-date` |

```python
STRATEGY = {
    "name": "my_idea",
    "mode": "intraday",               # "daily" = one bar a session; "intraday" = 3-minute bars (Oct 2021 on)
    "picks": {"engines": ["D"], "ranks": [1, 2, 3], "from": None, "to": None, "filter": "prob_trap < 0.10"},
    "max_sessions": 5,                # the trade ends at this session's close at the latest
    "warmup_sessions": 1,             # sessions before the signal day loaded for indicators (daily default 30)
    "events": {"reclaim": "crosses_above(close, vwap)"},          # named conditions, usable anywhere
    "entries": [
        {"name": "first", "size": 0.2, "at": "open", "session": 1},                       # official open
        {"name": "add", "size": 0.8, "when": "reclaim", "sessions": [1, 2], "time": ["09:30", "14:30"]},
        # fill: "next_open" (default) | "stop" / "limit" (with "level": "...") | "close" (needs same_bar_close_fills)
        # "cancel_if": "..." cancels a waiting leg for good
    ],
    "exits": [
        {"name": "stop", "type": "stop", "level": "avg_entry * 0.95"},           # sell stop (gap -> the open)
        {"name": "tgt", "type": "target", "level": "first_entry * 1.10", "size": 0.5},
        {"name": "trail", "type": "trail", "pct": 0.04, "activate": "upnl > 0.03"},  # or "atr": 2.0
        {"name": "weak", "type": "signal", "when": "close < vwap and upnl < -0.02", "sessions": [2, 4]},
        {"name": "time", "type": "time", "at": "close", "session": 5},           # "at": "open" for an open exit
    ],
    "intrabar": "worst",              # stop and target in one bar: worst | best | intraday (daily mode)
    "costs": {"model": "flat", "round_trip_bp": 35},   # or per_side (buy_bp, sell_bp) or zerodha (itemised)
    "slippage_bp": 0,                 # added against you on every fill
    "sizing": {"rule": "equal_slots", "slots": 15, "max_pct": 0.25},
    "portfolio": {"capital": 1000000, "integer_shares": True, "min_order_frac": 0.25,
                  "max_new_per_day": None, "max_open": None, "allow_duplicates": True},
    "decision_rule": {"metric": "diff_mean_bp", "pass_if": "lower > 0"},
    "plugins": ["example_plugin.py"],
}
```

**Timing rules (no look-ahead).** A rule checked at a bar's close acts at the next bar's open. Stop / limit / trail levels are computed at the previous bar's close (state-based levels such as `avg_entry * 0.95` are refreshed right after fills at a bar's open) — so inside a level, `low` means the low of the bar before, and `opening_range_high(5)` is blank until the session's 5th bar (give such orders a `time` window that starts after the range). `at: open/close` orders use the session's official open / close. A window (`sessions`, `time`) applies to the bar where the order fills. An entry filled inside a bar cannot exit inside that same bar. A level built on today's open is valid from the second bar on (`time` starting 09:18).

**Sizes.** Entry sizes are fractions of the trade's target size; P&L is measured on the full target, so an unfilled leg counts as cash. Legs may add up to more than 1.0 when they are alternatives — a buy is clipped so the position never exceeds the target. Exit sizes are fractions of the position held.

**Sizing rules** (`sizing.rule`): `equal_slots` (equity / slots), `pct_equity` (`pct`), `fixed` (`amount`), `atr_risk` (`risk_pct`, `atr_mult`: risk_pct × equity / (atr_mult × the stock's ATR14% on the signal day)), `expression` (any rule over `equity`, `cash`, `open_positions`, `signal_atr14_pct` and pick attributes, e.g. `"equity / 15 * min(1.5, 0.03 / signal_atr14_pct)"`). Caps: `max_pct` of equity, `liquidity_cap` (share of the 20-session median turnover), `min_notional`.

**What a rule can use** — run `python tl_backtest.py --list-names --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001`:
- bar: `open high low close volume typical hl_range body upper_wick lower_wick clv bar_ret`
- clock: `session` (0 = signal day, 1 = entry day) `bar_in_session minute hhmm is_first_bar is_last_bar weekday sessions_left`
- session: `vwap` (3-minute only) `session_open session_high session_low session_volume day_ret gap prev_close prev_open prev_high prev_low prev_volume dist_prev_high dist_prev_low entry_open signal_close ret_vs_entry_open`
- daily context: `atr14 atr14_pct vol_med20 rvol nifty nifty_day_ret rel_nifty_day nifty_ret5` (values known when the rule is checked)
- v1.1 market context: `mid_day_ret small_day_ret` (daily mode; blank intraday — no 3-minute Midcap / Smallcap index), `nifty_prev_ret mid_prev_ret small_prev_ret` (the session before), `nifty_minus_mid_20 nifty_minus_small_20 ad_ratio ad_ratio_10 vix vix_chg_pct vix_chg5_pct vix_pct250 env_code high_stress` — in daily mode the bar's own session (checked at its close), in intraday mode the last completed session. `env_code`: 0 broad bullish, 1 narrow bullish, 2 mixed, 3 broad bearish
- pick attributes (constant per trade): `rank score other_rank both_engines repeat engine_D s_atr14 prob_* pred_*`, and v1.1 every numeric `pre_*` value (e.g. `pre_small_ret pre_high_stress pre_env_code pre_ad_ratio_10 pre_vix_chg5_pct pre_beta_home pre_size_class_num pre_amfi_rank`) — usable in `picks.filter`, rules and sizing
- panel features by name (daily values; in intraday mode the previous session's)
- trade state: `pos in_pos avg_entry first_entry upnl upnl_first mfe_sofar mae_sofar peak_close bars_in_trade sessions_in_trade legs_filled exits_done realized filled_<leg>`
- functions: `shift prev sma/mean ema rsi std zscore highest lowest roc change rsum crosses_above crosses_below rising falling bars_since held_for count_true trade_max trade_min session_max session_min session_sum session_first prev_session opening_range_high opening_range_low` and `abs min max log exp sqrt sign round clip where isnan nz`
- operators: `+ - * / ** % //`, comparisons (chains allowed), `and or not`, `x if cond else y`

A blank value is false in a condition: `pre_small_ret > -0.015` also skips picks whose Smallcap return is unknown; `not (pre_small_ret <= -0.015)` keeps them.

Refused: `label_*` and forward-looking names (the firewall), **`post_*` (observed after entry)**, `shift(x, -1)`, attributes, indexing, strings, lambdas, imports.

**Your own values and functions** — copy `plugins\example_plugin.py`:
```python
from tl_rules import variable, function

@variable("vol_surge", "bar volume / mean of the previous 20 bars")
def vol_surge(ctx):                       # ctx.open/high/low/close/volume, ctx.var("vwap"), ctx.daily, ...
    v = pd.Series(ctx.volume)
    return (v / v.shift(1).rolling(20, min_periods=20).mean()).to_numpy(float)
```
List it in the strategy (`"plugins": ["my_plugin.py"]`). tradelab recomputes every plugin value with the later bars removed and refuses the run if anything earlier changes.

## Limits

- 3-minute bars start Oct 2021: intraday strategies skip earlier picks (`no_intraday`); the plan comparison uses the same picks.
- Exits are decided on the planned position; if cash trims a leg in the money view, the shares held follow the same exit decisions (counted in the report).
- Not modelled: buys at an upper-circuit lock, partial fills, impact beyond the cost model. VWAP is computed from 3-minute bars (typical price × volume), close to — not identical with — the exchange VWAP.
- v1.1 breadth is counted over your cache, not NSE's official advance / decline (coverage and survivorship differ; `ad_n` shows the count each day). Midcap / Smallcap / VIX values exist only where the cache has their daily files; intraday rules cannot see a same-day Midcap / Smallcap move.
- v1.1 AMFI classes exist only from the first list you add; the half-year a list covers comes from its title or file name.
- Results on 2020–2026 are the same history the engines were built and studied on: descriptive, not new evidence. The warning signs and walk-forward use that same history — a CANDIDATE is a hypothesis for the forward paper test, nothing more.

## Changelog

**v1.2.1 — 24 Oct 2026 (after the first real run):** beta and correlation use only returns between consecutive sessions. A return across a gap in a stock's bars (a suspension, or a stale bar long before listing) is no longer one giant data point: on your data it had given AVALON a beta of 1,152.5 and pushed ENS's average 'market part' to +111.3 bp.

**v1.2 — 24 Oct 2026: fixes after a review** (research-declaration-2, declared before any real run)
- Walk-forward training is **purged**: a test year qualifies signs only on trades whose actual exit (incl. lower-circuit delays) came before 1 Jan of that year. v1.1 used every trade signalled earlier, so late-December trades brought January outcomes into the decision.
- **Blank inputs** are left out of both sides of each comparison and counted (`unknown`). v1.1 counted them as unflagged in the statistic but not in the displayed mean.
- **Multiplicity:** qualification needs a one-sided bootstrap p ≤ 0.05 / 8 (Bonferroni, 10,000 resamples) instead of each sign's own 95% interval.
- **Drawdown and return** in the research come from the plan's compounded, cash-limited money view, not the additive 1/15 proxy; the verdict is now "CANDIDATE for a stage E replay", because tradelab's money view is not stage E's simulator.
- **Portfolio fix (present since v1):** the running peak now starts at the starting capital. Before, a loss ahead of the first new high (₹100 → ₹90 on day 1) showed 0% drawdown in the backtest / sim money view.
- **AMFI timing:** lists are used from 1 Feb / 1 Aug (assumed, disclosed), or from the day after an actual publication date given in `amfi_published.csv`; v1.1 assumed 10 days.
- `tl_research.py` needs `--root` and `--pm-run` to rebuild the money view for an older export.

**v1.1 — 24 Oct 2026: the market intelligence layer** (an observation and investigation tool; nothing filters trades automatically)
- New `tl_context.py`: NIFTY 50 / Midcap 150 / Smallcap 250 direction, divergence, breadth (A/D over the cached stocks), India VIX, AMFI size class (point in time, lists expire after their half-year, renamed stocks via ISIN, malformed lists refused), beta / correlation to the three indices with a home index, and the declared environment labels with High stress as a separate flag. Missing inputs stay blank and are named; nothing is filled.
- Every pick gets `pre_*` (known before entry) and `post_*` (after entry) context; `trade_days` gets the market each session and the daily market / stock split; new `market_days`, `market_diary.md`, `context_breakdown.csv`.
- New `tl_research.py`: winners / losers / severe losers, warning signs W1–W8 tested on winners as well as losers, chronological walk-forward by year, the book by environment — declared before any real run and logged before its result.
- New `tl_cards.py` (trade cards, diary) and `tl_dictionary.py` (every column documented with its unit and when it is known: `DATA_DICTIONARY.md`).
- `tl_backtest.py`: `--context`, `--split-date` (chronological before / from view), the paired difference by market condition, `money_by_environment.csv`. `tl_sim.py`: the market around the trade in the story and an index panel in the chart.
- Rules: 15 market-context values, every numeric `pre_*` value as a pick attribute; `post_*` names refused.
- **Fix (portfolio, present since v1):** a trade whose every buy leg cash could not fund stayed "open" with no shares until the end of the run. That inflated `n_open` and `trades_opened`, fed a wrong `open_positions` to expression sizing, and — with `max_open` or `allow_duplicates: False` — blocked later trades (in a test world with ₹30,000 and `allow_duplicates: False`, v1 held 839 trades and reported 21 unfunded ones as opened; v1.1 holds 1,055). Now such a trade is reported as skipped (`skip_reason` = `cash`) and is never an open position. With the default portfolio settings the equity and P&L were not affected.
- Tests: sections 10–13 (`tests/test_context.py`, worlds in `tests/tl_ctx_world.py`); new example `strategies/hypo_skip_smallcap_fall.py`; tl_check lists the index files, breadth count and AMFI lists.

**v1 — 24 Oct 2026:** first release — export of every pick with day-by-day outcomes, the rule language, the trade engine, the backtester with paired intervals and a money view, the trade simulator.
