# MANIFEST - tradelab v1.2.1

Built 2026-10-24. Folder: C:\Users\karanvsi\PyCharmMiscProject\tradelab (beside bigmove_deploy, never inside it). Outputs: C:\QuantData\tradelab. Production files are read, never written. 'tradelab v1' = unchanged since the v1 bundle (a6cbcd209f3bc759); v1.1 = unchanged since the v1.1 bundle (14584256599dd3aa); v1.2 = unchanged since the v1.2 bundle (9352fdf46e7cdfcb); v1.2.1 = changed in v1.2.1.

| file | version | sha256 (first 16) | role |
|---|---|---|---|
| README_TRADELAB.md | tradelab v1.2.1 | 365968800099662a | how to install, run, read the market layer, write strategies; changelog |
| env_tradelab.bat | tradelab v1 | fc1a395d0e460583 | start a session: env_daily.bat, PYTHONPATH (tradelab, open_close, bigmove_deploy), TRADELAB_OUT (CRLF) |
| plugins/example_plugin.py | tradelab v1 | 52b7f8a1462d4a50 | example plugin: vol_surge, range_pos20, above_for() |
| strategies/dip_or_fallback.py | tradelab v1 | fce97d839c256931 | example strategy |
| strategies/filtered_rsi_entry.py | tradelab v1 | af30c8ad09315f78 | example strategy |
| strategies/half_target_stop.py | tradelab v1 | 8f5ebeb98f88cf03 | example strategy |
| strategies/hypo_skip_smallcap_fall.py | tradelab v1.1 | e0f3691f06adfaed | example HYPOTHESIS (not a rule): the plan skipping W6 picks; run with --split-date |
| strategies/open6.py | tradelab v1 | 86a67db320a11d6f | example strategy |
| strategies/orb_add_on.py | tradelab v1 | e7ac4b38b71d56da | example strategy |
| strategies/plan.py | tradelab v1 | 98481fc8789d03e3 | example strategy |
| strategies/plan_intraday.py | tradelab v1 | fca2e77d51d4af68 | example strategy |
| strategies/scale_20_80_vwap.py | tradelab v1 | 629d2b225be2814a | example strategy |
| strategies/trail_after_5pct.py | tradelab v1 | cc08706cd7df6fd6 | example strategy |
| strategies/weak_close_exit.py | tradelab v1 | 64f072d7314c6535 | example strategy |
| tests/test_context.py | tradelab v1.2.1 | 4a8baa02216deaae | sections 10-13: the market layer by hand, point in time, research, integration |
| tests/test_tradelab.py | tradelab v1.2.1 | 4361fd06a459a5a3 | the test suite, sections 1-13 (must end VERIFIED (tradelab v1.2.1)) |
| tests/tl_ctx_world.py | tradelab v1.1 | 887f935958821722 | synthetic worlds with planted size / index structure and AMFI lists (CSV / Excel / PDF) |
| tests/tl_world.py | tradelab v1 | d70cd0564be62ba0 | synthetic worlds + stand-in production modules for the tests |
| tl_backtest.py | tradelab v1.1 | 4570b637fc1d229e | COMMAND: a strategy vs the plan on the same picks, paired 95% intervals, money view, by market environment, --split-date, ledger |
| tl_cards.py | tradelab v1.1 | 9b3d39dbc1c0cad1 | COMMAND: trade cards (known before entry / forecasts / day by day / verdict) and the market diary |
| tl_check.py | tradelab v1.1 | c6200aefef157235 | COMMAND: 30-second preflight on real data (reads only), incl. index files, breadth count, AMFI lists |
| tl_common.py | tradelab v1.2.1 | d63bed224a2a83aa | versions, path guards (never writes into the cache or production), hashing, tables, ledger, block bootstrap |
| tl_context.py | tradelab v1.2.1 | c3e65f0fa44e2467 | COMMAND + library: the market layer - indices, divergence, breadth, VIX, AMFI size, beta / correlation, declared environment labels, pre_/post_ context |
| tl_data.py | tradelab v1.1 | 46ceff88fdadda7f | read-only production access: picks (pick_meta run, hash-checked), daily bars + lock rule (stage E), calendar, 3-minute sessions, panel features (label firewall) |
| tl_dictionary.py | tradelab v1.2 | ef652eaeeb934bb5 | the data dictionary: every column's meaning, unit and when it is known |
| tl_engine.py | tradelab v1.1 | f0601965341a62b7 | strategies and the bar-by-bar trade engine (fills, intrabar policy, honest exits, path, timeline); market-context rule values |
| tl_export.py | tradelab v1.2 | b2fcf8ba7ad25f7a | COMMAND: every pick with outcomes, day by day, the market around it, research, cards, dictionary; reconcile safety stop |
| tl_portfolio.py | tradelab v1.2 | b15f0570f3aca067 | the money layer: sizing rules, capital, cash, integer shares, limits, equity, drawdown (v1.1: unfunded trades are skipped, not open) |
| tl_research.py | tradelab v1.2 | 2293435c77f7332b | COMMAND + library: winners / losers / severe losers, warning signs W1-W8, purged walk-forward with Bonferroni, money-view returns and drawdowns (research-declaration-2) |
| tl_rules.py | tradelab v1.1 | 0ff123752954d1f6 | the rule language: safe expression compiler, values, functions, events, plugins; post_* refused |
| tl_run.py | tradelab v1.1 | 69087dd69bff5873 | one run's data and simulation, symbol by symbol (memory stays flat); market context per run |
| tl_sim.py | tradelab v1.1 | 2b1f78d86b1841cb | COMMAND: replay trades bar by bar: story (with the market around the trade), timeline, chart (with index panel) |

Read-only production dependencies (on your PC, unchanged): bigmove_deploy\open_close\stage_e_execution.py (v1.2, 158883f0af70728d - checked at start; --stage-e-any to accept another), EXECUTION_DECLARATION.json, intraday_cache.py (+ its declaration), research_common.py; bigmove_deploy\data_quality.py, panel_build.py (optional); %CACHE_DAILY_ROOT% (daily bars incl. NIFTY50 / NIFTYMIDCAP150 / NIFTYSMLCAP250 / INDIAVIX, intraday_3m, panel_oc, research2\pick_meta\PM_20261017_001, sectors\amfi\ for AMFI's lists).

Python packages beyond production's: pypdf, openpyxl (AMFI lists); pdfplumber, reportlab (the tests).
