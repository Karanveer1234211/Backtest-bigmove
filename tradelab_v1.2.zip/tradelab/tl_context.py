"""
tl_context.py - tradelab v1.2: the market around every trade (the market intelligence layer).

    python tl_context.py check --root %CACHE_DAILY_ROOT%      which index files and AMFI lists tradelab sees
    python tl_context.py build --root %CACHE_DAILY_ROOT%      daily breadth (A/D) for the whole cache, saved under
                                                             <out>\\context\\ (tl_export does this itself; tl_sim and
                                                             tl_backtest reuse the saved copy)
    python tl_context.py diary --root %CACHE_DAILY_ROOT% [--from 2024-06-01] [--to 2024-06-30]
                                                             one plain-English line per session + market_days.csv

WHAT IT MEASURES - everything POINT IN TIME: a value for day d uses bars up to d's close (15:30 IST), never later.
  direction    NIFTY 50, Midcap 150, Smallcap 250: day return, gap, open-to-close, 5 / 20-day returns, close vs the
               50-day average, the day's move in standard deviations of the previous 60 days
  divergence   NIFTY minus Midcap and NIFTY minus Smallcap: the day and 20 days (> 0 = NIFTY ahead = narrow market)
  breadth      advancers / (advancers + decliners) over EVERY stock in the cache that traded that day (vs its
               previous close; unchanged stocks are left out) and its 10-day average. Not NSE's official count: the
               cache's coverage, and stocks delisted before the cache was built are missing (survivorship) - the
               daily count is in ad_n
  volatility   India VIX level, day change, 5-day % change, percentile within its last 250 sessions
  size         large / mid / small from AMFI's official half-yearly lists ONLY (Excel / PDF / CSV in
               %CACHE_DAILY_ROOT%\\sectors\\amfi\\), each used from 1 Feb / 1 Aug (a disclosed, conservative stand-in
               for the publication date, which is not recorded; amfi_published.csv gives actual dates) until the next
               half-year's list is due. No list in force (before the first, or a half-year's list missing - an older
               list is never carried on), or the stock not in it -> blank (never today's list, never a proxy). A
               renamed stock is found under its company's ISIN (identity only; the class is that list's)
  sensitivity  each pick's beta and correlation to the three indices over the 120 sessions up to the pick day; its
               home index = the one it correlates with most
  environment  DECLARED 24 Oct 2026, before any real run (never tuned on results):
                 an index is 'up' when it closes at or above its 50-day average; breadth = the 10-day average A/D
                 broad_bullish   NIFTY, Midcap and Smallcap all up, and breadth >= 0.50
                 narrow_bullish  NIFTY up, but Midcap or Smallcap down, or breadth < 0.50
                 broad_bearish   all three down, and breadth < 0.50
                 mixed           anything else (no clear directional agreement)
               high_stress is a SEPARATE flag (it can coexist with any direction): VIX at or above the 90th
               percentile of its last 250 sessions, or VIX up 25% or more in 5 sessions, or a NIFTY or Smallcap day
               move of 2.5 standard deviations or more. 'environment' (the five-label view) = high_stress when the
               flag is on, else the direction.
  missing data is never filled: a missing input leaves the value blank and is named in market_days.missing.
Text is ASCII only (Windows consoles and Excel read it cleanly).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import (StopRun, TLError, VERSION, bootstrap_mean_by_day, out_base, parse_day, require_root, say,
                       to_day, write_table)
import tl_data as D

CTX_VERSION = "tl_context v1.2"

# key, cache symbol, display name, kind
INDEX_SPECS: List[Tuple[str, str, str, str]] = [
    ("nifty", "NIFTY50", "NIFTY 50", "broad"),
    ("mid", "NIFTYMIDCAP150", "Midcap 150", "broad"),
    ("small", "NIFTYSMLCAP250", "Smallcap 250", "broad"),
    ("vix", "INDIAVIX", "India VIX", "vol"),
]
SPEC = {k: (sym, name, kind) for k, sym, name, kind in INDEX_SPECS}
INDEX_NAME = {k: v[1] for k, v in SPEC.items()}
BROAD = ("nifty", "mid", "small")
# the cache's non-stock series (Daily_cache_v27 DEFAULT_EXOGENOUS): never counted in breadth
EXOGENOUS = {"NIFTY50", "NIFTYBANK", "NIFTY500", "NIFTYMIDCAP150", "NIFTYSMLCAP250", "INDIAVIX", "NIFTYAUTO",
             "NIFTYFMCG", "NIFTYIT", "NIFTYMETAL", "NIFTYPHARMA", "NIFTYREALTY", "NIFTYENERGY", "NIFTYPSUBANK",
             "NIFTYFINSERVICE", "NIFTYMEDIA", "NIFTYCONSUMPTION", "NIFTYINFRA", "USDINR", "CRUDEOIL", "GOLD"}

# ----- the declared definitions (24 Oct 2026; fixed before any real run) -----
MA_DAYS = 50                    # an index is 'up' at or above its 50-day average close
AD_AVG_DAYS = 10                # breadth for the environment: 10-day average of the daily A/D ratio
AD_STRONG = 0.50                # breadth 'strong' at or above 0.50
STRESS_VIX_PCT = 0.90           # high stress: VIX at or above its 90th percentile of the last 250 sessions ...
VIX_PCT_WINDOW, VIX_PCT_MIN = 250, 60
STRESS_VIX_5D = 0.25            # ... or VIX up 25% or more over 5 sessions ...
STRESS_Z = 2.5                  # ... or a NIFTY / Smallcap day move of 2.5 sd or more (sd of the previous 60 days)
Z_WINDOW, Z_MIN = 60, 40
EXPOSURE_WINDOW, EXPOSURE_MIN = 120, 60     # beta / correlation: 120 sessions to the pick day, at least 60 returns
AMFI_PUBLISHED_FILE = "amfi_published.csv"   # optional: file,published (YYYY-MM-DD) -> a list is used from the next day
DRIVER_RATIO, DRIVER_FLAT = 2.0, 0.005
DEFINITIONS = {"index_up": f"close >= its {MA_DAYS}-session average", "breadth": f"{AD_AVG_DAYS}-session average of "
               "advancers / (advancers + decliners), all cached stocks", "breadth_strong": f">= {AD_STRONG}",
               "broad_bullish": "NIFTY, Midcap, Smallcap up and breadth strong",
               "narrow_bullish": "NIFTY up, and Midcap or Smallcap down or breadth weak",
               "broad_bearish": "NIFTY, Midcap, Smallcap down and breadth weak", "mixed": "anything else",
               "high_stress": f"VIX at or above the {int(STRESS_VIX_PCT * 100)}th percentile of its last {VIX_PCT_WINDOW} sessions, or VIX "
                              f"+{STRESS_VIX_5D:.0%} in 5 sessions, or NIFTY / Smallcap day move >= {STRESS_Z} sd "
                              f"(of the previous {Z_WINDOW} days)",
               "size": "AMFI half-yearly lists only, each used from the 1st of the second month after its half-year "
                       "ends (1 Feb / 1 Aug: an ASSUMED, conservative availability - AMFI's publication dates are not "
                       "recorded; actual dates in amfi_published.csv are used instead, from the next day) "
                       "until the next half-year's list is due (a missing list leaves the size blank; never carried "
                       "forward)",
               "sensitivity": f"beta and correlation of daily returns, {EXPOSURE_WINDOW} sessions to the pick day "
                              f"(>= {EXPOSURE_MIN} returns)", "declared": "2026-10-24"}

ENV_ORDER = ("broad_bullish", "narrow_bullish", "mixed", "broad_bearish")
ENV_CODE = {k: i for i, k in enumerate(ENV_ORDER)}
ENV5_ORDER = ENV_ORDER + ("high_stress",)
ENV_TEXT = {"broad_bullish": "Broad bullish", "narrow_bullish": "Narrow bullish", "mixed": "Mixed / ranging",
            "broad_bearish": "Broad bearish", "high_stress": "HIGH STRESS"}
SIZE_NAMES = {1: "large", 2: "mid", 3: "small"}
DRIVER_TEXT = {"market": "mostly the market", "stock": "mostly the stock itself", "both": "market and stock together",
               "opposite": "market and stock pulled opposite ways", "flat": "a small move either way"}


# ======================================================================
# small helpers (ASCII text)
# ======================================================================
def fin(x) -> bool:
    try:
        return x is not None and bool(np.isfinite(float(x)))
    except (TypeError, ValueError):
        return False


def pct(x, nd: int = 1) -> str:
    """'+1.2%' / '-0.4%' / '0.0%' (never '-0.0%') / 'n/a'."""
    if not fin(x):
        return "n/a"
    v = round(float(x) * 100, nd)
    return f"{0.0:.{nd}f}%" if v == 0 else f"{v:+.{nd}f}%"


def pts(x, nd: int = 1) -> str:
    if not fin(x):
        return "n/a"
    v = round(float(x) * 100, nd)
    return f"{0.0:.{nd}f} pts" if v == 0 else f"{v:+.{nd}f} pts"


def ordinal(n: int) -> str:
    n = int(n)
    suf = "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suf}"


def day_label(d) -> str:
    try:
        return pd.Timestamp(d).strftime("%a %d %b %Y") if d is not None and not pd.isna(d) else "n/a"
    except (TypeError, ValueError):
        return "n/a"


def rolling_pct_rank(x: np.ndarray, window: int, minp: int) -> np.ndarray:
    """Share of the last `window` values (today included) at or below today's value; blank with < minp values."""
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    for i in range(len(x)):
        if not np.isfinite(x[i]):
            continue
        a = x[max(0, i - window + 1):i + 1]
        a = a[np.isfinite(a)]
        if len(a) >= minp:
            out[i] = float(np.mean(a <= x[i]))
    return out


def bucket(values, edges, labels) -> np.ndarray:
    """edges[k] <= v < edges[k+1] -> labels[k]; blank for NaN."""
    v = np.asarray(values, float)
    out = np.full(len(v), "", dtype=object)
    ok = np.isfinite(v)
    k = np.searchsorted(np.asarray(edges[1:-1], float), v[ok], side="right")
    out[ok] = np.asarray(labels, dtype=object)[k]
    return out


# ======================================================================
# indices
# ======================================================================
def daily_file(market, sym: str) -> Path:
    DQ = getattr(market.prod, "DQ", None)
    if DQ is not None and hasattr(DQ, "_paths"):
        try:
            return Path(DQ._paths(Path(market.root), sym)[0])
        except Exception:  # noqa: BLE001
            pass
    return Path(market.root) / f"{sym}_daily.parquet"


def load_optional(market, syms: Sequence[str]) -> None:
    """Load the symbols whose daily file exists; one that fails to load is treated as missing (never fatal)."""
    want = [s for s in syms if s not in market.daily and s not in market.missing]
    have = [s for s in want if daily_file(market, s).exists()]
    for s in want:
        if s not in have:
            market.missing.append(s)
    if not have:
        return
    try:
        market.load(have)
    except TLError:
        for s in have:
            try:
                market.load([s])
            except TLError:
                if s not in market.missing:
                    market.missing.append(s)


class IndexBook:
    """NIFTY 50, Midcap 150, Smallcap 250 and India VIX aligned to the NIFTY 50 calendar (one row per session)."""

    def __init__(self, market):
        self.m = market
        self.cal = market.cal
        self.n = len(self.cal)
        load_optional(market, [s for _, s, _n, _k in INDEX_SPECS])
        self.keys: List[str] = []
        self.missing: List[str] = []
        self.info: Dict[str, dict] = {}
        self.a: Dict[str, Dict[str, np.ndarray]] = {}
        for k, sym, name, kind in INDEX_SPECS:
            ds = market.series(sym)
            if ds is None or len(ds) < 30:
                self.missing.append(k)
                self.info[k] = {"symbol": sym, "found": False}
                continue
            self.a[k] = self._measures(k, ds, kind)
            self.keys.append(k)

    def pos(self, days) -> np.ndarray:
        d = np.asarray(days).astype("datetime64[D]")
        j = np.searchsorted(self.cal, d)
        ok = j < self.n
        ok[ok] = self.cal[j[ok]] == d[ok]
        return np.where(ok, j, -1).astype(np.int64)

    def pos1(self, day) -> int:
        try:
            if day is None or pd.isna(day):
                return -1
        except (TypeError, ValueError):
            pass
        return int(self.pos(np.array([np.datetime64(pd.Timestamp(day).date(), "D")]))[0])

    def g1(self, key: str, field: str, p: int) -> float:
        a = self.a.get(key)
        if a is None or field not in a or p < 0 or p >= self.n:
            return np.nan
        return float(a[field][p])

    def has_open(self, key: str) -> bool:
        return bool(self.info.get(key, {}).get("open_ok", False))

    def _measures(self, k: str, ds, kind: str) -> Dict[str, np.ndarray]:
        cal, n = self.cal, self.n
        j = np.searchsorted(ds.dates, cal)
        ok = j < len(ds.dates)
        ok[ok] = ds.dates[j[ok]] == cal[ok]

        def al(x):
            out = np.full(n, np.nan)
            out[ok] = np.asarray(x, float)[j[ok]]
            return out

        O, C = al(ds.o), al(ds.c)
        P = np.r_[np.nan, C[:-1]]
        with np.errstate(divide="ignore", invalid="ignore"):
            ret = C / P - 1
            gap = O / P - 1
            intra = C / O - 1
        fg = np.isfinite(gap)
        flat_open = float(np.mean(np.abs(gap[fg]) < 1e-9)) if fg.any() else 1.0
        open_ok = kind != "vol" and flat_open < 0.5          # an open equal to the previous close is not an open
        if not open_ok:
            gap = np.full(n, np.nan)
            intra = np.full(n, np.nan)
        s = pd.Series(C)
        out = {"open": O if open_ok else np.full(n, np.nan), "close": C, "ret": ret, "gap": gap, "intraday": intra}
        with np.errstate(divide="ignore", invalid="ignore"):
            for w in (5, 20):
                out[f"ret{w}"] = C / s.shift(w).to_numpy(float) - 1
            ma = s.rolling(MA_DAYS, min_periods=MA_DAYS).mean().to_numpy(float)
            out["vs_ma50"] = C / ma - 1
            out["up50"] = np.where(np.isfinite(out["vs_ma50"]), (out["vs_ma50"] >= 0).astype(float), np.nan)
            sd = pd.Series(ret).rolling(Z_WINDOW, min_periods=Z_MIN).std().shift(1).to_numpy(float)
            out["ret_z"] = np.where(sd > 0, ret / sd, np.nan)
        if kind == "vol":
            out["pct250"] = rolling_pct_rank(C, VIX_PCT_WINDOW, VIX_PCT_MIN)
        have = np.flatnonzero(np.isfinite(C))
        first, last = (int(have[0]), int(have[-1])) if len(have) else (0, -1)
        self.info[k] = {"symbol": ds.sym, "found": True, "sessions": int(len(have)),
                        "first": str(cal[first]) if len(have) else None, "last": str(cal[last]) if len(have) else None,
                        "sessions_behind_calendar": int(n - 1 - last) if len(have) else None,
                        "missing_inside": int((~np.isfinite(C[first:last + 1])).sum()) if len(have) else None,
                        "open_ok": bool(open_ok), "open_equals_prev_close_share": round(flat_open, 4)}
        return out


# ======================================================================
# breadth: advancers / (advancers + decliners) over every stock in the cache
# ======================================================================
def cache_stock_symbols(market) -> List[str]:
    """Every stock in the cache: <root>\\<SYMBOL>_daily.parquet minus the index / macro series (and ETFs when
    %CACHE_DAILY_ROOT%\\sectors\\eq_etfseclist.csv lists them)."""
    root = Path(market.root)
    out = []
    for p in root.glob("*_daily.parquet"):
        s = p.name[:-len("_daily.parquet")]
        if s and s.upper() not in EXOGENOUS:
            out.append(s)
    etf = root / "sectors" / "eq_etfseclist.csv"
    if etf.exists():
        try:
            E = pd.read_csv(etf, dtype=str)
            col = next((c for c in E.columns if c.strip().lower() == "symbol"), None)
            if col is not None:
                bad = set(E[col].astype(str).str.strip().str.upper())
                out = [s for s in out if s.upper() not in bad]
        except Exception:  # noqa: BLE001 - optional list
            pass
    return sorted(set(out))


def ad_breadth(market, cal: np.ndarray, symbols: Sequence[str], log=None, batch: int = 200) -> Tuple[pd.DataFrame, dict]:
    """Daily advancers / decliners / unchanged over `symbols` (each vs its own previous close). Bars are read in
    batches with stage E's loader and dropped after counting (memory stays flat). Nothing is filled: a stock
    without a bar that day is simply not counted (ad_n says how many were)."""
    t0 = time.time()
    n = len(cal)
    adv, dec, unch = np.zeros(n, np.int64), np.zeros(n, np.int64), np.zeros(n, np.int64)
    used, failed, diag = 0, [], {}
    EX = market.prod.EX
    for b0 in range(0, len(symbols), batch):
        chunk = list(symbols[b0:b0 + batch])
        try:
            bars = EX.load_bars(market.root, chunk)
        except Exception:  # noqa: BLE001 - fall back to one at a time
            bars = {}
            for s in chunk:
                try:
                    bars.update(EX.load_bars(market.root, [s]))
                except Exception:  # noqa: BLE001
                    failed.append(s)
        for s in chunk:
            b = bars.get(s) if isinstance(bars, dict) else None
            if b is None or len(np.asarray(b.ts)) < 2:
                if s not in failed:
                    failed.append(s)
                continue
            ds = market.daily.get(s) or D.DailySeries(s, b, market.prod, market.root, diag)
            c = np.asarray(ds.c, float)
            with np.errstate(divide="ignore", invalid="ignore"):
                r = c[1:] / c[:-1] - 1
            p = np.searchsorted(cal, ds.dates[1:])
            ok = (p < n) & np.isfinite(r)
            ok[ok] = cal[p[ok]] == ds.dates[1:][ok]
            p, r = p[ok], r[ok]
            np.add.at(adv, p[r > 1e-9], 1)
            np.add.at(dec, p[r < -1e-9], 1)
            np.add.at(unch, p[np.abs(r) <= 1e-9], 1)
            used += 1
        if log and (b0 // batch) % 5 == 4:
            log(f"   breadth: {min(b0 + batch, len(symbols)):,} of {len(symbols):,} stocks ({time.time() - t0:,.0f} s)")
    tot = adv + dec
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(tot > 0, adv / np.where(tot > 0, tot, 1), np.nan)
    B = pd.DataFrame({"date": pd.DatetimeIndex(cal.astype("datetime64[ns]")), "adv": adv, "dec": dec, "unch": unch,
                      "ad_n": adv + dec + unch, "ad_ratio": ratio})
    B["ad_ratio_10"] = B["ad_ratio"].rolling(AD_AVG_DAYS, min_periods=AD_AVG_DAYS).mean()
    meta = {"stocks_listed": len(symbols), "stocks_used": used, "stocks_unreadable": len(failed),
            "unreadable_sample": failed[:20], "median_ad_n": float(np.median(B["ad_n"][B["ad_n"] > 0]))
            if (B["ad_n"] > 0).any() else 0.0, "seconds": round(time.time() - t0, 1)}
    if log:
        log(f"   breadth: {used:,} stocks counted, median {meta['median_ad_n']:,.0f} a session "
            f"({meta['seconds']:.0f} s)")
    return B, meta


# ======================================================================
# AMFI size lists (official, point in time)
# ======================================================================
AMFI_SUBDIR = Path("sectors") / "amfi"
AMFI_LARGE_TOP, AMFI_MID_TOP = 100, 250       # SEBI's definition, used to validate a list
_ISIN = re.compile(r"^IN[A-Z0-9]{10}$")
_NUM = re.compile(r"^\(?-?[0-9][0-9,]*(\.[0-9]+)?\)?$")
_ROWX = re.compile(r"(?:^|\s)(\d{1,5})\s+(\S.*?)\s+(IN[A-Z0-9]{10})\s+(.*?)\s*\b(Large|Mid|Small)\s*-?\s*Cap\b", re.I)
_MON = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                    "dec"], 1)}
_CATNUM = {"large": 1, "mid": 2, "small": 3}
AMFI_COLS = ["rank", "company", "isin", "nse", "bse", "any_symbol", "category"]


def amfi_period_end(text: str) -> Optional[dt.date]:
    """Half-year end from a title or file name: 'six months ended 31 December 2024', '...ended30Jun2023',
    'AverageMarketCapitalization31Dec2025', 'Jul-Dec 2019', 'Jan - June 2020'."""
    t = str(text).lower().replace("%20", " ").replace("_", " ")
    m = re.search(r"ended\s*(\d{1,2})\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*,?\s*(\d{4})", t)
    if m:
        mon, yr = _MON[m.group(2)], int(m.group(3))
        if mon in (6, 12):
            return dt.date(yr, mon, 30 if mon == 6 else 31)
    m = re.search(r"(jan|jul)[a-z]*\s*-+\s*(jun|dec)[a-z]*\s*,?\s*(\d{4})", t)
    if m:
        yr = int(m.group(3))
        return dt.date(yr, 6, 30) if m.group(2) == "jun" else dt.date(yr, 12, 31)
    m = re.search(r"(?<!\d)(30\s*jun|31\s*dec)[a-z]*\s*,?\s*(\d{4})", t)
    if m:
        yr = int(m.group(2))
        return dt.date(yr, 6, 30) if "jun" in m.group(1) else dt.date(yr, 12, 31)
    return None


def _split_middle(mid: str) -> Tuple[List[str], int]:
    """Tokens between the ISIN and the category -> symbol groups (consecutive non-numbers) and the count of numbers."""
    groups, cur, nums = [], [], 0
    for tok in mid.split():
        if _NUM.match(tok):
            nums += 1
            if cur:
                groups.append(" ".join(cur))
                cur = []
        elif tok in ("-", "--", "NA", "N.A.", "N/A"):
            if cur:
                groups.append(" ".join(cur))
                cur = []
        else:
            cur.append(tok)
    if cur:
        groups.append(" ".join(cur))
    return groups, nums


def parse_amfi_lines(lines: Sequence[str]) -> pd.DataFrame:
    """AMFI rows from PDF text, read as one stream (a reader may put each cell on its own line or a whole row on one
    line): 'rank company ISIN [BSE symbol] [number] [NSE symbol] [number] ... Category'. Ranks run 1, 2, 3, ...: a
    match that starts on a stray number (a page title, a header, a wrapped name) is re-anchored on the expected rank."""
    text = " ".join(" ".join(str(x).split()) for x in lines)
    rows, expect = [], 1
    for m in _ROWX.finditer(text):
        rank, company = int(m.group(1)), m.group(2).strip()
        if rank != expect:
            hits = list(re.finditer(rf"(?:^|\s){expect}\s+(\S.*)$", company))
            if hits:
                rank, company = expect, hits[-1].group(1).strip()
        groups, _n = _split_middle(m.group(4))
        rows.append({"rank": rank, "company": company, "isin": m.group(3).upper(),
                     "nse": groups[1].upper() if len(groups) >= 2 else "",
                     "bse": groups[0].upper() if len(groups) >= 2 else "",
                     "any_symbol": groups[0].upper() if len(groups) == 1 else "",
                     "category": _CATNUM[m.group(5).lower()]})
        expect = rank + 1
    return pd.DataFrame(rows, columns=AMFI_COLS)


def _as_text(raw: pd.DataFrame) -> pd.DataFrame:
    """Every cell as a stripped Python string ('' for a missing cell) - pandas 2 and 3 alike."""
    return raw.apply(lambda c: c.map(lambda x: "" if (x is None or (isinstance(x, float) and np.isnan(x))
                                                    or pd.isna(x)) else str(x).strip()))


def parse_amfi_table(raw: pd.DataFrame) -> pd.DataFrame:
    """AMFI rows from a sheet read with header=None (Excel / CSV): finds the header row (ISIN + Categorization)."""
    R = _as_text(raw)
    hdr = None
    for i in range(min(40, len(R))):
        cells = [c.lower() for c in R.iloc[i].tolist()]
        if any("isin" in c for c in cells) and any("categor" in c for c in cells):
            hdr = i
            break
    if hdr is None:
        return pd.DataFrame(columns=AMFI_COLS)
    names = [c.lower() for c in R.iloc[hdr].tolist()]

    def find(*pats):
        for j, c in enumerate(names):
            if all(re.search(p, c) for p in pats):
                return j
        return None

    if find("nse", "symbol") is None and hdr + 1 < len(R):
        # a header over two rows ('NSE' over 'Symbol' | '6 month avg'): carry each top label across its blank cells
        # and join it with the label below
        ff, last = [], ""
        for c in R.iloc[hdr].tolist():
            last = c if c.strip() else last
            ff.append(last)
        two = [f"{a} {b}".strip().lower() for a, b in zip(ff, R.iloc[hdr + 1].tolist())]
        keep = names
        names = two
        if find("nse", "symbol") is None:
            names = keep
    ci, cc = find("isin"), find("categor")
    cn, cb = find("nse", "symbol"), find("bse", "symbol")
    cr, cm = find(r"sr\.?\s*no|^rank"), find("company")
    clean = lambda v: "" if v.lower() in ("", "nan", "none", "-", "na", "n.a.") else v.upper()
    rows = []
    for i in range(hdr + 1, len(R)):
        r = R.iloc[i].tolist()
        isin = r[ci].upper() if ci is not None else ""
        if not _ISIN.match(isin):
            continue
        cat = re.search(r"(large|mid|small)", r[cc].lower()) if cc is not None else None
        if not cat:
            continue
        try:
            rank = int(float(r[cr].replace(",", ""))) if cr is not None else len(rows) + 1
        except ValueError:
            continue
        rows.append({"rank": rank, "company": r[cm] if cm is not None else "", "isin": isin,
                     "nse": clean(r[cn]) if cn is not None else "", "bse": clean(r[cb]) if cb is not None else "",
                     "any_symbol": "", "category": _CATNUM[cat.group(1)]})
    return pd.DataFrame(rows, columns=AMFI_COLS)


def _pdf_lines(path: Path) -> Tuple[List[str], str]:
    errs = []
    try:
        import pypdf
        lines = []
        for pg in pypdf.PdfReader(str(path)).pages:
            lines += (pg.extract_text() or "").splitlines()
        return lines, "pypdf"
    except ImportError:
        errs.append("pypdf not installed")
    except Exception as e:  # noqa: BLE001
        errs.append(f"pypdf failed ({type(e).__name__})")
    try:
        import pdfplumber
        lines = []
        with pdfplumber.open(str(path)) as pdf:
            for pg in pdf.pages:
                lines += (pg.extract_text() or "").splitlines()
        return lines, "pdfplumber"
    except ImportError:
        errs.append("pdfplumber not installed")
    except Exception as e:  # noqa: BLE001
        errs.append(f"pdfplumber failed ({type(e).__name__})")
    raise TLError(f"cannot read {path.name}: {', '.join(errs)} (pip install pypdf)")


def validate_amfi(rows: pd.DataFrame) -> Tuple[bool, str, dict]:
    st = {"rows": int(len(rows))}
    if rows.empty:
        return False, "no rows recognised", st
    r = rows.drop_duplicates("rank")
    top = set(r.loc[r["rank"] <= AMFI_MID_TOP, "rank"])
    st["ranks_1_250_found"] = len(top)
    exp = np.where(r["rank"] <= AMFI_LARGE_TOP, 1, np.where(r["rank"] <= AMFI_MID_TOP, 2, 3))
    consistent = float(np.mean(exp == r["category"].to_numpy()))
    st["category_matches_rank"] = round(consistent, 4)
    st["dup_ranks"] = int(len(rows) - len(r))
    t250 = r[r["rank"] <= AMFI_MID_TOP]
    sym_ok = float(((t250["nse"] != "") | (t250["any_symbol"] != "")).mean()) if len(t250) else 0.0
    st["nse_symbol_share_1_250"] = round(sym_ok, 4)
    if len(top) < 240:
        return False, f"only {len(top)} of ranks 1-250 recognised", st
    if consistent < 0.99:
        return False, f"category agrees with the rank cut-offs on only {consistent:.1%} of rows", st
    if sym_ok < 0.90:
        return False, f"an NSE symbol was found for only {sym_ok:.1%} of ranks 1-250 (symbol column not recognised)", st
    return True, "ok", st


def amfi_rule_from(pe: dt.date) -> dt.date:
    """The assumed first day a list is usable: the 1st of the second month after its half-year (30 Jun -> 1 Aug,
    31 Dec -> 1 Feb). Conservative: AMFI's lists were reported on 5 Jan 2021 and by 9 Jul 2025, and funds realign
    within a month; the true publication dates are not recorded here."""
    y, m = pe.year, pe.month + 2
    if m > 12:
        y, m = y + 1, m - 12
    return dt.date(y, m, 1)


def next_half_end(pe: dt.date) -> dt.date:
    """The end of the half-year after the one ending pe (30 Jun -> 31 Dec -> 30 Jun ...)."""
    if pe.month == 6:
        return dt.date(pe.year, 12, 31)
    if pe.month == 12:
        return dt.date(pe.year + 1, 6, 30)
    return pe + dt.timedelta(days=183)


class AmfiList:
    def __init__(self, path: Path, period_end: dt.date, rows: pd.DataFrame, how: str, stats: dict,
                 published: Optional[dt.date] = None):
        self.path = path
        self.period_end = period_end
        self.published = published
        self.effective_from = np.datetime64(published + dt.timedelta(days=1) if published else amfi_rule_from(period_end),
                                            "D")
        # in force until the NEXT half-year's list is due; a missing list is never covered by carrying this one on
        self.valid_to = np.datetime64(amfi_rule_from(next_half_end(period_end)), "D")   # or the next list's start
        self.rows = rows
        self.how = how
        self.stats = stats
        self.label = f"AMFI {'Jan-Jun' if period_end.month == 6 else 'Jul-Dec'} {period_end.year}"
        m: Dict[str, Tuple[int, int]] = {}
        for r in rows.itertuples(index=False):                 # NSE symbols first ...
            if r.nse and r.nse not in m:
                m[r.nse] = (int(r.rank), int(r.category))
        for r in rows.itertuples(index=False):                 # ... then a lone or BSE symbol not already taken
            for s in (r.any_symbol, r.bse):
                if s and s not in m:
                    m[s] = (int(r.rank), int(r.category))
        self.map = m
        self.by_isin: Dict[str, Tuple[int, int]] = {}
        self.sym_isin: Dict[str, str] = {}
        for r in rows.itertuples(index=False):
            if r.isin and r.isin not in self.by_isin:
                self.by_isin[r.isin] = (int(r.rank), int(r.category))
            for s in (r.nse, r.any_symbol, r.bse):
                if s and s not in self.sym_isin:
                    self.sym_isin[s] = r.isin


class AmfiBook:
    """The accepted lists in effective-date order; lookup(symbol, day) uses the list in force that day."""

    def __init__(self, lists: Sequence[AmfiList], report: List[dict]):
        self.lists = sorted(lists, key=lambda x: x.effective_from)
        self.report = report
        for a, b in zip(self.lists[:-1], self.lists[1:]):    # the next half-year's list takes over when IT starts
            if b.period_end == next_half_end(a.period_end):
                a.valid_to = b.effective_from
        self.eff = np.array([L.effective_from for L in self.lists], dtype="datetime64[D]")
        # a symbol's company (ISIN), from any list - identity only, so a renamed stock (MCDOWELL-N -> UNITDSPR) is
        # found in the lists that used its old symbol; its class always comes from the list in force that day
        self.isin_of: Dict[str, str] = {}
        for L in reversed(self.lists):
            for s_, i_ in L.sym_isin.items():
                self.isin_of.setdefault(s_, i_)

    def lookup(self, symbol: str, day) -> Tuple[str, float, float, str]:
        """-> (class name or 'not in list' / 'no list', class number, AMFI rank, list label). 'no list': no list in
        force that day - before the first one, or the half-year's list is missing (the older list is NOT carried on)."""
        if not len(self.lists):
            return "no list", np.nan, np.nan, ""
        d = np.datetime64(pd.Timestamp(day).date(), "D")
        k = int(np.searchsorted(self.eff, d, side="right")) - 1
        if k < 0:
            return "no list", np.nan, np.nan, ""
        L = self.lists[k]
        if d >= L.valid_to:
            return "no list", np.nan, np.nan, ""
        sym = str(symbol).upper()
        v, label = L.map.get(sym), L.label
        if v is None and self.isin_of.get(sym):
            v = L.by_isin.get(self.isin_of[sym])
            label = f"{L.label} (via ISIN {self.isin_of[sym]})"
        if v is None:
            return "not in list", np.nan, np.nan, L.label
        return SIZE_NAMES[v[1]], float(v[1]), float(v[0]), label


def read_amfi_dir(root: Path, folder: Optional[Path] = None) -> AmfiBook:
    d = Path(folder) if folder else Path(root) / AMFI_SUBDIR
    lists, report = [], []
    if not d.is_dir():
        return AmfiBook([], [])
    pub: Dict[str, dt.date] = {}
    if (d / AMFI_PUBLISHED_FILE).exists():
        P = pd.read_csv(d / AMFI_PUBLISHED_FILE, dtype=str)
        for f_, v_ in zip(P.get("file", []), P.get("published", [])):
            try:
                pub[str(f_).strip()] = pd.Timestamp(str(v_).strip()).date()
            except Exception:  # noqa: BLE001
                raise TLError(f"{AMFI_PUBLISHED_FILE}: '{v_}' for {f_} is not a date (use YYYY-MM-DD)") from None
    for p in sorted(d.iterdir()):
        if p.suffix.lower() not in (".pdf", ".xlsx", ".xls", ".csv") or p.name == AMFI_PUBLISHED_FILE:
            continue
        rec = {"file": p.name}
        try:
            if p.suffix.lower() == ".pdf":
                lines, how = _pdf_lines(p)
                title = " ".join(lines[:8])
                rows = parse_amfi_lines(lines)
            else:
                if p.suffix.lower() == ".csv":
                    import csv
                    with open(p, encoding="utf-8-sig", errors="replace", newline="") as f:
                        recs = list(csv.reader(f))
                    wd = max((len(x) for x in recs), default=0)
                    raw = pd.DataFrame([x + [""] * (wd - len(x)) for x in recs])
                    how = "csv"
                else:
                    try:
                        raw = pd.read_excel(p, header=None, dtype=str)
                    except ImportError as e:
                        raise TLError(f"cannot read {p.name} ({e}); pip install openpyxl, or save it as CSV") from None
                    how = "excel"
                tx = _as_text(raw)
                title = " ".join(" ".join(tx.iloc[i].tolist()) for i in range(min(6, len(tx))))
                rows = parse_amfi_table(raw)
            pe = amfi_period_end(title) or amfi_period_end(p.name)
            if pe is None:
                raise TLError("cannot tell which half-year it covers (title or file name like '...ended 31 Dec 2024')")
            ok, why, st = validate_amfi(rows)
            rec.update({"period_end": str(pe), "read_with": how, **st})
            if not ok:
                rec["status"] = f"REFUSED: {why}"
            else:
                L = AmfiList(p, pe, rows, how, st, pub.get(p.name))
                rec.update({"status": "ok", "label": L.label, "used_from": str(L.effective_from),
                            "timing": f"published {pub[p.name]} + 1 day" if p.name in pub else
                            "assumed: 1st of the second month (publication date not recorded)"})
                lists.append(L)
        except TLError as e:
            rec["status"] = f"REFUSED: {e}"
        except Exception as e:  # noqa: BLE001
            rec["status"] = f"REFUSED: unreadable ({type(e).__name__}: {e})"
        report.append(rec)
    by_end: Dict[dt.date, AmfiList] = {}
    for L in lists:                                        # one list per half-year: the later file name wins
        by_end[L.period_end] = L
    return AmfiBook(list(by_end.values()), report)


# ======================================================================
# sensitivity: beta and correlation to each index (point in time)
# ======================================================================
class Exposure:
    """Beta and correlation of a stock's daily returns with each index over the EXPOSURE_WINDOW sessions to day s0
    (returns between the stock's own consecutive bars, the index over exactly the same dates)."""

    def __init__(self, ib: IndexBook):
        self.ib = ib
        self.keys = [k for k in BROAD if k in ib.keys]
        self._cache: Dict[Tuple[str, int], dict] = {}

    @staticmethod
    def empty() -> dict:
        out = {"exposure_days": 0}
        for k in BROAD:
            out[f"beta_{k}"] = np.nan
            out[f"corr_{k}"] = np.nan
        out.update({"home_index": "", "beta_home": np.nan, "corr_home": np.nan})
        return out

    def of(self, ds, s0: int) -> dict:
        key = (ds.sym, int(s0))
        hit = self._cache.get(key)
        if hit is not None:
            return hit
        out = self.empty()
        if s0 < 1:
            self._cache[key] = out
            return out
        js = np.arange(max(1, s0 - EXPOSURE_WINDOW + 1), s0 + 1)
        with np.errstate(divide="ignore", invalid="ignore"):
            r = ds.c[js] / ds.c[js - 1] - 1
        cp, pp = self.ib.pos(ds.dates[js]), self.ib.pos(ds.dates[js - 1])
        out["exposure_days"] = int(np.isfinite(r).sum())
        corrs = {}
        for k in self.keys:
            C = self.ib.a[k]["close"]
            x = np.full(len(js), np.nan)
            okp = (cp >= 0) & (pp >= 0)
            with np.errstate(divide="ignore", invalid="ignore"):
                x[okp] = C[cp[okp]] / C[pp[okp]] - 1
            ok = np.isfinite(r) & np.isfinite(x)
            if ok.sum() < EXPOSURE_MIN:
                continue
            xc, rc = x[ok] - x[ok].mean(), r[ok] - r[ok].mean()
            vx, vr = float(xc @ xc), float(rc @ rc)
            if vx <= 0 or vr <= 0:
                continue
            cov = float(xc @ rc)
            out[f"beta_{k}"] = cov / vx
            out[f"corr_{k}"] = cov / np.sqrt(vx * vr)
            corrs[k] = out[f"corr_{k}"]
        if corrs:
            h = max(corrs, key=lambda k: (corrs[k], -BROAD.index(k)))
            out.update({"home_index": h, "beta_home": out[f"beta_{h}"], "corr_home": out[f"corr_{h}"]})
        self._cache[key] = out
        return out


# ======================================================================
# the market table (one row per session) and its labels
# ======================================================================
def environment(nu, mu, su, ad10) -> np.ndarray:
    """The four directional labels (blank when an input is missing)."""
    nu, mu, su, ad10 = (np.asarray(v, float) for v in (nu, mu, su, ad10))
    out = np.full(len(nu), "", dtype=object)
    ok = np.isfinite(nu) & np.isfinite(mu) & np.isfinite(su) & np.isfinite(ad10)
    with np.errstate(invalid="ignore"):
        n_, m_, s_, b_ = nu == 1, mu == 1, su == 1, ad10 >= AD_STRONG
    out[ok] = "mixed"
    out[ok & n_ & ~(m_ & s_ & b_)] = "narrow_bullish"
    out[ok & n_ & m_ & s_ & b_] = "broad_bullish"
    out[ok & ~n_ & ~m_ & ~s_ & ~b_] = "broad_bearish"
    return out


def stress(vix_pct, vix_5d, nz, sz) -> Tuple[np.ndarray, np.ndarray]:
    """high_stress 1 / 0 / NaN (unknown: no condition fired and an input is missing) and the reasons in words."""
    vp, v5, nz, sz = (np.asarray(v, float) for v in (vix_pct, vix_5d, nz, sz))
    n = len(vp)
    flag = np.full(n, np.nan)
    why = np.full(n, "", dtype=object)
    for i in range(n):
        r = []
        if fin(vp[i]) and vp[i] >= STRESS_VIX_PCT:
            r.append(f"VIX at its {ordinal(round(vp[i] * 100))} percentile of {VIX_PCT_WINDOW} sessions")
        if fin(v5[i]) and v5[i] >= STRESS_VIX_5D:
            r.append(f"VIX {pct(v5[i], 0)} in 5 sessions")
        if fin(nz[i]) and abs(nz[i]) >= STRESS_Z:
            r.append(f"NIFTY {nz[i]:+.1f} sd day")
        if fin(sz[i]) and abs(sz[i]) >= STRESS_Z:
            r.append(f"Smallcap {sz[i]:+.1f} sd day")
        if r:
            flag[i] = 1.0
            why[i] = "; ".join(r)
        elif all(fin(x) for x in (vp[i], v5[i], nz[i], sz[i])):
            flag[i] = 0.0
    return flag, why


def market_frame(ib: IndexBook, breadth: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    n = ib.n
    F: Dict[str, object] = {"date": pd.DatetimeIndex(ib.cal.astype("datetime64[ns]"))}
    F["weekday"] = F["date"].strftime("%a")
    nan = np.full(n, np.nan)
    for k in BROAD:
        a = ib.a.get(k)
        for f in ("close", "ret", "gap", "intraday", "ret5", "ret20", "vs_ma50", "up50", "ret_z"):
            F[f"{k}_{f}"] = a[f] if a else nan
    v = ib.a.get("vix")
    F["vix"] = v["close"] if v else nan
    F["vix_chg_pct"] = v["ret"] if v else nan
    F["vix_chg5_pct"] = v["ret5"] if v else nan
    F["vix_pct250"] = v["pct250"] if v else nan
    df = pd.DataFrame(F)
    for g in ("mid", "small"):
        df[f"nifty_minus_{g}"] = df["nifty_ret"] - df[f"{g}_ret"]
        df[f"nifty_minus_{g}_20"] = df["nifty_ret20"] - df[f"{g}_ret20"]
    bcols = ["adv", "dec", "unch", "ad_n", "ad_ratio", "ad_ratio_10"]
    if breadth is not None and len(breadth):
        b = breadth.copy()
        b["date"] = pd.DatetimeIndex(pd.to_datetime(b["date"]).astype("datetime64[ns]"))
        df = df.merge(b[["date"] + [c for c in bcols if c in b.columns]], on="date", how="left")
    for c in bcols:
        if c not in df.columns:
            df[c] = np.nan
    env = environment(df["nifty_up50"], df["mid_up50"], df["small_up50"], df["ad_ratio_10"])
    df["env_direction"] = env
    df["env_code"] = np.array([float(ENV_CODE[e]) if e else np.nan for e in env])
    fl, why = stress(df["vix_pct250"], df["vix_chg5_pct"], df["nifty_ret_z"], df["small_ret_z"])
    df["high_stress"] = fl
    df["stress_reason"] = why
    df["environment"] = np.where(fl == 1, "high_stress", env).astype(object)
    df["env_text"] = [(ENV_TEXT["high_stress"] + (f" (direction: {ENV_TEXT[e]})" if e else "")) if f == 1
                      else (ENV_TEXT.get(e, "") + (" (stress unknown)" if not fin(f) and e else ""))
                      for e, f in zip(env, fl)]
    miss = []
    for i in range(len(df)):
        mm = [k for k in BROAD if not fin(df[f"{k}_ret"].iat[i])]
        if not fin(df["vix"].iat[i]):
            mm.append("vix")
        if not fin(df["ad_ratio"].iat[i]):
            mm.append("breadth")
        miss.append(",".join(mm))
    df["missing"] = miss
    return df


# ======================================================================
# sentences
# ======================================================================
def day_sentence(r) -> str:
    """One plain-English line for a market_days row (a dict)."""
    g = (lambda c: r.get(c) if isinstance(r, dict) else getattr(r, c, None))
    parts = []
    idx = []
    for k, nm in (("nifty", "NIFTY"), ("mid", "Midcap"), ("small", "Smallcap")):
        x = g(f"{k}_ret")
        if not fin(x):
            continue
        s = f"{nm} {pct(x)}"
        z = g(f"{k}_ret_z")
        if fin(z) and abs(z) >= 2:
            s += f" ({abs(z):.1f} sd {'rise' if x > 0 else 'fall'})"
        idx.append(s)
    if idx:
        parts.append(", ".join(idx))
    if fin(g("nifty_minus_small")):
        parts.append(f"NIFTY minus Smallcap {pts(g('nifty_minus_small'))} (20-day {pts(g('nifty_minus_small_20'))})")
    if fin(g("ad_ratio")):
        b = f"breadth {float(g('ad_ratio')):.2f} ({int(g('adv')):,} up / {int(g('dec')):,} down of {int(g('ad_n')):,}"
        b += f"; 10-day {float(g('ad_ratio_10')):.2f})" if fin(g("ad_ratio_10")) else ")"
        parts.append(b)
    if fin(g("vix")):
        v = f"VIX {float(g('vix')):.1f} (day {pct(g('vix_chg_pct'))}, 5-day {pct(g('vix_chg5_pct'))}"
        if fin(g("vix_pct250")):
            v += f", {ordinal(round(float(g('vix_pct250')) * 100))} percentile"
        parts.append(v + ")")
    if g("env_text"):
        e = f"environment: {g('env_text')}"
        if g("stress_reason"):
            e += f" - {g('stress_reason')}"
        parts.append(e)
    if g("missing"):
        parts.append(f"MISSING: {g('missing')}")
    d = g("date")
    return f"{day_label(d)}: " + "; ".join(parts) + "." if parts else f"{day_label(d)}: no index data."


def driver_of(gross, mkt, stock) -> str:
    if not (fin(gross) and fin(mkt) and fin(stock)):
        return ""
    if abs(gross) < DRIVER_FLAT and abs(mkt) < DRIVER_FLAT and abs(stock) < DRIVER_FLAT:
        return "flat"
    if abs(mkt) >= DRIVER_RATIO * abs(stock):
        return "market"
    if abs(stock) >= DRIVER_RATIO * abs(mkt):
        return "stock"
    return "both" if np.sign(mkt) == np.sign(stock) else "opposite"


def trade_story(r) -> str:
    """The chain in one line: market before the pick -> the pick -> the trade -> the market during it -> the split."""
    g = (lambda c: r.get(c) if isinstance(r, dict) else getattr(r, c, None))
    env = ENV_TEXT.get(g("pre_environment") or "", "environment unknown")
    first = f"Pick day {day_label(g('signal_day'))} [{env}]: NIFTY {pct(g('pre_nifty_ret'))}, Smallcap {pct(g('pre_small_ret'))}"
    if fin(g("pre_ad_ratio")):
        first += f", breadth {float(g('pre_ad_ratio')):.2f}"
    if fin(g("pre_vix")):
        first += f", VIX {float(g('pre_vix')):.1f} ({pct(g('pre_vix_chg5_pct'), 0)} in 5 days)"
    s = [first]
    prof = []
    if g("pre_size_class") in ("large", "mid", "small"):
        prof.append(f"{g('pre_size_class')} cap")
    if g("pre_home_index_name"):
        prof.append(f"moves with {g('pre_home_index_name')}" + (f", beta {float(g('pre_beta_home')):.2f}"
                                                               if fin(g("pre_beta_home")) else ""))
    rk = g("rank")
    s.append(f"{g('engine')} rank {int(rk) if fin(rk) else '?'} {g('symbol')}" + (f" ({'; '.join(prof)})" if prof else ""))
    if g("status") == "ok" and fin(g("post_gross_ret")):
        s.append(f"bought {day_label(g('entry_day'))} open, sold {day_label(g('exit_day'))} "
                 f"{'close' if str(g('exit_kind')) == 'close' else 'open'}: gross {pct(g('post_gross_ret'), 2)}, net "
                 f"{float(g('net_bp')):+.0f} bp")
        hold = f"during the hold NIFTY {pct(g('post_hold_nifty_ret'))}, Smallcap {pct(g('post_hold_small_ret'))}"
        if fin(g("post_hold_stress_days")) and float(g("post_hold_stress_days")) > 0:
            hold += f", {int(g('post_hold_stress_days'))} high-stress day(s)"
        s.append(hold)
        if g("post_driver"):
            s.append(f"market part {pct(float(g('post_mkt_part_bp')) / 1e4, 2)}, stock part "
                     f"{pct(float(g('post_stock_part_bp')) / 1e4, 2)}: {DRIVER_TEXT.get(g('post_driver'), '')}")
    else:
        s.append(f"status {g('status')}")
    return " -> ".join(s) + "."


# ======================================================================
# the context of a run
# ======================================================================
PRE_DAY_FIELDS = (  # market_days column -> pre_<column> on the pick day
    "nifty_ret", "mid_ret", "small_ret", "nifty_ret5", "mid_ret5", "small_ret5", "nifty_ret20", "mid_ret20",
    "small_ret20", "nifty_vs_ma50", "mid_vs_ma50", "small_vs_ma50", "nifty_minus_mid", "nifty_minus_small",
    "nifty_minus_mid_20", "nifty_minus_small_20", "ad_ratio", "ad_ratio_10", "ad_n", "vix", "vix_chg_pct",
    "vix_chg5_pct", "vix_pct250", "env_direction", "env_code", "high_stress", "stress_reason", "environment", "missing")
PRE_PREV_FIELDS = ("nifty_ret", "mid_ret", "small_ret", "ad_ratio", "vix_chg_pct", "environment", "high_stress")
POST_COLS = ("post_entry_nifty_gap", "post_entry_nifty_intraday", "post_entry_mid_gap", "post_entry_mid_intraday",
             "post_entry_small_gap", "post_entry_small_intraday", "post_entry_ad_ratio", "post_entry_vix_chg_pct",
             "post_entry_environment", "post_entry_high_stress", "post_hold_start", "post_hold_nifty_ret",
             "post_hold_mid_ret", "post_hold_small_ret", "post_hold_home_ret", "post_hold_vix_chg_pct",
             "post_hold_ad_ratio_avg", "post_hold_stress_days", "post_gross_ret", "post_mkt_part_bp",
             "post_stock_part_bp", "post_cost_bp", "post_driver", "post_excess_vs_nifty_bp", "post_excess_vs_mid_bp",
             "post_excess_vs_small_bp", "post_excess_vs_home_bp")
# pick attributes a rule or a filter may read (numbers, all known at the pick day's close)
CTX_PICK_ATTRS = tuple(f"pre_{f}" for f in PRE_DAY_FIELDS if f not in ("env_direction", "stress_reason",
                                                                       "environment", "missing")) + \
    tuple(f"pre_prev_{f}" for f in PRE_PREV_FIELDS if f != "environment") + \
    ("pre_stock_ret", "pre_prev_stock_ret", "pre_stock_minus_home", "pre_size_class_num", "pre_amfi_rank",
     "pre_beta_nifty", "pre_beta_mid", "pre_beta_small", "pre_corr_nifty", "pre_corr_mid", "pre_corr_small",
     "pre_beta_home", "pre_corr_home", "pre_home_index_num", "pre_context_complete")


class Context:
    """Index measures + breadth + AMFI size + sensitivity, for one run."""

    def __init__(self, market, ib: IndexBook, breadth: Optional[pd.DataFrame], amfi: Optional[AmfiBook],
                 meta: Optional[dict] = None):
        self.m = market
        self.ib = ib
        self.breadth = breadth
        self.amfi = amfi or AmfiBook([], [])
        self.meta = dict(meta or {})
        self.run_meta: dict = {}
        self.expo = Exposure(ib)
        self.frame = market_frame(ib, breadth)
        self.F = {c: self.frame[c].to_numpy() for c in self.frame.columns}

    @property
    def has_breadth(self) -> bool:
        return self.breadth is not None and len(self.breadth) > 0

    def fcol(self, c: str, p) -> np.ndarray:
        arr = self.F.get(c)
        p = np.asarray(p, dtype=np.int64)
        if arr is None:
            return np.full(p.shape, np.nan)
        out = np.full(p.shape, np.nan) if arr.dtype != object else np.full(p.shape, "", dtype=object)
        ok = (p >= 0) & (p < len(arr))
        out[ok] = arr[p[ok]]
        return out

    # ------------------------------------------------------------------
    def pick_context(self, T: pd.DataFrame, plan: Optional[list] = None) -> pd.DataFrame:
        """One row per pick (T's order). pre_* = known at the pick day's close (the day before, the pick day, the
        stock's size and sensitivity); with the plan's results also post_* = observed after the entry."""
        m, ib = self.m, self.ib
        n = len(T)
        sdays = to_day(T["signal_day"]) if n else np.array([], dtype="datetime64[D]")
        P0 = ib.pos(sdays) if n else np.zeros(0, dtype=np.int64)
        PB = np.where(P0 > 0, P0 - 1, -1)
        out: Dict[str, object] = {}
        dbd = np.full(n, np.datetime64("NaT"), dtype="datetime64[D]")
        dbd[PB >= 0] = ib.cal[PB[PB >= 0]]
        out["pre_prev_date"] = pd.DatetimeIndex(dbd.astype("datetime64[ns]"))
        for f in PRE_DAY_FIELDS:
            out[f"pre_{f}"] = self.fcol(f, P0)
        for f in PRE_PREV_FIELDS:
            out[f"pre_prev_{f}"] = self.fcol(f, PB)
        sz = [self.amfi.lookup(s, d) for s, d in zip(T["symbol"].astype(str).tolist(), sdays)]
        out["pre_size_class"] = np.array([x[0] for x in sz], dtype=object)
        out["pre_size_class_num"] = np.array([x[1] for x in sz], dtype=float)
        out["pre_amfi_rank"] = np.array([x[2] for x in sz], dtype=float)
        out["pre_amfi_list"] = np.array([x[3] for x in sz], dtype=object)
        ex_rows, s0r, sbr, sigs = [], np.full(n, np.nan), np.full(n, np.nan), np.full(n, -1, dtype=np.int64)
        for i, (sym, d) in enumerate(zip(T["symbol"].astype(str).tolist(), sdays)):
            ds = m.series(sym)
            sig = ds.idx(d) if ds is not None else -1
            sigs[i] = sig
            ex_rows.append(self.expo.of(ds, sig) if ds is not None and sig >= 1 else self.expo.empty())
            if sig >= 1:
                s0r[i] = ds.c[sig] / ds.c[sig - 1] - 1
            if sig >= 2:
                sbr[i] = ds.c[sig - 1] / ds.c[sig - 2] - 1
        EX = pd.DataFrame(ex_rows, columns=list(Exposure.empty().keys()))
        for c in EX.columns:
            out[f"pre_{c}"] = EX[c].to_numpy()
        home = EX["home_index"].fillna("").to_numpy(object)
        out["pre_home_index_name"] = np.array([INDEX_NAME.get(h, "") for h in home], object)
        out["pre_home_index_num"] = np.array([float(BROAD.index(h) + 1) if h in BROAD else np.nan for h in home])
        out["pre_stock_ret"] = s0r
        out["pre_prev_stock_ret"] = sbr
        hr = np.full(n, np.nan)
        for k in BROAD:
            mk = home == k
            if mk.any():
                hr[mk] = self.fcol(f"{k}_ret", P0[mk])
        out["pre_stock_minus_home"] = s0r - hr
        core = ("pre_nifty_ret", "pre_mid_ret", "pre_small_ret", "pre_vix", "pre_ad_ratio", "pre_env_code",
                "pre_high_stress")
        out["pre_context_complete"] = (np.all([np.isfinite(np.asarray(out[c], float)) for c in core], axis=0)
                                       .astype(float) if n else np.zeros(0))
        X = pd.DataFrame(out)
        if plan is not None:
            A = [self._after(p, m.series(p["symbol"]), int(sigs[i]), plan[i], ex_rows[i])
                 for i, p in enumerate(T.to_dict("records"))]
            X = pd.concat([X.reset_index(drop=True), pd.DataFrame(A, columns=list(POST_COLS))], axis=1)
        return X

    def window_returns(self, start_day, start_kind: str, end_day, end_kind: str,
                       keys: Sequence[str] = BROAD) -> Dict[str, float]:
        """Index returns from start (the open or close of start_day) to end (the open or close of end_day). An index
        without a usable open uses the previous close instead (post_hold_start says so)."""
        ib = self.ib
        a, b = ib.pos1(start_day), ib.pos1(end_day)
        out = {}
        for k in keys:
            if k not in ib.keys or a < 0 or b < 0:
                out[k] = np.nan
                continue
            op = ib.has_open(k)
            s = ib.g1(k, "open", a) if (start_kind == "open" and op) else (
                ib.g1(k, "close", a - 1) if start_kind == "open" else ib.g1(k, "close", a))
            e = ib.g1(k, "close", b) if end_kind == "close" else (
                ib.g1(k, "open", b) if op else ib.g1(k, "close", b - 1))
            out[k] = float(e / s - 1) if fin(s) and fin(e) and s > 0 else np.nan
        return out

    def _after(self, p: dict, ds, sig: int, r, ex: dict) -> dict:
        ib = self.ib
        rec: Dict[str, object] = {c: np.nan for c in POST_COLS}
        rec.update({"post_hold_start": "", "post_driver": "", "post_entry_environment": ""})
        ent = sig + 1 if ds is not None and sig >= 0 and sig + 1 < len(ds) else -1
        pe = ib.pos1(ds.dates[ent]) if ent >= 0 else -1
        for k in BROAD:
            rec[f"post_entry_{k}_gap"] = self.fcol(f"{k}_gap", [pe])[0]
            rec[f"post_entry_{k}_intraday"] = self.fcol(f"{k}_intraday", [pe])[0]
        rec["post_entry_ad_ratio"] = self.fcol("ad_ratio", [pe])[0]
        rec["post_entry_vix_chg_pct"] = self.fcol("vix_chg_pct", [pe])[0]
        rec["post_entry_environment"] = self.fcol("environment", [pe])[0]
        rec["post_entry_high_stress"] = self.fcol("high_stress", [pe])[0]
        if r is None or r.status != "ok" or ent < 0:
            return rec
        buys = [f for f in r.fills if f.side == "buy"]
        sells = [f for f in r.fills if f.side == "sell"]
        if not buys or not sells:
            return rec
        bj, sj = sig + int(buys[0].session), sig + int(sells[-1].session)
        if not (0 <= bj < len(ds) and 0 <= sj < len(ds)):
            return rec
        bkind = "close" if buys[0].kind == "close" else "open"
        skind = "close" if sells[-1].kind == "close" else "open"
        w = self.window_returns(ds.dates[bj], bkind, ds.dates[sj], skind, BROAD)
        for k in BROAD:
            rec[f"post_hold_{k}_ret"] = w[k]
        rec["post_hold_start"] = "index open" if all(ib.has_open(k) for k in BROAD if k in ib.keys) \
            else "previous close (an index open is unusable)"
        pa, pz = ib.pos1(ds.dates[bj]), ib.pos1(ds.dates[sj])
        if pa >= 1 and pz >= pa:
            v0 = self.fcol("vix", [pa - 1 if bkind == "open" else pa])[0]
            v1 = self.fcol("vix", [pz if skind == "close" else pz - 1])[0]
            rec["post_hold_vix_chg_pct"] = float(v1 / v0 - 1) if fin(v0) and fin(v1) and v0 > 0 else np.nan
            span = np.arange(pa, pz + 1)
            bu = self.fcol("ad_ratio", span)
            rec["post_hold_ad_ratio_avg"] = float(np.nanmean(bu)) if np.isfinite(bu).any() else np.nan
            hs = self.fcol("high_stress", span)
            rec["post_hold_stress_days"] = float(np.sum(hs == 1)) if np.isfinite(hs).any() else np.nan
        g = float(r.gross)
        rec["post_gross_ret"] = g
        rec["post_cost_bp"] = float(-r.costs * 1e4)
        h = ex.get("home_index", "")
        hk = w.get(h, np.nan) if h else np.nan
        rec["post_hold_home_ret"] = hk
        for k in BROAD:
            rec[f"post_excess_vs_{k}_bp"] = (g - w[k]) * 1e4 if fin(w[k]) else np.nan
        rec["post_excess_vs_home_bp"] = (g - hk) * 1e4 if fin(hk) else np.nan
        b = ex.get("beta_home", np.nan)
        if fin(b) and fin(hk):
            mk = float(b) * hk
            rec["post_mkt_part_bp"] = mk * 1e4
            rec["post_stock_part_bp"] = (g - mk) * 1e4
            rec["post_driver"] = driver_of(g, mk, g - mk)
        return rec

    # ------------------------------------------------------------------
    def day_rows(self, days: pd.DataFrame, pick_ctx: pd.DataFrame, T: pd.DataFrame,
                 exit_kind: Dict[str, str]) -> pd.DataFrame:
        """Market columns for each trade_days row (that session's own close) and the part of the day the position
        was held, split into the market part (beta x the home index over the same span) and the stock part."""
        ib = self.ib
        p = ib.pos(pd.to_datetime(days["date"]).values.astype("datetime64[D]"))
        out = pd.DataFrame(index=days.index)
        dret = days["day_ret"].to_numpy(float)
        out["mid_day_ret"] = self.fcol("mid_ret", p)
        out["small_day_ret"] = self.fcol("small_ret", p)
        out["nifty_minus_small_day"] = self.fcol("nifty_minus_small", p)
        out["vix_close"] = self.fcol("vix", p)
        out["vix_chg_pct"] = self.fcol("vix_chg_pct", p)
        out["ad_ratio"] = self.fcol("ad_ratio", p)
        out["environment"] = self.fcol("environment", p)
        out["high_stress"] = self.fcol("high_stress", p)
        hm = dict(zip(T["trade_id"].astype(str), pick_ctx["pre_home_index"].fillna("").astype(str)))
        bm = dict(zip(T["trade_id"].astype(str), pick_ctx["pre_beta_home"].astype(float)))
        tid = days["trade_id"].astype(str).to_numpy(object)
        home = np.array([hm.get(t, "") for t in tid], dtype=object)
        beta = np.array([bm.get(t, np.nan) for t in tid], dtype=float)
        out["home_index"] = home
        hret, hint, hgap = (np.full(len(days), np.nan) for _ in range(3))
        for k in BROAD:
            mk = home == k
            if mk.any():
                hret[mk] = self.fcol(f"{k}_ret", p[mk])
                hint[mk] = self.fcol(f"{k}_intraday", p[mk])
                hgap[mk] = self.fcol(f"{k}_gap", p[mk])
        out["home_day_ret"] = hret
        out["rel_home_day"] = dret - hret
        sess = days["session"].to_numpy(int)
        held = days["held_at_close"].to_numpy(bool)
        o, c = days["open"].to_numpy(float), days["close"].to_numpy(float)
        same = np.r_[False, tid[1:] == tid[:-1]]
        prev_c = np.where(same, np.r_[np.nan, c[:-1]], np.nan)
        prev_held = np.r_[False, held[:-1]] & same
        is_exit = days["is_exit_day"].to_numpy(bool)
        ek = np.array([exit_kind.get(t, "") for t in tid], dtype=object)
        stock, idx = np.full(len(days), np.nan), np.full(len(days), np.nan)
        with np.errstate(divide="ignore", invalid="ignore"):
            e1 = sess == 1                                       # bought at the open: open -> close
            stock[e1] = c[e1] / o[e1] - 1
            idx[e1] = hint[e1]
            thr = (sess >= 2) & prev_held & held                 # held through the whole day
            stock[thr] = c[thr] / prev_c[thr] - 1
            idx[thr] = hret[thr]
            xc = (sess >= 2) & prev_held & is_exit & (ek == "close")
            stock[xc] = c[xc] / prev_c[xc] - 1
            idx[xc] = hret[xc]
            xo = (sess >= 2) & prev_held & is_exit & (ek == "open")
            stock[xo] = o[xo] / prev_c[xo] - 1
            idx[xo] = hgap[xo]
        out["held_ret"] = stock
        out["home_held_ret"] = idx
        out["mkt_part_day_bp"] = beta * idx * 1e4
        out["stock_part_day_bp"] = stock * 1e4 - out["mkt_part_day_bp"].to_numpy(float)
        nd = days["nifty_day_ret"].to_numpy(float) if "nifty_day_ret" in days else self.fcol("nifty_ret", p)
        out["market_line"] = [f"NIFTY {pct(a_)}, Midcap {pct(b_)}, Smallcap {pct(c_)}"
                              + (f", breadth {float(d_):.2f}" if fin(d_) else "") + (f", VIX {v_:.1f}" if fin(v_) else "")
                              for a_, b_, c_, d_, v_ in zip(nd, out["mid_day_ret"].to_numpy(float),
                                                            out["small_day_ret"].to_numpy(float),
                                                            out["ad_ratio"].to_numpy(float),
                                                            out["vix_close"].to_numpy(float))]
        return out


# ======================================================================
# building / saving / loading
# ======================================================================
CTX_SUB = "context"


def save_breadth(base: Path, breadth: pd.DataFrame, meta: dict) -> Path:
    d = Path(base) / CTX_SUB
    d.mkdir(parents=True, exist_ok=True)
    breadth.to_parquet(d / "breadth.parquet", index=False)
    (d / "context_meta.json").write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    return d


def load_breadth(base: Optional[Path]):
    if base is None:
        return None
    d = Path(base) / CTX_SUB
    need = [d / "breadth.parquet", d / "context_meta.json"]
    if not all(p.exists() for p in need):
        return None
    try:
        meta = json.loads(need[1].read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    if meta.get("version") != CTX_VERSION:
        return None
    return pd.read_parquet(need[0]), meta


def light_context(market) -> "Context":
    """The run's context when one was built (market.ctx), else indices only (built once, kept on the market)."""
    if getattr(market, "ctx", None) is None:
        market.ctx = Context(market, IndexBook(market), None, None, {})
    return market.ctx


def build_context(ws, mode: str = "full", base: Optional[Path] = None, rebuild: bool = False,
                  amfi_dir: Optional[Path] = None, log=say) -> Optional[Context]:
    """mode: full     indices + AMFI + breadth; breadth from the saved copy when it is current (same last session),
                      else counted over every cached stock and saved
             auto     the saved breadth when there is any (even if older than the data: later days are blank and it
                      says so), else as full - the first run counts it once
             saved    the saved breadth only (never reads every stock)
             indices  indices + AMFI, no breadth
             none     no context"""
    if mode == "none":
        return None
    if mode not in ("full", "auto", "saved", "indices"):
        raise TLError(f"--context {mode}: use full, auto, saved, indices or none")
    if mode == "auto":
        mode = "saved" if (load_breadth(base) is not None and not rebuild) else "full"
    t0 = time.time()
    m = ws.market
    ib = IndexBook(m)
    core = [k for k in BROAD + ("vix",) if k in ib.missing]
    if core:
        log(f"   note: no daily file for {', '.join(SPEC[k][0] for k in core)} in the cache - those values are blank, "
            f"and so are the environment labels that need them")
    amfi = read_amfi_dir(ws.root, amfi_dir)
    for r in amfi.report:
        log(f"   AMFI {r['file']}: {r['status']}")
    if not amfi.report:
        log(f"   note: no AMFI lists in {Path(ws.root) / AMFI_SUBDIR} - size class blank (never filled)")
    run = {"mode": mode, "indices": ib.info, "missing_indices": list(ib.missing), "amfi_files": amfi.report,
           "definitions": DEFINITIONS}
    breadth, bmeta = None, {}
    if mode in ("full", "saved"):
        got = None if rebuild else load_breadth(base)
        if got is not None and mode == "full" and str(got[1].get("calendar_last")) != str(ib.cal[-1]):
            got = None
        if got is not None:
            breadth, bmeta = got
            run["breadth_source"] = f"saved copy built {bmeta.get('built')}"
            log(f"   breadth: the saved copy built {bmeta.get('built')} (to {bmeta.get('calendar_last')})")
            if str(bmeta.get("calendar_last")) != str(ib.cal[-1]):
                log(f"   note: the cache now runs to {ib.cal[-1]}; breadth after {bmeta.get('calendar_last')} is blank "
                    f"(refresh: python tl_context.py build --root ...)")
        elif mode == "full":
            syms = cache_stock_symbols(m)
            log(f"   breadth: advancers / decliners over {len(syms):,} cached stocks ...")
            breadth, bmeta = ad_breadth(m, ib.cal, syms, log=log)
            bmeta.update({"version": CTX_VERSION, "built": dt.datetime.now().isoformat(timespec="seconds"),
                          "calendar_last": str(ib.cal[-1])})
            run["breadth_source"] = "counted now"
            if base is not None:
                save_breadth(base, breadth, bmeta)
        else:
            run["breadth_source"] = "none saved"
            log("   note: no saved breadth yet (tl_context.py build, or one export, makes it) - breadth and the "
                "environment labels are blank")
    else:
        run["breadth_source"] = "not requested"
    run["breadth"] = bmeta
    ctx = Context(m, ib, breadth, amfi, bmeta)
    run["seconds"] = round(time.time() - t0, 1)
    ctx.run_meta = run
    m.ctx = ctx
    return ctx


# ======================================================================
# breakdown tables (reports)
# ======================================================================
AD_EDGES = (-np.inf, 0.40, 0.50, 0.60, np.inf)
AD_LABELS = ("< 0.40", "0.40 - 0.50", "0.50 - 0.60", ">= 0.60")
VIX5_EDGES = (-np.inf, -0.10, 0.0, 0.10, 0.25, np.inf)
VIX5_LABELS = ("< -10%", "-10% .. 0%", "0% .. +10%", "+10% .. +25%", ">= +25%")
DIV_EDGES = (-np.inf, -0.03, 0.0, 0.03, np.inf)
DIV_LABELS = ("< -3 pts (small caps ahead)", "-3 .. 0 pts", "0 .. +3 pts", ">= +3 pts (NIFTY ahead: narrow)")
HOLD_EDGES = (-np.inf, -0.03, -0.01, 0.01, 0.03, np.inf)
HOLD_LABELS = ("< -3%", "-3% .. -1%", "-1% .. +1%", "+1% .. +3%", ">= +3%")
SEVERE_BP = -500.0                  # declared: a severe loser loses 5% or more after costs

BREAKDOWN_DIMS = (
    # label, column, (numeric edges, labels) or category order, timing
    ("environment at the pick", "pre_environment", ENV5_ORDER, "before"),
    ("high stress at the pick", "pre_high_stress", ((-np.inf, 0.5, np.inf), ("no", "yes")), "before"),
    ("direction at the pick (stress ignored)", "pre_env_direction", ENV_ORDER, "before"),
    ("breadth at the pick (10-day A/D)", "pre_ad_ratio_10", (AD_EDGES, AD_LABELS), "before"),
    ("VIX 5-day change at the pick", "pre_vix_chg5_pct", (VIX5_EDGES, VIX5_LABELS), "before"),
    ("NIFTY minus Smallcap, 20 days, at the pick", "pre_nifty_minus_small_20", (DIV_EDGES, DIV_LABELS), "before"),
    ("size class (AMFI)", "pre_size_class", ("large", "mid", "small", "not in list", "no list"), "before"),
    ("home index", "pre_home_index_name", ("NIFTY 50", "Midcap 150", "Smallcap 250"), "before"),
    ("environment on the entry day", "post_entry_environment", ENV5_ORDER, "after"),
    ("Smallcap over the hold", "post_hold_small_ret", (HOLD_EDGES, HOLD_LABELS), "after"),
    ("what drove the trade", "post_driver", ("market", "stock", "both", "opposite", "flat"), "after"),
)


def _is_numeric_spec(spec) -> bool:
    return isinstance(spec, tuple) and len(spec) == 2 and isinstance(spec[0], tuple)


def breakdown(df: pd.DataFrame, values: Sequence[str], group_col: str = "engine", dims=BREAKDOWN_DIMS) -> pd.DataFrame:
    """Mean of each value column per bucket of each dimension, with 95% block-bootstrap intervals over signal days
    (circular blocks of 10 signal days, 2,000 resamples, seed 7), the win rate and the severe-loser rate."""
    rows = []
    if df is None or not len(df):
        return pd.DataFrame()
    for gkey, G in df.groupby(group_col, sort=True):
        tot = len(G)
        for label, col, spec, timing in dims:
            if col not in G.columns:
                continue
            if _is_numeric_spec(spec):
                b = bucket(G[col].to_numpy(float), spec[0], spec[1])
                order = list(spec[1])
            else:
                b = G[col].fillna("").astype(str).to_numpy(object)
                order = list(spec) + sorted(set(b) - set(spec) - {""})
            blank = int((b == "").sum())
            for bk in order + (["(blank)"] if blank else []):
                mk = (b == bk) if bk != "(blank)" else (b == "")
                if not mk.any():
                    continue
                sub = G[mk]
                rec = {group_col: gkey, "dimension": label, "timing": timing, "bucket": bk, "trades": int(mk.sum()),
                       "share": float(mk.sum() / tot), "days": int(pd.Series(sub["signal_day"]).nunique())}
                for v in values:
                    if v not in sub.columns:
                        continue
                    mm, lo, hi, _nd = bootstrap_mean_by_day(sub["signal_day"].values, sub[v].to_numpy(float))
                    rec[f"{v}_mean"], rec[f"{v}_lo"], rec[f"{v}_hi"] = mm, lo, hi
                if "net_bp" in sub.columns:
                    w = sub["net_bp"].to_numpy(float)
                    w = w[np.isfinite(w)]
                    rec["win_rate"] = float(np.mean(w > 0)) if len(w) else np.nan
                    rec["severe_rate"] = float(np.mean(w <= SEVERE_BP)) if len(w) else np.nan
                rows.append(rec)
    return pd.DataFrame(rows)


def breakdown_md(B: pd.DataFrame, values: Sequence[Tuple[str, str]], group_col: str = "engine") -> List[str]:
    """Markdown tables, one per (group, dimension)."""
    if B is None or B.empty:
        return ["(no rows)", ""]
    L: List[str] = []
    for gkey, G in B.groupby(group_col, sort=True):
        L += [f"#### {group_col} {gkey}", ""]
        for dim, H in G.groupby("dimension", sort=False):
            tm = H["timing"].iloc[0]
            L += [f"**{dim}** - {'known BEFORE entry' if tm == 'before' else 'observed AFTER entry: explains, cannot select'}",
                  "", "| bucket | trades | share | " + " | ".join(lbl for _, lbl in values) + " | win | severe |",
                  "|---|---|---|" + "---|" * len(values) + "---|---|"]
            for d in H.to_dict("records"):
                cells = []
                for v, _ in values:
                    mm, lo, hi = d.get(f"{v}_mean"), d.get(f"{v}_lo"), d.get(f"{v}_hi")
                    if fin(mm) and fin(lo) and fin(hi):
                        cells.append(f"{mm:+.1f} [{lo:+.1f}, {hi:+.1f}]")
                    else:
                        cells.append(f"{mm:+.1f}" if fin(mm) else "n/a")
                wr, sr = d.get("win_rate"), d.get("severe_rate")
                tail = f" | {wr:.0%} | {sr:.1%} |" if fin(wr) and fin(sr) else " | n/a | n/a |"
                L.append(f"| {d['bucket']} | {d['trades']:,} | {d['share']:.0%} | " + " | ".join(cells) + tail)
            L.append("")
    return L


# ======================================================================
# check / build / diary (command line)
# ======================================================================
def check_lines(ws) -> Tuple[List[str], List[str]]:
    """Index files, cached stocks for breadth and AMFI lists, for tl_check. Returns (lines, warnings)."""
    L, warn = [], []
    ib = IndexBook(ws.market)
    for k, sym, name, kind in INDEX_SPECS:
        inf = ib.info.get(k, {})
        if not inf.get("found"):
            L.append(f"   {sym:<16} MISSING")
            warn.append(f"{sym}_daily.parquet not in the cache ({name} values and the environment labels are blank)")
            continue
        behind = inf.get("sessions_behind_calendar")
        tail = "" if kind == "vol" else ("; open usable" if inf["open_ok"] else
                                         "; open NOT usable (equals the previous close) -> gaps blank")
        L.append(f"   {sym:<16} {inf['sessions']:,} sessions {inf['first']} .. {inf['last']}"
                 f"{'' if not behind else f' (STALE: {behind} sessions behind NIFTY)'}{tail}")
        if behind:
            warn.append(f"{sym} is {behind} sessions behind NIFTY 50")
    syms = cache_stock_symbols(ws.market)
    L.append(f"   breadth: {len(syms):,} cached stocks will be counted (advancers / decliners each day)")
    amfi = read_amfi_dir(ws.root)
    if not amfi.report:
        L.append(f"   AMFI lists: none in {Path(ws.root) / AMFI_SUBDIR} -> size class blank until you add them")
    for r in amfi.report:
        L.append(f"   AMFI {r['file']}: {r['status']}; half-year ending {r.get('period_end')}, used from "
                 f"{r.get('used_from', '-')} ({r.get('timing', '-')}), read with {r.get('read_with')}, rows "
                 f"{r.get('rows')}, ranks 1-250 found "
                 f"{r.get('ranks_1_250_found')}, an NSE symbol on "
                 f"{(format(r['nse_symbol_share_1_250'], '.1%') if fin(r.get('nse_symbol_share_1_250')) else '-')} of them")
        if not str(r["status"]).startswith("ok"):
            warn.append(f"AMFI file {r['file']}: {r['status']}")
    if amfi.lists:
        ends = [x.period_end for x in amfi.lists]
        L.append(f"   AMFI lists accepted: {len(ends)}, half-years ending {min(ends)} .. {max(ends)}")
        for a, b in zip(amfi.lists[:-1], amfi.lists[1:]):
            if b.effective_from > a.valid_to:
                warn.append(f"AMFI list missing between the half-years ending {a.period_end} and {b.period_end}: size "
                            f"class blank ('no list') from {a.valid_to} to {b.effective_from} (never carried forward)")
        last = amfi.lists[-1]
        d_last = max(last.effective_from, min(last.valid_to - 1, np.datetime64(ws.market.cal[-1], "D"))) \
            if len(ws.market.cal) else last.effective_from
        found = [amfi.lookup(s_, pd.Timestamp(d_last)) for s_ in syms]
        n_sym = sum(1 for f in found if f[0] in ("large", "mid", "small") and "via ISIN" not in f[3])
        n_isin = sum(1 for f in found if "via ISIN" in f[3])
        L.append(f"   AMFI coverage: of {len(syms):,} cached stocks, {n_sym:,} are in the latest list by symbol and "
                 f"{n_isin:,} via ISIN (renamed); the rest show 'not in list'")
        cal_end = ws.market.cal[-1] if len(ws.market.cal) else None
        if cal_end is not None and np.datetime64(cal_end, "D") >= last.valid_to:
            warn.append(f"the latest AMFI list (half-year ending {last.period_end}) is out of date from {last.valid_to}: "
                        f"size class blank after that - add the newer list")
    import importlib.util as _iu
    have = {m: _iu.find_spec(m) is not None for m in ("pypdf", "pdfplumber", "openpyxl")}
    L.append("   AMFI readers: PDF via " + ("pypdf" if have["pypdf"] else "pdfplumber" if have["pdfplumber"] else
                                           "NOTHING (pip install pypdf)") +
             "; Excel via " + ("openpyxl" if have["openpyxl"] else "NOTHING (pip install openpyxl)") + "; CSV built in")
    return L, warn


def diary_md(X: pd.DataFrame, title: str = "Market diary") -> str:
    L = [f"# {title}", "",
         "One line per session, from that day's close (nothing later). NIFTY / Midcap 150 / Smallcap 250 day returns "
         "('sd' = the move in standard deviations of the previous 60 days); NIFTY minus Smallcap (> 0 = NIFTY ahead); "
         "breadth = advancers / (advancers + decliners) over the cached stocks; VIX with its 5-day change and "
         "percentile of the last 250 sessions; environment as declared in tl_context.py.", ""]
    cur = None
    for r in X.itertuples(index=False):
        mo = pd.Timestamp(r.date).strftime("%B %Y")
        if mo != cur:
            L += ["", f"## {mo}", ""]
            cur = mo
        L.append(f"- {r.summary}")
    return "\n".join(L) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="tradelab market context")
    ap.add_argument("what", choices=["check", "build", "diary"])
    ap.add_argument("--root")
    ap.add_argument("--from", dest="d_from", default=None)
    ap.add_argument("--to", dest="d_to", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--amfi-dir", default=None)
    ap.add_argument("--context", default="auto", help="diary: auto (default) | full | saved | indices")
    ap.add_argument("--stage-e-any", action="store_true")
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    t0 = time.time()
    try:
        root = require_root(a.root)
        from tl_run import Workspace
        ws = Workspace(root, None, stage_e_any=a.stage_e_any)
        if a.what == "check":
            L, warn = check_lines(ws)
            say(f"{CTX_VERSION} ({VERSION}) - market context inputs in {root}:")
            for x in L:
                say(x)
            say("CONTEXT OK" if not warn else "CONTEXT WARNINGS:\n  - " + "\n  - ".join(warn))
            return 0
        base = out_base(a.out, root)
        if a.what == "build":
            ctx = build_context(ws, "full", base, rebuild=True, amfi_dir=Path(a.amfi_dir) if a.amfi_dir else None)
            bm = ctx.run_meta.get("breadth", {})
            say(f"DONE {base / CTX_SUB}: breadth over {bm.get('stocks_used', 0):,} stocks, median "
                f"{bm.get('median_ad_n', 0):,.0f} a session, to {bm.get('calendar_last')} ({time.time() - t0:,.0f} s)")
            return 0
        ctx = build_context(ws, a.context, base, amfi_dir=Path(a.amfi_dir) if a.amfi_dir else None)
        Fm = ctx.frame
        mk = np.ones(len(Fm), bool)
        if a.d_from:
            mk &= Fm["date"].values >= np.datetime64(parse_day(a.d_from), "ns")
        if a.d_to:
            mk &= Fm["date"].values <= np.datetime64(parse_day(a.d_to), "ns")
        X = Fm[mk].copy()
        X["summary"] = [day_sentence(r) for r in X.to_dict("records")]
        from tl_common import new_run_dir
        run = new_run_dir(base, "context", "TLD")
        write_table(X, run / "market_days")
        (run / "market_diary.md").write_text(diary_md(X), encoding="utf-8")
        for s in X["summary"].tail(30):
            say(s)
        say(f"DONE {run} ({len(X):,} sessions, {time.time() - t0:,.0f} s)")
        return 0
    except StopRun as e:
        say(f"STOPPED: {e}")
        return 3
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
