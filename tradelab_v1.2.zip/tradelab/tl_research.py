"""
tl_research.py - tradelab v1.2: why D / ENS trades win or lose in different markets (reads an export folder).

    python tl_research.py --export C:\\QuantData\\tradelab\\export\\TLX_20261024_001 --root %CACHE_DAILY_ROOT% --pm-run PM_20261017_001
        (tl_export runs this itself at the end; run it again only on an older export)

v1.2 (24 Oct 2026, after a review): training for a test year is PURGED (only trades whose actual exit came before
1 Jan of that year); a sign is compared on trades whose input is KNOWN (flagged vs known-unflagged); qualification
needs a one-sided bootstrap p <= 0.05 / 8 (Bonferroni over the 8 signs, 10,000 resamples); P&L and drawdown come
from the plan's compounded, cash-limited MONEY VIEW (tl_portfolio), not an additive proxy - and it is still not stage
E's execution simulator, so a CANDIDATE goes to a stage E replay before a forward test.

The research question: can the market conditions behind D / ENS's worst losses be seen BEFORE entry, and would
avoiding them cut drawdown without destroying the edge? This tool OBSERVES. It never filters a trade, never changes
the plan, and its thresholds were declared on 24 Oct 2026 before any real run (DECLARATION below; a change is a new
version, logged in tradelab_ledger.jsonl).

Uses the traded picks (ranks 1-3, finished) of the export and its market context (pre_* = known at the pick day's
close; post_* = observed after the entry). Writes <export>\\research\\:
  research_report.md        the answers, verdict first
  outcome_groups.csv        winners / losers / severe losers (net <= -500 bp): counts, P&L, market vs stock part
  outcome_profiles.csv      the pre-entry market of each group (means / shares) - what did the worst losses look like
  warning_signs.csv         each declared warning sign on ALL trades: how many severe losers it catches AND how many
                            winners it would have thrown away, flagged vs not (95% intervals), what skipping them would
                            have done to P&L and to the book's worst drawdown (in-sample: same history)
  walk_forward.csv          the chronological out-of-sample check: a sign qualifies on earlier years only, then is
                            judged on the next year's P&L and drawdown; repeated year by year
  book_by_environment.csv   the plan's book (1/15 of capital a slot) by the environment known at the previous close:
                            return, worst drawdown inside that environment, simultaneous positions
  severe_losers.md / .html  cards of the worst trades with the warning signs that fired before entry
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from tl_common import (BOOT, TLError, VERSION, bootstrap_daily, bootstrap_mean_by_day, circular_block_index, fmt_bp,
                       ledger_append, say, write_outputs_sha)
import tl_context as C

TOOL = "tl_research v1.2"
SLOTS = 15                           # the plan's book: 3 picks a day x 5 sessions -> 1/15 of capital a slot
ALPHA_FAMILY = 0.05                  # family-wise error over the declared signs (Bonferroni)
B_QUALIFY = 10_000                   # bootstrap resamples behind a qualification p-value (batches of 2,000)

# ----- DECLARED 24 Oct 2026, before any real run; never tuned on results -----
DECLARATION = {
    "version": "research-declaration-2 (2026-10-24)",
    "severe_bp": C.SEVERE_BP,
    "groups": "winner: net > 0; loser: -500 < net <= 0; severe: net <= -500 bp (after the 35 bp cost)",
    "warnings": [
        # id, words, column, operator, threshold
        ["W1", "high stress at the pick", "pre_high_stress", "==", 1],
        ["W2", "broad bearish at the pick", "pre_env_code", "==", C.ENV_CODE["broad_bearish"]],
        ["W3", "narrow bullish at the pick", "pre_env_code", "==", C.ENV_CODE["narrow_bullish"]],
        ["W4", "weak breadth: 10-day A/D below 0.40", "pre_ad_ratio_10", "<", 0.40],
        ["W5", "VIX up 15% or more in 5 days", "pre_vix_chg5_pct", ">=", 0.15],
        ["W6", "Smallcap fell 1.5% or more on the pick day", "pre_small_ret", "<=", -0.015],
        ["W7", "NIFTY ahead of Smallcap by 3 pts or more over 20 days", "pre_nifty_minus_small_20", ">=", 0.03],
        ["W8", "high-beta pick: beta to its home index 1.5 or more", "pre_beta_home", ">=", 1.5],
    ],
    "known_only": "a sign is compared on the trades whose input is known (flagged vs known-unflagged); a blank never "
                  "flags a trade",
    "purge": "a test year is qualified only on trades whose actual exit (incl. lower-circuit delays) came before 1 Jan "
             "of that year",
    "qualify": "on the purged training trades: >= 30 flagged trades on >= 20 signal days, and the one-sided bootstrap "
               "p-value of (flagged - unflagged mean net) < 0 at most 0.05 / 8 = 0.00625 (Bonferroni over the 8 "
               "signs; 10,000 circular-block resamples over signal days)",
    "candidate": "qualified in at least 2 test years; over those years skipping its flagged trades did not lower the "
                 "money view's return (summed) and improved the year's worst drawdown in at least half of them -> a "
                 "CANDIDATE for a stage E replay (the execution simulator), then a declared forward paper test; "
                 "otherwise NOT SUPPORTED or NEVER QUALIFIED. Nothing is ever applied automatically.",
    "money": "the plan's own fills through tradelab's money layer: Rs 10 lakh, 1/15 of the previous close's equity a "
             "new position, integer shares, 25% minimum order, flat 35 bp, compounded and cash-limited; a skipped "
             "trade's money stays in cash; each test year starts from fresh capital. Not stage E's simulator.",
    "book": "the money view by environment: each day labelled with the environment known at the previous close",
}


def declaration_hash() -> str:
    return hashlib.sha256(json.dumps(DECLARATION, sort_keys=True).encode("utf-8")).hexdigest()[:16]


# ----------------------------------------------------------------------
# statistics
# ----------------------------------------------------------------------
def boot_diff_by_day(days: np.ndarray, values: np.ndarray, flag: np.ndarray, known=None, B: Optional[int] = None,
                     min_days: int = 20):
    """Mean(flagged) - mean(known unflagged) with a circular block bootstrap over signal days (the project's
    convention). Rows whose input is unknown are left out of BOTH groups. Returns (diff, lo, hi, p): the 95%
    interval and p = the share of resamples where the difference is >= 0 (one-sided: is the flagged group worse?)."""
    v = np.asarray(values, float)
    f = np.asarray(flag, bool)
    ok = np.isfinite(v) & (np.ones(len(v), bool) if known is None else np.asarray(known, bool))
    v, f, d = v[ok], f[ok], np.asarray(days)[ok]
    if not f.any() or f.all():
        return np.nan, np.nan, np.nan, np.nan
    ud, inv = np.unique(d, return_inverse=True)
    S1 = np.bincount(inv, weights=np.where(f, v, 0.0), minlength=len(ud))
    N1 = np.bincount(inv, weights=f.astype(float), minlength=len(ud))
    S0 = np.bincount(inv, weights=np.where(~f, v, 0.0), minlength=len(ud))
    N0 = np.bincount(inv, weights=(~f).astype(float), minlength=len(ud))
    diff = S1.sum() / N1.sum() - S0.sum() / N0.sum()
    if len(ud) < min_days or (N1 > 0).sum() < 2:
        return float(diff), np.nan, np.nan, np.nan
    total = int(B or BOOT["B"])
    parts = []
    for k in range(max(1, total // BOOT["B"])):            # batches of 2,000 (seeds 7, 8, ...): memory stays small
        I = circular_block_index(len(ud), min(BOOT["B"], total), BOOT["block"], BOOT["seed"] + k)
        with np.errstate(invalid="ignore", divide="ignore"):
            parts.append(S1[I].sum(1) / N1[I].sum(1) - S0[I].sum(1) / N0[I].sum(1))
    st = np.concatenate(parts)
    st = st[np.isfinite(st)]
    if len(st) < total * 0.9:
        return float(diff), np.nan, np.nan, np.nan
    lo, hi = np.percentile(st, [2.5, 97.5])
    return float(diff), float(lo), float(hi), float(np.mean(st >= 0))


def flag_of(df: pd.DataFrame, w: Sequence) -> np.ndarray:
    _id, _words, col, op, thr = w
    if col not in df.columns:
        return np.zeros(len(df), bool)
    x = pd.to_numeric(df[col], errors="coerce").to_numpy(float)
    with np.errstate(invalid="ignore"):
        r = {"==": x == thr, "<": x < thr, "<=": x <= thr, ">": x > thr, ">=": x >= thr}[op]
    return np.where(np.isfinite(x), r, False)


def known_of(df: pd.DataFrame, w: Sequence) -> np.ndarray:
    """True where the sign's input is known (a blank can neither flag nor clear a trade)."""
    col = w[2]
    if col not in df.columns:
        return np.zeros(len(df), bool)
    return np.isfinite(pd.to_numeric(df[col], errors="coerce").to_numpy(float))


def money_view(money, ids, skip=()) -> dict:
    """The plan's compounded, cash-limited portfolio over these trades (skipped ones left in cash): total return,
    worst drawdown (from the starting capital), its peak / trough dates and the daily table. money(ids, skip) ->
    (daily, stats) comes from tl_export (or tl_research --root --pm-run); without it everything here is blank."""
    blank = {"ret": np.nan, "dd": np.nan, "peak": None, "trough": None, "daily": None}
    if money is None:
        return blank
    daily, st = money(list(ids), set(skip))
    if daily is None or len(daily) == 0:
        return {"ret": 0.0, "dd": 0.0, "peak": None, "trough": None, "daily": daily}
    return {"ret": float(st.get("total_return", np.nan)), "dd": float(st.get("max_drawdown", np.nan)),
            "peak": st.get("dd_peak"), "trough": st.get("dd_trough"), "daily": daily}


def book_series(days: pd.DataFrame, exclude: Optional[set] = None) -> pd.Series:
    """The plan's additive book (1/15 of capital a slot): day return by date from the held trade-days."""
    d = days
    if exclude:
        d = d[~d["trade_id"].isin(exclude)]
    if d.empty:
        return pd.Series(dtype=float)
    s = d.groupby("date")["day_pnl_bp"].sum(min_count=1) / 1e4 / SLOTS
    s.index = pd.to_datetime(s.index)
    return s.sort_index()


def max_dd(ret: pd.Series, on: Optional[pd.DatetimeIndex] = None) -> Tuple[float, object, object]:
    """Worst drawdown of the additive curve (fraction of capital), its peak and trough dates."""
    r = ret if on is None else ret.reindex(on).fillna(0.0)
    if r.empty:
        return np.nan, None, None
    cum = r.cumsum()
    peak = cum.cummax().clip(lower=0.0)
    dd = cum - peak
    t = dd.idxmin()
    if dd.loc[t] >= 0:
        return 0.0, None, None
    p = cum.loc[:t][cum.loc[:t] >= peak.loc[t] - 1e-15].index
    return float(dd.loc[t]), (p[-1] if len(p) else r.index[0]), t


# ----------------------------------------------------------------------
# the analyses
# ----------------------------------------------------------------------
def outcome_of(net_bp: np.ndarray) -> np.ndarray:
    v = np.asarray(net_bp, float)
    out = np.full(len(v), "", dtype=object)
    out[v > 0] = "winner"
    out[(v <= 0) & (v > C.SEVERE_BP)] = "loser"
    out[v <= C.SEVERE_BP] = "severe_loser"
    return out


def outcome_groups(T: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for e, G in T.groupby("engine"):
        for g in ("winner", "loser", "severe_loser"):
            H = G[G["outcome"] == g]
            if H.empty:
                continue
            m, lo, hi, nd = bootstrap_mean_by_day(H["signal_day"].values, H["net_bp"].to_numpy(float))
            rows.append({"engine": e, "group": g, "trades": len(H), "share": len(H) / len(G), "mean_net_bp": m,
                         "net_lo": lo, "net_hi": hi, "sum_net_bp": float(H["net_bp"].sum()),
                         "median_mae": float(H["mae"].median()) if "mae" in H else np.nan,
                         "mean_mkt_part_bp": float(H["post_mkt_part_bp"].mean()) if "post_mkt_part_bp" in H else np.nan,
                         "mean_stock_part_bp": float(H["post_stock_part_bp"].mean()) if "post_stock_part_bp" in H else np.nan,
                         "share_driven_by_market": float((H.get("post_driver", pd.Series(dtype=str)) == "market").mean())})
    return pd.DataFrame(rows)


PROFILE_NUM = [("pre_ad_ratio_10", "breadth, 10-day A/D", "ratio"), ("pre_ad_ratio", "breadth on the pick day", "ratio"),
               ("pre_vix", "VIX", "level"), ("pre_vix_chg5_pct", "VIX 5-day change", "pct"),
               ("pre_vix_pct250", "VIX percentile", "ratio"),
               ("pre_nifty_minus_small_20", "NIFTY minus Smallcap, 20 days", "pct"),
               ("pre_nifty_minus_mid_20", "NIFTY minus Midcap, 20 days", "pct"),
               ("pre_small_ret", "Smallcap pick-day move", "pct"), ("pre_prev_small_ret", "Smallcap move the day before", "pct"),
               ("pre_small_ret5", "Smallcap 5 days", "pct"), ("pre_nifty_vs_ma50", "NIFTY vs its 50-day average", "pct"),
               ("pre_small_vs_ma50", "Smallcap vs its 50-day average", "pct"),
               ("pre_beta_home", "beta to the home index", "num"), ("pre_corr_home", "correlation with the home index", "num"),
               ("pre_stock_ret", "the stock's pick-day move", "pct")]
PROFILE_CAT = [("pre_environment", "environment"), ("pre_high_stress", "high stress"),
               ("pre_size_class", "size class (AMFI)"), ("pre_home_index_name", "home index")]


def outcome_profiles(T: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for e, G in T.groupby("engine"):
        for col, lbl, fmt in PROFILE_NUM:
            if col not in G:
                continue
            rec = {"engine": e, "field": col, "meaning": lbl, "kind": "mean (median)", "format": fmt}
            vals = {}
            for g in ("winner", "loser", "severe_loser"):
                x = pd.to_numeric(G.loc[G["outcome"] == g, col], errors="coerce")
                rec[f"{g}_mean"], rec[f"{g}_median"] = float(x.mean()), float(x.median())
                vals[g] = x.dropna().to_numpy(float)
            a, b = vals.get("severe_loser", np.array([])), vals.get("winner", np.array([]))
            sd = np.sqrt((np.var(a) + np.var(b)) / 2) if len(a) > 1 and len(b) > 1 else np.nan
            rec["severe_minus_winner_in_sd"] = float((a.mean() - b.mean()) / sd) if fin_pos(sd) else np.nan
            rows.append(rec)
        for col, lbl in PROFILE_CAT:
            if col not in G:
                continue
            vals = G[col].map(_cat_text)
            for v in sorted(set(vals)):
                rec = {"engine": e, "field": col, "meaning": f"{lbl} = {v}", "kind": "share of the group",
                       "format": "share"}
                for g in ("winner", "loser", "severe_loser"):
                    mk = (G["outcome"] == g).to_numpy()
                    rec[f"{g}_mean"] = float((vals[mk] == v).mean()) if mk.any() else np.nan
                    rec[f"{g}_median"] = np.nan
                rec["severe_minus_winner_in_sd"] = np.nan
                rows.append(rec)
    return pd.DataFrame(rows)


def _cat_text(x) -> str:
    """A category value as text, the same on pandas 2 and 3: blank / yes / no / the text."""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return "(blank)"
    if isinstance(x, (int, float, np.floating, np.integer)) and not isinstance(x, bool):
        return "yes" if float(x) == 1.0 else ("no" if float(x) == 0.0 else f"{float(x):g}")
    t = str(x)
    return "(blank)" if t in ("", "nan", "None") else t


def fin_pos(x) -> bool:
    return C.fin(x) and float(x) > 0


def warning_table(T: pd.DataFrame, money=None) -> pd.DataFrame:
    rows = []
    for e, G in T.groupby("engine"):
        ids = list(G["trade_id"])
        base = money_view(money, ids)
        sev, win, los = (G["outcome"] == "severe_loser").to_numpy(), (G["outcome"] == "winner").to_numpy(), \
            (G["outcome"] == "loser").to_numpy()
        for w in DECLARATION["warnings"]:
            f = flag_of(G, w)
            known = known_of(G, w)
            net = G["net_bp"].to_numpy(float)
            d, lo, hi, pv = boot_diff_by_day(G["signal_day"].values, net, f, known)
            m1 = float(net[f].mean()) if f.any() else np.nan
            m0 = float(net[~f & known].mean()) if (~f & known).any() else np.nan
            alt = money_view(money, ids, set(G.loc[f, "trade_id"]))
            dd0, dd1 = base["dd"], alt["dd"]
            rows.append({"engine": e, "warning": w[0], "words": w[1], "rule": f"{w[2]} {w[3]} {w[4]}",
                         "trades": int(len(G)), "known": int(known.sum()), "unknown": int((~known).sum()),
                         "flagged": int(f.sum()),
                         "flagged_share": float(f.mean()), "flag_days": int(pd.Series(G.loc[f, "signal_day"]).nunique()),
                         "severe_caught": int((f & sev).sum()), "severe_total": int(sev.sum()),
                         "severe_recall": float((f & sev).sum() / max(1, sev.sum())),
                         "winners_flagged": int((f & win).sum()), "winners_total": int(win.sum()),
                         "winner_cost": float((f & win).sum() / max(1, win.sum())),
                         "losers_flagged": int((f & los).sum()),
                         "severe_rate_flagged": float(sev[f].mean()) if f.any() else np.nan,
                         "severe_rate_all": float(sev.mean()),
                         "lift": float(sev[f].mean() / sev.mean()) if f.any() and sev.mean() > 0 else np.nan,
                         "mean_net_flagged_bp": m1, "mean_net_unflagged_bp": m0, "diff_bp": d, "diff_lo": lo,
                         "diff_hi": hi, "diff_p": pv, "losses_avoided_bp": float(-net[f & (net < 0)].sum()),
                         "wins_forgone_bp": float(net[f & (net > 0)].sum()), "pnl_change_if_skipped_bp": float(-net[f].sum()),
                         "book_return": base["ret"], "book_return_if_skipped": alt["ret"],
                         "book_max_dd": dd0, "book_max_dd_if_skipped": dd1,
                         "book_dd_change": (dd1 - dd0) if C.fin(dd0) and C.fin(dd1) else np.nan})
    return pd.DataFrame(rows)


def walk_forward(T: pd.DataFrame, money=None) -> pd.DataFrame:
    """Chronological out-of-sample check, year by year: qualify on PURGED earlier trades (exited before 1 Jan of the
    test year), known inputs only, Bonferroni p; judge on the year itself in the money view (fresh capital)."""
    rows = []
    a_one = ALPHA_FAMILY / len(DECLARATION["warnings"])
    for e, G in T.groupby("engine"):
        yg = pd.DatetimeIndex(G["signal_day"]).year.to_numpy()
        ex = pd.to_datetime(G["exit_day"]) if "exit_day" in G else pd.Series(pd.NaT, index=G.index)
        years = sorted(set(yg))
        for Y in years[1:]:
            done = (ex < pd.Timestamp(f"{Y}-01-01")).to_numpy()
            tr, te = G[(yg < Y) & done], G[yg == Y]
            purged = int(((yg < Y) & ~done).sum())
            if tr.empty or te.empty:
                continue
            ids = list(te["trade_id"])
            base = money_view(money, ids)
            net = te["net_bp"].to_numpy(float)
            out = te["outcome"].to_numpy()
            any_q = np.zeros(len(te), bool)
            for w in DECLARATION["warnings"]:
                ftr, ktr = flag_of(tr, w), known_of(tr, w)
                d, lo, hi, pv = boot_diff_by_day(tr["signal_day"].values, tr["net_bp"].to_numpy(float), ftr, ktr,
                                                 B=B_QUALIFY)
                nflag, ndays = int(ftr.sum()), int(pd.Series(tr.loc[ftr, "signal_day"]).nunique())
                q = bool(nflag >= 30 and ndays >= 20 and C.fin(pv) and pv <= a_one)
                fte = flag_of(te, w)
                rec = {"engine": e, "warning": w[0], "test_year": int(Y), "train_years": f"{years[0]}-{Y - 1}",
                       "train_trades": int(len(tr)), "train_purged": purged, "train_unknown": int((~ktr).sum()),
                       "train_flagged": nflag, "train_flag_days": ndays, "train_diff_bp": d, "train_diff_lo": lo,
                       "train_diff_hi": hi, "train_p": pv, "p_needed": a_one, "qualified": q,
                       "test_trades": int(len(te)), "test_flagged": int(fte.sum()),
                       "test_unknown": int((~known_of(te, w)).sum())}
                if q:
                    any_q |= fte
                    alt = money_view(money, ids, set(te.loc[fte, "trade_id"]))
                    rec.update({"test_severe_avoided": int((fte & (out == "severe_loser")).sum()),
                                "test_winners_forgone": int((fte & (out == "winner")).sum()),
                                "test_pnl_change_bp": float(-net[fte].sum()),
                                "test_mean_net_flagged_bp": float(net[fte].mean()) if fte.any() else np.nan,
                                "test_return": base["ret"], "test_return_if_skipped": alt["ret"],
                                "test_return_change": alt["ret"] - base["ret"],
                                "test_book_max_dd": base["dd"], "test_book_max_dd_if_skipped": alt["dd"],
                                "test_dd_improved": bool(C.fin(base["dd"]) and C.fin(alt["dd"]) and
                                                         alt["dd"] > base["dd"] + 1e-12)})
                rows.append(rec)
            alt = money_view(money, ids, set(te.loc[any_q, "trade_id"]))
            rows.append({"engine": e, "warning": "ANY", "test_year": int(Y), "train_years": f"{years[0]}-{Y - 1}",
                         "train_trades": int(len(tr)), "train_purged": purged,
                         "qualified": bool(any_q.any()), "test_trades": int(len(te)), "test_flagged": int(any_q.sum()),
                         "test_severe_avoided": int((any_q & (out == "severe_loser")).sum()),
                         "test_winners_forgone": int((any_q & (out == "winner")).sum()),
                         "test_pnl_change_bp": float(-net[any_q].sum()), "test_return": base["ret"],
                         "test_return_if_skipped": alt["ret"], "test_return_change": alt["ret"] - base["ret"],
                         "test_book_max_dd": base["dd"], "test_book_max_dd_if_skipped": alt["dd"],
                         "test_dd_improved": bool(C.fin(base["dd"]) and C.fin(alt["dd"]) and
                                                  alt["dd"] > base["dd"] + 1e-12)})
    return pd.DataFrame(rows)


def walk_verdicts(WF: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if WF.empty:
        return pd.DataFrame()
    for (e, w), G in WF.groupby(["engine", "warning"], sort=False):
        Q = G[G["qualified"] == True]  # noqa: E712
        nq, ny = len(Q), len(G)
        pnl = float(Q["test_pnl_change_bp"].sum()) if nq else 0.0
        ret = float(Q["test_return_change"].sum(min_count=nq)) if nq else 0.0
        imp = int(Q["test_dd_improved"].sum()) if nq else 0
        ok = nq >= 2 and C.fin(ret) and ret >= 0 and imp >= nq / 2
        rows.append({"engine": e, "warning": w, "test_years": ny, "qualified_years": nq,
                     "return_change": ret, "pnl_change_bp": pnl, "severe_avoided": int(Q["test_severe_avoided"].sum()) if nq else 0,
                     "winners_forgone": int(Q["test_winners_forgone"].sum()) if nq else 0,
                     "dd_improved_years": imp, "verdict": ("CANDIDATE for a stage E replay" if ok else
                                                           ("NOT SUPPORTED" if nq else "NEVER QUALIFIED"))})
    return pd.DataFrame(rows)


def by_environment(daily: pd.DataFrame, env_prev: pd.Series, ret_col: str, pos_col: Optional[str],
                   group_col: Optional[str] = None, exposure_col: Optional[str] = None, additive: bool = True) -> pd.DataFrame:
    """Daily returns grouped by the environment known at the previous close: return, worst drawdown inside the
    environment (its days chained), simultaneous positions."""
    X = daily.copy()
    X["date"] = pd.to_datetime(X["date"])
    X["env_prev"] = X["date"].map(env_prev).fillna("(unknown)")
    rows = []
    groups = X.groupby(group_col) if group_col else [("all", X)]
    for gk, G in groups:
        for env in list(C.ENV5_ORDER) + ["(unknown)"]:
            H = G[G["env_prev"] == env].sort_values("date")
            if H.empty:
                continue
            r = H[ret_col].astype(float).fillna(0.0)
            m, lo, hi = bootstrap_daily(r.to_numpy() * 1e4)
            if additive:
                cum = r.cumsum()
                dd = float((cum - cum.cummax().clip(lower=0)).min())
                tot = float(r.sum())
            else:
                eq = (1 + r).cumprod()
                dd = float((eq / eq.cummax().clip(lower=1.0) - 1).min())
                tot = float(eq.iloc[-1] - 1)
            rec = {"group": gk, "environment": env, "days": int(len(H)), "share_of_days": len(H) / len(G),
                   "mean_day_bp": m, "lo": lo, "hi": hi, "total_return": tot, "max_drawdown_inside": dd,
                   "worst_day_bp": float(r.min() * 1e4), "best_day_bp": float(r.max() * 1e4)}
            if pos_col and pos_col in H:
                rec["avg_positions"] = float(H[pos_col].mean())
                rec["max_positions"] = float(H[pos_col].max())
            if exposure_col and exposure_col in H:
                rec["avg_exposure"] = float(H[exposure_col].mean())
                rec["max_exposure"] = float(H[exposure_col].max())
            rows.append(rec)
    return pd.DataFrame(rows)


def env_prev_map(mk: pd.DataFrame) -> pd.Series:
    """date -> the environment label known at the PREVIOUS session's close (what a trader knew that morning)."""
    M = mk[["date", "environment"]].copy()
    M["date"] = pd.to_datetime(M["date"])
    M = M.sort_values("date")
    prev = M["environment"].shift(1).fillna("").replace("", "(unknown)")
    return pd.Series(prev.to_numpy(), index=M["date"])


# ----------------------------------------------------------------------
# the report
# ----------------------------------------------------------------------
def report_md(meta: dict, OG: pd.DataFrame, PR: pd.DataFrame, WT: pd.DataFrame, WF: pd.DataFrame, WV: pd.DataFrame,
              BE: pd.DataFrame, worst_dd: dict) -> str:
    L = [f"# Research: why D / ENS trades win or lose in different markets", "",
         f"{TOOL} ({VERSION}), {meta['created']}; export {meta['export']}; declaration {meta['declaration_hash']} "
         f"({DECLARATION['version']}). Traded picks only (ranks 1-3, finished): "
         + ", ".join(f"{e} {n:,}" for e, n in meta["trades"].items()) + ".", "",
         "**Question:** can the market conditions behind the worst losses be seen BEFORE entry, and would avoiding them "
         "cut drawdown without destroying the edge? This report observes only: nothing is filtered, the plan is "
         "unchanged, and every threshold below was declared on 24 Oct 2026 before any real run "
         "(research-declaration-2 after a review: purged training, known inputs only, Bonferroni, money view).", "",
         "**What the numbers are:** trade nets are pick_meta's recorded plan nets (flat 35 bp round trip). Returns and "
         "drawdowns are tradelab's money view of the plan (compounded, cash-limited) - NOT stage E's execution "
         "backtest (EXEC_20260930_001, the -47.64% baseline). Lower-circuit exits follow stage E's own rule.", ""]
    # verdict first
    L += ["## Verdict first", ""]
    if WV is not None and not WV.empty:
        for e, G in WV.groupby("engine"):
            cands = G[G["verdict"].str.startswith("CANDIDATE") & (G["warning"] != "ANY")]
            anyrow = G[G["warning"] == "ANY"]
            L.append(f"- **{e}**: walk-forward (each year judged by signs chosen on earlier years only): "
                     + (f"{len(cands)} candidate sign(s): " + ", ".join(cands["warning"]) if len(cands) else
                        "no warning sign survives out of sample")
                     + (f"; all qualified signs together: money-view return change "
                        f"{sgn_pct(anyrow['return_change'].iloc[0])} (summed over qualified years), worst "
                        f"drawdown improved in {int(anyrow['dd_improved_years'].iloc[0])} of "
                        f"{int(anyrow['qualified_years'].iloc[0])} qualified year(s)." if len(anyrow) else "."))
    if WV is None or WV.empty:
        L.append("- Walk-forward: not enough history (it needs trades in at least two calendar years); sections 1-3 "
                 "and 5 below are descriptive only.")
    L += ["- A CANDIDATE is not a rule: next comes a replay in stage E's execution simulator (the -47.64% baseline; "
          "the -25% target can only be judged there), then a declared forward paper test (month-6 checkpoint).", ""]
    L += ["## 1. Winners, losers and severe losers", "",
          f"Severe loser = net <= {C.SEVERE_BP:+.0f} bp after costs. Market / stock part: beta to the home index x that "
          "index over the same hold, and the rest.", "",
          "| engine | group | trades | share | mean net bp | sum net bp | median MAE | market part bp | stock part bp | driven by market |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in OG.to_dict("records"):
        L.append(f"| {r['engine']} | {r['group']} | {r['trades']:,} | {r['share']:.1%} | {fmt_bp(r['mean_net_bp'], r['net_lo'], r['net_hi'])} "
                 f"| {r['sum_net_bp']:+,.0f} | {r['median_mae']:+.2%} | {r['mean_mkt_part_bp']:+.1f} | "
                 f"{r['mean_stock_part_bp']:+.1f} | {r['share_driven_by_market']:.0%} |")
    L += ["", "## 2. What the market looked like before entry, by outcome", "",
          "Means (shares for categories) of pre-entry values. 'sd gap' = (severe losers - winners) / pooled sd: about "
          "0.2 is small, 0.5 medium. Descriptive - many fields are compared.", ""]
    for e, G in PR.groupby("engine"):
        L += [f"#### {e}", "", "| field | winners | losers | severe losers | sd gap |", "|---|---|---|---|---|"]
        for r in G.to_dict("records"):
            if r["kind"].startswith("share"):
                L.append(f"| {r['meaning']} | {r['winner_mean']:.1%} | {r['loser_mean']:.1%} | {r['severe_loser_mean']:.1%} | |")
            else:
                fm = r.get("format", "num")
                f = (lambda x, fm=fm: "n/a" if not C.fin(x) else (C.pct(x, 2) if fm == "pct" else (
                    f"{x:.2f}" if fm in ("ratio", "num") else f"{x:.1f}")))
                gap = r["severe_minus_winner_in_sd"]
                gtxt = f"{gap:+.2f}" if C.fin(gap) else "n/a"
                L.append(f"| {r['meaning']} | {f(r['winner_mean'])} | {f(r['loser_mean'])} | "
                         f"{f(r['severe_loser_mean'])} | {gtxt} |")
        L.append("")
    L += ["## 3. Warning signs on ALL trades (in-sample: the same history)", "",
          "Each sign is a yes/no condition known before entry. 'catches' = severe losers it flags; 'costs' = winners it "
          "flags too. 'difference' = mean net of flagged minus KNOWN unflagged trades (blank inputs left out of both; "
          "'unknown' counts them) with its 95% interval and one-sided p. 'skip' = what skipping the flagged trades "
          "would have done: P&L in bp (one slot each, summed) and the money view's worst drawdown with and without "
          "them. A sign that also flags many winners destroys the edge it protects.", ""]
    for e, G in WT.groupby("engine"):
        L += [f"#### {e}", "", "| sign | flags (unknown) | catches severe | costs winners | severe rate flagged / all | "
              "difference bp (p) | P&L if skipped bp | money view: worst drawdown -> if skipped |",
              "|---|---|---|---|---|---|---|---|"]
        for r in G.to_dict("records"):
            ptxt = f" (p {r['diff_p']:.4f})" if C.fin(r.get("diff_p")) else ""
            L.append(f"| {r['warning']} {r['words']} | {r['flagged']:,} ({r['flagged_share']:.1%}; {r['unknown']:,}) | "
                     f"{r['severe_caught']}/{r['severe_total']} ({r['severe_recall']:.0%}) | {r['winners_flagged']}/"
                     f"{r['winners_total']} ({r['winner_cost']:.0%}) | {pct_or(r['severe_rate_flagged'])} / "
                     f"{pct_or(r['severe_rate_all'])} | {fmt_bp(r['diff_bp'], r['diff_lo'], r['diff_hi'])}{ptxt} | "
                     f"{r['pnl_change_if_skipped_bp']:+,.0f} | {pct_or(r['book_max_dd'], 2)} -> "
                     f"{pct_or(r['book_max_dd_if_skipped'], 2)} |")
        L.append("")
    L += ["## 4. Out of sample, in time order (walk-forward)", "",
          f"For each year: {DECLARATION['purge']}; a sign QUALIFIES {DECLARATION['qualify']}. A qualified sign is then "
          "judged on that year alone in the money view (fresh capital): the year's return and worst drawdown with and "
          f"without its flagged trades. Verdict rule: {DECLARATION['candidate']}", ""]
    if WV is not None and not WV.empty:
        L += ["| engine | sign | qualified years | return change (money view) | P&L change bp | severe avoided | "
              "winners forgone | drawdown improved | verdict |", "|---|---|---|---|---|---|---|---|---|"]
        for r in WV.to_dict("records"):
            L.append(f"| {r['engine']} | {r['warning']} | {r['qualified_years']}/{r['test_years']} | "
                     f"{sgn_pct(r['return_change'])} | {r['pnl_change_bp']:+,.0f} | {r['severe_avoided']} | {r['winners_forgone']} | "
                     f"{r['dd_improved_years']}/{r['qualified_years']} | {r['verdict']} |")
        pg = WF[WF["warning"] == "ANY"].groupby("engine")["train_purged"].sum() if "train_purged" in WF else {}
        L += ["Purged from training (exited inside the test year): "
              + ", ".join(f"{k} {int(v):,} trade-folds" for k, v in dict(pg).items()) + ".", ""]
    L += ["## 5. The plan's money view by market environment", "",
          f"{DECLARATION['money']} {DECLARATION['book']}. Mean day return in bp with a 95% block-bootstrap interval; "
          "worst drawdown inside = that environment's days chained together; positions = trades held at the close; "
          "exposure = invested / equity.", "",
          "| engine | environment (previous close) | days | mean day bp | total | worst drawdown inside | worst day bp | avg / max positions |",
          "|---|---|---|---|---|---|---|---|"]
    for r in BE.to_dict("records"):
        L.append(f"| {r['group']} | {r['environment']} | {r['days']:,} ({r['share_of_days']:.0%}) | "
                 f"{fmt_bp(r['mean_day_bp'], r['lo'], r['hi'], nd=2)} | {r['total_return']:+.2%} | "
                 f"{r['max_drawdown_inside']:+.2%} | {r['worst_day_bp']:+.0f} | {r.get('avg_positions', np.nan):.1f} / "
                 f"{r.get('max_positions', np.nan):.0f} |")
    L += ["", "**The book's worst drawdown and the environments during it**", ""]
    for e, d in worst_dd.items():
        if d.get("dd") is None:
            continue
        L.append(f"- {e}: {pct_or(d['dd'], 2)} from {d['peak']} to {d['trough']}; environments (previous close) on "
                 f"those days: " + ", ".join(f"{k} {v:.0%}" for k, v in d["mix"].items()))
    L += ["", "## How much to trust this", "",
          "- Same 2020-2026 history the engines were built and studied on: sections 1-3 and 5 describe it. Section 4 "
          "is the honest test - each year judged only by signs chosen on earlier years - but it is still the same "
          "history; the forward paper ledger is the only untouched evidence.",
          f"- {len(DECLARATION['warnings'])} signs are tested per engine and year: qualification uses a Bonferroni "
          "p-value (0.05 / 8), so luck alone qualifies a sign in about 5% of engine-years at most; the descriptive 95% "
          "intervals in section 3 are not corrected.",
          "- Breadth counts the stocks in your cache (survivors), not NSE's official advance/decline. Size class is "
          "AMFI's list in force on the pick day, blank where no list was given.",
          "- Returns and drawdowns are tradelab's money view (compounded, cash-limited, flat 35 bp), not stage E's "
          "execution simulator; a CANDIDATE has to be replayed there before it can speak to the -25% target.", "",
          "## Files", "", "- outcome_groups.csv, outcome_profiles.csv, warning_signs.csv, walk_forward.csv (+ "
          "walk_forward_verdicts.csv), book_by_environment.csv, severe_losers.md / .html"]
    return "\n".join(L) + "\n"


def sgn_pct(x) -> str:
    return f"{float(x):+.2%}" if C.fin(x) else "n/a"


def pct_or(x, nd: int = 1) -> str:
    return f"{float(x):+.{nd}%}" if C.fin(x) and float(x) < 0 else (f"{float(x):.{nd}%}" if C.fin(x) else "n/a")


# ----------------------------------------------------------------------
def run(ex_dir: Path, trades: Optional[pd.DataFrame] = None, days: Optional[pd.DataFrame] = None,
        book: Optional[pd.DataFrame] = None, mk: Optional[pd.DataFrame] = None, base: Optional[Path] = None,
        cards: int = 20, log=say, money=None) -> dict:
    """Read (or take) an export's tables and write <export>/research/. money(ids, skip) -> (daily, stats) is the
    plan's money view (tl_export.make_plan_money); without it the money columns and the verdicts stay blank."""
    t0 = time.time()
    ex_dir = Path(ex_dir)
    trades = trades if trades is not None else pd.read_parquet(ex_dir / "trades.parquet")
    days = days if days is not None else pd.read_parquet(ex_dir / "trade_days.parquet")
    book = book if book is not None else pd.read_parquet(ex_dir / "daily_book.parquet")
    mk = mk if mk is not None else pd.read_parquet(ex_dir / "market_days.parquet")
    need = [c for c in ("pre_environment", "pre_high_stress", "net_bp") if c not in trades.columns]
    if need:
        raise TLError(f"{ex_dir} has no market context ({need}) - run tl_export.py v1.1 with --context full")
    T = trades[trades["traded"] & (trades["status"] == "ok")].copy()
    T["signal_day"] = pd.to_datetime(T["signal_day"])
    T["outcome"] = outcome_of(T["net_bp"].to_numpy(float))
    Dd = days[days["traded"] & (days["session"] >= 1) & (days["after_exit"] == False)]  # noqa: E712
    Dd = Dd[Dd["trade_id"].isin(set(T["trade_id"]))].copy()
    Dd["date"] = pd.to_datetime(Dd["date"])
    rdir = ex_dir / "research"
    rdir.mkdir(exist_ok=True)
    dh = declaration_hash()
    if base is not None:
        ledger_append(base, {"tool": TOOL, "event": "research_declared", "export": ex_dir.name, "declaration": dh,
                             "declaration_text": DECLARATION})
    log("research: outcome groups, profiles, warning signs ...")
    OG = outcome_groups(T)
    PR = outcome_profiles(T)
    WT = warning_table(T, money)
    log("research: walk-forward (purged, known inputs, Bonferroni, money view) ...")
    WF = walk_forward(T, money)
    WV = walk_verdicts(WF)
    envp = env_prev_map(mk)
    worst = {}
    parts = []
    for e, G in (T.groupby("engine") if money is not None else []):
        mv = money_view(money, list(G["trade_id"]))
        Dm = mv["daily"]
        if Dm is None or len(Dm) == 0:
            continue
        Dm = Dm.assign(engine=e, date=pd.to_datetime(Dm["date"]))
        parts.append(by_environment(Dm, envp, "day_ret", "n_open", "engine", "exposure", additive=False))
        lo_d = Dm["date"].iloc[0] if mv["peak"] in (None, "start") else pd.Timestamp(mv["peak"])
        span = Dm.loc[(Dm["date"] >= lo_d) & (Dm["date"] <= pd.Timestamp(mv["trough"] or Dm["date"].iloc[-1])), "date"]
        mix = pd.Series(span.map(envp)).fillna("(unknown)").value_counts(normalize=True).to_dict()
        worst[e] = {"dd": mv["dd"], "peak": str(mv["peak"])[:10] if mv["peak"] else None,
                    "trough": str(mv["trough"])[:10] if mv["trough"] else None, "mix": mix}
    BE = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    B = book.copy()
    B["date"] = pd.to_datetime(B["date"])
    if BE.empty:                                           # no money view: the export's additive book, labelled so
        BE = by_environment(B, envp, "book_day_ret_slot", "positions_at_close", "engine", additive=True)
    for e, G in (B.groupby("engine") if not worst else []):
        r = G.set_index("date")["book_day_ret_slot"].astype(float).sort_index()
        dd, pk, tr = max_dd(r)
        if pk is None:
            worst[e] = {"dd": dd, "peak": None, "trough": None, "mix": {}}
            continue
        span = r.loc[pk:tr].index
        mix = pd.Series(span.map(envp)).fillna("(unknown)").value_counts(normalize=True).to_dict()
        worst[e] = {"dd": dd, "peak": str(pd.Timestamp(pk).date()), "trough": str(pd.Timestamp(tr).date()), "mix": mix}
    files = []
    for nm, X in (("outcome_groups", OG), ("outcome_profiles", PR), ("warning_signs", WT), ("walk_forward", WF),
                  ("walk_forward_verdicts", WV), ("book_by_environment", BE)):
        X.to_csv(rdir / f"{nm}.csv", index=False, float_format="%.10g")
        files.append(f"research/{nm}.csv")
    meta = {"created": pd.Timestamp.now().isoformat(timespec="seconds"), "export": ex_dir.name,
            "declaration_hash": dh, "trades": {e: int((T["engine"] == e).sum()) for e in sorted(T["engine"].unique())}}
    (rdir / "research_report.md").write_text(report_md(meta, OG, PR, WT, WF, WV, BE, worst), encoding="utf-8")
    files.append("research/research_report.md")
    if cards > 0 and mk is not None and len(T):
        import tl_cards
        fired = {}
        for w in DECLARATION["warnings"]:
            f = flag_of(T, w)
            for tid in T.loc[f, "trade_id"]:
                fired.setdefault(tid, []).append(f"{w[0]} {w[1]}")
        S = pd.concat([G.nsmallest(cards, "net_bp") for _, G in T.groupby("engine")])
        S = S.assign(warnings_fired=[("; ".join(fired.get(t, [])) or "none") for t in S["trade_id"]])
        files += [f"research/{f}" for f in tl_cards.write_cards(
            rdir, "severe_losers", S, days[days["trade_id"].isin(S["trade_id"])], mk,
            f"The {cards} worst trades per engine - with the warning signs that fired before entry")]
    summ = {"tool": TOOL, "declaration": dh, "files": files, "seconds": round(time.time() - t0, 1),
            "verdicts": WV.to_dict("records") if WV is not None else [], "worst_drawdown": worst,
            "tables": {nm: list(X.columns) for nm, X in (("outcome_groups", OG), ("outcome_profiles", PR),
                                                         ("warning_signs", WT), ("walk_forward", WF),
                                                         ("walk_forward_verdicts", WV), ("book_by_environment", BE))}}
    (rdir / "research_summary.json").write_text(json.dumps({k: v for k, v in summ.items() if k != "tables"}, indent=2,
                                                           default=str), encoding="utf-8")
    files.append("research/research_summary.json")
    if base is not None:
        ledger_append(base, {"tool": TOOL, "event": "research_run", "export": ex_dir.name, "declaration": dh,
                             "verdicts": [(r["engine"], r["warning"], r["verdict"]) for r in summ["verdicts"]]})
    return summ


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="tradelab research: winners, losers, warning signs, walk-forward")
    ap.add_argument("--export", required=False)
    ap.add_argument("--out", default=None, help="tradelab's output folder (for the ledger); default TRADELAB_OUT")
    ap.add_argument("--cards", type=int, default=20)
    ap.add_argument("--root", help="the cache root (rebuilds the plan's money view)")
    ap.add_argument("--pm-run", help="the export's pick_meta run")
    ap.add_argument("--panel", default="panel_oc")
    ap.add_argument("--stage-e-any", action="store_true")
    a = ap.parse_args(sys.argv[1:] if argv is None else argv)
    try:
        if not a.export:
            raise TLError("--export is required (an export folder, e.g. C:\\QuantData\\tradelab\\export\\TLX_20261024_001)")
        ex = Path(a.export)
        if not (ex / "trades.parquet").exists():
            raise TLError(f"{ex} is not an export folder (no trades.parquet)")
        import os
        base = Path(a.out or os.environ.get("TRADELAB_OUT", "")) if (a.out or os.environ.get("TRADELAB_OUT")) else None
        if not (a.root and a.pm_run):
            raise TLError("--root and --pm-run are required: the verdicts use the plan's money view, rebuilt from the "
                          "cache (same values as the export)")
        import tl_export as X
        money = X.money_from_root(a.root, a.pm_run, ex, stage_e_any=a.stage_e_any, panel=a.panel)
        s = run(ex, base=base, cards=a.cards, money=money)
        from tl_common import write_outputs_sha
        write_outputs_sha(ex)                      # the export's fingerprints match the rewritten research files
        for r in s["verdicts"]:
            say(f"  {r['engine']} {r['warning']}: {r['verdict']} (qualified {r['qualified_years']}/{r['test_years']} "
                f"years, P&L change {r['pnl_change_bp']:+,.0f} bp)")
        say(f"DONE {ex / 'research'} ({s['seconds']:.0f} s)")
        return 0
    except TLError as e:
        say(f"ERROR: {e}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
