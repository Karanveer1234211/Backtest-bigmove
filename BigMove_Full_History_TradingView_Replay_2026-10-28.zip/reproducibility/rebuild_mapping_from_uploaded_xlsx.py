#!/usr/bin/env python3
"""Read-only deterministic full journal -> seven setup-family memberships.
CSV-only output; no production artifacts or original xlsx changed.
Reads worksheet XML directly to avoid unnecessary xlsx memory and value inference.
"""
import csv, datetime as dt, hashlib, json, os, re, collections, zipfile, xml.etree.ElementTree as ET
from pathlib import Path

SOURCE = Path('/mnt/data/TRADE_JOURNAL 2.xlsx')
OUT=Path('/mnt/data/BigMove_Full_History_Setup_Map_2026-10-28')
DATA=OUT/'data'; BY_SETUP=DATA/'by_setup'; SCRIPTS=OUT/'scripts'
for p in [DATA, BY_SETUP, SCRIPTS]:p.mkdir(parents=True,exist_ok=True)
NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
BASE=dt.datetime(1899,12,30)
NAMES={
  'P0':'VIX 5-day spike >= +25% — failed breakdown reclaim',
  'P1':'S08 bear continuation + VIX 5-day change < -10% — capitulation reversal',
  'P2':'S10 new breakdown + 10-day breadth >=50% and <60% — reclaim',
  'P3':'S04 confirmed breakout + VIX 5-day change < -10% — retest hold',
  'P4':'S01 strong bull + Compressed stock volatility — base breakout',
  'P5':'S03 bull consolidation + VIX change >=10% and <25% — tight base',
  'P6':'S08 bear continuation + HIGH STRESS market — shock reversal',
}

def worksheet_rows(z,number):
  with z.open(f'xl/worksheets/sheet{number}.xml') as fp:
    for _,elem in ET.iterparse(fp,events=('end',)):
      if elem.tag != NS+'row':continue
      row_no=int(elem.attrib['r']); fields={}
      for cell in elem.findall(NS+'c'):
        m=re.match(r'[A-Z]+',cell.attrib['r'])
        if not m:continue
        v=cell.find(NS+'v'); inline=cell.find(NS+'is')
        if inline is not None: value=''.join(t.text or '' for t in inline.iter(NS+'t'))
        elif v is not None: value=v.text or ''
        else: value=''
        fields[m.group(0)]=value
      yield row_no,fields
      elem.clear()

def excel_date(s):
    try:return (BASE+dt.timedelta(days=float(s))).date().isoformat() if s else ''
    except: return ''
def fnum(s):
    try: return float(s)
    except (TypeError,ValueError):return None

def rname(s):return str(s).strip()
def ev_age(event):
    if not event:return ''
    m=re.search(r'\((\d+)d\)',event)
    if m:return int(m.group(1))
    if 'today' in event.lower():return 0
    return ''

def flags(x):
    vix=fnum(x.get('AW')); breadth=fnum(x.get('AU'))
    return {
      'P0':vix is not None and vix>=0.25,
      'P1':x.get('AA')=='S08 Bear continuation' and vix is not None and vix<-0.10,
      'P2':x.get('AG','').startswith('S10 breakdown new') and breadth is not None and .50<=breadth<.60,
      'P3':x.get('AG','').startswith('S04 breakout confirmed') and vix is not None and vix<-0.10,
      'P4':x.get('AA')=='S01 Strong bull' and x.get('AI')=='Compressed',
      'P5':x.get('AA')=='S03 Bull consolidation' and vix is not None and .10<=vix<.25,
      'P6':x.get('AA')=='S08 Bear continuation' and x.get('AO')=='HIGH STRESS',
    }

with zipfile.ZipFile(SOURCE) as z:
    market={excel_date(x.get('A')):x for row_no,x in worksheet_rows(z,2) if row_no>=4 and excel_date(x.get('A'))}
    source_count=0; records=[]; missing_cal=[]; market_mismatches=[]
    for rowno,x in worksheet_rows(z,1):
        if rowno<4: continue
        source_count+=1
        if x.get('B') not in ('D','ENS') or x.get('C') not in list('123456789')+['10'] or not x.get('D'):
            raise RuntimeError('Unexpected trade row structure '+str((rowno,x)))
        selection=excel_date(x.get('A')); buy=excel_date(x.get('U')); sell=excel_date(x.get('W'))
        mc=market.get(selection)
        if mc is None: missing_cal.append((rowno,selection))
        elif not (x.get('AO')==mc.get('B') and abs(fnum(x.get('AU'))-fnum(mc.get('K')))<1e-8 and abs(fnum(x.get('AW'))-fnum(mc.get('P')))<1e-8):
            market_mismatches.append((rowno,selection,x.get('AO'),mc.get('B')))
        rank=int(x['C']); traded=(x.get('E')=='yes'); assert traded==(rank<=3),('Traded flag mismatch',rowno)
        conditions=flags(x); match=[k for k in NAMES if conditions[k]]
        orig_symbol=x['D']; tv_symbol='NSE:HEGAM' if orig_symbol=='HEG' else f'NSE:{orig_symbol}'
        a=ev_age(x.get('AG',''))
        key=f'{selection}|{x["B"]}|{rank}|{orig_symbol}'
        record={
          'trade_id':key,'selection_date':selection,'selection_year':selection[:4],
          'engine':x['B'],'rank':rank,'traded_top3':'YES' if traded else 'NO',
          'journal_symbol':orig_symbol,'tradingview_symbol_suggestion':tv_symbol,
          'ticker_status':'CURRENT_ALIAS_CHECKED' if orig_symbol=='HEG' else 'NOT_VERIFIED_FOR_THIS_DATE',
          'journal_buy_date':buy,'journal_exit_date':sell,
          'journal_buy_price':x.get('V',''),'journal_exit_price':x.get('X',''),
          'journal_result':x.get('F',''),
          'journal_net_return_pct':(fnum(x.get('G'))*100 if fnum(x.get('G')) is not None else ''),
          'journal_excess_return_pct':(fnum(x.get('H'))*100 if fnum(x.get('H')) is not None else ''),
          'journal_best_daily_close_vs_buy_pct':(fnum(x.get('I'))*100 if fnum(x.get('I')) is not None else ''),
          'journal_worst_daily_close_vs_buy_pct':(fnum(x.get('K'))*100 if fnum(x.get('K')) is not None else ''),
          'journal_exit_type':x.get('Y',''),
          'journal_exit_execution_status':'STUCK_NOT_REALIZED' if x.get('F')=='Stuck' else 'REALIZED',
          'primary_stock_state_at_pick':x.get('AA',''),
          'stock_state_strength_at_pick':x.get('AB',''),
          'stock_state_direction_at_pick':x.get('AC',''),
          'previous_stock_state_at_pick':x.get('AE',''),
          'stock_event_at_pick':x.get('AG',''),
          'stock_event_age_at_pick_sessions':a,
          'stock_risk_flags_at_pick':x.get('AH',''),
          'stock_volatility_at_pick':x.get('AI',''),
          'stock_pickday_return_pct':(fnum(x.get('AJ'))*100 if fnum(x.get('AJ')) is not None else ''),
          'stock_20day_return_pct':(fnum(x.get('AK'))*100 if fnum(x.get('AK')) is not None else ''),
          'market_environment_at_pick':x.get('AO',''),
          'market_shock_at_pick':x.get('AP',''),
          'nifty_day_return_pct':(fnum(x.get('AQ'))*100 if fnum(x.get('AQ')) is not None else ''),
          'smallcap_day_return_pct':(fnum(x.get('AR'))*100 if fnum(x.get('AR')) is not None else ''),
          'nifty_20day_return_pct':(fnum(x.get('AS'))*100 if fnum(x.get('AS')) is not None else ''),
          'smallcap_20day_return_pct':(fnum(mc.get('H'))*100 if mc and fnum(mc.get('H')) is not None else ''),
          'market_breadth_1day_at_pick':x.get('AT',''),
          'market_breadth_10day_at_pick':x.get('AU',''),
          'india_vix_at_pick':x.get('AV',''),
          'vix_5day_change_at_pick_pct':(fnum(x.get('AW'))*100 if fnum(x.get('AW')) is not None else ''),
          'nifty_minus_smallcap_20day_pct_points':((fnum(mc.get('G'))-fnum(mc.get('H')))*100 if mc and fnum(mc.get('G')) is not None and fnum(mc.get('H')) is not None else ''),
          'setup_ids':'/'.join(match) if match else 'UNMATCHED',
          'setup_match_count':len(match),
          **{k+'_eligible':'YES' if conditions[k] else 'NO' for k in NAMES},
          'journal_picks_excel_row':rowno,
          'mapping_source':'TRADE_JOURNAL 2.xlsx / Picks: ' + str(rowno),
        }
        records.append(record)
if source_count!=33100:raise RuntimeError(f'Source count changed: {source_count}')
if missing_cal or market_mismatches:raise RuntimeError(f'Market cross-check failed: {missing_cal[:3]} {market_mismatches[:3]}')
# Original 5th close, independent of recorded exit (locked circuits may delay W).
calendar=sorted(market); pos={d:i for i,d in enumerate(calendar)}
for r in records:
    idx=pos[r['selection_date']]
    expected=calendar[idx+5] if idx+5<len(calendar) else ''
    r['scheduled_5th_close_date']=expected
    r['exit_delayed_vs_scheduled']='STUCK_UNREALIZED' if r['journal_exit_execution_status']=='STUCK_NOT_REALIZED' else 'YES' if (r['journal_exit_date'] and expected and r['journal_exit_date']>expected) else 'NO' if r['journal_exit_date'] else 'UNSETTLED'
    # Trade identity + date contract. Correct case key pasteable into v2 Pine strategy input.
    r['case_key_hint']='|' .join([r['setup_ids'],r['selection_date'],r['engine']+str(r['rank']),r['journal_symbol'],r['tradingview_symbol_suggestion'],str(r['stock_event_age_at_pick_sessions'] if r['stock_event_age_at_pick_sessions']!='' else 0),r['journal_buy_date'],r['journal_exit_date']])
# Remove intentionally placeholder hint from full mapping? case_key_hint includes multiple setups not a valid setup id: put blank when >1.
for r in records:
    if r['setup_match_count']!=1:r['case_key_hint']='USE_CATEGORY_MEMBERSHIPS_FILE' if r['setup_match_count']>1 else ''
records.sort(key=lambda r:(r['selection_date'],r['engine'],r['rank'],r['journal_symbol']))
columns=list(records[0])

def write_csv(path, rows, fieldnames=None):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fieldnames or columns,extrasaction='ignore');w.writeheader();w.writerows(rows)

write_csv(DATA/'ALL_33100_raw_selection_mapped.csv',records)
traded=[r for r in records if r['traded_top3']=='YES']; shadow=[r for r in records if r['traded_top3']=='NO']
assert len(traded)==9930 and len(shadow)==23170
write_csv(DATA/'TOP3_all_9930_mapped.csv',traded)
write_csv(DATA/'SHADOW_ranks4to10_all_23170_mapped.csv',shadow)
write_csv(DATA/'TOP3_unmatched_8482.csv',[r for r in traded if r['setup_match_count']==0])

def memberships(rows):
    out=[]
    for r in rows:
        for k in NAMES:
            if r[k+'_eligible']!='YES':continue
            x=dict(r)
            x['setup_id']=k;x['setup_name']=NAMES[k]
            x['pine_case_key']='|'.join([k,r['selection_date'],r['engine']+str(r['rank']),r['journal_symbol'],r['tradingview_symbol_suggestion'],str(r['stock_event_age_at_pick_sessions'] if r['stock_event_age_at_pick_sessions']!='' else 0),r['journal_buy_date'],r['journal_exit_date']])
            out.append(x)
    return sorted(out,key=lambda r:(r['setup_id'],r['selection_date'],r['engine'],r['rank'],r['journal_symbol']))
member=memberships(traded);shadow_member=memberships(shadow)
mem_cols=['setup_id','setup_name','pine_case_key']+columns
write_csv(DATA/'TOP3_ALL_category_memberships.csv',member,mem_cols)
write_csv(DATA/'SHADOW_ALL_category_memberships.csv',shadow_member,mem_cols)
blind_cols=[k for k in mem_cols if k not in {'journal_buy_price','journal_exit_price','journal_net_return_pct','journal_excess_return_pct','journal_best_daily_close_vs_buy_pct','journal_worst_daily_close_vs_buy_pct','journal_result'}]
write_csv(DATA/'TOP3_BLIND_replay_no_outcomes.csv',member,blind_cols)
# Per-category complete list and shadow inventory
for k in NAMES:
    write_csv(BY_SETUP/f'{k}_ALL_top3_cases.csv',[r for r in member if r['setup_id']==k],mem_cols)
    write_csv(BY_SETUP/f'{k}_ALL_shadow_cases.csv',[r for r in shadow_member if r['setup_id']==k],mem_cols)
# Group chronologically by ticker to reduce repeated Pine chart switch
write_csv(DATA/'TOP3_replay_order_by_ticker.csv',sorted(member,key=lambda r:(r['tradingview_symbol_suggestion'],r['selection_date'],r['setup_id'],r['engine'],r['rank'])),mem_cols)

tracker_cols=['test_id','setup_id','pine_case_key','selection_date','engine','rank','tradingview_symbol_suggestion','stock_event_at_pick','market_environment_at_pick','journal_buy_date','journal_exit_date','setup_triggered_yes_no','trigger_date','actual_setup_entry_date','actual_setup_entry_price','initial_stop','target_price','setup_exit_date','setup_exit_price','setup_net_return_pct','setup_mfe_pct','setup_mae_pct','reason_no_trigger_or_no_fill','chart_data_issue','notes']
track=[]
for i,r in enumerate(member,1):
    x={k:r.get(k,'') for k in tracker_cols}
    x['test_id']=f'BM-{i:05d}'
    track.append(x)
write_csv(DATA/'TOP3_REPLAY_RESULTS_TO_FILL.csv',track,tracker_cols)

cyr=[]
for k in NAMES:
    for engine in ('D','ENS'):
      for year in range(2020,2027):
        rr=[r for r in member if r['setup_id']==k and r['engine']==engine and r['selection_year']==str(year)]
        cyr.append({'setup_id':k,'setup_name':NAMES[k],'engine':engine,'year':year,'top3_cases':len(rr),'unique_selection_days':len(set(x['selection_date'] for x in rr)),'journal_winners':sum(x['journal_net_return_pct']!='' and float(x['journal_net_return_pct'])>0 for x in rr),'journal_net_mean_pct_DESCRIPTIVE':sum(float(x['journal_net_return_pct']) for x in rr if x['journal_net_return_pct']!='')/sum(x['journal_net_return_pct']!='' for x in rr) if any(x['journal_net_return_pct']!='' for x in rr) else ''})
cy_cols=list(cyr[0]);write_csv(DATA/'COUNTS_by_category_engine_year.csv',cyr,cy_cols)

overlap=collections.Counter(tuple(r['setup_ids'].split('/')) for r in traded if r['setup_match_count']>1)
write_csv(DATA/'TOP3_OVERLAP_groups.csv',[{'simultaneous_categories':' + '.join(k),'top3_trades':v} for k,v in sorted(overlap.items(),key=lambda x:(-x[1],x[0]))],['simultaneous_categories','top3_trades'])

# Independent source checks and assertions
assert len({r['trade_id'] for r in records})==len(records), 'Duplicate raw source records'
assert len(member)==sum(int(r['setup_match_count']) for r in traded)
assert len({r['trade_id'] for r in member})==sum(r['setup_match_count']>0 for r in traded)
assert sum(r['setup_match_count']==0 for r in traded)==8482
nulls=[r for r in traded if r['journal_net_return_pct']=='']
summary={
 'source_file':SOURCE.name,'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
 'history_first_selection_date':traded[0]['selection_date'],'history_last_selection_date':traded[-1]['selection_date'],
 'total_source_picks':len(records),'unique_pick_dates':len(set(r['selection_date'] for r in records)),
 'engines':dict(collections.Counter(r['engine'] for r in records)),
 'top3_total':len(traded),'shadows_rank4to10_total':len(shadow),
 'journal_top3_null_exit_return':len(nulls),'journal_top3_null_exit_return_trade_ids':[r['trade_id'] for r in nulls],
 'unique_top3_matching_at_least_one_family':len({r['trade_id'] for r in member}),
 'unique_top3_matching_no_family':sum(r['setup_match_count']==0 for r in traded),
 'total_top3_category_memberships':len(member),'total_shadow_category_memberships':len(shadow_member),
 'top3_overlap_distribution':dict(sorted(collections.Counter(r['setup_match_count'] for r in traded).items())),
 'top3_category_counts':{k:{'D':sum(r['setup_id']==k and r['engine']=='D' for r in member),'ENS':sum(r['setup_id']==k and r['engine']=='ENS' for r in member)} for k in NAMES},
 'shadow_category_counts':{k:{'D':sum(r['setup_id']==k and r['engine']=='D' for r in shadow_member),'ENS':sum(r['setup_id']==k and r['engine']=='ENS' for r in shadow_member)} for k in NAMES},
 'market_day_worksheet_rows':len(market), 'market_selection_day_mismatches':len(market_mismatches),'missing_selection_dates_in_market_days':len(missing_cal),
 'date_contract_mismatches_for_top3':sum(1 for r in traded if r['journal_buy_date'] and calendar[pos[r['selection_date']]+1] != r['journal_buy_date']),
 'realized_delayed_exits_top3':sum(r['exit_delayed_vs_scheduled']=='YES' for r in traded),
 'unrealized_stuck_top3':sum(r['exit_delayed_vs_scheduled']=='STUCK_UNREALIZED' for r in traded),
 'top3_3d_breakdown_new_cases':sum(r['setup_id']=='P2' and r['stock_event_at_pick'].startswith('S10 breakdown new') for r in member),
 'notes':['All matches use columns AA,AG,AI,AO,AU,AW on evening selection day; no outcome fields are used to select cases.','Memberships overlap; sum across families is not a count of unique trades.','Original top-3 data are not setup backtest outcomes.','Dates are source journal dates; a proposed entry after confirmation can differ.','The full universe of rank4-10 is preserved separately and must not be pooled with top-3 baseline.']
}
with (DATA/'SOURCE_VALIDATION.json').open('w',encoding='utf-8') as f:json.dump(summary,f,ensure_ascii=False,indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ['source_sha256','notes']},ensure_ascii=False,indent=2))
