from pathlib import Path
import csv,re,zipfile,hashlib,json,collections
ROOT=Path('/mnt/data/BigMove_Full_History_Setup_Map_2026-10-28')
SCRIPTS=ROOT/'scripts'
EXIST=Path('/mnt/data/BigMove_Replay_2026-10-28/scripts/BigMove_ALL_7_Setups_v6.pine').read_text(encoding='utf-8')
with (ROOT/'data/TOP3_ALL_category_memberships.csv').open(encoding='utf-8') as ff:
 members=list(csv.DictReader(ff))
def create(family):
    rows=[r for r in members if family=='ALL' or r['setup_id']==family]
    prefer={'P0':('2020-03-24','D','HEG'),'P1':('2020-04-01','ENS','JINDALSTEL'),'P2':('2026-02-13','ENS','INTELLECT'),'P3':('2024-10-01','ENS','MARKSANS'),'P4':('2023-11-09','D','PERSISTENT'),'P5':('2020-11-25','D','APLAPOLLO'),'P6':('2020-03-25','D','HCC')}
    actual=prefer['P0' if family=='ALL' else family]
    defaults=[r for r in rows if (r['selection_date'],r['engine'],r['journal_symbol'])==actual]
    default=(defaults[0] if defaults else rows[0])['pine_case_key']
    s=EXIST
    start=s.index('string selected = input.string(')
    end=s.index('int watchDays = input.int(', start)
    inp='''// Paste the complete pine_case_key from TOP3_ALL_category_memberships.csv.
// This free-text input replaces the former 42-item dropdown and supports the ENTIRE history.
// Example key format: P2|2026-02-13|ENS3|INTELLECT|NSE:INTELLECT|2|2026-02-16|2026-02-20
string selected = input.string("'''+default+'''", "CSV pine_case_key (8 fields)", group = "1. Select journal trade")
'''
    s=s[:start]+inp+s[end:]
    name='All 7 Families | Full History v2' if family=='ALL' else family+' | Full History v2'
    s=re.sub(r'^strategy\("BigMove \|[^\n]*',f'strategy("BigMove | {name}", overlay = true,',s,count=1,flags=re.M)
    # Input is a plain string for every case. Add a guard against pasting the wrong category into a family-specific script.
    s=s.replace('array<string> p = str.split(selected, "|")','''// A row can qualify for multiple families; use its individual membership row
// so the setup ID is unambiguous and the original trade remains unchanged.
array<string> p = str.split(selected, "|")''')
    s=s.replace('bool tickerMatches = syminfo.prefix',f'''bool familyMatches = "{family}" == "ALL" or setup == "{family}"
bool tickerMatches = familyMatches and syminfo.prefix''')
    s=s.replace('bool isPick = timeframe.isdaily and tickerMatches and year == yy', 'bool isPick = timeframe.isdaily and tickerMatches and year == yy')
    s=s.replace('not tickerMatches ? "WRONG SYMBOL" : na(pickIndex)', 'not familyMatches ? "WRONG SETUP" : not tickerMatches ? "WRONG SYMBOL" : na(pickIndex)')
    s=s.replace('Original model pick / study case', 'Case from full-history CSV')
    s=s.replace('bool overrideSetupTTL = input.bool(false, "Override shorter setup TTL; use whole watch window"', 'bool overrideSetupTTL = input.bool(true, "Use complete 10-session watchlist (off = shorter setup TTL)"')
    s=s.replace('BigMove RESEARCH ONLY. Journal states/market conditions are frozen at the pick close.', 'BigMove RESEARCH ONLY. ALL 2020-2026 journal selections, no 42-case limit.')
    s=s.replace('// Run on an NSE stock DAILY chart. The exact D/ENS model and proprietary states', '// Copy pine_case_key for THIS SETUP family. Use NSE stock DAILY chart.\n// The exact D/ENS model and proprietary states')
    s=s.replace('This setup entry is NOT the journal\'s historical open-entry trade.', 'This setup entry is NOT the journal\'s historical open-entry trade.\n// Pine cannot import CSV. One copy-paste case at a time; all cases are in the CSV.')
    s=s.replace('// Use TradingView Create Alert > Any alert() function call (no alert is auto-created).', '// Use TradingView Create Alert > Any alert() function call (no alert is auto-created).\n// IMPORTANT: Tested by deterministic static checks, not compiled in TradingView.')
    outfile=SCRIPTS/('BigMove_ALL_7_Setups_v2_full_history.pine' if family=='ALL' else f'BigMove_{family}_v2_full_history.pine')
    outfile.write_text(s,encoding='utf-8')
    assert len(re.findall(r'input.string\(',s))>0
    assert 'Original model pick / study case' not in s
    assert s.startswith('//@version=6')
    assert default in s
    assert f'"{family}" == "ALL"' in s
    assert s.count('strategy(')==1
    return outfile,default
files=[create(fam) for fam in ('ALL','P0','P1','P2','P3','P4','P5','P6')]
print('Pine scripts:',[(p.name,len(p.read_bytes()),key[:62]) for p,key in files])
