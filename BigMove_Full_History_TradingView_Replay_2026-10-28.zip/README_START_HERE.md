# BigMove Full-History TradingView Replay — v2

Generated: 2026-10-28. **Read-only analysis** of original `TRADE_JOURNAL 2.xlsx`.

## Provenance and coverage

- Source: `Picks` worksheet (rows 4–33103), with independently joined `Market days` worksheet on original **selection day T**. `What worked` is context for the seven earlier research hypotheses; the membership computation reads the raw per-pick labels directly and does *not* use later trade outcomes.
- History: **2020-01-16 to 2026-09-15**; **1,655** selection days; **33,100** raw selections = D 16,550 + ENS 16,550.
- Traded ranks 1–3: **9,930** original selections, of which **9,928** have realized journal net returns and **2 TRU rows** are marked **Stuck** (no realized return). Shadow ranks 4–10: **23,170**; kept separate.
- **1,448 unique top-3 trades** match one or more of P0–P6; **8,482** are `UNMATCHED`; **1,583 category memberships** (overlaps intentional); **3,183 shadow memberships**.
- `Market days` selection-day checks: market environment, 10-day breadth, VIX 5-day percent change all match (zero discrepancies). Original top-3 buy dates match the next market session in all 9,930 rows.
- 330 **realized delayed exits** beyond the scheduled fifth close, plus 2 *stuck, not realized* TRU entries. Exit types preserved, not replaced with theoretical outcomes.

## EXACT setup membership logic (evaluated at evening T)

| Setup | Frozen pick-time condition | Top-3 total (D / ENS) | Hypothesized Pine trigger |
|---|---|---:|---|
| P0 | VIX five-session change >=25% | 288 (144 / 144) | Failed 20-day breakdown + strong reclaim |
| P1 | Primary `S08 Bear continuation` and VIX five-session change <-10% | 210 (98 / 112) | Rejection from 20-day low, high volume |
| P2 | Event text starts `S10 breakdown new`; 10-day breadth >=0.50 and <0.60 | 337 (157 / 180) | Close back above **pre-event** support |
| P3 | Event text starts `S04 breakout confirmed`; VIX five-session change <-10% | 151 (86 / 65) | Retest and hold of **pre-event** resistance |
| P4 | Primary `S01 Strong bull` and stock volatility is `Compressed` | 296 (144 / 152) | Frozen 10-bar high break after price compression |
| P5 | Primary `S03 Bull consolidation` and VIX five-session change >=10% and <25% | 85 (35 / 50) | Frozen 7-bar tight base break |
| P6 | Primary `S08 Bear continuation` and market environment `HIGH STRESS` | 216 (108 / 108) | Sharp selloff + capitulation/recoil |

**P2 and P3 refer to *event overlays*, not necessarily the primary stock state.** P0 is a market condition without any primary stock-state requirement. A trade qualifying for two setups appears twice in the *membership* files but once in the raw top-3 master. Never pool category totals as unique trades.

## Which file to use

- `data/TOP3_ALL_category_memberships.csv`: **All 1,583 top-3 category cases**, each with date/engine/rank/state/market and a **`pine_case_key`** for copy-paste into TradingView.
- `data/by_setup/P0_ALL_top3_cases.csv` through `P6_ALL_top3_cases.csv`: **every qualifying historical top-3 case for that category**, chronological order; *no cherry-picked six examples*.
- `data/TOP3_BLIND_replay_no_outcomes.csv`: same eligible cases **with journal outcome columns hidden**. Preferred for unbiased manual replay.
- `data/TOP3_replay_order_by_ticker.csv`: all memberships sorted ticker→date to reduce switching TradingView charts.
- `data/TOP3_REPLAY_RESULTS_TO_FILL.csv`: **1,583 blank result rows** for triggered/no-triggered outcomes; do not delete no-triggers or setup/stock duplicates.
- `data/COUNTS_by_category_engine_year.csv`: 7 × 2 × 7 annual breakdown. The historical average of the *original model trade* is descriptive, not a setup result.
- `data/CATEGORY_market_x_stock_state.csv`, `CATEGORY_market_x_event.csv`, `CATEGORY_volatility_x_stock_state.csv` and `CATEGORY_state_phase_x_market.csv`: contextual subgroups and their sizes. These are not out-of-sample findings.
- `data/TOP3_OVERLAP_groups.csv`: multi-category overlaps.
- `data/TOP3_all_9930_mapped.csv`: all original traded top-3 records, **including 8,482 unmatched** and two stuck TRU cases.
- `data/ALL_33100_raw_selection_mapped.csv`: ALL raw ranks 1–10, showing which match P0..P6.
- `data/SHADOW_ranks4to10_all_23170_mapped.csv` and `data/SHADOW_ALL_category_memberships.csv`: complete shadow data for separate research; do not treat shadow as traded baseline.
- `data/SOURCE_VALIDATION.json`: full input provenance and counts.

## Pine script — replay ANY case from the entire journal

1. In `data/by_setup`, choose a category. Sort/filter by **selection_date**, **engine**, **rank**, **market_environment_at_pick**, **primary_stock_state_at_pick**, **stock_event_at_pick** or **stock_volatility_at_pick**. There are no omitted matches in these files.
2. Open its `tradingview_symbol_suggestion` chart on the **TradingView NSE 1D timeframe**. Check the stock's **historical symbol** and valid data for the selection date. Some tickers changed, and some old/delisted stocks may have no accessible TradingView history. Mark unavailable cases; do not substitute another stock.
3. Paste `scripts/BigMove_ALL_7_Setups_v2_full_history.pine` into TradingView Pine Editor, or use the family-specific `scripts/BigMove_P*_v2_full_history.pine`.
4. In settings, paste that CSV row's entire **`pine_case_key`** into **CSV pine_case_key (8 fields)**. This replaces the previous 42-case dropdown and supports all cases; Pine cannot directly read CSV files. Correct key example:

   `P2|2026-02-13|ENS3|INTELLECT|NSE:INTELLECT|2|2026-02-16|2026-02-20`

5. Start replay at least 50–100 daily bars **before** T (for EMA, ATR, 20-day levels). The orange `PICK`, `BASE IN`, `BASE OUT` belong to the historical journal; aqua `TRIGGER` belongs to the **NEW hypothesis**. `BASE OUT` is a recorded exit marker, not evidence of the new setup exiting.
6. Default watchlist is **10 trading sessions after T**. Close-confirmed triggers enter the *next session open*; a signal at T+10 would fill T+11 and is deliberately excluded. Toggle shorter family-specific TTL to study that separately. The default stop/target/position risk are **research assumptions**, not historically validated improvements.
7. Use **one selection at a time**, enter its observed result into `TOP3_REPLAY_RESULTS_TO_FILL.csv`, including `NO TRIGGER`, bad gaps, circuit constraints, missing chart data and rejected fills. Once complete, compare **all eligible selection opportunities**, not just filled profitable setups, against the unchanged top-3 baseline.

## Selection-time versus future data: critical

- Selection evening T: raw columns A (pick date), B (engine), C (rank), D (stock), AA (stock state), AC (phase), AG (event), AI (stock volatility), AO (market environment), AU (10-day breadth), AW (VIX 5-day change); these determine P0–P6 membership.
- Baseline buy and recorded sell/last mark: raw U (next-session buy date), V (buy price), W (recorded exit date or last mark when stuck), X (sale/mark price), Y (exit type), G (original net), I/K (best/worst **daily CLOSE vs buy**, **NOT intraday high/low MFE/MAE**).
- Raw `Picks!AQ`=NIFTY day return, `AR`=Smallcap day return, `AS`=NIFTY 20-day return, `AT`=1-day breadth, `AU`=10-day breadth, `AV`=VIX, `AW`=VIX 5-day return. NIFTY–Smallcap 20-day relative performance in our mapping is computed using `Market days!G-H`, not inferred from `Picks!AR`.
- `TRU` stuck examples: `Picks!W` records a date of observation/mark, NOT a successful sale. Two rows have no realized net return; they are excluded from realized averages, not silently assigned a loss.
- All setup entry/stop/target results must be newly measured in replay. We do **not** claim the proposed price triggers occurred for all 1,583 category cases.

## Testing caveats

- The source journal is historical/researched data; even a strong result here is **not** new external out-of-sample evidence. Do not tune rule parameters while testing one category without separately documenting a holdout/future paper cohort.
- Identical selection days and repeated engine picks produce correlated observations; use date-clustered / moving-block uncertainty, not independent-trade intervals.
- The proposed strategies rely on **daily** OHLCV; intraday path order for SL vs TP is not trustworthy without lower-timeframe confirmation. Stops may be impossible to fill at lower circuits; TradingView backtests cannot replicate the journal's honest exit mechanics exactly. Prices may be split-adjusted differently.
- Pine works on *one chart at a time*. It does not regenerate or verify the model's selection/ranking, historical market breadth, state classifications or symbol changes. Rows marked `NOT_VERIFIED_FOR_THIS_DATE` still require ticker checks. The sole researched alias applied automatically is `HEG→HEGAM`.
- The scripts were constructed and statically audited; no connected TradingView **Pine compiler / install Pine study** action is available here. Compile status must be checked in TradingView; report errors verbatim before interpreting results.
- Never modify the original `.xlsx`, frozen D/ENS research artifacts or the ongoing forward paper test. All new work is in this isolated folder.

## Replay completeness acceptance

For each P0..P6 category, the sum of **TRIGGER**, **NO TRIGGER**, **UNTESTABLE DATA**, and **OTHER / INVALID** must equal its fixed full-history top-3 count. Every overlapping membership is a separate *setup candidate*, but daily baseline opportunity returns should not be double counted. Report both (1) conditional return on triggered entries and (2) all-opportunity return with skipped opportunities earning zero, plus opportunity participation and portfolio-level drawdown. Use the same dates and cost assumptions when comparing against the original model.
