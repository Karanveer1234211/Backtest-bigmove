# BigMove — One-file State × Event × Market × M × P Mapping
**30 October 2026 · read-only research artifacts · source: TRADE_JOURNAL 2.xlsx / `_journal_sheet1.csv`, STATE RULES.md, v4 source-aware mapping.**

## Exactly which file to open
1. **Open `BigMove_Pine_Replay_Navigator_20261030.xlsx`** for the manageable filtered list of all 1,583 P0–P6 eligibility cases, plus M/P crosswalk and definitions.
2. **Open `MASTER_TOP3_9930_BLIND.csv`** when you want to see **every original top-3 selection**, including ones where a mechanism applies but no Pine setup exists. Filter by selection_date, symbol, state_code, market_environment, mechanisms_all or eligible_pine_setups_all. It intentionally excludes the original realized return.
3. For any matched P case, **paste `BigMove_AUTO_P0_P6_SourceAware_v4.pine`** into TradingView (NSE symbol, 1D chart), choose the **exact P category, engine and rank** shown in the row. No case key is needed.
4. Record what actually happened in TradingView. **Only then** open `MASTER_TOP3_9930_ALL_STATES_M_P.csv` to see the original model's realized return and compare.
5. `RAW_ALL_RANKS_33100_WITH_M_P_RESEARCH_CLASSIFICATIONS.csv` is a separate optional full historical archive. **Ranks 4–10 are shadow selections, not top-3 trades.** They are not embedded in the Pine v4 trading registry.

## What each field really means
- **Selection date:** T evening (decision-time stock, event and market snapshot). Journal buy date normally T+1; original exit may be later than planned because of honest exit handling.
- **Primary stock state / event:** exactly preserved from source journal; they are **separate dimensions**. For example S01 + S04_CONFIRMED can coexist; neither is an entry trigger.
- **M1–M7:** hypotheses about possible movement **mechanisms**, screened from the source journal. They are **not** source-declared tl_state v1 states and **not** executable Pine trading rules. Multiple M's can apply to one trade.
- **P0–P6:** historical **selection-day eligibility** under the existing v4 research setup rules. One case can be eligible for multiple P's. Eligibility does **NOT** mean the price-action trigger occurred, an order filled, or the setup made money.
- **Pine category:** when P is assigned, its **exact P0–P6 tag** is the category to select in the one bundled v4 Pine strategy; when P=NONE, **no applicable P0–P6 executable script exists** for that case.
- **P2/P3:** the v4 Pine strategy separately checks the historical event-day level against available TradingView chart prices; `EVENT LEVEL UNVERIFIED` is possible. Adjusted TV prices and Kite journal can differ.
- **Source flags:** `EVENT_AGE_GT_10` means source event age is older than the declared 10-session display window; do not silently rewrite it. `TICKER_DATE_NOT_VERIFIED` means the proposed TradingView ticker was not checked for that historical date. `UNKNOWN_PRIMARY_STATE` is different from an S07 range.

## The exact M screens (for research population only)
- **M1:** S01 or S02 → possible trend continuation.
- **M2:** S03 or S07 → possible range/compression release.
- **M3:** event S10 NEW and primary state S06, S07, S08 or S09 → possible failed breakdown.
- **M4:** primary state S08/S09/S12 AND (market HIGH STRESS OR vol Extreme OR VIX 5D change >= +25%) → possible capitulation.
- **M5:** S02 or S06 → developing structural transition.
- **M6:** event S11 → failed-breakout **risk diagnostic**, not a buy signal.
- **M7:** market HIGH STRESS or Narrow bullish, AND state S06/S08/S09 → potential market-driven repricing.

## The exact P eligibility screens (only these have current Pine triggers)
- **P0:** VIX 5D change >= +25%, any state; look for failed 20D breakdown same-day reclaim.
- **P1:** S08 + VIX 5D change < -10%; investigate capitulation low rejection.
- **P2:** S10 NEW + 10D market breadth >=50% and <60%; reclaim original S10 event level.
- **P3:** S04 CONFIRMED + VIX 5D change < -10%; retest original S04 event level.
- **P4:** S01 + official COMPRESSED volatility; additional setup compression and base-break trigger.
- **P5:** S03 + VIX 5D change >= +10% and < +25%; additional 7-bar tight-base trigger.
- **P6:** S08 + market HIGH STRESS; shock-selling reversal trigger.

**Current Pine script covers P0–P6, not M1–M7 directly.** A conceptual relationship M1→P4 or M3→P2 is **not** eligibility unless the trade's exact P flag is YES.

## Reconciliation
- `TRADE_JOURNAL 2.xlsx` raw flattened sheet: **33,100** rank 1–10 model selections, dated **2020-01-16 through 2026-09-15**.
- **9,930** model top-3 picks; **23,170** rank4–10 shadows.
- 9,930 top-3 identities exactly match v4 source mapping. Full raw records were independently rescanned: **0 different P flags and 0 different M flags** across the 9,930 trade keys.
- **10,932** M memberships across **7,019** unique top-3 picks.
- **1,583** P memberships across **1,448** unique top-3 picks.
- **5,787** unique top-3 picks are **M-only** (no current Pine P strategy); **216** P-only; **1,232** both M+P; **2,695** neither.
- **614** original top-3 picks have journal event age >10; **2** lack realized exits.
- The 55-session event level is **NOT reconstructed in the CSV** (no original event-day OHLCV supplied). The Pine event-level checker is only a chart-data verification step. The classifications themselves come from the journal rather than being recalculated in TradingView.

## Testing discipline
1. Choose **every** case in a P queue, including when nothing triggers. No outcome-based cherry-picking.
2. Keep the P filters and proposed trigger thresholds unchanged during the initial test.
3. Log separate cases for the same NSE symbol/date under D and ENS, even if TradingView permits only one portfolio position at once.
4. Track `PICK -> ELIGIBLE -> TRIGGER/NONE -> FILLED/BLOCKED -> EXIT` independently. The chart's Strategy Tester is **not** a multi-stock portfolio backtest.
5. Compare original vs proposed only after all cases have been logged, preferably with day-block uncertainty and market-date-matched comparisons.

**Safety:** no frozen model, production pipeline or original journal files were modified. Pine code is unchanged from source-aware v4 and remains uncompiled in TradingView within this session.
